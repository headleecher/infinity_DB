/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1_3306
Source Server Version : 50045
Source Host           : 127.0.0.1:3306
Source Database       : characters

Target Server Type    : MYSQL
Target Server Version : 50045
File Encoding         : 65001

Date: 2011-01-03 05:46:28
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `account_data`
-- ----------------------------
DROP TABLE IF EXISTS `account_data`;
CREATE TABLE `account_data` (
  `account` int(11) unsigned NOT NULL default '0',
  `type` int(11) unsigned NOT NULL default '0',
  `time` bigint(11) unsigned NOT NULL default '0',
  `data` longblob NOT NULL,
  PRIMARY KEY  (`account`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of account_data
-- ----------------------------
INSERT INTO `account_data` VALUES ('5', '0', '1291952975', 0x534554207363726970744572726F7273202231220A53455420666C61676765645475746F7269616C7320227601220A5345542063616D65726144697374616E63654D6178466163746F72202232220A5345542074616C656E744672616D6553686F776E202231220A);
INSERT INTO `account_data` VALUES ('5', '4', '1289771944', 0x4D4143524F2032202264616D22204162696C6974795F43726561747572655F446973656173655F30350D0A2E64616D616765203130303030300D0A454E440D0A4D4143524F2031202264696522204162696C6974795F43726561747572655F446973656173655F30320D0A2E6469650D0A454E440D0A4D4143524F20352022666C7922204162696C6974795F43726561747572655F4375727365645F30330D0A2E676D20666C79206F6E0D0A454E440D0A4D4143524F20342022696D6D6F7274616C22204162696C6974795F416D627573680D0A2E6D6F646966792068702039393939393939393939393939393939390D0A454E440D0A4D4143524F20332022737070656422204162696C6974795F43726561747572655F446973656173655F30330D0A2E6D6F6469667920737065656420390D0A454E440D0A);
INSERT INTO `account_data` VALUES ('6', '0', '1293995888', 0x534554207363726970744572726F7273202231220A53455420666C61676765645475746F7269616C732022760123234D23232523232623232423233A23232B23234523232823232A23235A23233823235B23233B23234B23232923235C23232D23233F23235E23235D23233723233123233C23234123234223232E23232F23234023233923234923234323232C23234F232344232346232330232333232336232335232334220A534554206C6F636B416374696F6E42617273202230220A5345542063616D65726156696577202235220A5345542063616D65726144697374616E63654D6178466163746F72202231220A);

-- ----------------------------
-- Table structure for `anticheat_config`
-- ----------------------------
DROP TABLE IF EXISTS `anticheat_config`;
CREATE TABLE `anticheat_config` (
  `checktype` mediumint(8) unsigned NOT NULL COMMENT 'Type of check',
  `description` varchar(255) default NULL,
  `check_period` int(11) unsigned NOT NULL default '0' COMMENT 'Time period of check, in ms, 0 - always',
  `alarmscount` int(11) unsigned NOT NULL default '1' COMMENT 'Count of alarms before action',
  `disableoperation` tinyint(3) unsigned NOT NULL default '0' COMMENT 'Anticheat disable operations in main core code after check fail',
  `messagenum` int(11) NOT NULL default '0' COMMENT 'Number of system message',
  `intparam1` mediumint(8) NOT NULL default '0' COMMENT 'Int parameter 1',
  `intparam2` mediumint(8) NOT NULL default '0' COMMENT 'Int parameter 2',
  `floatparam1` float NOT NULL default '0' COMMENT 'Float parameter 1',
  `floatparam2` float NOT NULL default '0' COMMENT 'Float parameter 2',
  `action1` mediumint(8) NOT NULL default '0' COMMENT 'Action 1',
  `actionparam1` mediumint(8) NOT NULL default '0' COMMENT 'Action parameter 1',
  `action2` mediumint(8) NOT NULL default '0' COMMENT 'Action 1',
  `actionparam2` mediumint(8) NOT NULL default '0' COMMENT 'Action parameter 1',
  PRIMARY KEY  (`checktype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 PACK_KEYS=0 COMMENT='Anticheat configuration';

-- ----------------------------
-- Records of anticheat_config
-- ----------------------------
INSERT INTO `anticheat_config` VALUES ('0', 'Null check', '0', '1', '0', '11000', '0', '0', '0', '0', '1', '0', '0', '0');
INSERT INTO `anticheat_config` VALUES ('1', 'Movement cheat', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('2', 'Spell cheat', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('3', 'Quest cheat', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('4', 'Transport cheat', '0', '3', '0', '11000', '0', '0', '60', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('5', 'Damage cheat', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('101', 'Speed hack', '500', '5', '0', '11000', '10000', '0', '0.0012', '0', '2', '1', '6', '20000');
INSERT INTO `anticheat_config` VALUES ('102', 'Fly hack', '500', '5', '0', '11000', '20000', '0', '10', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('103', 'Wall climb hack', '500', '2', '0', '11000', '10000', '0', '2.3', '2.37', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('104', 'Waterwalking hack', '1000', '3', '0', '11000', '20000', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('105', 'Teleport to plane hack', '500', '1', '0', '11000', '0', '0', '0.0001', '0.1', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('106', 'AirJump hack', '500', '3', '0', '11000', '30000', '0', '10', '25', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('107', 'Teleport hack', '0', '1', '0', '11000', '0', '0', '50', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('108', 'Fall hack', '0', '3', '0', '11000', '10000', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('201', 'Spell invalid', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('202', 'Spellcast in dead state', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('203', 'Spell not valid for player', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('204', 'Spell not in player book', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('501', 'Spell damage hack', '0', '1', '0', '11000', '0', '50000', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('502', 'Melee damage hack', '0', '1', '0', '11000', '0', '50000', '0', '0', '2', '1', '0', '0');

-- ----------------------------
-- Table structure for `anticheat_log`
-- ----------------------------
DROP TABLE IF EXISTS `anticheat_log`;
CREATE TABLE `anticheat_log` (
  `playername` varchar(32) NOT NULL,
  `checktype` mediumint(8) unsigned NOT NULL,
  `alarm_time` datetime NOT NULL,
  `reason` varchar(255) NOT NULL default 'Unknown',
  `guid` int(11) unsigned NOT NULL,
  `action1` mediumint(8) NOT NULL default '0',
  `action2` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`checktype`,`alarm_time`,`guid`),
  KEY `idx_Player` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Anticheat log table';

-- ----------------------------
-- Records of anticheat_log
-- ----------------------------
INSERT INTO `anticheat_log` VALUES ('Franklin', '106', '2010-11-26 22:19:43', 'AirJump hack Map Z = 64.112885, player Z = 108.896027, opcode MSG_MOVE_SET_FACING', '6', '2', '0');

-- ----------------------------
-- Table structure for `arena_team`
-- ----------------------------
DROP TABLE IF EXISTS `arena_team`;
CREATE TABLE `arena_team` (
  `arenateamid` int(10) unsigned NOT NULL default '0',
  `name` char(255) NOT NULL,
  `captainguid` int(10) unsigned NOT NULL default '0',
  `type` tinyint(3) unsigned NOT NULL default '0',
  `BackgroundColor` int(10) unsigned NOT NULL default '0',
  `EmblemStyle` int(10) unsigned NOT NULL default '0',
  `EmblemColor` int(10) unsigned NOT NULL default '0',
  `BorderStyle` int(10) unsigned NOT NULL default '0',
  `BorderColor` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`arenateamid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of arena_team
-- ----------------------------

-- ----------------------------
-- Table structure for `arena_team_member`
-- ----------------------------
DROP TABLE IF EXISTS `arena_team_member`;
CREATE TABLE `arena_team_member` (
  `arenateamid` int(10) unsigned NOT NULL default '0',
  `guid` int(10) unsigned NOT NULL default '0',
  `played_week` int(10) unsigned NOT NULL default '0',
  `wons_week` int(10) unsigned NOT NULL default '0',
  `played_season` int(10) unsigned NOT NULL default '0',
  `wons_season` int(10) unsigned NOT NULL default '0',
  `personal_rating` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`arenateamid`,`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of arena_team_member
-- ----------------------------

-- ----------------------------
-- Table structure for `arena_team_stats`
-- ----------------------------
DROP TABLE IF EXISTS `arena_team_stats`;
CREATE TABLE `arena_team_stats` (
  `arenateamid` int(10) unsigned NOT NULL default '0',
  `rating` int(10) unsigned NOT NULL default '0',
  `games_week` int(10) unsigned NOT NULL default '0',
  `wins_week` int(10) unsigned NOT NULL default '0',
  `games_season` int(10) unsigned NOT NULL default '0',
  `wins_season` int(10) unsigned NOT NULL default '0',
  `rank` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`arenateamid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of arena_team_stats
-- ----------------------------

-- ----------------------------
-- Table structure for `armory_character_stats`
-- ----------------------------
DROP TABLE IF EXISTS `armory_character_stats`;
CREATE TABLE `armory_character_stats` (
  `guid` int(11) NOT NULL,
  `data` longtext NOT NULL,
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='World of Warcraft Armory table';

-- ----------------------------
-- Records of armory_character_stats
-- ----------------------------

-- ----------------------------
-- Table structure for `armory_game_chart`
-- ----------------------------
DROP TABLE IF EXISTS `armory_game_chart`;
CREATE TABLE `armory_game_chart` (
  `gameid` int(11) NOT NULL,
  `teamid` int(11) NOT NULL,
  `guid` int(11) NOT NULL,
  `changeType` int(11) NOT NULL,
  `ratingChange` int(11) NOT NULL,
  `teamRating` int(11) NOT NULL,
  `damageDone` int(11) NOT NULL,
  `deaths` int(11) NOT NULL,
  `healingDone` int(11) NOT NULL,
  `damageTaken` int(11) NOT NULL,
  `healingTaken` int(11) NOT NULL,
  `killingBlows` int(11) NOT NULL,
  `mapId` int(11) NOT NULL,
  `start` int(11) NOT NULL,
  `end` int(11) NOT NULL,
  PRIMARY KEY  (`gameid`,`teamid`,`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='WoWArmory Game Chart';

-- ----------------------------
-- Records of armory_game_chart
-- ----------------------------

-- ----------------------------
-- Table structure for `auction`
-- ----------------------------
DROP TABLE IF EXISTS `auction`;
CREATE TABLE `auction` (
  `id` int(11) unsigned NOT NULL default '0',
  `houseid` int(11) unsigned NOT NULL default '0',
  `itemguid` int(11) unsigned NOT NULL default '0',
  `item_template` int(11) unsigned NOT NULL default '0' COMMENT 'Item Identifier',
  `itemowner` int(11) unsigned NOT NULL default '0',
  `buyoutprice` int(11) NOT NULL default '0',
  `time` bigint(40) NOT NULL default '0',
  `buyguid` int(11) unsigned NOT NULL default '0',
  `lastbid` int(11) NOT NULL default '0',
  `startbid` int(11) NOT NULL default '0',
  `deposit` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `item_guid` (`itemguid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of auction
-- ----------------------------
INSERT INTO `auction` VALUES ('20819', '7', '38665', '1959', '2', '57876', '1294068038', '0', '0', '54982', '0');
INSERT INTO `auction` VALUES ('22143', '6', '40005', '36781', '2', '31680', '1294095984', '0', '0', '28828', '0');
INSERT INTO `auction` VALUES ('21144', '6', '38992', '10514', '2', '5460', '1294053698', '0', '0', '4313', '0');
INSERT INTO `auction` VALUES ('20110', '7', '37956', '31564', '2', '3227077', '1294082378', '0', '0', '2968910', '0');
INSERT INTO `auction` VALUES ('22624', '2', '40486', '9719', '2', '404250', '1294080068', '0', '0', '339570', '0');
INSERT INTO `auction` VALUES ('21428', '7', '39276', '4387', '2', '20048', '1294053698', '0', '0', '18845', '0');
INSERT INTO `auction` VALUES ('20252', '7', '38098', '9719', '2', '392000', '1294060778', '0', '0', '317520', '0');
INSERT INTO `auction` VALUES ('22329', '7', '40191', '36056', '2', '1761035', '1294103184', '0', '0', '1761035', '0');
INSERT INTO `auction` VALUES ('22687', '6', '40549', '25250', '2', '2444840', '1294126868', '0', '0', '2175907', '0');
INSERT INTO `auction` VALUES ('19939', '6', '37785', '13915', '2', '1070', '1294075178', '0', '0', '1070', '0');
INSERT INTO `auction` VALUES ('21869', '2', '39731', '3008', '2', '381', '1294131984', '0', '0', '354', '0');
INSERT INTO `auction` VALUES ('22233', '7', '40095', '2066', '2', '791', '1294124784', '0', '0', '719', '0');
INSERT INTO `auction` VALUES ('21427', '7', '39275', '4632', '2', '2184', '1294057298', '0', '0', '2140', '0');
INSERT INTO `auction` VALUES ('21426', '7', '39274', '41119', '2', '34850', '1294064498', '0', '0', '33107', '0');
INSERT INTO `auction` VALUES ('22688', '6', '40550', '30736', '2', '8635889', '1294130468', '0', '0', '7685941', '0');
INSERT INTO `auction` VALUES ('20930', '2', '38778', '28495', '2', '647009', '1294064498', '0', '0', '640538', '0');
INSERT INTO `auction` VALUES ('22722', '7', '40584', '41119', '2', '29400', '1294137668', '0', '0', '24402', '0');
INSERT INTO `auction` VALUES ('19800', '2', '37646', '9378', '2', '809715', '1294053578', '0', '0', '712549', '0');
INSERT INTO `auction` VALUES ('20072', '7', '37918', '2725', '2', '22950', '1294082378', '0', '0', '19966', '0');
INSERT INTO `auction` VALUES ('20446', '2', '38292', '24723', '2', '1113969', '1294075238', '0', '0', '958013', '0');
INSERT INTO `auction` VALUES ('22430', '2', '40292', '36569', '2', '5655468', '1294078044', '0', '0', '5655468', '0');
INSERT INTO `auction` VALUES ('22007', '6', '39869', '3008', '2', '358', '1294095984', '0', '0', '358', '0');
INSERT INTO `auction` VALUES ('22285', '7', '40147', '17964', '2', '209916', '1294117584', '0', '0', '178428', '0');
INSERT INTO `auction` VALUES ('20505', '6', '38351', '3323', '2', '161', '1294075238', '0', '0', '156', '0');
INSERT INTO `auction` VALUES ('20800', '7', '38646', '9719', '2', '431000', '1294071638', '0', '0', '323250', '0');
INSERT INTO `auction` VALUES ('22615', '7', '40477', '13422', '2', '1081', '1294103244', '0', '0', '962', '0');
INSERT INTO `auction` VALUES ('21292', '7', '39140', '36284', '2', '2667206', '1294057298', '0', '0', '2480501', '0');
INSERT INTO `auction` VALUES ('21691', '7', '39540', '4044', '2', '215457', '1294078958', '0', '0', '185293', '0');
INSERT INTO `auction` VALUES ('21930', '2', '39792', '5635', '2', '316', '1294085184', '0', '0', '316', '0');
INSERT INTO `auction` VALUES ('21700', '7', '39549', '21882', '2', '62800', '1294082558', '0', '0', '48356', '0');
INSERT INTO `auction` VALUES ('21598', '6', '39447', '36609', '2', '6498817', '1294082558', '0', '0', '5394018', '0');
INSERT INTO `auction` VALUES ('22142', '6', '40004', '1300', '2', '86869', '1294088784', '0', '0', '74707', '0');
INSERT INTO `auction` VALUES ('20747', '7', '38593', '16651', '2', '600', '1294068038', '0', '0', '438', '0');
INSERT INTO `auction` VALUES ('22187', '7', '40049', '1457', '2', '118135', '1294088784', '0', '0', '98052', '0');
INSERT INTO `auction` VALUES ('20910', '2', '38758', '24685', '2', '957233', '1294071698', '0', '0', '842365', '0');
INSERT INTO `auction` VALUES ('22704', '6', '40566', '5635', '2', '934', '1294112468', '0', '0', '653', '0');
INSERT INTO `auction` VALUES ('21995', '6', '39857', '36039', '2', '1269298', '1294081584', '0', '0', '1078903', '0');
INSERT INTO `auction` VALUES ('20986', '2', '38834', '10514', '2', '63720', '1294068098', '0', '0', '56710', '0');
INSERT INTO `auction` VALUES ('22494', '6', '40356', '9061', '2', '12950', '1294135644', '0', '0', '12302', '0');
INSERT INTO `auction` VALUES ('19685', '2', '37531', '2824', '2', '5527121', '1294060778', '0', '0', '5306036', '0');
INSERT INTO `auction` VALUES ('20098', '7', '37944', '25187', '2', '3931040', '1294060778', '0', '0', '3498625', '0');
INSERT INTO `auction` VALUES ('20743', '7', '38589', '14368', '2', '3875', '1294068038', '0', '0', '3371', '0');
INSERT INTO `auction` VALUES ('21919', '2', '39781', '18588', '2', '25648', '1294095984', '0', '0', '25648', '0');
INSERT INTO `auction` VALUES ('20472', '6', '38318', '9253', '2', '442', '1294057238', '0', '0', '331', '0');
INSERT INTO `auction` VALUES ('20188', '7', '38034', '5635', '2', '1389', '1294071578', '0', '0', '1055', '0');
INSERT INTO `auction` VALUES ('22451', '6', '40313', '3164', '2', '3025', '1294114044', '0', '0', '2813', '0');
INSERT INTO `auction` VALUES ('21757', '2', '39619', '13905', '2', '248', '1294081584', '0', '0', '235', '0');
INSERT INTO `auction` VALUES ('20068', '7', '37914', '1659', '2', '125204', '1294064378', '0', '0', '120195', '0');
INSERT INTO `auction` VALUES ('20292', '2', '38138', '19441', '2', '26160', '1294078838', '0', '0', '21974', '0');
INSERT INTO `auction` VALUES ('19727', '2', '37573', '36499', '2', '7253352', '1294053578', '0', '0', '6237882', '0');
INSERT INTO `auction` VALUES ('21157', '6', '39005', '6359', '2', '298', '1294082498', '0', '0', '250', '0');
INSERT INTO `auction` VALUES ('21769', '2', '39631', '9719', '2', '337250', '1294095984', '0', '0', '273172', '0');
INSERT INTO `auction` VALUES ('22006', '6', '39868', '13904', '2', '240', '1294117584', '0', '0', '172', '0');
INSERT INTO `auction` VALUES ('22719', '7', '40581', '36262', '2', '1618024', '1294083668', '0', '0', '1520942', '0');
INSERT INTO `auction` VALUES ('21526', '2', '39375', '10505', '2', '4950', '1294075358', '0', '0', '3910', '0');
INSERT INTO `auction` VALUES ('21237', '6', '39085', '24889', '2', '963501', '1294082498', '0', '0', '799705', '0');
INSERT INTO `auction` VALUES ('21069', '6', '38917', '2265', '2', '22757', '1294075298', '0', '0', '18205', '0');
INSERT INTO `auction` VALUES ('19724', '2', '37570', '9276', '2', '964', '1294082378', '0', '0', '867', '0');
INSERT INTO `auction` VALUES ('20389', '2', '38235', '9719', '2', '425000', '1294053638', '0', '0', '318750', '0');
INSERT INTO `auction` VALUES ('20723', '7', '38569', '3331', '2', '780', '1294057238', '0', '0', '717', '0');
INSERT INTO `auction` VALUES ('21256', '6', '39104', '31264', '2', '27922', '1294053698', '0', '0', '22616', '0');
INSERT INTO `auction` VALUES ('20546', '6', '38392', '45909', '2', '14912', '1294071638', '0', '0', '11034', '0');
INSERT INTO `auction` VALUES ('22089', '6', '39951', '9719', '2', '405500', '1294110384', '0', '0', '320345', '0');
INSERT INTO `auction` VALUES ('22017', '6', '39879', '9719', '2', '319000', '1294128384', '0', '0', '296670', '0');
INSERT INTO `auction` VALUES ('21969', '6', '39831', '4611', '2', '2912', '1294085184', '0', '0', '2416', '0');
INSERT INTO `auction` VALUES ('20228', '7', '38074', '9719', '2', '396000', '1294064378', '0', '0', '368280', '0');
INSERT INTO `auction` VALUES ('22241', '7', '40103', '1717', '2', '256581', '1294085184', '0', '0', '200133', '0');
INSERT INTO `auction` VALUES ('21621', '6', '39470', '6358', '2', '541', '1294068158', '0', '0', '476', '0');
INSERT INTO `auction` VALUES ('22030', '6', '39892', '41119', '2', '38340', '1294103184', '0', '0', '37189', '0');
INSERT INTO `auction` VALUES ('20436', '2', '38282', '13887', '2', '480', '1294064438', '0', '0', '422', '0');
INSERT INTO `auction` VALUES ('20023', '6', '37869', '8152', '2', '36300', '1294071578', '0', '0', '32670', '0');
INSERT INTO `auction` VALUES ('20237', '7', '38083', '35979', '2', '961562', '1294082378', '0', '0', '884637', '0');
INSERT INTO `auction` VALUES ('20903', '2', '38751', '36555', '2', '8069290', '1294071698', '0', '0', '7343053', '0');
INSERT INTO `auction` VALUES ('21776', '2', '39638', '20709', '2', '3808', '1294113984', '0', '0', '3808', '0');
INSERT INTO `auction` VALUES ('19806', '2', '37652', '44157', '2', '19875', '1294082378', '0', '0', '19676', '0');
INSERT INTO `auction` VALUES ('20603', '6', '38449', '9719', '2', '351500', '1294053638', '0', '0', '277685', '0');
INSERT INTO `auction` VALUES ('22043', '6', '39905', '44696', '2', '2494506', '1294081584', '0', '0', '2394725', '0');
INSERT INTO `auction` VALUES ('22237', '7', '40099', '44677', '2', '5783092', '1294135584', '0', '0', '5493937', '0');
INSERT INTO `auction` VALUES ('21293', '7', '39141', '20408', '2', '104317', '1294057298', '0', '0', '92842', '0');
INSERT INTO `auction` VALUES ('20227', '7', '38073', '9719', '2', '360500', '1294057178', '0', '0', '346080', '0');
INSERT INTO `auction` VALUES ('19718', '2', '37564', '16648', '2', '420', '1294078778', '0', '0', '327', '0');
INSERT INTO `auction` VALUES ('22013', '6', '39875', '5524', '2', '2629', '1294110384', '0', '0', '2418', '0');
INSERT INTO `auction` VALUES ('22491', '6', '40353', '36154', '2', '1232779', '1294135644', '0', '0', '998550', '0');
INSERT INTO `auction` VALUES ('19717', '2', '37563', '1475', '2', '732', '1294071578', '0', '0', '527', '0');
INSERT INTO `auction` VALUES ('22145', '6', '40007', '2084', '2', '398815', '1294085184', '0', '0', '370897', '0');
INSERT INTO `auction` VALUES ('20855', '7', '38701', '4402', '2', '6450', '1294053638', '0', '0', '5031', '0');
INSERT INTO `auction` VALUES ('20858', '7', '38704', '24892', '2', '1523295', '1294075238', '0', '0', '1401431', '0');
INSERT INTO `auction` VALUES ('21712', '7', '39561', '5755', '2', '202871', '1294068158', '0', '0', '170411', '0');
INSERT INTO `auction` VALUES ('20854', '7', '38700', '4388', '2', '9280', '1294053638', '0', '0', '7609', '0');
INSERT INTO `auction` VALUES ('22425', '2', '40287', '36172', '2', '2265883', '1294081644', '0', '0', '2061953', '0');
INSERT INTO `auction` VALUES ('20736', '7', '38582', '15968', '2', '431082', '1294057238', '0', '0', '400906', '0');
INSERT INTO `auction` VALUES ('22200', '7', '40062', '5109', '2', '1941', '1294081584', '0', '0', '1785', '0');
INSERT INTO `auction` VALUES ('22045', '6', '39907', '9719', '2', '368000', '1294113984', '0', '0', '364320', '0');
INSERT INTO `auction` VALUES ('20988', '2', '38836', '37147', '2', '3060', '1294071698', '0', '0', '2478', '0');
INSERT INTO `auction` VALUES ('19680', '2', '37526', '30736', '2', '6223239', '1294078778', '0', '0', '5227520', '0');
INSERT INTO `auction` VALUES ('21291', '7', '39139', '4387', '2', '22400', '1294078898', '0', '0', '19264', '0');
INSERT INTO `auction` VALUES ('22173', '7', '40035', '45909', '2', '32256', '1294113984', '0', '0', '26127', '0');
INSERT INTO `auction` VALUES ('20335', '2', '38181', '1318', '2', '250524', '1294057238', '0', '0', '207934', '0');
INSERT INTO `auction` VALUES ('22607', '7', '40469', '36169', '2', '2361890', '1294114044', '0', '0', '2125701', '0');
INSERT INTO `auction` VALUES ('22721', '7', '40583', '30723', '2', '19519342', '1294130468', '0', '0', '16591440', '0');
INSERT INTO `auction` VALUES ('21597', '6', '39446', '25116', '2', '3792761', '1294078958', '0', '0', '3641050', '0');
INSERT INTO `auction` VALUES ('20868', '2', '38716', '10505', '2', '13600', '1294068098', '0', '0', '13328', '0');
INSERT INTO `auction` VALUES ('21829', '2', '39691', '20664', '2', '412505', '1294095984', '0', '0', '334129', '0');
INSERT INTO `auction` VALUES ('19734', '2', '37580', '1288', '2', '4262', '1294067978', '0', '0', '3665', '0');
INSERT INTO `auction` VALUES ('22701', '6', '40563', '24711', '2', '1684928', '1294101668', '0', '0', '1651229', '0');
INSERT INTO `auction` VALUES ('20549', '6', '38395', '9719', '2', '383750', '1294068038', '0', '0', '299325', '0');
INSERT INTO `auction` VALUES ('21575', '6', '39424', '27515', '2', '12720', '1294082558', '0', '0', '10176', '0');
INSERT INTO `auction` VALUES ('22056', '6', '39918', '1722', '2', '1384732', '1294106784', '0', '0', '1232411', '0');
INSERT INTO `auction` VALUES ('19839', '2', '37685', '18711', '2', '732138', '1294053578', '0', '0', '688209', '0');
INSERT INTO `auction` VALUES ('20432', '2', '38278', '10560', '2', '48800', '1294064438', '0', '0', '34160', '0');
INSERT INTO `auction` VALUES ('21886', '2', '39748', '9719', '2', '351750', '1294124784', '0', '0', '334162', '0');
INSERT INTO `auction` VALUES ('22401', '2', '40263', '5524', '2', '2040', '1294103244', '0', '0', '1917', '0');
INSERT INTO `auction` VALUES ('22281', '7', '40143', '12804', '2', '56640', '1294077984', '0', '0', '48144', '0');
INSERT INTO `auction` VALUES ('19843', '2', '37689', '24836', '2', '1076018', '1294053578', '0', '0', '946895', '0');
INSERT INTO `auction` VALUES ('22165', '7', '40027', '22526', '2', '197120', '1294106784', '0', '0', '195148', '0');
INSERT INTO `auction` VALUES ('22168', '7', '40030', '4388', '2', '6680', '1294110384', '0', '0', '5878', '0');
INSERT INTO `auction` VALUES ('21521', '2', '39370', '6360', '2', '135631', '1294082558', '0', '0', '111217', '0');
INSERT INTO `auction` VALUES ('21756', '2', '39618', '30809', '2', '239072', '1294135584', '0', '0', '222336', '0');
INSERT INTO `auction` VALUES ('20550', '6', '38396', '9719', '2', '361500', '1294057238', '0', '0', '307275', '0');
INSERT INTO `auction` VALUES ('21236', '6', '39084', '36262', '2', '1545978', '1294060898', '0', '0', '1345000', '0');
INSERT INTO `auction` VALUES ('20740', '7', '38586', '35654', '2', '2037353', '1294071638', '0', '0', '1548388', '0');
INSERT INTO `auction` VALUES ('20515', '6', '38361', '9719', '2', '326000', '1294064438', '0', '0', '280360', '0');
INSERT INTO `auction` VALUES ('21765', '2', '39627', '23354', '2', '118', '1294077984', '0', '0', '109', '0');
INSERT INTO `auction` VALUES ('22053', '6', '39915', '18296', '2', '1064620', '1294113984', '0', '0', '1043327', '0');
INSERT INTO `auction` VALUES ('21370', '7', '39218', '814', '2', '1992', '1294082498', '0', '0', '1533', '0');
INSERT INTO `auction` VALUES ('22166', '7', '40028', '2879', '2', '202240', '1294124784', '0', '0', '182016', '0');
INSERT INTO `auction` VALUES ('21887', '2', '39749', '826', '2', '30028', '1294131984', '0', '0', '26424', '0');
INSERT INTO `auction` VALUES ('22400', '2', '40262', '10561', '2', '62800', '1294085244', '0', '0', '57148', '0');
INSERT INTO `auction` VALUES ('22355', '2', '40217', '14901', '2', '301842', '1294096044', '0', '0', '274676', '0');
INSERT INTO `auction` VALUES ('20784', '7', '38630', '44147', '2', '121000', '1294064438', '0', '0', '104060', '0');
INSERT INTO `auction` VALUES ('22340', '7', '40202', '18588', '2', '3408', '1294128384', '0', '0', '3203', '0');
INSERT INTO `auction` VALUES ('21903', '2', '39765', '36267', '2', '1627634', '1294135584', '0', '0', '1367212', '0');
INSERT INTO `auction` VALUES ('22019', '6', '39881', '6364', '2', '3150', '1294128384', '0', '0', '2677', '0');
INSERT INTO `auction` VALUES ('20270', '2', '38116', '22528', '2', '25856', '1294082438', '0', '0', '18357', '0');
INSERT INTO `auction` VALUES ('19923', '6', '37769', '5523', '2', '1310', '1294071578', '0', '0', '1074', '0');
INSERT INTO `auction` VALUES ('21363', '7', '39211', '12804', '2', '71040', '1294053698', '0', '0', '57542', '0');
INSERT INTO `auction` VALUES ('21752', '2', '39614', '37756', '2', '2166336', '1294117584', '0', '0', '1971365', '0');
INSERT INTO `auction` VALUES ('22191', '7', '40053', '36498', '2', '4588410', '1294131984', '0', '0', '4129569', '0');
INSERT INTO `auction` VALUES ('21209', '6', '39057', '3164', '2', '2685', '1294068098', '0', '0', '2416', '0');
INSERT INTO `auction` VALUES ('21713', '7', '39562', '24677', '2', '980289', '1294082558', '0', '0', '980289', '0');
INSERT INTO `auction` VALUES ('20313', '2', '38159', '44682', '2', '3264894', '1294060838', '0', '0', '3166947', '0');
INSERT INTO `auction` VALUES ('21335', '7', '39183', '40195', '2', '86580', '1294075298', '0', '0', '66666', '0');
INSERT INTO `auction` VALUES ('22325', '7', '40187', '10561', '2', '9000', '1294124784', '0', '0', '8550', '0');
INSERT INTO `auction` VALUES ('21538', '2', '39387', '24711', '2', '1467896', '1294053758', '0', '0', '1174316', '0');
INSERT INTO `auction` VALUES ('21845', '2', '39707', '9719', '2', '363000', '1294095984', '0', '0', '297660', '0');
INSERT INTO `auction` VALUES ('19669', '2', '37515', '9719', '2', '392750', '1294075178', '0', '0', '306345', '0');
INSERT INTO `auction` VALUES ('22545', '7', '40407', '10135', '2', '752121', '1294096044', '0', '0', '729557', '0');
INSERT INTO `auction` VALUES ('20865', '2', '38713', '36283', '2', '1975429', '1294078898', '0', '0', '1955674', '0');
INSERT INTO `auction` VALUES ('22148', '6', '40010', '40195', '2', '81900', '1294128384', '0', '0', '75348', '0');
INSERT INTO `auction` VALUES ('22488', '6', '40350', '2168', '2', '24617', '1294092444', '0', '0', '20678', '0');
INSERT INTO `auction` VALUES ('20510', '6', '38356', '36149', '2', '2484078', '1294064438', '0', '0', '2210829', '0');
INSERT INTO `auction` VALUES ('19733', '2', '37579', '9262', '2', '34240', '1294071578', '0', '0', '32870', '0');
INSERT INTO `auction` VALUES ('21250', '6', '39098', '1475', '2', '1115', '1294082498', '0', '0', '1014', '0');
INSERT INTO `auction` VALUES ('22557', '7', '40419', '8152', '2', '57600', '1294096044', '0', '0', '54720', '0');
INSERT INTO `auction` VALUES ('19912', '6', '37758', '10623', '2', '1570273', '1294075178', '0', '0', '1570273', '0');
INSERT INTO `auction` VALUES ('22533', '6', '40395', '24476', '2', '14016', '1294096044', '0', '0', '12053', '0');
INSERT INTO `auction` VALUES ('20551', '6', '38397', '9719', '2', '425000', '1294075238', '0', '0', '399500', '0');
INSERT INTO `auction` VALUES ('20159', '7', '38005', '9719', '2', '318250', '1294071578', '0', '0', '238687', '0');
INSERT INTO `auction` VALUES ('21051', '2', '38899', '27515', '2', '16600', '1294071698', '0', '0', '12118', '0');
INSERT INTO `auction` VALUES ('21862', '2', '39724', '832', '2', '8434', '1294103184', '0', '0', '7253', '0');
INSERT INTO `auction` VALUES ('20471', '6', '38317', '24476', '2', '13376', '1294082438', '0', '0', '12038', '0');
INSERT INTO `auction` VALUES ('19884', '6', '37730', '3075', '2', '2093750', '1294075178', '0', '0', '1695937', '0');
INSERT INTO `auction` VALUES ('20864', '2', '38712', '36260', '2', '2278500', '1294068098', '0', '0', '2210145', '0');
INSERT INTO `auction` VALUES ('22169', '7', '40031', '18512', '2', '95040', '1294085184', '0', '0', '73180', '0');
INSERT INTO `auction` VALUES ('22485', '6', '40347', '10559', '2', '33750', '1294110444', '0', '0', '26325', '0');
INSERT INTO `auction` VALUES ('21665', '7', '39514', '27515', '2', '6960', '1294075358', '0', '0', '6751', '0');
INSERT INTO `auction` VALUES ('22490', '6', '40352', '1461', '2', '181723', '1294088844', '0', '0', '179905', '0');
INSERT INTO `auction` VALUES ('21750', '7', '39599', '25320', '2', '3681326', '1294082558', '0', '0', '3092313', '0');
INSERT INTO `auction` VALUES ('19670', '2', '37516', '13876', '2', '216', '1294060778', '0', '0', '162', '0');
INSERT INTO `auction` VALUES ('22064', '6', '39926', '6647', '2', '248', '1294095984', '0', '0', '208', '0');
INSERT INTO `auction` VALUES ('21008', '2', '38856', '36037', '2', '2087184', '1294075298', '0', '0', '1982824', '0');
INSERT INTO `auction` VALUES ('22327', '7', '40189', '37145', '2', '19170', '1294121184', '0', '0', '16486', '0');
INSERT INTO `auction` VALUES ('21933', '2', '39795', '5180', '2', '134542', '1294099584', '0', '0', '122433', '0');
INSERT INTO `auction` VALUES ('22416', '2', '40278', '44475', '2', '135', '1294096044', '0', '0', '110', '0');
INSERT INTO `auction` VALUES ('21666', '7', '39515', '45909', '2', '10496', '1294082558', '0', '0', '9761', '0');
INSERT INTO `auction` VALUES ('21384', '7', '39232', '5635', '2', '1706', '1294057298', '0', '0', '1450', '0');
INSERT INTO `auction` VALUES ('21753', '2', '39615', '36499', '2', '5189523', '1294103184', '0', '0', '4203513', '0');
INSERT INTO `auction` VALUES ('21801', '2', '39663', '9486', '2', '377820', '1294103184', '0', '0', '336259', '0');
INSERT INTO `auction` VALUES ('22577', '7', '40439', '37160', '2', '5250', '1294078044', '0', '0', '4725', '0');
INSERT INTO `auction` VALUES ('20731', '7', '38577', '6358', '2', '357', '1294064438', '0', '0', '264', '0');
INSERT INTO `auction` VALUES ('22578', '7', '40440', '5637', '2', '495', '1294128444', '0', '0', '440', '0');
INSERT INTO `auction` VALUES ('20906', '2', '38754', '27513', '2', '128', '1294053698', '0', '0', '117', '0');
INSERT INTO `auction` VALUES ('21748', '7', '39597', '36271', '2', '2907017', '1294075358', '0', '0', '2848876', '0');
INSERT INTO `auction` VALUES ('19930', '6', '37776', '44683', '2', '2584047', '1294071578', '0', '0', '2532366', '0');
INSERT INTO `auction` VALUES ('22371', '2', '40233', '36668', '2', '4386938', '1294088844', '0', '0', '4343068', '0');
INSERT INTO `auction` VALUES ('21754', '2', '39616', '1315', '2', '2128880', '1294088784', '0', '0', '1830836', '0');
INSERT INTO `auction` VALUES ('22048', '6', '39910', '9719', '2', '393250', '1294128384', '0', '0', '349992', '0');
INSERT INTO `auction` VALUES ('22063', '6', '39925', '44673', '2', '2707010', '1294077984', '0', '0', '2571659', '0');
INSERT INTO `auction` VALUES ('22326', '7', '40188', '31268', '2', '61691', '1294124784', '0', '0', '53671', '0');
INSERT INTO `auction` VALUES ('21481', '2', '39330', '28495', '2', '698054', '1294053758', '0', '0', '621268', '0');
INSERT INTO `auction` VALUES ('21800', '2', '39662', '1913', '2', '1701', '1294088784', '0', '0', '1224', '0');
INSERT INTO `auction` VALUES ('21830', '2', '39692', '9719', '2', '390500', '1294099584', '0', '0', '382690', '0');
INSERT INTO `auction` VALUES ('22023', '6', '39885', '31254', '2', '1695050', '1294092384', '0', '0', '1610297', '0');
INSERT INTO `auction` VALUES ('22024', '6', '39886', '36978', '2', '2928572', '1294128384', '0', '0', '2430714', '0');
INSERT INTO `auction` VALUES ('20756', '7', '38602', '9719', '2', '357750', '1294060838', '0', '0', '339862', '0');
INSERT INTO `auction` VALUES ('22532', '6', '40394', '7973', '2', '2064', '1294135644', '0', '0', '1733', '0');
INSERT INTO `auction` VALUES ('22110', '6', '39972', '10627', '2', '2047326', '1294103184', '0', '0', '1678807', '0');
INSERT INTO `auction` VALUES ('22144', '6', '40006', '36050', '2', '920552', '1294113984', '0', '0', '773263', '0');
INSERT INTO `auction` VALUES ('20660', '6', '38506', '9719', '2', '373000', '1294060838', '0', '0', '279750', '0');
INSERT INTO `auction` VALUES ('22626', '2', '40488', '14553', '2', '2472850', '1294080068', '0', '0', '2225565', '0');
INSERT INTO `auction` VALUES ('22522', '6', '40384', '4388', '2', '9840', '1294096044', '0', '0', '8560', '0');
INSERT INTO `auction` VALUES ('20758', '7', '38604', '9719', '2', '429000', '1294075238', '0', '0', '326040', '0');
INSERT INTO `auction` VALUES ('20764', '7', '38610', '24476', '2', '7328', '1294078838', '0', '0', '7181', '0');
INSERT INTO `auction` VALUES ('20083', '7', '37929', '45998', '2', '470', '1294057178', '0', '0', '394', '0');
INSERT INTO `auction` VALUES ('21816', '2', '39678', '9427', '2', '1004076', '1294077984', '0', '0', '933790', '0');
INSERT INTO `auction` VALUES ('20094', '7', '37940', '8245', '2', '827718', '1294071578', '0', '0', '778054', '0');
INSERT INTO `auction` VALUES ('20199', '7', '38045', '9719', '2', '335000', '1294075178', '0', '0', '328300', '0');
INSERT INTO `auction` VALUES ('20765', '7', '38611', '9719', '2', '317250', '1294053638', '0', '0', '310905', '0');
INSERT INTO `auction` VALUES ('20980', '2', '38828', '19943', '2', '203280', '1294078898', '0', '0', '191083', '0');
INSERT INTO `auction` VALUES ('19891', '6', '37737', '1678', '2', '366512', '1294082378', '0', '0', '337191', '0');
INSERT INTO `auction` VALUES ('22390', '2', '40252', '24606', '2', '910101', '1294081644', '0', '0', '891898', '0');
INSERT INTO `auction` VALUES ('19960', '6', '37806', '20518', '2', '67500', '1294082378', '0', '0', '54675', '0');
INSERT INTO `auction` VALUES ('21732', '7', '39581', '31256', '2', '41800', '1294068158', '0', '0', '35530', '0');
INSERT INTO `auction` VALUES ('21514', '2', '39363', '8152', '2', '69600', '1294075358', '0', '0', '60552', '0');
INSERT INTO `auction` VALUES ('20095', '7', '37941', '31275', '2', '2287903', '1294064378', '0', '0', '1761685', '0');
INSERT INTO `auction` VALUES ('22099', '6', '39961', '43696', '2', '1180', '1294106784', '0', '0', '896', '0');
INSERT INTO `auction` VALUES ('21473', '2', '39322', '19943', '2', '233280', '1294075358', '0', '0', '205286', '0');
INSERT INTO `auction` VALUES ('20274', '2', '38120', '1703', '2', '1423', '1294064438', '0', '0', '1109', '0');
INSERT INTO `auction` VALUES ('22433', '2', '40295', '24669', '2', '934709', '1294124844', '0', '0', '934709', '0');
INSERT INTO `auction` VALUES ('21915', '2', '39777', '25270', '2', '2285997', '1294092384', '0', '0', '2217417', '0');
INSERT INTO `auction` VALUES ('20358', '2', '38204', '9719', '2', '382250', '1294075238', '0', '0', '332557', '0');
INSERT INTO `auction` VALUES ('21459', '7', '39307', '1288', '2', '4736', '1294060898', '0', '0', '4215', '0');
INSERT INTO `auction` VALUES ('20925', '2', '38773', '36153', '2', '2512932', '1294053698', '0', '0', '2135992', '0');
INSERT INTO `auction` VALUES ('22032', '6', '39894', '7754', '2', '140223', '1294081584', '0', '0', '119189', '0');
INSERT INTO `auction` VALUES ('20940', '2', '38788', '1943', '2', '41234', '1294060898', '0', '0', '39996', '0');
INSERT INTO `auction` VALUES ('21542', '2', '39391', '814', '2', '760', '1294064558', '0', '0', '608', '0');
INSERT INTO `auction` VALUES ('21735', '7', '39584', '36598', '2', '9748133', '1294075358', '0', '0', '9358207', '0');
INSERT INTO `auction` VALUES ('20125', '7', '37971', '9719', '2', '402000', '1294075178', '0', '0', '357780', '0');
INSERT INTO `auction` VALUES ('20074', '7', '37920', '14552', '2', '5104895', '1294057178', '0', '0', '4951748', '0');
INSERT INTO `auction` VALUES ('22497', '6', '40359', '36781', '2', '3648', '1294132044', '0', '0', '3356', '0');
INSERT INTO `auction` VALUES ('20198', '7', '38044', '2055', '2', '130', '1294082378', '0', '0', '94', '0');
INSERT INTO `auction` VALUES ('20470', '6', '38316', '2072', '2', '240121', '1294075238', '0', '0', '192096', '0');
INSERT INTO `auction` VALUES ('20294', '2', '38140', '6351', '2', '9', '1294060838', '0', '0', '6', '0');
INSERT INTO `auction` VALUES ('20859', '7', '38705', '9451', '2', '12530', '1294057238', '0', '0', '11778', '0');
INSERT INTO `auction` VALUES ('21773', '2', '39635', '31168', '2', '3028444', '1294121184', '0', '0', '2695315', '0');
INSERT INTO `auction` VALUES ('21701', '7', '39550', '14982', '2', '1247012', '1294064558', '0', '0', '1134780', '0');
INSERT INTO `auction` VALUES ('21071', '6', '38919', '27513', '2', '120', '1294075298', '0', '0', '90', '0');
INSERT INTO `auction` VALUES ('22507', '6', '40369', '25102', '2', '3463265', '1294114044', '0', '0', '3290101', '0');
INSERT INTO `auction` VALUES ('22431', '2', '40293', '13422', '2', '72', '1294099644', '0', '0', '67', '0');
INSERT INTO `auction` VALUES ('20222', '7', '38068', '13884', '2', '456', '1294057178', '0', '0', '369', '0');
INSERT INTO `auction` VALUES ('22348', '7', '40210', '1927', '2', '28677', '1294103184', '0', '0', '25235', '0');
INSERT INTO `auction` VALUES ('20233', '7', '38079', '4589', '2', '42930', '1294064378', '0', '0', '31768', '0');
INSERT INTO `auction` VALUES ('21611', '6', '39460', '4589', '2', '32648', '1294082558', '0', '0', '23180', '0');
INSERT INTO `auction` VALUES ('21854', '2', '39716', '10331', '2', '133857', '1294113984', '0', '0', '108424', '0');
INSERT INTO `auction` VALUES ('22741', '7', '40603', '36168', '2', '2410247', '1294137668', '0', '0', '2145119', '0');
INSERT INTO `auction` VALUES ('21532', '2', '39381', '5182', '2', '96011', '1294060958', '0', '0', '87370', '0');
INSERT INTO `auction` VALUES ('21449', '7', '39297', '4388', '2', '9040', '1294064498', '0', '0', '6418', '0');
INSERT INTO `auction` VALUES ('22302', '7', '40164', '5182', '2', '94861', '1294113984', '0', '0', '78734', '0');
INSERT INTO `auction` VALUES ('20717', '7', '38563', '10514', '2', '110700', '1294064438', '0', '0', '88560', '0');
INSERT INTO `auction` VALUES ('20817', '7', '38663', '16713', '2', '710449', '1294057238', '0', '0', '603881', '0');
INSERT INTO `auction` VALUES ('22743', '7', '40605', '10560', '2', '39040', '1294094468', '0', '0', '34355', '0');
INSERT INTO `auction` VALUES ('22452', '6', '40314', '10560', '2', '83520', '1294114044', '0', '0', '70156', '0');
INSERT INTO `auction` VALUES ('19739', '2', '37585', '873', '2', '3245996', '1294060778', '0', '0', '2791556', '0');
INSERT INTO `auction` VALUES ('20488', '6', '38334', '36456', '2', '4336104', '1294078838', '0', '0', '4032576', '0');
INSERT INTO `auction` VALUES ('21005', '2', '38853', '36457', '2', '3816534', '1294053698', '0', '0', '3778368', '0');
INSERT INTO `auction` VALUES ('21607', '6', '39456', '28497', '2', '964298', '1294071758', '0', '0', '800367', '0');
INSERT INTO `auction` VALUES ('22708', '6', '40570', '40195', '2', '79200', '1294080068', '0', '0', '64944', '0');
INSERT INTO `auction` VALUES ('21511', '2', '39360', '4611', '2', '1432', '1294082558', '0', '0', '1231', '0');
INSERT INTO `auction` VALUES ('22254', '7', '40116', '6307', '2', '9', '1294088784', '0', '0', '7', '0');
INSERT INTO `auction` VALUES ('20875', '2', '38723', '36049', '2', '2168311', '1294057298', '0', '0', '2103261', '0');
INSERT INTO `auction` VALUES ('21205', '6', '39053', '4611', '2', '6214', '1294064498', '0', '0', '5157', '0');
INSERT INTO `auction` VALUES ('20655', '6', '38501', '37159', '2', '24800', '1294053638', '0', '0', '18600', '0');
INSERT INTO `auction` VALUES ('20022', '6', '37868', '7517', '2', '652346', '1294060778', '0', '0', '613205', '0');
INSERT INTO `auction` VALUES ('20036', '6', '37882', '27481', '2', '8', '1294060778', '0', '0', '6', '0');
INSERT INTO `auction` VALUES ('20419', '2', '38265', '6522', '2', '378', '1294078838', '0', '0', '283', '0');
INSERT INTO `auction` VALUES ('22493', '6', '40355', '36277', '2', '4444318', '1294078044', '0', '0', '4222102', '0');
INSERT INTO `auction` VALUES ('19737', '2', '37583', '9719', '2', '415500', '1294064378', '0', '0', '382260', '0');
INSERT INTO `auction` VALUES ('22453', '6', '40315', '5524', '2', '1912', '1294103244', '0', '0', '1529', '0');
INSERT INTO `auction` VALUES ('20718', '7', '38564', '8152', '2', '26740', '1294078838', '0', '0', '19520', '0');
INSERT INTO `auction` VALUES ('20627', '6', '38473', '2075', '2', '25940', '1294060838', '0', '0', '25680', '0');
INSERT INTO `auction` VALUES ('22072', '6', '39934', '24934', '2', '1039693', '1294077984', '0', '0', '935723', '0');
INSERT INTO `auction` VALUES ('21847', '2', '39709', '4477', '2', '259264', '1294099584', '0', '0', '220374', '0');
INSERT INTO `auction` VALUES ('21136', '6', '38984', '5743', '2', '68181', '1294071698', '0', '0', '66135', '0');
INSERT INTO `auction` VALUES ('22041', '6', '39903', '37160', '2', '20880', '1294099584', '0', '0', '16495', '0');
INSERT INTO `auction` VALUES ('20451', '2', '38297', '8303', '2', '1346306', '1294078838', '0', '0', '1278990', '0');
INSERT INTO `auction` VALUES ('22267', '7', '40129', '9719', '2', '364000', '1294099584', '0', '0', '273000', '0');
INSERT INTO `auction` VALUES ('21310', '7', '39158', '5635', '2', '1962', '1294064498', '0', '0', '1962', '0');
INSERT INTO `auction` VALUES ('20632', '6', '38478', '24717', '2', '669905', '1294078838', '0', '0', '535924', '0');
INSERT INTO `auction` VALUES ('22349', '7', '40211', '8246', '2', '334897', '1294081584', '0', '0', '334897', '0');
INSERT INTO `auction` VALUES ('19736', '2', '37582', '9719', '2', '425000', '1294057178', '0', '0', '403750', '0');
INSERT INTO `auction` VALUES ('21848', '2', '39710', '5523', '2', '1780', '1294099584', '0', '0', '1619', '0');
INSERT INTO `auction` VALUES ('21928', '2', '39790', '35979', '2', '878589', '1294106784', '0', '0', '781944', '0');
INSERT INTO `auction` VALUES ('22350', '7', '40212', '24718', '2', '1076572', '1294128384', '0', '0', '925851', '0');
INSERT INTO `auction` VALUES ('21063', '2', '38911', '27511', '2', '250', '1294071698', '0', '0', '250', '0');
INSERT INTO `auction` VALUES ('20145', '7', '37991', '9719', '2', '359500', '1294078778', '0', '0', '334335', '0');
INSERT INTO `auction` VALUES ('22339', '7', '40201', '27511', '2', '184', '1294117584', '0', '0', '161', '0');
INSERT INTO `auction` VALUES ('21505', '2', '39354', '24607', '2', '1533437', '1294082558', '0', '0', '1472099', '0');
INSERT INTO `auction` VALUES ('22489', '6', '40351', '18512', '2', '192000', '1294117644', '0', '0', '168960', '0');
INSERT INTO `auction` VALUES ('21126', '6', '38974', '9262', '2', '19440', '1294075298', '0', '0', '15746', '0');
INSERT INTO `auction` VALUES ('20708', '7', '38554', '36049', '2', '2031382', '1294057238', '0', '0', '2031382', '0');
INSERT INTO `auction` VALUES ('20574', '6', '38420', '9719', '2', '402750', '1294068038', '0', '0', '330255', '0');
INSERT INTO `auction` VALUES ('22305', '7', '40167', '3076', '2', '36616', '1294131984', '0', '0', '32954', '0');
INSERT INTO `auction` VALUES ('20831', '7', '38677', '18300', '2', '54320', '1294064438', '0', '0', '45628', '0');
INSERT INTO `auction` VALUES ('20085', '7', '37931', '14157', '2', '4448', '1294075178', '0', '0', '3780', '0');
INSERT INTO `auction` VALUES ('22644', '2', '40506', '13911', '2', '512', '1294134068', '0', '0', '424', '0');
INSERT INTO `auction` VALUES ('20613', '6', '38459', '9719', '2', '354750', '1294078838', '0', '0', '305085', '0');
INSERT INTO `auction` VALUES ('22562', '7', '40424', '27515', '2', '23800', '1294132044', '0', '0', '19754', '0');
INSERT INTO `auction` VALUES ('21612', '6', '39461', '1475', '2', '1478', '1294082558', '0', '0', '1167', '0');
INSERT INTO `auction` VALUES ('22277', '7', '40139', '24833', '2', '1186165', '1294085184', '0', '0', '1091271', '0');
INSERT INTO `auction` VALUES ('19766', '2', '37612', '4387', '2', '8160', '1294075178', '0', '0', '8078', '0');
INSERT INTO `auction` VALUES ('22455', '6', '40317', '814', '2', '201', '1294117644', '0', '0', '196', '0');
INSERT INTO `auction` VALUES ('22528', '6', '40390', '1288', '2', '3700', '1294124844', '0', '0', '3219', '0');
INSERT INTO `auction` VALUES ('20032', '6', '37878', '3294', '2', '139', '1294075178', '0', '0', '125', '0');
INSERT INTO `auction` VALUES ('21855', '2', '39717', '44505', '2', '8984242', '1294103184', '0', '0', '7816290', '0');
INSERT INTO `auction` VALUES ('19918', '6', '37764', '9719', '2', '368500', '1294067978', '0', '0', '353760', '0');
INSERT INTO `auction` VALUES ('21927', '2', '39789', '27516', '2', '14800', '1294095984', '0', '0', '13616', '0');
INSERT INTO `auction` VALUES ('19729', '2', '37575', '37160', '2', '17480', '1294053578', '0', '0', '13634', '0');
INSERT INTO `auction` VALUES ('20482', '6', '38328', '9719', '2', '376500', '1294068038', '0', '0', '361440', '0');
INSERT INTO `auction` VALUES ('22418', '2', '40280', '36271', '2', '2326090', '1294092444', '0', '0', '2000437', '0');
INSERT INTO `auction` VALUES ('20031', '6', '37877', '37147', '2', '14350', '1294057178', '0', '0', '10475', '0');
INSERT INTO `auction` VALUES ('19715', '2', '37561', '2057', '2', '154', '1294078778', '0', '0', '129', '0');
INSERT INTO `auction` VALUES ('22727', '7', '40589', '9719', '2', '324750', '1294090868', '0', '0', '311760', '0');
INSERT INTO `auction` VALUES ('21616', '6', '39465', '21882', '2', '145200', '1294057358', '0', '0', '103092', '0');
INSERT INTO `auction` VALUES ('22213', '7', '40075', '9719', '2', '364500', '1294088784', '0', '0', '273375', '0');
INSERT INTO `auction` VALUES ('22083', '6', '39945', '1944', '2', '17691', '1294077984', '0', '0', '14152', '0');
INSERT INTO `auction` VALUES ('22004', '6', '39866', '9361', '2', '3040', '1294113984', '0', '0', '3009', '0');
INSERT INTO `auction` VALUES ('21720', '7', '39569', '24666', '2', '1814150', '1294060958', '0', '0', '1741584', '0');
INSERT INTO `auction` VALUES ('22657', '2', '40519', '897', '2', '66315', '1294083668', '0', '0', '57694', '0');
INSERT INTO `auction` VALUES ('21003', '2', '38851', '44475', '2', '156', '1294068098', '0', '0', '124', '0');
INSERT INTO `auction` VALUES ('20943', '2', '38791', '36471', '2', '1375683', '1294071698', '0', '0', '1169330', '0');
INSERT INTO `auction` VALUES ('22268', '7', '40130', '19943', '2', '63680', '1294077984', '0', '0', '47123', '0');
INSERT INTO `auction` VALUES ('20134', '7', '37980', '31188', '2', '1603777', '1294064378', '0', '0', '1363210', '0');
INSERT INTO `auction` VALUES ('22301', '7', '40163', '6358', '2', '79', '1294110384', '0', '0', '66', '0');
INSERT INTO `auction` VALUES ('21717', '7', '39566', '3283', '2', '16808', '1294068158', '0', '0', '14791', '0');
INSERT INTO `auction` VALUES ('21586', '6', '39435', '24476', '2', '6688', '1294068158', '0', '0', '6086', '0');
INSERT INTO `auction` VALUES ('20775', '7', '38621', '44144', '2', '6075', '1294060838', '0', '0', '5892', '0');
INSERT INTO `auction` VALUES ('22713', '6', '40575', '24599', '2', '1198562', '1294083668', '0', '0', '1174590', '0');
INSERT INTO `auction` VALUES ('20293', '2', '38139', '31246', '2', '2162454', '1294075238', '0', '0', '1838085', '0');
INSERT INTO `auction` VALUES ('20138', '7', '37984', '10560', '2', '32960', '1294057178', '0', '0', '32630', '0');
INSERT INTO `auction` VALUES ('20132', '7', '37978', '10627', '2', '2214565', '1294075178', '0', '0', '2059545', '0');
INSERT INTO `auction` VALUES ('21341', '7', '39189', '36486', '2', '7369657', '1294071698', '0', '0', '6780084', '0');
INSERT INTO `auction` VALUES ('19667', '2', '37513', '36041', '2', '2048428', '1294057178', '0', '0', '1966490', '0');
INSERT INTO `auction` VALUES ('22432', '2', '40294', '10561', '2', '9320', '1294132044', '0', '0', '9320', '0');
INSERT INTO `auction` VALUES ('22266', '7', '40128', '9719', '2', '329500', '1294095984', '0', '0', '322910', '0');
INSERT INTO `auction` VALUES ('22530', '6', '40392', '37159', '2', '6570', '1294135644', '0', '0', '4796', '0');
INSERT INTO `auction` VALUES ('22000', '6', '39862', '31562', '2', '3736681', '1294095984', '0', '0', '3288279', '0');
INSERT INTO `auction` VALUES ('21340', '7', '39188', '25138', '2', '3775021', '1294060898', '0', '0', '3624020', '0');
INSERT INTO `auction` VALUES ('21840', '2', '39702', '32716', '2', '1834500', '1294085184', '0', '0', '1651050', '0');
INSERT INTO `auction` VALUES ('20405', '2', '38251', '44688', '2', '3101513', '1294057238', '0', '0', '2698316', '0');
INSERT INTO `auction` VALUES ('22304', '7', '40166', '2267', '2', '31986', '1294092384', '0', '0', '30066', '0');
INSERT INTO `auction` VALUES ('19824', '2', '37670', '13757', '2', '39960', '1294082378', '0', '0', '36363', '0');
INSERT INTO `auction` VALUES ('22112', '6', '39974', '9262', '2', '25920', '1294106784', '0', '0', '21772', '0');
INSERT INTO `auction` VALUES ('22441', '2', '40303', '10559', '2', '13860', '1294096044', '0', '0', '12335', '0');
INSERT INTO `auction` VALUES ('21856', '2', '39718', '9397', '2', '312188', '1294128384', '0', '0', '268481', '0');
INSERT INTO `auction` VALUES ('19972', '6', '37818', '30728', '2', '9499796', '1294057178', '0', '0', '7599836', '0');
INSERT INTO `auction` VALUES ('22204', '7', '40066', '6331', '2', '595461', '1294124784', '0', '0', '547824', '0');
INSERT INTO `auction` VALUES ('21760', '2', '39622', '16656', '2', '505', '1294128384', '0', '0', '429', '0');
INSERT INTO `auction` VALUES ('21290', '7', '39138', '1218', '2', '113943', '1294071698', '0', '0', '92293', '0');
INSERT INTO `auction` VALUES ('20230', '7', '38076', '9719', '2', '383500', '1294067978', '0', '0', '310635', '0');
INSERT INTO `auction` VALUES ('20008', '6', '37854', '20526', '2', '58240', '1294057178', '0', '0', '54745', '0');
INSERT INTO `auction` VALUES ('21582', '6', '39431', '36379', '2', '1714410', '1294057358', '0', '0', '1680121', '0');
INSERT INTO `auction` VALUES ('20754', '7', '38600', '10560', '2', '38400', '1294064438', '0', '0', '30336', '0');
INSERT INTO `auction` VALUES ('19777', '2', '37623', '2258', '2', '871', '1294082378', '0', '0', '783', '0');
INSERT INTO `auction` VALUES ('20755', '7', '38601', '44143', '2', '88825', '1294053638', '0', '0', '74613', '0');
INSERT INTO `auction` VALUES ('20591', '6', '38437', '2114', '2', '347', '1294078838', '0', '0', '256', '0');
INSERT INTO `auction` VALUES ('20103', '7', '37949', '3475', '2', '3356651', '1294064378', '0', '0', '3020985', '0');
INSERT INTO `auction` VALUES ('19805', '2', '37651', '23381', '2', '148', '1294067978', '0', '0', '142', '0');
INSERT INTO `auction` VALUES ('22084', '6', '39946', '19441', '2', '18840', '1294081584', '0', '0', '16202', '0');
INSERT INTO `auction` VALUES ('21518', '2', '39367', '4676', '2', '13469', '1294068158', '0', '0', '12660', '0');
INSERT INTO `auction` VALUES ('20077', '7', '37923', '9719', '2', '420750', '1294057178', '0', '0', '403920', '0');
INSERT INTO `auction` VALUES ('22101', '6', '39963', '20261', '2', '987888', '1294088784', '0', '0', '800189', '0');
INSERT INTO `auction` VALUES ('22410', '2', '40272', '19441', '2', '54000', '1294092444', '0', '0', '38880', '0');
INSERT INTO `auction` VALUES ('22190', '7', '40052', '25214', '2', '4093111', '1294131984', '0', '0', '3888455', '0');
INSERT INTO `auction` VALUES ('21060', '2', '38908', '25032', '2', '1050241', '1294057298', '0', '0', '903207', '0');
INSERT INTO `auction` VALUES ('22298', '7', '40160', '21882', '2', '231000', '1294077984', '0', '0', '191730', '0');
INSERT INTO `auction` VALUES ('20443', '2', '38289', '2327', '2', '396', '1294082438', '0', '0', '336', '0');
INSERT INTO `auction` VALUES ('22427', '2', '40289', '18588', '2', '28320', '1294092444', '0', '0', '22089', '0');
INSERT INTO `auction` VALUES ('21338', '7', '39186', '28498', '2', '1442717', '1294071698', '0', '0', '1356153', '0');
INSERT INTO `auction` VALUES ('19714', '2', '37560', '39681', '2', '223104', '1294064378', '0', '0', '187407', '0');
INSERT INTO `auction` VALUES ('22424', '2', '40286', '19943', '2', '36960', '1294096044', '0', '0', '30307', '0');
INSERT INTO `auction` VALUES ('22026', '6', '39888', '13891', '2', '920', '1294117584', '0', '0', '846', '0');
INSERT INTO `auction` VALUES ('21134', '6', '38982', '880', '2', '130023', '1294082498', '0', '0', '120921', '0');
INSERT INTO `auction` VALUES ('20567', '6', '38413', '2168', '2', '29245', '1294071638', '0', '0', '26905', '0');
INSERT INTO `auction` VALUES ('22510', '6', '40372', '24832', '2', '1732401', '1294078044', '0', '0', '1593808', '0');
INSERT INTO `auction` VALUES ('20324', '2', '38170', '36511', '2', '8090480', '1294075238', '0', '0', '7685956', '0');
INSERT INTO `auction` VALUES ('22323', '7', '40185', '1288', '2', '1665', '1294110384', '0', '0', '1282', '0');
INSERT INTO `auction` VALUES ('22467', '6', '40329', '36262', '2', '1652545', '1294132044', '0', '0', '1322036', '0');
INSERT INTO `auction` VALUES ('22575', '7', '40437', '25004', '2', '1928873', '1294128444', '0', '0', '1543098', '0');
INSERT INTO `auction` VALUES ('22332', '7', '40194', '1955', '2', '75926', '1294110384', '0', '0', '71370', '0');
INSERT INTO `auction` VALUES ('20683', '7', '38529', '6359', '2', '474', '1294057238', '0', '0', '350', '0');
INSERT INTO `auction` VALUES ('20155', '7', '38001', '2879', '2', '263880', '1294053578', '0', '0', '213742', '0');
INSERT INTO `auction` VALUES ('22662', '2', '40524', '44700', '2', '5800', '1294090868', '0', '0', '4408', '0');
INSERT INTO `auction` VALUES ('22423', '2', '40285', '24663', '2', '1619979', '1294081644', '0', '0', '1587579', '0');
INSERT INTO `auction` VALUES ('22297', '7', '40159', '727', '2', '12985', '1294081584', '0', '0', '11037', '0');
INSERT INTO `auction` VALUES ('20878', '2', '38726', '24778', '2', '2349748', '1294057298', '0', '0', '2349748', '0');
INSERT INTO `auction` VALUES ('21251', '6', '39099', '19943', '2', '140800', '1294078898', '0', '0', '101376', '0');
INSERT INTO `auction` VALUES ('22162', '7', '40024', '30736', '2', '8939580', '1294085184', '0', '0', '7866830', '0');
INSERT INTO `auction` VALUES ('20750', '7', '38596', '31268', '2', '52893', '1294075238', '0', '0', '43901', '0');
INSERT INTO `auction` VALUES ('21923', '2', '39785', '24836', '2', '1223291', '1294095984', '0', '0', '1125427', '0');
INSERT INTO `auction` VALUES ('21942', '2', '39804', '15968', '2', '412064', '1294077984', '0', '0', '387340', '0');
INSERT INTO `auction` VALUES ('20983', '2', '38831', '4402', '2', '2180', '1294082498', '0', '0', '2005', '0');
INSERT INTO `auction` VALUES ('22499', '6', '40361', '1288', '2', '6401', '1294132044', '0', '0', '4864', '0');
INSERT INTO `auction` VALUES ('20548', '6', '38394', '4724', '2', '109053', '1294064438', '0', '0', '107962', '0');
INSERT INTO `auction` VALUES ('22484', '6', '40346', '4589', '2', '3900', '1294078044', '0', '0', '3861', '0');
INSERT INTO `auction` VALUES ('20706', '7', '38552', '5524', '2', '3748', '1294060838', '0', '0', '3335', '0');
INSERT INTO `auction` VALUES ('19893', '6', '37739', '44700', '2', '4625', '1294078778', '0', '0', '3977', '0');
INSERT INTO `auction` VALUES ('20025', '6', '37871', '9719', '2', '355500', '1294057178', '0', '0', '270180', '0');
INSERT INTO `auction` VALUES ('20223', '7', '38069', '20653', '2', '965995', '1294067978', '0', '0', '850075', '0');
INSERT INTO `auction` VALUES ('20414', '2', '38260', '10634', '2', '684215', '1294064438', '0', '0', '520003', '0');
INSERT INTO `auction` VALUES ('22351', '7', '40213', '36399', '2', '3075893', '1294113984', '0', '0', '3014375', '0');
INSERT INTO `auction` VALUES ('20504', '6', '38350', '9262', '2', '145600', '1294053638', '0', '0', '119392', '0');
INSERT INTO `auction` VALUES ('22321', '7', '40183', '36512', '2', '8676033', '1294077984', '0', '0', '8242231', '0');
INSERT INTO `auction` VALUES ('22235', '7', '40097', '9719', '2', '358000', '1294131984', '0', '0', '275660', '0');
INSERT INTO `auction` VALUES ('20263', '7', '38109', '9719', '2', '375250', '1294064378', '0', '0', '307705', '0');
INSERT INTO `auction` VALUES ('21419', '7', '39267', '36389', '2', '4580978', '1294082498', '0', '0', '4077070', '0');
INSERT INTO `auction` VALUES ('22645', '2', '40507', '9719', '2', '403250', '1294108868', '0', '0', '375022', '0');
INSERT INTO `auction` VALUES ('20573', '6', '38419', '31224', '2', '1569496', '1294068038', '0', '0', '1569496', '0');
INSERT INTO `auction` VALUES ('21791', '2', '39653', '30736', '2', '5885806', '1294117584', '0', '0', '5532657', '0');
INSERT INTO `auction` VALUES ('20456', '2', '38302', '20670', '2', '540125', '1294064438', '0', '0', '432100', '0');
INSERT INTO `auction` VALUES ('21936', '2', '39798', '5524', '2', '1522', '1294085184', '0', '0', '1385', '0');
INSERT INTO `auction` VALUES ('20291', '2', '38137', '2084', '2', '239232', '1294075238', '0', '0', '196170', '0');
INSERT INTO `auction` VALUES ('19964', '6', '37810', '10627', '2', '2329204', '1294064378', '0', '0', '2329204', '0');
INSERT INTO `auction` VALUES ('20309', '2', '38155', '13884', '2', '552', '1294075238', '0', '0', '507', '0');
INSERT INTO `auction` VALUES ('22224', '7', '40086', '36679', '2', '6493560', '1294128384', '0', '0', '5389654', '0');
INSERT INTO `auction` VALUES ('20418', '2', '38264', '20722', '2', '2705862', '1294071638', '0', '0', '2462334', '0');
INSERT INTO `auction` VALUES ('21393', '7', '39241', '45909', '2', '34736', '1294064498', '0', '0', '27094', '0');
INSERT INTO `auction` VALUES ('21545', '2', '39394', '25040', '2', '1350255', '1294078958', '0', '0', '1282742', '0');
INSERT INTO `auction` VALUES ('20384', '2', '38230', '9719', '2', '429250', '1294075238', '0', '0', '334815', '0');
INSERT INTO `auction` VALUES ('22534', '6', '40396', '10560', '2', '28440', '1294135644', '0', '0', '21898', '0');
INSERT INTO `auction` VALUES ('20262', '7', '38108', '1401', '2', '1061', '1294067978', '0', '0', '816', '0');
INSERT INTO `auction` VALUES ('22226', '7', '40088', '9719', '2', '329750', '1294113984', '0', '0', '247312', '0');
INSERT INTO `auction` VALUES ('20261', '7', '38107', '25061', '2', '1123653', '1294078778', '0', '0', '977578', '0');
INSERT INTO `auction` VALUES ('21614', '6', '39463', '2620', '2', '153532', '1294078958', '0', '0', '124360', '0');
INSERT INTO `auction` VALUES ('21248', '6', '39096', '24612', '2', '629270', '1294064498', '0', '0', '553757', '0');
INSERT INTO `auction` VALUES ('21537', '2', '39386', '24823', '2', '1356667', '1294057358', '0', '0', '1207433', '0');
INSERT INTO `auction` VALUES ('20260', '7', '38106', '39682', '2', '305280', '1294078778', '0', '0', '305280', '0');
INSERT INTO `auction` VALUES ('19829', '2', '37675', '31882', '2', '2910000', '1294082378', '0', '0', '2880900', '0');
INSERT INTO `auction` VALUES ('20290', '2', '38136', '9719', '2', '414500', '1294060838', '0', '0', '393775', '0');
INSERT INTO `auction` VALUES ('21253', '6', '39101', '36066', '2', '1406918', '1294053698', '0', '0', '1195880', '0');
INSERT INTO `auction` VALUES ('22044', '6', '39906', '16654', '2', '452', '1294085184', '0', '0', '370', '0');
INSERT INTO `auction` VALUES ('21073', '6', '38921', '5635', '2', '1139', '1294057298', '0', '0', '865', '0');
INSERT INTO `auction` VALUES ('21843', '2', '39705', '9719', '2', '401750', '1294088784', '0', '0', '317382', '0');
INSERT INTO `auction` VALUES ('20441', '2', '38287', '18588', '2', '19200', '1294057238', '0', '0', '17088', '0');
INSERT INTO `auction` VALUES ('20289', '2', '38135', '9719', '2', '344250', '1294064438', '0', '0', '330480', '0');
INSERT INTO `auction` VALUES ('20391', '2', '38237', '27515', '2', '12840', '1294071638', '0', '0', '9886', '0');
INSERT INTO `auction` VALUES ('20901', '2', '38749', '36612', '2', '6088602', '1294064498', '0', '0', '5175311', '0');
INSERT INTO `auction` VALUES ('22413', '2', '40275', '36165', '2', '3702268', '1294128444', '0', '0', '3332041', '0');
INSERT INTO `auction` VALUES ('20762', '7', '38608', '10562', '2', '63600', '1294053638', '0', '0', '62964', '0');
INSERT INTO `auction` VALUES ('22227', '7', '40089', '24401', '2', '512820', '1294124784', '0', '0', '410256', '0');
INSERT INTO `auction` VALUES ('20075', '7', '37921', '9719', '2', '343750', '1294082378', '0', '0', '340312', '0');
INSERT INTO `auction` VALUES ('21246', '6', '39094', '36609', '2', '8065497', '1294075298', '0', '0', '7178292', '0');
INSERT INTO `auction` VALUES ('19951', '6', '37797', '811', '2', '6689701', '1294053578', '0', '0', '5485554', '0');
INSERT INTO `auction` VALUES ('22155', '7', '40017', '1973', '2', '315737', '1294106784', '0', '0', '315737', '0');
INSERT INTO `auction` VALUES ('20333', '2', '38179', '1608', '2', '1035114', '1294057238', '0', '0', '983358', '0');
INSERT INTO `auction` VALUES ('21628', '6', '39477', '8152', '2', '15920', '1294075358', '0', '0', '11462', '0');
INSERT INTO `auction` VALUES ('19836', '2', '37682', '9719', '2', '421250', '1294071578', '0', '0', '370700', '0');
INSERT INTO `auction` VALUES ('21625', '6', '39474', '24609', '2', '767672', '1294078958', '0', '0', '660197', '0');
INSERT INTO `auction` VALUES ('22439', '2', '40301', '789', '2', '127420', '1294081644', '0', '0', '110855', '0');
INSERT INTO `auction` VALUES ('22357', '2', '40219', '35987', '2', '956313', '1294103244', '0', '0', '784176', '0');
INSERT INTO `auction` VALUES ('21392', '7', '39240', '15687', '2', '1330625', '1294075298', '0', '0', '1277400', '0');
INSERT INTO `auction` VALUES ('22343', '7', '40205', '4402', '2', '12200', '1294121184', '0', '0', '12200', '0');
INSERT INTO `auction` VALUES ('22724', '7', '40586', '2975', '2', '1059', '1294134068', '0', '0', '1006', '0');
INSERT INTO `auction` VALUES ('21360', '7', '39208', '10505', '2', '14210', '1294053698', '0', '0', '12646', '0');
INSERT INTO `auction` VALUES ('20073', '7', '37919', '36444', '2', '1569304', '1294064378', '0', '0', '1490838', '0');
INSERT INTO `auction` VALUES ('20790', '7', '38636', '9719', '2', '368500', '1294057238', '0', '0', '368500', '0');
INSERT INTO `auction` VALUES ('22667', '6', '40529', '24837', '2', '867960', '1294112468', '0', '0', '755125', '0');
INSERT INTO `auction` VALUES ('19925', '6', '37771', '31228', '2', '1749248', '1294053578', '0', '0', '1556830', '0');
INSERT INTO `auction` VALUES ('21254', '6', '39102', '25130', '2', '3360840', '1294060898', '0', '0', '3293623', '0');
INSERT INTO `auction` VALUES ('19784', '2', '37630', '9719', '2', '335250', '1294082378', '0', '0', '315135', '0');
INSERT INTO `auction` VALUES ('19726', '2', '37572', '2244', '2', '7104546', '1294060778', '0', '0', '5754682', '0');
INSERT INTO `auction` VALUES ('21961', '6', '39823', '9719', '2', '362000', '1294121184', '0', '0', '314940', '0');
INSERT INTO `auction` VALUES ('22015', '6', '39877', '2018', '2', '186006', '1294128384', '0', '0', '167405', '0');
INSERT INTO `auction` VALUES ('20084', '7', '37930', '2624', '2', '207280', '1294082378', '0', '0', '192770', '0');
INSERT INTO `auction` VALUES ('22651', '2', '40513', '36393', '2', '2523024', '1294134068', '0', '0', '2094109', '0');
INSERT INTO `auction` VALUES ('20872', '2', '38720', '24937', '2', '1151081', '1294060898', '0', '0', '1024462', '0');
INSERT INTO `auction` VALUES ('22116', '6', '39978', '18512', '2', '36160', '1294106784', '0', '0', '34352', '0');
INSERT INTO `auction` VALUES ('20385', '2', '38231', '10559', '2', '112200', '1294053638', '0', '0', '83028', '0');
INSERT INTO `auction` VALUES ('20002', '6', '37848', '4436', '2', '13289', '1294075178', '0', '0', '12890', '0');
INSERT INTO `auction` VALUES ('19911', '6', '37757', '3293', '2', '143', '1294060778', '0', '0', '112', '0');
INSERT INTO `auction` VALUES ('21687', '7', '39536', '24608', '2', '482533', '1294053758', '0', '0', '472882', '0');
INSERT INTO `auction` VALUES ('20250', '7', '38096', '20692', '2', '563908', '1294071578', '0', '0', '473682', '0');
INSERT INTO `auction` VALUES ('21852', '2', '39714', '18600', '2', '828480', '1294077984', '0', '0', '820195', '0');
INSERT INTO `auction` VALUES ('22399', '2', '40261', '27513', '2', '180', '1294124844', '0', '0', '176', '0');
INSERT INTO `auction` VALUES ('20052', '6', '37898', '31197', '2', '1662267', '1294082378', '0', '0', '1545908', '0');
INSERT INTO `auction` VALUES ('21433', '7', '39281', '25102', '2', '2287008', '1294075298', '0', '0', '2264137', '0');
INSERT INTO `auction` VALUES ('20899', '2', '38747', '2015', '2', '308399', '1294060898', '0', '0', '262139', '0');
INSERT INTO `auction` VALUES ('22341', '7', '40203', '4394', '2', '66240', '1294113984', '0', '0', '54316', '0');
INSERT INTO `auction` VALUES ('22537', '6', '40399', '4387', '2', '22896', '1294092444', '0', '0', '22209', '0');
INSERT INTO `auction` VALUES ('22711', '6', '40573', '24476', '2', '7560', '1294098068', '0', '0', '6123', '0');
INSERT INTO `auction` VALUES ('21594', '6', '39443', '24712', '2', '614434', '1294068158', '0', '0', '552990', '0');
INSERT INTO `auction` VALUES ('22750', '7', '40612', '36640', '2', '4413288', '1294080068', '0', '0', '4325022', '0');
INSERT INTO `auction` VALUES ('22243', '7', '40105', '9719', '2', '382250', '1294103184', '0', '0', '317267', '0');
INSERT INTO `auction` VALUES ('21857', '2', '39719', '17055', '2', '1859213', '1294081584', '0', '0', '1803436', '0');
INSERT INTO `auction` VALUES ('21066', '6', '38914', '39681', '2', '277200', '1294082498', '0', '0', '205128', '0');
INSERT INTO `auction` VALUES ('21432', '7', '39280', '24667', '2', '870914', '1294075298', '0', '0', '827368', '0');
INSERT INTO `auction` VALUES ('22683', '6', '40545', '4387', '2', '14160', '1294130468', '0', '0', '13593', '0');
INSERT INTO `auction` VALUES ('21912', '2', '39774', '24938', '2', '1647229', '1294128384', '0', '0', '1597812', '0');
INSERT INTO `auction` VALUES ('21578', '6', '39427', '5637', '2', '2700', '1294053758', '0', '0', '2457', '0');
INSERT INTO `auction` VALUES ('22189', '7', '40051', '1986', '2', '792877', '1294106784', '0', '0', '737375', '0');
INSERT INTO `auction` VALUES ('22679', '6', '40541', '9719', '2', '423000', '1294090868', '0', '0', '342630', '0');
INSERT INTO `auction` VALUES ('20684', '7', '38530', '4302', '2', '1222', '1294060838', '0', '0', '977', '0');
INSERT INTO `auction` VALUES ('22252', '7', '40114', '36267', '2', '2170179', '1294088784', '0', '0', '1888055', '0');
INSERT INTO `auction` VALUES ('19892', '6', '37738', '19943', '2', '173600', '1294075178', '0', '0', '168392', '0');
INSERT INTO `auction` VALUES ('19845', '2', '37691', '1318', '2', '237339', '1294057178', '0', '0', '201738', '0');
INSERT INTO `auction` VALUES ('21311', '7', '39159', '36444', '2', '1318346', '1294057298', '0', '0', '1173327', '0');
INSERT INTO `auction` VALUES ('21815', '2', '39677', '21592', '2', '1938', '1294106784', '0', '0', '1938', '0');
INSERT INTO `auction` VALUES ('21221', '6', '39069', '36568', '2', '6597278', '1294082498', '0', '0', '5541713', '0');
INSERT INTO `auction` VALUES ('20200', '7', '38046', '31198', '2', '1186787', '1294071578', '0', '0', '1186787', '0');
INSERT INTO `auction` VALUES ('20772', '7', '38618', '13036', '2', '2863053', '1294068038', '0', '0', '2748530', '0');
INSERT INTO `auction` VALUES ('20492', '6', '38338', '21882', '2', '187200', '1294064438', '0', '0', '181584', '0');
INSERT INTO `auction` VALUES ('22137', '6', '39999', '36385', '2', '3250287', '1294131984', '0', '0', '3087772', '0');
INSERT INTO `auction` VALUES ('20568', '6', '38414', '2751', '2', '6390', '1294060838', '0', '0', '5495', '0');
INSERT INTO `auction` VALUES ('22608', '7', '40470', '4611', '2', '2928', '1294092444', '0', '0', '2723', '0');
INSERT INTO `auction` VALUES ('22107', '6', '39969', '9719', '2', '386750', '1294081584', '0', '0', '309400', '0');
INSERT INTO `auction` VALUES ('21302', '7', '39150', '4660', '2', '16700', '1294075298', '0', '0', '14696', '0');
INSERT INTO `auction` VALUES ('21222', '6', '39070', '8152', '2', '33440', '1294075298', '0', '0', '30764', '0');
INSERT INTO `auction` VALUES ('21853', '2', '39715', '9719', '2', '411250', '1294103184', '0', '0', '394800', '0');
INSERT INTO `auction` VALUES ('22207', '7', '40069', '44475', '2', '166', '1294103184', '0', '0', '152', '0');
INSERT INTO `auction` VALUES ('22514', '6', '40376', '24998', '2', '1045234', '1294092444', '0', '0', '836187', '0');
INSERT INTO `auction` VALUES ('20705', '7', '38551', '4359', '2', '856', '1294075238', '0', '0', '736', '0');
INSERT INTO `auction` VALUES ('22407', '2', '40269', '10562', '2', '30300', '1294096044', '0', '0', '25755', '0');
INSERT INTO `auction` VALUES ('21364', '7', '39212', '4402', '2', '1670', '1294075298', '0', '0', '1369', '0');
INSERT INTO `auction` VALUES ('22215', '7', '40077', '9719', '2', '334250', '1294077984', '0', '0', '290797', '0');
INSERT INTO `auction` VALUES ('22094', '6', '39956', '31191', '2', '1288639', '1294106784', '0', '0', '1056683', '0');
INSERT INTO `auction` VALUES ('20433', '2', '38279', '3429', '2', '27003', '1294064438', '0', '0', '21872', '0');
INSERT INTO `auction` VALUES ('22419', '2', '40281', '24823', '2', '1840153', '1294114044', '0', '0', '1821751', '0');
INSERT INTO `auction` VALUES ('21223', '6', '39071', '2624', '2', '177999', '1294053698', '0', '0', '153079', '0');
INSERT INTO `auction` VALUES ('21781', '2', '39643', '31151', '2', '1766372', '1294110384', '0', '0', '1430761', '0');
INSERT INTO `auction` VALUES ('21067', '6', '38915', '2226', '2', '206723', '1294053698', '0', '0', '173647', '0');
INSERT INTO `auction` VALUES ('22366', '2', '40228', '2566', '2', '56937', '1294085244', '0', '0', '47827', '0');
INSERT INTO `auction` VALUES ('21297', '7', '39145', '2073', '2', '40668', '1294053698', '0', '0', '33754', '0');
INSERT INTO `auction` VALUES ('20007', '6', '37853', '9378', '2', '879135', '1294057178', '0', '0', '835178', '0');
INSERT INTO `auction` VALUES ('20552', '6', '38398', '1288', '2', '2974', '1294060838', '0', '0', '2587', '0');
INSERT INTO `auction` VALUES ('22385', '2', '40247', '1993', '2', '115164', '1294081644', '0', '0', '92131', '0');
INSERT INTO `auction` VALUES ('22055', '6', '39917', '36056', '2', '1848773', '1294103184', '0', '0', '1700871', '0');
INSERT INTO `auction` VALUES ('22521', '6', '40383', '4377', '2', '14760', '1294117644', '0', '0', '13431', '0');
INSERT INTO `auction` VALUES ('21885', '2', '39747', '9719', '2', '411500', '1294081584', '0', '0', '308625', '0');
INSERT INTO `auction` VALUES ('21431', '7', '39279', '4402', '2', '11700', '1294053698', '0', '0', '9009', '0');
INSERT INTO `auction` VALUES ('22684', '6', '40546', '36694', '2', '5415673', '1294108868', '0', '0', '4982419', '0');
INSERT INTO `auction` VALUES ('20914', '2', '38762', '10505', '2', '36360', '1294057298', '0', '0', '25452', '0');
INSERT INTO `auction` VALUES ('22627', '2', '40489', '940', '2', '2547128', '1294119668', '0', '0', '2445242', '0');
INSERT INTO `auction` VALUES ('22402', '2', '40264', '4611', '2', '3360', '1294106844', '0', '0', '3057', '0');
INSERT INTO `auction` VALUES ('22358', '2', '40220', '36281', '2', '2098256', '1294110444', '0', '0', '1867447', '0');
INSERT INTO `auction` VALUES ('20344', '2', '38190', '27511', '2', '153', '1294071638', '0', '0', '108', '0');
INSERT INTO `auction` VALUES ('22003', '6', '39865', '9719', '2', '417750', '1294092384', '0', '0', '325845', '0');
INSERT INTO `auction` VALUES ('21145', '6', '38993', '24773', '2', '1083730', '1294078898', '0', '0', '932007', '0');
INSERT INTO `auction` VALUES ('21780', '2', '39642', '9719', '2', '435000', '1294077984', '0', '0', '391500', '0');
INSERT INTO `auction` VALUES ('20412', '2', '38258', '8152', '2', '87200', '1294064438', '0', '0', '78480', '0');
INSERT INTO `auction` VALUES ('22595', '7', '40457', '27513', '2', '123', '1294114044', '0', '0', '107', '0');
INSERT INTO `auction` VALUES ('21806', '2', '39668', '6643', '2', '58', '1294113984', '0', '0', '49', '0');
INSERT INTO `auction` VALUES ('22729', '7', '40591', '39682', '2', '212160', '1294112468', '0', '0', '167606', '0');
INSERT INTO `auction` VALUES ('19976', '6', '37822', '13918', '2', '8', '1294078778', '0', '0', '6', '0');
INSERT INTO `auction` VALUES ('19887', '6', '37733', '2622', '2', '125724', '1294078778', '0', '0', '108122', '0');
INSERT INTO `auction` VALUES ('22208', '7', '40070', '4377', '2', '20640', '1294128384', '0', '0', '16924', '0');
INSERT INTO `auction` VALUES ('20143', '7', '37989', '13913', '2', '880', '1294053578', '0', '0', '686', '0');
INSERT INTO `auction` VALUES ('22616', '7', '40478', '814', '2', '3600', '1294128444', '0', '0', '3024', '0');
INSERT INTO `auction` VALUES ('20927', '2', '38775', '4478', '2', '712376', '1294060898', '0', '0', '669633', '0');
INSERT INTO `auction` VALUES ('21258', '6', '39106', '44475', '2', '174', '1294082498', '0', '0', '156', '0');
INSERT INTO `auction` VALUES ('20342', '2', '38188', '3429', '2', '24599', '1294075238', '0', '0', '20663', '0');
INSERT INTO `auction` VALUES ('22603', '7', '40465', '3057', '2', '55489', '1294121244', '0', '0', '53269', '0');
INSERT INTO `auction` VALUES ('20020', '6', '37866', '36582', '2', '5390532', '1294082378', '0', '0', '4797573', '0');
INSERT INTO `auction` VALUES ('20704', '7', '38550', '3328', '2', '452', '1294057238', '0', '0', '329', '0');
INSERT INTO `auction` VALUES ('22440', '2', '40302', '2623', '2', '150359', '1294121244', '0', '0', '150359', '0');
INSERT INTO `auction` VALUES ('22307', '7', '40169', '24832', '2', '2291294', '1294117584', '0', '0', '2291294', '0');
INSERT INTO `auction` VALUES ('22376', '2', '40238', '3164', '2', '256', '1294078044', '0', '0', '199', '0');
INSERT INTO `auction` VALUES ('21831', '2', '39693', '3263', '2', '52', '1294131984', '0', '0', '43', '0');
INSERT INTO `auction` VALUES ('22209', '7', '40071', '5267', '2', '4541190', '1294088784', '0', '0', '4541190', '0');
INSERT INTO `auction` VALUES ('22436', '2', '40298', '24774', '2', '1796204', '1294088844', '0', '0', '1760279', '0');
INSERT INTO `auction` VALUES ('22647', '2', '40509', '18588', '2', '31536', '1294090868', '0', '0', '26490', '0');
INSERT INTO `auction` VALUES ('21814', '2', '39676', '17414', '2', '976450', '1294085184', '0', '0', '869040', '0');
INSERT INTO `auction` VALUES ('21344', '7', '39192', '21882', '2', '344000', '1294078898', '0', '0', '302720', '0');
INSERT INTO `auction` VALUES ('20360', '2', '38206', '9719', '2', '408250', '1294082438', '0', '0', '396002', '0');
INSERT INTO `auction` VALUES ('22529', '6', '40391', '10559', '2', '5430', '1294096044', '0', '0', '4724', '0');
INSERT INTO `auction` VALUES ('21779', '2', '39641', '44700', '2', '4950', '1294103184', '0', '0', '4257', '0');
INSERT INTO `auction` VALUES ('21921', '2', '39783', '12804', '2', '114720', '1294110384', '0', '0', '110131', '0');
INSERT INTO `auction` VALUES ('20042', '6', '37888', '9719', '2', '429000', '1294060778', '0', '0', '338910', '0');
INSERT INTO `auction` VALUES ('19987', '6', '37833', '5066', '2', '311', '1294082378', '0', '0', '301', '0');
INSERT INTO `auction` VALUES ('21911', '2', '39773', '10505', '2', '26180', '1294081584', '0', '0', '24347', '0');
INSERT INTO `auction` VALUES ('20610', '6', '38456', '4377', '2', '1992', '1294078838', '0', '0', '1992', '0');
INSERT INTO `auction` VALUES ('22550', '7', '40412', '24837', '2', '1065947', '1294081644', '0', '0', '1001990', '0');
INSERT INTO `auction` VALUES ('20759', '7', '38605', '16653', '2', '617', '1294057238', '0', '0', '456', '0');
INSERT INTO `auction` VALUES ('20813', '7', '38659', '24888', '2', '2802176', '1294064438', '0', '0', '2325806', '0');
INSERT INTO `auction` VALUES ('21429', '7', '39277', '4359', '2', '1352', '1294075298', '0', '0', '1189', '0');
INSERT INTO `auction` VALUES ('19876', '6', '37722', '1728', '2', '13847051', '1294071578', '0', '0', '13570109', '0');
INSERT INTO `auction` VALUES ('22601', '7', '40463', '7072', '2', '10374', '1294106844', '0', '0', '9440', '0');
INSERT INTO `auction` VALUES ('21264', '7', '39112', '18588', '2', '22736', '1294060898', '0', '0', '21826', '0');
INSERT INTO `auction` VALUES ('20898', '2', '38746', '5750', '2', '25928', '1294064498', '0', '0', '24890', '0');
INSERT INTO `auction` VALUES ('19763', '2', '37609', '9719', '2', '370500', '1294071578', '0', '0', '326040', '0');
INSERT INTO `auction` VALUES ('22438', '2', '40300', '2981', '2', '35867', '1294081644', '0', '0', '29410', '0');
INSERT INTO `auction` VALUES ('22211', '7', '40073', '9719', '2', '429500', '1294081584', '0', '0', '326420', '0');
INSERT INTO `auction` VALUES ('21988', '6', '39850', '24476', '2', '5664', '1294081584', '0', '0', '4417', '0');
INSERT INTO `auction` VALUES ('21006', '2', '38854', '25200', '2', '3112654', '1294060898', '0', '0', '2988147', '0');
INSERT INTO `auction` VALUES ('22047', '6', '39909', '13901', '2', '218', '1294106784', '0', '0', '161', '0');
INSERT INTO `auction` VALUES ('20473', '6', '38319', '44708', '2', '12530794', '1294060838', '0', '0', '9523403', '0');
INSERT INTO `auction` VALUES ('20793', '7', '38639', '9719', '2', '418250', '1294075238', '0', '0', '401520', '0');
INSERT INTO `auction` VALUES ('21164', '6', '39012', '2168', '2', '26943', '1294068098', '0', '0', '26943', '0');
INSERT INTO `auction` VALUES ('20748', '7', '38594', '9719', '2', '362000', '1294068038', '0', '0', '307700', '0');
INSERT INTO `auction` VALUES ('22527', '6', '40389', '36428', '2', '1954362', '1294132044', '0', '0', '1915274', '0');
INSERT INTO `auction` VALUES ('21196', '6', '39044', '3042', '2', '225446', '1294082498', '0', '0', '214173', '0');
INSERT INTO `auction` VALUES ('19789', '2', '37635', '9719', '2', '341500', '1294075178', '0', '0', '331255', '0');
INSERT INTO `auction` VALUES ('22676', '6', '40538', '4387', '2', '3664', '1294098068', '0', '0', '3554', '0');
INSERT INTO `auction` VALUES ('21913', '2', '39775', '38513', '2', '16194', '1294121184', '0', '0', '14736', '0');
INSERT INTO `auction` VALUES ('21228', '6', '39076', '7072', '2', '7776', '1294060898', '0', '0', '5909', '0');
INSERT INTO `auction` VALUES ('22344', '7', '40206', '4388', '2', '6360', '1294110384', '0', '0', '5724', '0');
INSERT INTO `auction` VALUES ('22106', '6', '39968', '2267', '2', '33160', '1294106784', '0', '0', '26859', '0');
INSERT INTO `auction` VALUES ('22556', '7', '40418', '41119', '2', '2490', '1294085244', '0', '0', '1817', '0');
INSERT INTO `auction` VALUES ('21772', '2', '39634', '14551', '2', '1260000', '1294110384', '0', '0', '1234800', '0');
INSERT INTO `auction` VALUES ('21866', '2', '39728', '18512', '2', '27040', '1294092384', '0', '0', '27040', '0');
INSERT INTO `auction` VALUES ('20535', '6', '38381', '14157', '2', '3537', '1294064438', '0', '0', '3254', '0');
INSERT INTO `auction` VALUES ('22386', '2', '40248', '24822', '2', '829046', '1294110444', '0', '0', '795884', '0');
INSERT INTO `auction` VALUES ('21512', '2', '39361', '7072', '2', '4776', '1294053758', '0', '0', '3438', '0');
INSERT INTO `auction` VALUES ('22621', '7', '40483', '4387', '2', '26880', '1294085244', '0', '0', '21772', '0');
INSERT INTO `auction` VALUES ('19885', '6', '37731', '25000', '2', '2413426', '1294060778', '0', '0', '2413426', '0');
INSERT INTO `auction` VALUES ('22747', '7', '40609', '27515', '2', '10740', '1294087268', '0', '0', '9666', '0');
INSERT INTO `auction` VALUES ('20749', '7', '38595', '9719', '2', '315500', '1294057238', '0', '0', '265020', '0');
INSERT INTO `auction` VALUES ('21851', '2', '39713', '6310', '2', '1470', '1294085184', '0', '0', '1396', '0');
INSERT INTO `auction` VALUES ('22113', '6', '39975', '18337', '2', '521846', '1294113984', '0', '0', '433132', '0');
INSERT INTO `auction` VALUES ('20316', '2', '38162', '1929', '2', '26020', '1294075238', '0', '0', '24719', '0');
INSERT INTO `auction` VALUES ('20411', '2', '38257', '20652', '2', '651910', '1294078838', '0', '0', '606276', '0');
INSERT INTO `auction` VALUES ('21192', '6', '39040', '25054', '2', '1172853', '1294053698', '0', '0', '1020382', '0');
INSERT INTO `auction` VALUES ('22506', '6', '40368', '3073', '2', '69739', '1294110444', '0', '0', '68344', '0');
INSERT INTO `auction` VALUES ('20219', '7', '38065', '9719', '2', '393250', '1294060778', '0', '0', '342127', '0');
INSERT INTO `auction` VALUES ('21822', '2', '39684', '7072', '2', '10422', '1294085184', '0', '0', '7920', '0');
INSERT INTO `auction` VALUES ('22075', '6', '39937', '12535', '2', '3033323', '1294099584', '0', '0', '2456991', '0');
INSERT INTO `auction` VALUES ('22480', '6', '40342', '40195', '2', '73920', '1294088844', '0', '0', '71702', '0');
INSERT INTO `auction` VALUES ('22594', '7', '40456', '18588', '2', '20384', '1294135644', '0', '0', '16918', '0');
INSERT INTO `auction` VALUES ('20739', '7', '38585', '9719', '2', '437250', '1294064438', '0', '0', '406642', '0');
INSERT INTO `auction` VALUES ('20218', '7', '38064', '32535', '2', '3746799', '1294075178', '0', '0', '3671863', '0');
INSERT INTO `auction` VALUES ('20805', '7', '38651', '5245', '2', '246942', '1294071638', '0', '0', '242003', '0');
INSERT INTO `auction` VALUES ('21456', '7', '39304', '4377', '2', '18408', '1294075298', '0', '0', '18408', '0');
INSERT INTO `auction` VALUES ('21413', '7', '39261', '24476', '2', '6644', '1294064498', '0', '0', '5182', '0');
INSERT INTO `auction` VALUES ('19983', '6', '37829', '44732', '2', '3280170', '1294071578', '0', '0', '2624136', '0');
INSERT INTO `auction` VALUES ('19688', '2', '37534', '13884', '2', '477', '1294057178', '0', '0', '472', '0');
INSERT INTO `auction` VALUES ('22383', '2', '40245', '9060', '2', '110080', '1294106844', '0', '0', '108979', '0');
INSERT INTO `auction` VALUES ('22221', '7', '40083', '21882', '2', '91500', '1294092384', '0', '0', '74115', '0');
INSERT INTO `auction` VALUES ('21811', '2', '39673', '1213', '2', '678', '1294121184', '0', '0', '555', '0');
INSERT INTO `auction` VALUES ('21973', '6', '39835', '27481', '2', '6', '1294135584', '0', '0', '4', '0');
INSERT INTO `auction` VALUES ('22129', '6', '39991', '1664', '2', '916245', '1294124784', '0', '0', '833782', '0');
INSERT INTO `auction` VALUES ('22346', '7', '40208', '1288', '2', '6956', '1294128384', '0', '0', '5495', '0');
INSERT INTO `auction` VALUES ('21412', '7', '39260', '4359', '2', '732', '1294060898', '0', '0', '578', '0');
INSERT INTO `auction` VALUES ('22118', '6', '39980', '5637', '2', '1872', '1294088784', '0', '0', '1684', '0');
INSERT INTO `auction` VALUES ('20092', '7', '37938', '3200', '2', '229', '1294053578', '0', '0', '203', '0');
INSERT INTO `auction` VALUES ('19675', '2', '37521', '14901', '2', '318934', '1294075178', '0', '0', '261525', '0');
INSERT INTO `auction` VALUES ('22547', '7', '40409', '3000', '2', '5054', '1294128444', '0', '0', '4295', '0');
INSERT INTO `auction` VALUES ('21868', '2', '39730', '4436', '2', '21226', '1294113984', '0', '0', '18254', '0');
INSERT INTO `auction` VALUES ('22583', '7', '40445', '39682', '2', '246240', '1294121244', '0', '0', '219153', '0');
INSERT INTO `auction` VALUES ('20359', '2', '38205', '36526', '2', '6654124', '1294053638', '0', '0', '6321417', '0');
INSERT INTO `auction` VALUES ('21768', '2', '39630', '7973', '2', '1383', '1294095984', '0', '0', '1106', '0');
INSERT INTO `auction` VALUES ('20902', '2', '38750', '6198', '2', '69964', '1294078898', '0', '0', '58070', '0');
INSERT INTO `auction` VALUES ('22218', '7', '40080', '2799', '2', '6358', '1294135584', '0', '0', '5086', '0');
INSERT INTO `auction` VALUES ('21724', '7', '39573', '24890', '2', '2100547', '1294068158', '0', '0', '1722448', '0');
INSERT INTO `auction` VALUES ('20374', '2', '38220', '9719', '2', '426750', '1294053638', '0', '0', '384075', '0');
INSERT INTO `auction` VALUES ('21974', '6', '39836', '12550', '2', '722528', '1294124784', '0', '0', '556346', '0');
INSERT INTO `auction` VALUES ('21878', '2', '39740', '9719', '2', '377500', '1294121184', '0', '0', '362400', '0');
INSERT INTO `auction` VALUES ('21879', '2', '39741', '39681', '2', '416976', '1294135584', '0', '0', '316901', '0');
INSERT INTO `auction` VALUES ('21525', '2', '39374', '10514', '2', '41220', '1294075358', '0', '0', '32563', '0');
INSERT INTO `auction` VALUES ('20215', '7', '38061', '40195', '2', '77220', '1294082378', '0', '0', '59459', '0');
INSERT INTO `auction` VALUES ('22274', '7', '40136', '39970', '2', '37440', '1294124784', '0', '0', '28080', '0');
INSERT INTO `auction` VALUES ('22210', '7', '40072', '25292', '2', '2916963', '1294131984', '0', '0', '2916963', '0');
INSERT INTO `auction` VALUES ('19859', '2', '37705', '12804', '2', '128000', '1294075178', '0', '0', '115200', '0');
INSERT INTO `auction` VALUES ('22444', '2', '40306', '10329', '2', '135034', '1294114044', '0', '0', '114778', '0');
INSERT INTO `auction` VALUES ('20992', '2', '38840', '36274', '2', '1645094', '1294068098', '0', '0', '1431231', '0');
INSERT INTO `auction` VALUES ('21881', '2', '39743', '4768', '2', '7182', '1294124784', '0', '0', '6679', '0');
INSERT INTO `auction` VALUES ('19786', '2', '37632', '24368', '2', '575640', '1294064378', '0', '0', '466268', '0');
INSERT INTO `auction` VALUES ('21132', '6', '38980', '8151', '2', '39440', '1294071698', '0', '0', '35496', '0');
INSERT INTO `auction` VALUES ('22382', '2', '40244', '37159', '2', '8360', '1294128444', '0', '0', '7440', '0');
INSERT INTO `auction` VALUES ('22663', '2', '40525', '27516', '2', '14040', '1294119668', '0', '0', '13759', '0');
INSERT INTO `auction` VALUES ('19959', '6', '37805', '9719', '2', '372500', '1294060778', '0', '0', '298000', '0');
INSERT INTO `auction` VALUES ('21411', '7', '39259', '1475', '2', '1498', '1294068098', '0', '0', '1438', '0');
INSERT INTO `auction` VALUES ('22283', '7', '40145', '21882', '2', '206700', '1294081584', '0', '0', '146757', '0');
INSERT INTO `auction` VALUES ('21410', '7', '39258', '32716', '2', '973000', '1294053698', '0', '0', '856240', '0');
INSERT INTO `auction` VALUES ('22397', '2', '40259', '24837', '2', '873263', '1294114044', '0', '0', '724808', '0');
INSERT INTO `auction` VALUES ('21591', '6', '39440', '4359', '2', '486', '1294064558', '0', '0', '393', '0');
INSERT INTO `auction` VALUES ('21924', '2', '39786', '36513', '2', '5629673', '1294081584', '0', '0', '4616331', '0');
INSERT INTO `auction` VALUES ('20214', '7', '38060', '2284', '2', '13335', '1294082378', '0', '0', '13335', '0');
INSERT INTO `auction` VALUES ('20696', '7', '38542', '1469', '2', '78411', '1294064438', '0', '0', '62728', '0');
INSERT INTO `auction` VALUES ('21475', '2', '39324', '36382', '2', '1696959', '1294057358', '0', '0', '1493323', '0');
INSERT INTO `auction` VALUES ('22079', '6', '39941', '1318', '2', '197629', '1294088784', '0', '0', '191700', '0');
INSERT INTO `auction` VALUES ('20315', '2', '38161', '18588', '2', '31680', '1294068038', '0', '0', '25977', '0');
INSERT INTO `auction` VALUES ('19850', '2', '37696', '9719', '2', '317250', '1294071578', '0', '0', '288697', '0');
INSERT INTO `auction` VALUES ('20666', '7', '38512', '9719', '2', '409500', '1294060838', '0', '0', '380835', '0');
INSERT INTO `auction` VALUES ('22703', '6', '40565', '36598', '2', '7436871', '1294126868', '0', '0', '6470077', '0');
INSERT INTO `auction` VALUES ('20361', '2', '38207', '36260', '2', '2955761', '1294071638', '0', '0', '2394166', '0');
INSERT INTO `auction` VALUES ('21823', '2', '39685', '9719', '2', '432500', '1294085184', '0', '0', '402225', '0');
INSERT INTO `auction` VALUES ('22180', '7', '40042', '9719', '2', '352500', '1294103184', '0', '0', '352500', '0');
INSERT INTO `auction` VALUES ('21982', '6', '39844', '4589', '2', '11575', '1294099584', '0', '0', '9954', '0');
INSERT INTO `auction` VALUES ('20408', '2', '38254', '3311', '2', '1584', '1294071638', '0', '0', '1520', '0');
INSERT INTO `auction` VALUES ('21975', '6', '39837', '37159', '2', '15015', '1294081584', '0', '0', '13513', '0');
INSERT INTO `auction` VALUES ('20392', '2', '38238', '16737', '2', '1202420', '1294053638', '0', '0', '1034081', '0');
INSERT INTO `auction` VALUES ('21305', '7', '39153', '4377', '2', '11100', '1294057298', '0', '0', '11100', '0');
INSERT INTO `auction` VALUES ('21796', '2', '39658', '1951', '2', '51774', '1294135584', '0', '0', '47632', '0');
INSERT INTO `auction` VALUES ('22008', '6', '39870', '31156', '2', '3154492', '1294131984', '0', '0', '2586683', '0');
INSERT INTO `auction` VALUES ('21408', '7', '39256', '40199', '2', '4140', '1294082498', '0', '0', '3519', '0');
INSERT INTO `auction` VALUES ('22417', '2', '40279', '19441', '2', '26160', '1294132044', '0', '0', '18312', '0');
INSERT INTO `auction` VALUES ('22273', '7', '40135', '3340', '2', '2925', '1294092384', '0', '0', '2486', '0');
INSERT INTO `auction` VALUES ('22077', '6', '39939', '16685', '2', '639009', '1294131984', '0', '0', '562327', '0');
INSERT INTO `auction` VALUES ('21824', '2', '39686', '5020', '2', '31', '1294103184', '0', '0', '25', '0');
INSERT INTO `auction` VALUES ('20212', '7', '38058', '9719', '2', '427000', '1294060778', '0', '0', '392840', '0');
INSERT INTO `auction` VALUES ('21477', '2', '39326', '1927', '2', '40928', '1294060958', '0', '0', '33560', '0');
INSERT INTO `auction` VALUES ('22394', '2', '40256', '4723', '2', '100938', '1294085244', '0', '0', '80750', '0');
INSERT INTO `auction` VALUES ('21703', '7', '39552', '12804', '2', '231840', '1294053758', '0', '0', '183153', '0');
INSERT INTO `auction` VALUES ('22300', '7', '40162', '39681', '2', '323904', '1294124784', '0', '0', '262362', '0');
INSERT INTO `auction` VALUES ('22658', '2', '40520', '24669', '2', '874709', '1294116068', '0', '0', '813479', '0');
INSERT INTO `auction` VALUES ('22009', '6', '39871', '9719', '2', '328250', '1294088784', '0', '0', '318402', '0');
INSERT INTO `auction` VALUES ('19834', '2', '37680', '22890', '2', '517600', '1294075178', '0', '0', '403728', '0');
INSERT INTO `auction` VALUES ('20586', '6', '38432', '24938', '2', '1986546', '1294078838', '0', '0', '1708429', '0');
INSERT INTO `auction` VALUES ('21131', '6', '38979', '8292', '2', '496936', '1294071698', '0', '0', '467119', '0');
INSERT INTO `auction` VALUES ('20695', '7', '38541', '36019', '2', '1205754', '1294053638', '0', '0', '1024890', '0');
INSERT INTO `auction` VALUES ('19762', '2', '37608', '37781', '2', '2565026', '1294053578', '0', '0', '1949419', '0');
INSERT INTO `auction` VALUES ('21910', '2', '39772', '36162', '2', '1222962', '1294088784', '0', '0', '1198502', '0');
INSERT INTO `auction` VALUES ('22018', '6', '39880', '9262', '2', '177840', '1294113984', '0', '0', '160056', '0');
INSERT INTO `auction` VALUES ('21825', '2', '39687', '9719', '2', '387500', '1294077984', '0', '0', '341000', '0');
INSERT INTO `auction` VALUES ('19687', '2', '37533', '13911', '2', '480', '1294071578', '0', '0', '340', '0');
INSERT INTO `auction` VALUES ('21826', '2', '39688', '1986', '2', '821857', '1294110384', '0', '0', '813638', '0');
INSERT INTO `auction` VALUES ('21984', '6', '39846', '9719', '2', '326000', '1294092384', '0', '0', '296660', '0');
INSERT INTO `auction` VALUES ('21952', '6', '39814', '2245', '2', '3882942', '1294128384', '0', '0', '3455818', '0');
INSERT INTO `auction` VALUES ('22130', '6', '39992', '36148', '2', '2326642', '1294099584', '0', '0', '2093977', '0');
INSERT INTO `auction` VALUES ('19847', '2', '37693', '12546', '2', '496302', '1294064378', '0', '0', '387115', '0');
INSERT INTO `auction` VALUES ('22520', '6', '40382', '36665', '2', '4727266', '1294092444', '0', '0', '4727266', '0');
INSERT INTO `auction` VALUES ('21396', '7', '39244', '40195', '2', '128520', '1294082498', '0', '0', '120808', '0');
INSERT INTO `auction` VALUES ('21001', '2', '38849', '36176', '2', '3719141', '1294068098', '0', '0', '3570375', '0');
INSERT INTO `auction` VALUES ('22403', '2', '40265', '4388', '2', '6720', '1294117644', '0', '0', '6182', '0');
INSERT INTO `auction` VALUES ('20521', '6', '38367', '18743', '2', '899375', '1294075238', '0', '0', '701512', '0');
INSERT INTO `auction` VALUES ('22029', '6', '39891', '36485', '2', '7253540', '1294081584', '0', '0', '6455650', '0');
INSERT INTO `auction` VALUES ('22542', '7', '40404', '24777', '2', '1634887', '1294110444', '0', '0', '1618538', '0');
INSERT INTO `auction` VALUES ('19686', '2', '37532', '5760', '2', '16980', '1294078778', '0', '0', '14093', '0');
INSERT INTO `auction` VALUES ('22694', '6', '40556', '14899', '2', '289037', '1294123268', '0', '0', '251462', '0');
INSERT INTO `auction` VALUES ('20968', '2', '38816', '2079', '2', '64072', '1294057298', '0', '0', '60227', '0');
INSERT INTO `auction` VALUES ('20967', '2', '38815', '9262', '2', '46200', '1294075298', '0', '0', '46200', '0');
INSERT INTO `auction` VALUES ('21085', '6', '38933', '10561', '2', '25280', '1294057298', '0', '0', '17696', '0');
INSERT INTO `auction` VALUES ('20679', '7', '38525', '5624', '2', '127617', '1294068038', '0', '0', '109750', '0');
INSERT INTO `auction` VALUES ('22381', '2', '40243', '44700', '2', '4950', '1294135644', '0', '0', '3663', '0');
INSERT INTO `auction` VALUES ('21708', '7', '39557', '4402', '2', '5370', '1294060958', '0', '0', '4027', '0');
INSERT INTO `auction` VALUES ('22124', '6', '39986', '44700', '2', '6200', '1294128384', '0', '0', '5890', '0');
INSERT INTO `auction` VALUES ('22125', '6', '39987', '12804', '2', '300000', '1294110384', '0', '0', '279000', '0');
INSERT INTO `auction` VALUES ('21037', '2', '38885', '24724', '2', '808742', '1294053698', '0', '0', '792567', '0');
INSERT INTO `auction` VALUES ('21168', '6', '39016', '13422', '2', '1394', '1294082498', '0', '0', '1101', '0');
INSERT INTO `auction` VALUES ('20600', '6', '38446', '5020', '2', '28', '1294064438', '0', '0', '22', '0');
INSERT INTO `auction` VALUES ('22256', '7', '40118', '9719', '2', '404250', '1294113984', '0', '0', '375952', '0');
INSERT INTO `auction` VALUES ('22446', '2', '40308', '37147', '2', '7785', '1294092444', '0', '0', '7785', '0');
INSERT INTO `auction` VALUES ('21989', '6', '39851', '44750', '2', '62080', '1294131984', '0', '0', '60838', '0');
INSERT INTO `auction` VALUES ('22330', '7', '40192', '44700', '2', '5300', '1294077984', '0', '0', '5300', '0');
INSERT INTO `auction` VALUES ('22447', '6', '40309', '3042', '2', '235288', '1294110444', '0', '0', '195289', '0');
INSERT INTO `auction` VALUES ('22563', '7', '40425', '2080', '2', '366118', '1294099644', '0', '0', '351473', '0');
INSERT INTO `auction` VALUES ('19795', '2', '37641', '9719', '2', '373250', '1294082378', '0', '0', '287402', '0');
INSERT INTO `auction` VALUES ('21876', '2', '39738', '31564', '2', '2662653', '1294121184', '0', '0', '2502893', '0');
INSERT INTO `auction` VALUES ('20964', '2', '38812', '4387', '2', '10176', '1294075298', '0', '0', '7530', '0');
INSERT INTO `auction` VALUES ('19970', '6', '37816', '45998', '2', '432', '1294057178', '0', '0', '349', '0');
INSERT INTO `auction` VALUES ('22392', '2', '40254', '10141', '2', '849541', '1294092444', '0', '0', '688128', '0');
INSERT INTO `auction` VALUES ('21233', '6', '39081', '3074', '2', '29167', '1294053698', '0', '0', '28291', '0');
INSERT INTO `auction` VALUES ('22580', '7', '40442', '19441', '2', '54240', '1294135644', '0', '0', '41222', '0');
INSERT INTO `auction` VALUES ('21731', '7', '39580', '4660', '2', '19135', '1294071758', '0', '0', '17030', '0');
INSERT INTO `auction` VALUES ('22581', '7', '40443', '36528', '2', '4750981', '1294117644', '0', '0', '4323392', '0');
INSERT INTO `auction` VALUES ('20231', '7', '38077', '9719', '2', '319500', '1294053578', '0', '0', '309915', '0');
INSERT INTO `auction` VALUES ('20977', '2', '38825', '37147', '2', '16380', '1294064498', '0', '0', '15397', '0');
INSERT INTO `auction` VALUES ('20955', '2', '38803', '37159', '2', '24300', '1294057298', '0', '0', '18225', '0');
INSERT INTO `auction` VALUES ('22600', '7', '40462', '6358', '2', '30', '1294099644', '0', '0', '21', '0');
INSERT INTO `auction` VALUES ('22476', '6', '40338', '3902', '2', '78013', '1294117644', '0', '0', '73332', '0');
INSERT INTO `auction` VALUES ('21160', '6', '39008', '10560', '2', '38400', '1294068098', '0', '0', '30336', '0');
INSERT INTO `auction` VALUES ('22270', '7', '40132', '20679', '2', '73280', '1294088784', '0', '0', '71814', '0');
INSERT INTO `auction` VALUES ('20444', '2', '38290', '1440', '2', '81575', '1294071638', '0', '0', '73417', '0');
INSERT INTO `auction` VALUES ('21045', '2', '38893', '892', '2', '20202', '1294057298', '0', '0', '17373', '0');
INSERT INTO `auction` VALUES ('20658', '6', '38504', '9719', '2', '412750', '1294053638', '0', '0', '379730', '0');
INSERT INTO `auction` VALUES ('22161', '7', '40023', '9719', '2', '372250', '1294077984', '0', '0', '279187', '0');
INSERT INTO `auction` VALUES ('20635', '6', '38481', '36049', '2', '2213417', '1294071638', '0', '0', '2147014', '0');
INSERT INTO `auction` VALUES ('22126', '6', '39988', '37147', '2', '11950', '1294088784', '0', '0', '9918', '0');
INSERT INTO `auction` VALUES ('21101', '6', '38949', '814', '2', '4320', '1294064498', '0', '0', '4276', '0');
INSERT INTO `auction` VALUES ('21082', '6', '38930', '36397', '2', '3585157', '1294064498', '0', '0', '3083235', '0');
INSERT INTO `auction` VALUES ('21235', '6', '39083', '37160', '2', '19805', '1294064498', '0', '0', '15844', '0');
INSERT INTO `auction` VALUES ('22646', '2', '40508', '1475', '2', '3382', '1294130468', '0', '0', '3246', '0');
INSERT INTO `auction` VALUES ('20624', '6', '38470', '9719', '2', '343000', '1294068038', '0', '0', '305270', '0');
INSERT INTO `auction` VALUES ('22552', '7', '40414', '40195', '2', '38700', '1294124844', '0', '0', '29799', '0');
INSERT INTO `auction` VALUES ('20536', '6', '38382', '37157', '2', '13840', '1294075238', '0', '0', '12317', '0');
INSERT INTO `auction` VALUES ('22671', '6', '40533', '9391', '2', '952746', '1294123268', '0', '0', '933691', '0');
INSERT INTO `auction` VALUES ('19791', '2', '37637', '9719', '2', '428000', '1294064378', '0', '0', '321000', '0');
INSERT INTO `auction` VALUES ('21883', '2', '39745', '10514', '2', '52140', '1294095984', '0', '0', '46926', '0');
INSERT INTO `auction` VALUES ('22582', '7', '40444', '25124', '2', '4547297', '1294110444', '0', '0', '4001621', '0');
INSERT INTO `auction` VALUES ('22458', '6', '40320', '18588', '2', '8520', '1294099644', '0', '0', '7412', '0');
INSERT INTO `auction` VALUES ('20962', '2', '38810', '36626', '2', '5149162', '1294071698', '0', '0', '4634245', '0');
INSERT INTO `auction` VALUES ('20702', '7', '38548', '31244', '2', '2118895', '1294071638', '0', '0', '1610360', '0');
INSERT INTO `auction` VALUES ('20487', '6', '38333', '9719', '2', '415250', '1294057238', '0', '0', '415250', '0');
INSERT INTO `auction` VALUES ('22448', '6', '40310', '24892', '2', '1447603', '1294114044', '0', '0', '1360746', '0');
INSERT INTO `auction` VALUES ('21835', '2', '39697', '43624', '2', '52290', '1294113984', '0', '0', '49675', '0');
INSERT INTO `auction` VALUES ('21834', '2', '39696', '9719', '2', '374750', '1294092384', '0', '0', '322285', '0');
INSERT INTO `auction` VALUES ('22449', '6', '40311', '1458', '2', '124349', '1294110444', '0', '0', '99479', '0');
INSERT INTO `auction` VALUES ('22560', '7', '40422', '20655', '2', '403908', '1294096044', '0', '0', '387751', '0');
INSERT INTO `auction` VALUES ('21288', '7', '39136', '25312', '2', '2560823', '1294071698', '0', '0', '2227916', '0');
INSERT INTO `auction` VALUES ('21891', '2', '39753', '9719', '2', '343250', '1294121184', '0', '0', '302060', '0');
INSERT INTO `auction` VALUES ('22236', '7', '40098', '18512', '2', '72000', '1294117584', '0', '0', '52560', '0');
INSERT INTO `auction` VALUES ('22170', '7', '40032', '20518', '2', '33740', '1294131984', '0', '0', '24967', '0');
INSERT INTO `auction` VALUES ('20249', '7', '38095', '4387', '2', '14336', '1294064378', '0', '0', '13619', '0');
INSERT INTO `auction` VALUES ('22518', '6', '40380', '20655', '2', '444983', '1294128444', '0', '0', '418284', '0');
INSERT INTO `auction` VALUES ('21564', '6', '39413', '4611', '2', '420', '1294060958', '0', '0', '399', '0');
INSERT INTO `auction` VALUES ('22574', '7', '40436', '8245', '2', '578950', '1294092444', '0', '0', '503686', '0');
INSERT INTO `auction` VALUES ('19778', '2', '37624', '45909', '2', '34880', '1294082378', '0', '0', '31392', '0');
INSERT INTO `auction` VALUES ('22061', '6', '39923', '9375', '2', '340586', '1294124784', '0', '0', '272468', '0');
INSERT INTO `auction` VALUES ('21767', '2', '39629', '3844', '2', '495145', '1294110384', '0', '0', '450581', '0');
INSERT INTO `auction` VALUES ('20097', '7', '37943', '31164', '2', '1879878', '1294053578', '0', '0', '1673091', '0');
INSERT INTO `auction` VALUES ('22387', '2', '40249', '5524', '2', '1210', '1294081644', '0', '0', '1016', '0');
INSERT INTO `auction` VALUES ('20693', '7', '38539', '9719', '2', '386250', '1294078838', '0', '0', '301275', '0');
INSERT INTO `auction` VALUES ('21819', '2', '39681', '16651', '2', '545', '1294110384', '0', '0', '523', '0');
INSERT INTO `auction` VALUES ('21079', '6', '38927', '2077', '2', '315441', '1294060898', '0', '0', '305977', '0');
INSERT INTO `auction` VALUES ('21106', '6', '38954', '4388', '2', '6560', '1294068098', '0', '0', '4854', '0');
INSERT INTO `auction` VALUES ('20703', '7', '38549', '3329', '2', '1379', '1294071638', '0', '0', '1034', '0');
INSERT INTO `auction` VALUES ('21078', '6', '38926', '36514', '2', '7141398', '1294071698', '0', '0', '6712914', '0');
INSERT INTO `auction` VALUES ('22571', '7', '40433', '17963', '2', '10111', '1294110444', '0', '0', '8897', '0');
INSERT INTO `auction` VALUES ('19870', '6', '37716', '37147', '2', '15260', '1294071578', '0', '0', '14802', '0');
INSERT INTO `auction` VALUES ('22406', '2', '40268', '36682', '2', '6918773', '1294085244', '0', '0', '5604206', '0');
INSERT INTO `auction` VALUES ('22127', '6', '39989', '24890', '2', '2172228', '1294121184', '0', '0', '1889838', '0');
INSERT INTO `auction` VALUES ('22553', '7', '40415', '24685', '2', '761757', '1294128444', '0', '0', '754139', '0');
INSERT INTO `auction` VALUES ('19985', '6', '37831', '9719', '2', '362250', '1294078778', '0', '0', '318780', '0');
INSERT INTO `auction` VALUES ('22516', '6', '40378', '7072', '2', '3648', '1294099644', '0', '0', '3319', '0');
INSERT INTO `auction` VALUES ('22720', '7', '40582', '4632', '2', '1908', '1294134068', '0', '0', '1698', '0');
INSERT INTO `auction` VALUES ('21863', '2', '39725', '13035', '2', '1762412', '1294110384', '0', '0', '1392305', '0');
INSERT INTO `auction` VALUES ('21755', '2', '39617', '39682', '2', '295200', '1294077984', '0', '0', '212544', '0');
INSERT INTO `auction` VALUES ('21949', '2', '39811', '10561', '2', '8520', '1294121184', '0', '0', '6986', '0');
INSERT INTO `auction` VALUES ('22102', '6', '39964', '9719', '2', '358500', '1294106784', '0', '0', '322650', '0');
INSERT INTO `auction` VALUES ('19984', '6', '37830', '9719', '2', '424250', '1294067978', '0', '0', '330915', '0');
INSERT INTO `auction` VALUES ('20026', '6', '37872', '9719', '2', '395500', '1294057178', '0', '0', '328265', '0');
INSERT INTO `auction` VALUES ('19677', '2', '37523', '14368', '2', '3200', '1294071578', '0', '0', '2592', '0');
INSERT INTO `auction` VALUES ('19807', '2', '37653', '814', '2', '1240', '1294057178', '0', '0', '942', '0');
INSERT INTO `auction` VALUES ('21385', '7', '39233', '27516', '2', '3660', '1294064498', '0', '0', '2964', '0');
INSERT INTO `auction` VALUES ('22409', '2', '40271', '25222', '2', '4924224', '1294128444', '0', '0', '4874981', '0');
INSERT INTO `auction` VALUES ('22396', '2', '40258', '25033', '2', '958679', '1294092444', '0', '0', '949092', '0');
INSERT INTO `auction` VALUES ('22309', '7', '40171', '36044', '2', '1378998', '1294088784', '0', '0', '1337628', '0');
INSERT INTO `auction` VALUES ('20133', '7', '37979', '9719', '2', '330000', '1294071578', '0', '0', '313500', '0');
INSERT INTO `auction` VALUES ('22640', '2', '40502', '816', '2', '20398', '1294087268', '0', '0', '18154', '0');
INSERT INTO `auction` VALUES ('20152', '7', '37998', '9719', '2', '383500', '1294053578', '0', '0', '371995', '0');
INSERT INTO `auction` VALUES ('19731', '2', '37577', '30741', '2', '9293018', '1294075178', '0', '0', '8084925', '0');
INSERT INTO `auction` VALUES ('22728', '7', '40590', '22641', '2', '4890', '1294126868', '0', '0', '4596', '0');
INSERT INTO `auction` VALUES ('22128', '6', '39990', '10562', '2', '141000', '1294113984', '0', '0', '133950', '0');
INSERT INTO `auction` VALUES ('21807', '2', '39669', '14170', '2', '2565', '1294095984', '0', '0', '2257', '0');
INSERT INTO `auction` VALUES ('21420', '7', '39268', '4785', '2', '32314', '1294060898', '0', '0', '28436', '0');
INSERT INTO `auction` VALUES ('22736', '7', '40598', '36526', '2', '5296368', '1294108868', '0', '0', '5031549', '0');
INSERT INTO `auction` VALUES ('19783', '2', '37629', '27513', '2', '161', '1294064378', '0', '0', '161', '0');
INSERT INTO `auction` VALUES ('22097', '6', '39959', '9719', '2', '360500', '1294110384', '0', '0', '331660', '0');
INSERT INTO `auction` VALUES ('22245', '7', '40107', '2194', '2', '262963', '1294088784', '0', '0', '220888', '0');
INSERT INTO `auction` VALUES ('22375', '2', '40237', '1405', '2', '58647', '1294117644', '0', '0', '49849', '0');
INSERT INTO `auction` VALUES ('22587', '7', '40449', '2266', '2', '32178', '1294117644', '0', '0', '28960', '0');
INSERT INTO `auction` VALUES ('21217', '6', '39065', '4723', '2', '115929', '1294057298', '0', '0', '106654', '0');
INSERT INTO `auction` VALUES ('20530', '6', '38376', '19268', '2', '1725000', '1294078838', '0', '0', '1569750', '0');
INSERT INTO `auction` VALUES ('22014', '6', '39876', '10559', '2', '26760', '1294092384', '0', '0', '25957', '0');
INSERT INTO `auction` VALUES ('21117', '6', '38965', '39681', '2', '151424', '1294053698', '0', '0', '121139', '0');
INSERT INTO `auction` VALUES ('20557', '6', '38403', '16652', '2', '482', '1294082438', '0', '0', '428', '0');
INSERT INTO `auction` VALUES ('21462', '7', '39310', '9061', '2', '35000', '1294071698', '0', '0', '34650', '0');
INSERT INTO `auction` VALUES ('20589', '6', '38435', '24886', '2', '1118346', '1294064438', '0', '0', '972961', '0');
INSERT INTO `auction` VALUES ('22426', '2', '40288', '7973', '2', '2075', '1294078044', '0', '0', '1597', '0');
INSERT INTO `auction` VALUES ('21935', '2', '39797', '24949', '2', '1081802', '1294117584', '0', '0', '1070983', '0');
INSERT INTO `auction` VALUES ('22730', '7', '40592', '9719', '2', '418750', '1294112468', '0', '0', '418750', '0');
INSERT INTO `auction` VALUES ('20340', '2', '38186', '9719', '2', '391250', '1294064438', '0', '0', '367775', '0');
INSERT INTO `auction` VALUES ('22618', '7', '40480', '6358', '2', '319', '1294081644', '0', '0', '267', '0');
INSERT INTO `auction` VALUES ('21654', '6', '39503', '27516', '2', '11160', '1294078958', '0', '0', '8146', '0');
INSERT INTO `auction` VALUES ('21029', '2', '38877', '20408', '2', '133553', '1294082498', '0', '0', '121533', '0');
INSERT INTO `auction` VALUES ('22076', '6', '39938', '36062', '2', '1515857', '1294095984', '0', '0', '1333954', '0');
INSERT INTO `auction` VALUES ('22278', '7', '40140', '9719', '2', '415500', '1294113984', '0', '0', '390570', '0');
INSERT INTO `auction` VALUES ('20649', '6', '38495', '36269', '2', '2965015', '1294082438', '0', '0', '2965015', '0');
INSERT INTO `auction` VALUES ('21095', '6', '38943', '36154', '2', '1731246', '1294057298', '0', '0', '1419621', '0');
INSERT INTO `auction` VALUES ('21809', '2', '39671', '9719', '2', '359750', '1294128384', '0', '0', '316580', '0');
INSERT INTO `auction` VALUES ('21218', '6', '39066', '28498', '2', '1004201', '1294060898', '0', '0', '923864', '0');
INSERT INTO `auction` VALUES ('22085', '6', '39947', '13422', '2', '1195', '1294131984', '0', '0', '1075', '0');
INSERT INTO `auction` VALUES ('20172', '7', '38018', '9719', '2', '422750', '1294071578', '0', '0', '363565', '0');
INSERT INTO `auction` VALUES ('22086', '6', '39948', '34859', '2', '404461', '1294077984', '0', '0', '283122', '0');
INSERT INTO `auction` VALUES ('22036', '6', '39898', '35836', '2', '181200', '1294081584', '0', '0', '154020', '0');
INSERT INTO `auction` VALUES ('22037', '6', '39899', '5637', '2', '2844', '1294117584', '0', '0', '2019', '0');
INSERT INTO `auction` VALUES ('22689', '6', '40551', '9719', '2', '392500', '1294116068', '0', '0', '325775', '0');
INSERT INTO `auction` VALUES ('22167', '7', '40029', '9719', '2', '347250', '1294095984', '0', '0', '309052', '0');
INSERT INTO `auction` VALUES ('22598', '7', '40460', '18512', '2', '112000', '1294078044', '0', '0', '108640', '0');
INSERT INTO `auction` VALUES ('20078', '7', '37924', '14552', '2', '6045023', '1294075178', '0', '0', '5380070', '0');
INSERT INTO `auction` VALUES ('21568', '6', '39417', '1288', '2', '3537', '1294064558', '0', '0', '3112', '0');
INSERT INTO `auction` VALUES ('21810', '2', '39672', '1720', '2', '2031244', '1294110384', '0', '0', '1909369', '0');
INSERT INTO `auction` VALUES ('21540', '2', '39389', '1280', '2', '184635', '1294053758', '0', '0', '147708', '0');
INSERT INTO `auction` VALUES ('20014', '6', '37860', '31564', '2', '3632036', '1294057178', '0', '0', '3523074', '0');
INSERT INTO `auction` VALUES ('20422', '2', '38268', '27516', '2', '24000', '1294075238', '0', '0', '19200', '0');
INSERT INTO `auction` VALUES ('22543', '7', '40405', '36457', '2', '3951479', '1294085244', '0', '0', '3240212', '0');
INSERT INTO `auction` VALUES ('21983', '6', '39845', '44145', '2', '84000', '1294121184', '0', '0', '69720', '0');
INSERT INTO `auction` VALUES ('22642', '2', '40504', '36061', '2', '2339611', '1294119668', '0', '0', '1965273', '0');
INSERT INTO `auction` VALUES ('21118', '6', '38966', '9061', '2', '10050', '1294071698', '0', '0', '8442', '0');
INSERT INTO `auction` VALUES ('22740', '7', '40602', '4359', '2', '288', '1294126868', '0', '0', '233', '0');
INSERT INTO `auction` VALUES ('21362', '7', '39210', '1679', '2', '564634', '1294053698', '0', '0', '474292', '0');
INSERT INTO `auction` VALUES ('21728', '7', '39577', '36055', '2', '1843058', '1294078958', '0', '0', '1585029', '0');
INSERT INTO `auction` VALUES ('22456', '6', '40318', '36526', '2', '4931682', '1294128444', '0', '0', '4043979', '0');
INSERT INTO `auction` VALUES ('22589', '7', '40451', '6358', '2', '489', '1294081644', '0', '0', '410', '0');
INSERT INTO `auction` VALUES ('22038', '6', '39900', '31125', '2', '2544494', '1294135584', '0', '0', '2213709', '0');
INSERT INTO `auction` VALUES ('20645', '6', '38491', '4439', '2', '103750', '1294082438', '0', '0', '101675', '0');
INSERT INTO `auction` VALUES ('22659', '2', '40521', '4359', '2', '1719', '1294116068', '0', '0', '1358', '0');
INSERT INTO `auction` VALUES ('20664', '7', '38510', '9719', '2', '359000', '1294053638', '0', '0', '290790', '0');
INSERT INTO `auction` VALUES ('22219', '7', '40081', '3279', '2', '1130', '1294110384', '0', '0', '1005', '0');
INSERT INTO `auction` VALUES ('20091', '7', '37937', '9719', '2', '361000', '1294071578', '0', '0', '314070', '0');
INSERT INTO `auction` VALUES ('20232', '7', '38078', '9719', '2', '413750', '1294067978', '0', '0', '351687', '0');
INSERT INTO `auction` VALUES ('21745', '7', '39594', '24609', '2', '1151947', '1294071758', '0', '0', '956116', '0');
INSERT INTO `auction` VALUES ('21872', '2', '39734', '31211', '2', '3166062', '1294095984', '0', '0', '2437867', '0');
INSERT INTO `auction` VALUES ('21440', '7', '39288', '10560', '2', '29760', '1294064498', '0', '0', '21129', '0');
INSERT INTO `auction` VALUES ('20062', '6', '37908', '21595', '2', '1770', '1294053578', '0', '0', '1256', '0');
INSERT INTO `auction` VALUES ('21762', '2', '39624', '9719', '2', '436750', '1294117584', '0', '0', '397442', '0');
INSERT INTO `auction` VALUES ('21836', '2', '39698', '42780', '2', '70048', '1294099584', '0', '0', '56038', '0');
INSERT INTO `auction` VALUES ('21859', '2', '39721', '12531', '2', '1831207', '1294124784', '0', '0', '1556525', '0');
INSERT INTO `auction` VALUES ('20646', '6', '38492', '4447', '2', '60028', '1294082438', '0', '0', '60028', '0');
INSERT INTO `auction` VALUES ('22310', '7', '40172', '45909', '2', '35520', '1294124784', '0', '0', '26995', '0');
INSERT INTO `auction` VALUES ('20647', '6', '38493', '10514', '2', '7380', '1294082438', '0', '0', '7011', '0');
INSERT INTO `auction` VALUES ('22172', '7', '40034', '9428', '2', '142450', '1294092384', '0', '0', '141025', '0');
INSERT INTO `auction` VALUES ('21111', '6', '38959', '10514', '2', '21480', '1294071698', '0', '0', '16110', '0');
INSERT INTO `auction` VALUES ('20121', '7', '37967', '9719', '2', '370500', '1294078778', '0', '0', '285285', '0');
INSERT INTO `auction` VALUES ('20959', '2', '38807', '36527', '2', '5728274', '1294071698', '0', '0', '4983598', '0');
INSERT INTO `auction` VALUES ('21534', '2', '39383', '36161', '2', '1647262', '1294078958', '0', '0', '1416645', '0');
INSERT INTO `auction` VALUES ('21375', '7', '39223', '1475', '2', '1623', '1294078898', '0', '0', '1412', '0');
INSERT INTO `auction` VALUES ('22465', '6', '40327', '31256', '2', '41702', '1294081644', '0', '0', '33361', '0');
INSERT INTO `auction` VALUES ('21746', '7', '39595', '36381', '2', '4910956', '1294053758', '0', '0', '4910956', '0');
INSERT INTO `auction` VALUES ('22057', '6', '39919', '31249', '2', '1621347', '1294103184', '0', '0', '1329504', '0');
INSERT INTO `auction` VALUES ('20336', '2', '38182', '9719', '2', '434250', '1294078838', '0', '0', '330030', '0');
INSERT INTO `auction` VALUES ('21576', '6', '39425', '36045', '2', '2708876', '1294057358', '0', '0', '2302544', '0');
INSERT INTO `auction` VALUES ('21374', '7', '39222', '39682', '2', '308160', '1294075298', '0', '0', '261936', '0');
INSERT INTO `auction` VALUES ('21561', '6', '39410', '36178', '2', '1160226', '1294060958', '0', '0', '986192', '0');
INSERT INTO `auction` VALUES ('22066', '6', '39928', '9719', '2', '323250', '1294128384', '0', '0', '268297', '0');
INSERT INTO `auction` VALUES ('20423', '2', '38269', '3321', '2', '509', '1294053638', '0', '0', '468', '0');
INSERT INTO `auction` VALUES ('20527', '6', '38373', '1288', '2', '3640', '1294075238', '0', '0', '2875', '0');
INSERT INTO `auction` VALUES ('21837', '2', '39699', '35557', '2', '199', '1294099584', '0', '0', '177', '0');
INSERT INTO `auction` VALUES ('20946', '2', '38794', '36266', '2', '1771050', '1294082498', '0', '0', '1487682', '0');
INSERT INTO `auction` VALUES ('22554', '7', '40416', '920', '2', '147418', '1294088844', '0', '0', '140047', '0');
INSERT INTO `auction` VALUES ('20995', '2', '38843', '18512', '2', '75520', '1294060898', '0', '0', '73254', '0');
INSERT INTO `auction` VALUES ('22655', '2', '40517', '24887', '2', '1742541', '1294112468', '0', '0', '1742541', '0');
INSERT INTO `auction` VALUES ('21793', '2', '39655', '9719', '2', '345500', '1294077984', '0', '0', '297130', '0');
INSERT INTO `auction` VALUES ('21818', '2', '39680', '9719', '2', '354750', '1294106784', '0', '0', '354750', '0');
INSERT INTO `auction` VALUES ('22067', '6', '39929', '10405', '2', '3394', '1294077984', '0', '0', '2511', '0');
INSERT INTO `auction` VALUES ('22706', '6', '40568', '36394', '2', '2628229', '1294126868', '0', '0', '2575664', '0');
INSERT INTO `auction` VALUES ('20700', '7', '38546', '9719', '2', '429000', '1294057238', '0', '0', '407550', '0');
INSERT INTO `auction` VALUES ('19995', '6', '37841', '30739', '2', '15089080', '1294060778', '0', '0', '14787298', '0');
INSERT INTO `auction` VALUES ('22181', '7', '40043', '9719', '2', '340500', '1294131984', '0', '0', '262185', '0');
INSERT INTO `auction` VALUES ('21330', '7', '39178', '1355', '2', '13446', '1294057298', '0', '0', '11966', '0');
INSERT INTO `auction` VALUES ('22039', '6', '39901', '9719', '2', '433000', '1294092384', '0', '0', '376710', '0');
INSERT INTO `auction` VALUES ('21907', '2', '39769', '3164', '2', '2192', '1294128384', '0', '0', '1907', '0');
INSERT INTO `auction` VALUES ('22632', '2', '40494', '12552', '2', '736771', '1294119668', '0', '0', '685197', '0');
INSERT INTO `auction` VALUES ('22262', '7', '40124', '41119', '2', '1540', '1294131984', '0', '0', '1262', '0');
INSERT INTO `auction` VALUES ('20086', '7', '37932', '51958', '2', '4677121', '1294053578', '0', '0', '4022324', '0');
INSERT INTO `auction` VALUES ('20606', '6', '38452', '36283', '2', '2123184', '1294053638', '0', '0', '2038256', '0');
INSERT INTO `auction` VALUES ('22353', '2', '40215', '36386', '2', '2045221', '1294124844', '0', '0', '1697533', '0');
INSERT INTO `auction` VALUES ('20461', '2', '38307', '1958', '2', '60474', '1294057238', '0', '0', '51402', '0');
INSERT INTO `auction` VALUES ('19704', '2', '37550', '35580', '2', '2645982', '1294053578', '0', '0', '2407843', '0');
INSERT INTO `auction` VALUES ('21328', '7', '39176', '25208', '2', '3560461', '1294082498', '0', '0', '3026391', '0');
INSERT INTO `auction` VALUES ('22275', '7', '40137', '25047', '2', '1393094', '1294110384', '0', '0', '1295577', '0');
INSERT INTO `auction` VALUES ('19668', '2', '37514', '1288', '2', '1768', '1294053578', '0', '0', '1379', '0');
INSERT INTO `auction` VALUES ('21898', '2', '39760', '36276', '2', '2720083', '1294110384', '0', '0', '2284869', '0');
INSERT INTO `auction` VALUES ('20688', '7', '38534', '31227', '2', '1510287', '1294071638', '0', '0', '1374361', '0');
INSERT INTO `auction` VALUES ('21014', '2', '38862', '27515', '2', '3280', '1294078898', '0', '0', '2624', '0');
INSERT INTO `auction` VALUES ('20733', '7', '38579', '28533', '2', '1446711', '1294071638', '0', '0', '1345441', '0');
INSERT INTO `auction` VALUES ('20140', '7', '37986', '22276', '2', '17', '1294064378', '0', '0', '12', '0');
INSERT INTO `auction` VALUES ('21786', '2', '39648', '2824', '2', '3747744', '1294077984', '0', '0', '3148104', '0');
INSERT INTO `auction` VALUES ('22412', '2', '40274', '24827', '2', '2036634', '1294085244', '0', '0', '1873703', '0');
INSERT INTO `auction` VALUES ('20144', '7', '37990', '9719', '2', '342750', '1294067978', '0', '0', '284482', '0');
INSERT INTO `auction` VALUES ('22685', '6', '40547', '30724', '2', '12527450', '1294119668', '0', '0', '10147234', '0');
INSERT INTO `auction` VALUES ('22098', '6', '39960', '9719', '2', '315750', '1294081584', '0', '0', '299962', '0');
INSERT INTO `auction` VALUES ('21560', '6', '39409', '37147', '2', '9480', '1294057358', '0', '0', '8058', '0');
INSERT INTO `auction` VALUES ('19933', '6', '37779', '29425', '2', '221200', '1294075178', '0', '0', '205716', '0');
INSERT INTO `auction` VALUES ('22087', '6', '39949', '9719', '2', '376750', '1294117584', '0', '0', '327772', '0');
INSERT INTO `auction` VALUES ('19760', '2', '37606', '18612', '2', '350', '1294053578', '0', '0', '245', '0');
INSERT INTO `auction` VALUES ('22635', '2', '40497', '36159', '2', '2007421', '1294130468', '0', '0', '1746456', '0');
INSERT INTO `auction` VALUES ('19709', '2', '37555', '2740', '2', '8280', '1294064378', '0', '0', '6789', '0');
INSERT INTO `auction` VALUES ('22472', '6', '40334', '36061', '2', '2507037', '1294110444', '0', '0', '2181122', '0');
INSERT INTO `auction` VALUES ('21808', '2', '39670', '9759', '2', '1290', '1294110384', '0', '0', '1135', '0');
INSERT INTO `auction` VALUES ('21986', '6', '39848', '25874', '2', '0', '1294106784', '0', '0', '0', '0');
INSERT INTO `auction` VALUES ('22733', '7', '40595', '36394', '2', '2275908', '1294116068', '0', '0', '1957280', '0');
INSERT INTO `auction` VALUES ('22641', '2', '40503', '24999', '2', '2116021', '1294108868', '0', '0', '1883258', '0');
INSERT INTO `auction` VALUES ('21664', '7', '39513', '36045', '2', '1790398', '1294071758', '0', '0', '1575550', '0');
INSERT INTO `auction` VALUES ('21552', '2', '39401', '10561', '2', '61200', '1294068158', '0', '0', '45288', '0');
INSERT INTO `auction` VALUES ('21838', '2', '39700', '24827', '2', '1835639', '1294077984', '0', '0', '1541936', '0');
INSERT INTO `auction` VALUES ('20135', '7', '37981', '9061', '2', '49600', '1294064378', '0', '0', '48112', '0');
INSERT INTO `auction` VALUES ('22074', '6', '39936', '31189', '2', '1359503', '1294085184', '0', '0', '1359503', '0');
INSERT INTO `auction` VALUES ('22443', '2', '40305', '5755', '2', '204316', '1294124844', '0', '0', '183884', '0');
INSERT INTO `auction` VALUES ('21839', '2', '39701', '28452', '2', '3507', '1294113984', '0', '0', '2525', '0');
INSERT INTO `auction` VALUES ('22312', '7', '40174', '36043', '2', '855994', '1294113984', '0', '0', '753274', '0');
INSERT INTO `auction` VALUES ('20394', '2', '38240', '9719', '2', '408250', '1294064438', '0', '0', '371507', '0');
INSERT INTO `auction` VALUES ('20629', '6', '38475', '2265', '2', '28202', '1294082438', '0', '0', '26509', '0');
INSERT INTO `auction` VALUES ('22016', '6', '39878', '6205', '2', '41433', '1294117584', '0', '0', '37704', '0');
INSERT INTO `auction` VALUES ('20862', '7', '38708', '36457', '2', '4792293', '1294082438', '0', '0', '3833834', '0');
INSERT INTO `auction` VALUES ('22308', '7', '40170', '1288', '2', '3862', '1294124784', '0', '0', '3050', '0');
INSERT INTO `auction` VALUES ('20729', '7', '38575', '18588', '2', '23504', '1294053638', '0', '0', '18568', '0');
INSERT INTO `auction` VALUES ('22313', '7', '40175', '18512', '2', '181600', '1294081584', '0', '0', '136200', '0');
INSERT INTO `auction` VALUES ('21842', '2', '39704', '2055', '2', '192', '1294106784', '0', '0', '134', '0');
INSERT INTO `auction` VALUES ('19703', '2', '37549', '31228', '2', '1395318', '1294067978', '0', '0', '1046488', '0');
INSERT INTO `auction` VALUES ('21182', '6', '39030', '814', '2', '1840', '1294053698', '0', '0', '1306', '0');
INSERT INTO `auction` VALUES ('21203', '6', '39051', '36415', '2', '1458495', '1294064498', '0', '0', '1312645', '0');
INSERT INTO `auction` VALUES ('22735', '7', '40597', '9719', '2', '380250', '1294134068', '0', '0', '308002', '0');
INSERT INTO `auction` VALUES ('21950', '2', '39812', '24476', '2', '8400', '1294110384', '0', '0', '6300', '0');
INSERT INTO `auction` VALUES ('20945', '2', '38793', '9060', '2', '160360', '1294068098', '0', '0', '112252', '0');
INSERT INTO `auction` VALUES ('22203', '7', '40065', '2911', '2', '34597', '1294092384', '0', '0', '26985', '0');
INSERT INTO `auction` VALUES ('20337', '2', '38183', '24834', '2', '1791167', '1294068038', '0', '0', '1576226', '0');
INSERT INTO `auction` VALUES ('22361', '2', '40223', '2167', '2', '22658', '1294135644', '0', '0', '19032', '0');
INSERT INTO `auction` VALUES ('20633', '6', '38479', '27515', '2', '9240', '1294057238', '0', '0', '7946', '0');
INSERT INTO `auction` VALUES ('21058', '2', '38906', '9262', '2', '87360', '1294068098', '0', '0', '77750', '0');
INSERT INTO `auction` VALUES ('19720', '2', '37566', '2282', '2', '1080', '1294075178', '0', '0', '1026', '0');
INSERT INTO `auction` VALUES ('21057', '2', '38905', '36553', '2', '6552385', '1294068098', '0', '0', '5372955', '0');
INSERT INTO `auction` VALUES ('22136', '6', '39998', '9262', '2', '58320', '1294121184', '0', '0', '41990', '0');
INSERT INTO `auction` VALUES ('21998', '6', '39860', '5020', '2', '31', '1294088784', '0', '0', '27', '0');
INSERT INTO `auction` VALUES ('20241', '7', '38087', '13023', '2', '2461774', '1294078778', '0', '0', '2092507', '0');
INSERT INTO `auction` VALUES ('21353', '7', '39201', '18512', '2', '150400', '1294060898', '0', '0', '141376', '0');
INSERT INTO `auction` VALUES ('21615', '6', '39464', '25327', '2', '4232327', '1294057358', '0', '0', '3936064', '0');
INSERT INTO `auction` VALUES ('20297', '2', '38143', '24101', '2', '6612000', '1294078838', '0', '0', '5818560', '0');
INSERT INTO `auction` VALUES ('21841', '2', '39703', '20406', '2', '108699', '1294095984', '0', '0', '96742', '0');
INSERT INTO `auction` VALUES ('20460', '2', '38306', '5524', '2', '2846', '1294064438', '0', '0', '2817', '0');
INSERT INTO `auction` VALUES ('22027', '6', '39889', '9719', '2', '372250', '1294110384', '0', '0', '364805', '0');
INSERT INTO `auction` VALUES ('21056', '2', '38904', '37159', '2', '12180', '1294082498', '0', '0', '9744', '0');
INSERT INTO `auction` VALUES ('22501', '6', '40363', '19441', '2', '24120', '1294092444', '0', '0', '20743', '0');
INSERT INTO `auction` VALUES ('20431', '2', '38277', '9759', '2', '1621', '1294064438', '0', '0', '1394', '0');
INSERT INTO `auction` VALUES ('20240', '7', '38086', '31233', '2', '2286698', '1294082378', '0', '0', '1875092', '0');
INSERT INTO `auction` VALUES ('20058', '6', '37904', '25320', '2', '3798194', '1294078778', '0', '0', '3456356', '0');
INSERT INTO `auction` VALUES ('22345', '7', '40207', '4716', '2', '90487', '1294128384', '0', '0', '79628', '0');
INSERT INTO `auction` VALUES ('20146', '7', '37992', '2034', '2', '71366', '1294060778', '0', '0', '61374', '0');
INSERT INTO `auction` VALUES ('22093', '6', '39955', '9719', '2', '392500', '1294092384', '0', '0', '368950', '0');
INSERT INTO `auction` VALUES ('21775', '2', '39637', '7973', '2', '1110', '1294131984', '0', '0', '1098', '0');
INSERT INTO `auction` VALUES ('21877', '2', '39739', '9719', '2', '429500', '1294088784', '0', '0', '343600', '0');
INSERT INTO `auction` VALUES ('21941', '2', '39803', '25320', '2', '4210668', '1294121184', '0', '0', '4084347', '0');
INSERT INTO `auction` VALUES ('22639', '2', '40501', '13905', '2', '170', '1294087268', '0', '0', '130', '0');
INSERT INTO `auction` VALUES ('21040', '2', '38888', '6205', '2', '56613', '1294082498', '0', '0', '53782', '0');
INSERT INTO `auction` VALUES ('19759', '2', '37605', '12804', '2', '72320', '1294064378', '0', '0', '61472', '0');
INSERT INTO `auction` VALUES ('20741', '7', '38587', '44147', '2', '96800', '1294064438', '0', '0', '73568', '0');
INSERT INTO `auction` VALUES ('20447', '2', '38293', '9719', '2', '366500', '1294082438', '0', '0', '355505', '0');
INSERT INTO `auction` VALUES ('20498', '6', '38344', '9719', '2', '422500', '1294053638', '0', '0', '359125', '0');
INSERT INTO `auction` VALUES ('22709', '6', '40571', '24889', '2', '1204635', '1294137668', '0', '0', '1120310', '0');
INSERT INTO `auction` VALUES ('21584', '6', '39433', '36556', '2', '6287145', '1294064558', '0', '0', '6035659', '0');
INSERT INTO `auction` VALUES ('20677', '7', '38523', '44475', '2', '192', '1294060838', '0', '0', '182', '0');
INSERT INTO `auction` VALUES ('20822', '7', '38668', '753', '2', '173100', '1294075238', '0', '0', '162714', '0');
INSERT INTO `auction` VALUES ('20774', '7', '38620', '31179', '2', '1470992', '1294071638', '0', '0', '1470992', '0');
INSERT INTO `auction` VALUES ('22082', '6', '39944', '4402', '2', '3400', '1294077984', '0', '0', '3332', '0');
INSERT INTO `auction` VALUES ('21544', '2', '39393', '1986', '2', '656148', '1294071758', '0', '0', '636463', '0');
INSERT INTO `auction` VALUES ('19857', '2', '37703', '24938', '2', '2057494', '1294060778', '0', '0', '1934044', '0');
INSERT INTO `auction` VALUES ('22117', '6', '39979', '24601', '2', '1173065', '1294085184', '0', '0', '1137873', '0');
INSERT INTO `auction` VALUES ('19895', '6', '37741', '9719', '2', '323500', '1294053578', '0', '0', '281445', '0');
INSERT INTO `auction` VALUES ('21041', '2', '38889', '4589', '2', '31609', '1294071698', '0', '0', '27815', '0');
INSERT INTO `auction` VALUES ('19758', '2', '37604', '2748', '2', '17010', '1294064378', '0', '0', '12587', '0');
INSERT INTO `auction` VALUES ('21953', '6', '39815', '866', '2', '945197', '1294103184', '0', '0', '812869', '0');
INSERT INTO `auction` VALUES ('21892', '2', '39754', '35979', '2', '1133039', '1294095984', '0', '0', '997074', '0');
INSERT INTO `auction` VALUES ('19757', '2', '37603', '36386', '2', '2600621', '1294067978', '0', '0', '2080496', '0');
INSERT INTO `auction` VALUES ('21604', '6', '39453', '5758', '2', '8540', '1294064558', '0', '0', '7515', '0');
INSERT INTO `auction` VALUES ('22171', '7', '40033', '2825', '2', '2161925', '1294117584', '0', '0', '1902494', '0');
INSERT INTO `auction` VALUES ('19868', '6', '37714', '9061', '2', '20070', '1294082378', '0', '0', '18865', '0');
INSERT INTO `auction` VALUES ('20167', '7', '38013', '40199', '2', '7740', '1294064378', '0', '0', '6501', '0');
INSERT INTO `auction` VALUES ('21882', '2', '39744', '9719', '2', '374500', '1294110384', '0', '0', '355775', '0');
INSERT INTO `auction` VALUES ('22338', '7', '40200', '36395', '2', '2061088', '1294121184', '0', '0', '1793146', '0');
INSERT INTO `auction` VALUES ('20015', '6', '37861', '4454', '2', '312582', '1294071578', '0', '0', '240688', '0');
INSERT INTO `auction` VALUES ('21940', '2', '39802', '7072', '2', '3708', '1294131984', '0', '0', '3633', '0');
INSERT INTO `auction` VALUES ('21042', '2', '38890', '36581', '2', '6258660', '1294064498', '0', '0', '5883140', '0');
INSERT INTO `auction` VALUES ('19809', '2', '37655', '13908', '2', '437', '1294067978', '0', '0', '319', '0');
INSERT INTO `auction` VALUES ('20201', '7', '38047', '39682', '2', '109440', '1294064378', '0', '0', '94118', '0');
INSERT INTO `auction` VALUES ('22596', '7', '40458', '44700', '2', '4500', '1294088844', '0', '0', '4365', '0');
INSERT INTO `auction` VALUES ('20721', '7', '38567', '5637', '2', '1692', '1294075238', '0', '0', '1658', '0');
INSERT INTO `auction` VALUES ('20129', '7', '37975', '4359', '2', '808', '1294075178', '0', '0', '719', '0');
INSERT INTO `auction` VALUES ('22269', '7', '40131', '36286', '2', '1952709', '1294124784', '0', '0', '1855073', '0');
INSERT INTO `auction` VALUES ('22680', '6', '40542', '9719', '2', '433500', '1294101668', '0', '0', '433500', '0');
INSERT INTO `auction` VALUES ('22483', '6', '40345', '39681', '2', '62832', '1294078044', '0', '0', '61575', '0');
INSERT INTO `auction` VALUES ('21551', '2', '39400', '10560', '2', '33280', '1294071758', '0', '0', '32614', '0');
INSERT INTO `auction` VALUES ('22674', '6', '40536', '10562', '2', '16560', '1294112468', '0', '0', '14904', '0');
INSERT INTO `auction` VALUES ('19929', '6', '37775', '4387', '2', '35840', '1294064378', '0', '0', '31897', '0');
INSERT INTO `auction` VALUES ('20399', '2', '38245', '9719', '2', '369750', '1294082438', '0', '0', '354960', '0');
INSERT INTO `auction` VALUES ('20915', '2', '38763', '8152', '2', '27540', '1294075298', '0', '0', '23684', '0');
INSERT INTO `auction` VALUES ('22696', '6', '40558', '39682', '2', '164160', '1294083668', '0', '0', '128044', '0');
INSERT INTO `auction` VALUES ('21914', '2', '39776', '5742', '2', '455596', '1294088784', '0', '0', '451040', '0');
INSERT INTO `auction` VALUES ('21622', '6', '39471', '36556', '2', '6033119', '1294068158', '0', '0', '4947157', '0');
INSERT INTO `auction` VALUES ('22421', '2', '40283', '45909', '2', '15040', '1294085244', '0', '0', '13836', '0');
INSERT INTO `auction` VALUES ('22253', '7', '40115', '13885', '2', '442', '1294135584', '0', '0', '384', '0');
INSERT INTO `auction` VALUES ('21183', '6', '39031', '5752', '2', '182844', '1294060898', '0', '0', '146275', '0');
INSERT INTO `auction` VALUES ('20540', '6', '38386', '9719', '2', '387250', '1294064438', '0', '0', '336907', '0');
INSERT INTO `auction` VALUES ('21871', '2', '39733', '8292', '2', '608833', '1294124784', '0', '0', '560126', '0');
INSERT INTO `auction` VALUES ('20711', '7', '38557', '24935', '2', '1678490', '1294057238', '0', '0', '1577780', '0');
INSERT INTO `auction` VALUES ('22468', '6', '40330', '39681', '2', '360640', '1294096044', '0', '0', '292118', '0');
INSERT INTO `auction` VALUES ('20069', '7', '37915', '1722', '2', '1285753', '1294064378', '0', '0', '1157177', '0');
INSERT INTO `auction` VALUES ('22012', '6', '39874', '9719', '2', '377750', '1294106784', '0', '0', '309755', '0');
INSERT INTO `auction` VALUES ('20874', '2', '38722', '2079', '2', '52397', '1294053698', '0', '0', '47157', '0');
INSERT INTO `auction` VALUES ('22080', '6', '39942', '6294', '2', '64', '1294077984', '0', '0', '56', '0');
INSERT INTO `auction` VALUES ('22505', '6', '40367', '1639', '2', '1263632', '1294081644', '0', '0', '1061450', '0');
INSERT INTO `auction` VALUES ('19780', '2', '37626', '35665', '2', '2529271', '1294078778', '0', '0', '2099294', '0');
INSERT INTO `auction` VALUES ('22347', '7', '40209', '4394', '2', '32550', '1294131984', '0', '0', '25389', '0');
INSERT INTO `auction` VALUES ('21133', '6', '38981', '8152', '2', '17600', '1294060898', '0', '0', '12672', '0');
INSERT INTO `auction` VALUES ('21270', '7', '39118', '5029', '2', '282085', '1294064498', '0', '0', '273622', '0');
INSERT INTO `auction` VALUES ('21074', '6', '38922', '21882', '2', '458000', '1294068098', '0', '0', '435100', '0');
INSERT INTO `auction` VALUES ('22251', '7', '40113', '31165', '2', '1412751', '1294124784', '0', '0', '1229093', '0');
INSERT INTO `auction` VALUES ('21920', '2', '39782', '36168', '2', '2844551', '1294081584', '0', '0', '2503204', '0');
INSERT INTO `auction` VALUES ('19888', '6', '37734', '16714', '2', '694470', '1294067978', '0', '0', '569465', '0');
INSERT INTO `auction` VALUES ('19823', '2', '37669', '9719', '2', '390500', '1294057178', '0', '0', '312400', '0');
INSERT INTO `auction` VALUES ('22034', '6', '39896', '37156', '2', '14820', '1294117584', '0', '0', '11856', '0');
INSERT INTO `auction` VALUES ('20895', '2', '38743', '6333', '2', '134354', '1294060898', '0', '0', '133010', '0');
INSERT INTO `auction` VALUES ('20725', '7', '38571', '5523', '2', '1599', '1294071638', '0', '0', '1199', '0');
INSERT INTO `auction` VALUES ('22495', '6', '40357', '7072', '2', '2232', '1294103244', '0', '0', '2008', '0');
INSERT INTO `auction` VALUES ('22619', '7', '40481', '27515', '2', '12240', '1294121244', '0', '0', '11260', '0');
INSERT INTO `auction` VALUES ('21901', '2', '39763', '19441', '2', '65100', '1294128384', '0', '0', '47523', '0');
INSERT INTO `auction` VALUES ('21849', '2', '39711', '8152', '2', '11580', '1294099584', '0', '0', '8685', '0');
INSERT INTO `auction` VALUES ('19935', '6', '37781', '17413', '2', '498480', '1294064378', '0', '0', '498480', '0');
INSERT INTO `auction` VALUES ('22202', '7', '40064', '13909', '2', '446', '1294103184', '0', '0', '388', '0');
INSERT INTO `auction` VALUES ('22477', '6', '40339', '36040', '2', '2353276', '1294114044', '0', '0', '1929686', '0');
INSERT INTO `auction` VALUES ('22666', '2', '40528', '45909', '2', '53088', '1294105268', '0', '0', '42470', '0');
INSERT INTO `auction` VALUES ('20712', '7', '38558', '23909', '2', '58', '1294053638', '0', '0', '52', '0');
INSERT INTO `auction` VALUES ('21156', '6', '39004', '36066', '2', '1138828', '1294068098', '0', '0', '1070498', '0');
INSERT INTO `auction` VALUES ('21939', '2', '39801', '2013', '2', '235258', '1294124784', '0', '0', '232905', '0');
INSERT INTO `auction` VALUES ('22678', '6', '40540', '18710', '2', '521240', '1294090868', '0', '0', '479540', '0');
INSERT INTO `auction` VALUES ('20842', '7', '38688', '40195', '2', '45090', '1294078838', '0', '0', '31563', '0');
INSERT INTO `auction` VALUES ('21761', '2', '39623', '2020', '2', '47512', '1294121184', '0', '0', '39434', '0');
INSERT INTO `auction` VALUES ('20714', '7', '38560', '37159', '2', '2370', '1294082438', '0', '0', '1730', '0');
INSERT INTO `auction` VALUES ('22040', '6', '39902', '18343', '2', '666466', '1294110384', '0', '0', '546502', '0');
INSERT INTO `auction` VALUES ('22620', '7', '40482', '21882', '2', '70000', '1294099644', '0', '0', '61600', '0');
INSERT INTO `auction` VALUES ('21794', '2', '39656', '5183', '2', '80829', '1294095984', '0', '0', '61430', '0');
INSERT INTO `auction` VALUES ('22551', '7', '40413', '866', '2', '1038385', '1294096044', '0', '0', '1017617', '0');
INSERT INTO `auction` VALUES ('20833', '7', '38679', '18677', '2', '747079', '1294078838', '0', '0', '612604', '0');
INSERT INTO `auction` VALUES ('21893', '2', '39755', '24836', '2', '1095920', '1294077984', '0', '0', '898654', '0');
INSERT INTO `auction` VALUES ('21249', '6', '39097', '914', '2', '184469', '1294075298', '0', '0', '160488', '0');
INSERT INTO `auction` VALUES ('19755', '2', '37601', '9719', '2', '413250', '1294082378', '0', '0', '314070', '0');
INSERT INTO `auction` VALUES ('22637', '2', '40499', '10407', '2', '5270', '1294134068', '0', '0', '4901', '0');
INSERT INTO `auction` VALUES ('20840', '7', '38686', '2971', '2', '882', '1294053638', '0', '0', '617', '0');
INSERT INTO `auction` VALUES ('21832', '2', '39694', '37160', '2', '16830', '1294117584', '0', '0', '15315', '0');
INSERT INTO `auction` VALUES ('19832', '2', '37678', '18295', '2', '850162', '1294078778', '0', '0', '824657', '0');
INSERT INTO `auction` VALUES ('22454', '6', '40316', '25268', '2', '2646718', '1294092444', '0', '0', '2461447', '0');
INSERT INTO `auction` VALUES ('21549', '2', '39398', '24608', '2', '656781', '1294082558', '0', '0', '525424', '0');
INSERT INTO `auction` VALUES ('20619', '6', '38465', '1213', '2', '814', '1294075238', '0', '0', '569', '0');
INSERT INTO `auction` VALUES ('20597', '6', '38443', '36062', '2', '891616', '1294082438', '0', '0', '882699', '0');
INSERT INTO `auction` VALUES ('21096', '6', '38944', '24716', '2', '688125', '1294082498', '0', '0', '605550', '0');
INSERT INTO `auction` VALUES ('20296', '2', '38142', '36539', '2', '5728155', '1294078838', '0', '0', '5269902', '0');
INSERT INTO `auction` VALUES ('20386', '2', '38232', '6359', '2', '772', '1294078838', '0', '0', '748', '0');
INSERT INTO `auction` VALUES ('21388', '7', '39236', '18588', '2', '7200', '1294057298', '0', '0', '6624', '0');
INSERT INTO `auction` VALUES ('22717', '6', '40579', '36178', '2', '1347849', '1294137668', '0', '0', '1078279', '0');
INSERT INTO `auction` VALUES ('21482', '2', '39331', '36264', '2', '2776894', '1294075358', '0', '0', '2360359', '0');
INSERT INTO `auction` VALUES ('22695', '6', '40557', '9719', '2', '386000', '1294126868', '0', '0', '293360', '0');
INSERT INTO `auction` VALUES ('22612', '7', '40474', '36065', '2', '2094194', '1294121244', '0', '0', '1968542', '0');
INSERT INTO `auction` VALUES ('22356', '2', '40218', '4589', '2', '12592', '1294103244', '0', '0', '9444', '0');
INSERT INTO `auction` VALUES ('19919', '6', '37765', '4694', '2', '4844', '1294060778', '0', '0', '3536', '0');
INSERT INTO `auction` VALUES ('21894', '2', '39756', '36456', '2', '2770382', '1294085184', '0', '0', '2714974', '0');
INSERT INTO `auction` VALUES ('22188', '7', '40050', '6294', '2', '64', '1294077984', '0', '0', '56', '0');
INSERT INTO `auction` VALUES ('22311', '7', '40173', '10246', '2', '950774', '1294092384', '0', '0', '817665', '0');
INSERT INTO `auction` VALUES ('22105', '6', '39967', '31234', '2', '6719690', '1294110384', '0', '0', '5846130', '0');
INSERT INTO `auction` VALUES ('20838', '7', '38684', '9719', '2', '381000', '1294053638', '0', '0', '304800', '0');
INSERT INTO `auction` VALUES ('21159', '6', '39007', '36781', '2', '1664', '1294075298', '0', '0', '1264', '0');
INSERT INTO `auction` VALUES ('19915', '6', '37761', '1981', '2', '2140972', '1294057178', '0', '0', '2076742', '0');
INSERT INTO `auction` VALUES ('20501', '6', '38347', '31160', '2', '2658180', '1294075238', '0', '0', '2126544', '0');
INSERT INTO `auction` VALUES ('20837', '7', '38683', '24607', '2', '1169570', '1294064438', '0', '0', '1052613', '0');
INSERT INTO `auction` VALUES ('22195', '7', '40057', '20543', '2', '53550', '1294117584', '0', '0', '46588', '0');
INSERT INTO `auction` VALUES ('19725', '2', '37571', '1265', '2', '881947', '1294075178', '0', '0', '846669', '0');
INSERT INTO `auction` VALUES ('21759', '2', '39621', '812', '2', '9921236', '1294077984', '0', '0', '8036201', '0');
INSERT INTO `auction` VALUES ('22567', '7', '40429', '1677', '2', '546546', '1294114044', '0', '0', '453633', '0');
INSERT INTO `auction` VALUES ('22156', '7', '40018', '19258', '2', '1701000', '1294088784', '0', '0', '1701000', '0');
INSERT INTO `auction` VALUES ('19900', '6', '37746', '9719', '2', '321500', '1294053578', '0', '0', '241125', '0');
INSERT INTO `auction` VALUES ('20621', '6', '38467', '9719', '2', '329000', '1294060838', '0', '0', '302680', '0');
INSERT INTO `auction` VALUES ('22377', '2', '40239', '8251', '2', '607634', '1294081644', '0', '0', '607634', '0');
INSERT INTO `auction` VALUES ('20453', '2', '38299', '24890', '2', '1290247', '1294053638', '0', '0', '1161222', '0');
INSERT INTO `auction` VALUES ('19858', '2', '37704', '22529', '2', '258720', '1294064378', '0', '0', '256132', '0');
INSERT INTO `auction` VALUES ('22555', '7', '40417', '2020', '2', '59062', '1294135644', '0', '0', '59062', '0');
INSERT INTO `auction` VALUES ('20458', '2', '38304', '9719', '2', '334500', '1294075238', '0', '0', '254220', '0');
INSERT INTO `auction` VALUES ('22565', '7', '40427', '885', '2', '101589', '1294106844', '0', '0', '87366', '0');
INSERT INTO `auction` VALUES ('22282', '7', '40144', '37145', '2', '12480', '1294077984', '0', '0', '9360', '0');
INSERT INTO `auction` VALUES ('20295', '2', '38141', '4444', '2', '86345', '1294082438', '0', '0', '72529', '0');
INSERT INTO `auction` VALUES ('20680', '7', '38526', '31254', '2', '1764148', '1294060838', '0', '0', '1446601', '0');
INSERT INTO `auction` VALUES ('22201', '7', '40063', '40195', '2', '79920', '1294131984', '0', '0', '78321', '0');
INSERT INTO `auction` VALUES ('21200', '6', '39048', '28496', '2', '967994', '1294064498', '0', '0', '871194', '0');
INSERT INTO `auction` VALUES ('20836', '7', '38682', '41119', '2', '9480', '1294071638', '0', '0', '6636', '0');
INSERT INTO `auction` VALUES ('20321', '2', '38167', '6206', '2', '5333', '1294078838', '0', '0', '4319', '0');
INSERT INTO `auction` VALUES ('22558', '7', '40420', '25075', '2', '2168621', '1294092444', '0', '0', '2081876', '0');
INSERT INTO `auction` VALUES ('21421', '7', '39269', '6358', '2', '391', '1294057298', '0', '0', '344', '0');
INSERT INTO `auction` VALUES ('21239', '6', '39087', '4394', '2', '82620', '1294064498', '0', '0', '59486', '0');
INSERT INTO `auction` VALUES ('21020', '2', '38868', '25158', '2', '3744800', '1294060898', '0', '0', '2995840', '0');
INSERT INTO `auction` VALUES ('22738', '7', '40600', '44677', '2', '7298839', '1294080068', '0', '0', '6131024', '0');
INSERT INTO `auction` VALUES ('20809', '7', '38655', '9719', '2', '338250', '1294053638', '0', '0', '270600', '0');
INSERT INTO `auction` VALUES ('19701', '2', '37547', '20540', '2', '23900', '1294064378', '0', '0', '18164', '0');
INSERT INTO `auction` VALUES ('22194', '7', '40056', '4302', '2', '1317', '1294124784', '0', '0', '1040', '0');
INSERT INTO `auction` VALUES ('22239', '7', '40101', '4387', '2', '11424', '1294103184', '0', '0', '9024', '0');
INSERT INTO `auction` VALUES ('19841', '2', '37687', '9719', '2', '338750', '1294075178', '0', '0', '264225', '0');
INSERT INTO `auction` VALUES ('22544', '7', '40406', '832', '2', '8718', '1294088844', '0', '0', '8282', '0');
INSERT INTO `auction` VALUES ('22163', '7', '40025', '5756', '2', '675304', '1294103184', '0', '0', '661797', '0');
INSERT INTO `auction` VALUES ('21764', '2', '39626', '9719', '2', '323500', '1294081584', '0', '0', '307325', '0');
INSERT INTO `auction` VALUES ('20194', '7', '38040', '2975', '2', '1303', '1294075178', '0', '0', '1159', '0');
INSERT INTO `auction` VALUES ('22217', '7', '40079', '31231', '2', '1157325', '1294113984', '0', '0', '1122605', '0');
INSERT INTO `auction` VALUES ('22636', '2', '40498', '9308', '2', '732', '1294090868', '0', '0', '651', '0');
INSERT INTO `auction` VALUES ('22135', '6', '39997', '5758', '2', '12050', '1294106784', '0', '0', '11809', '0');
INSERT INTO `auction` VALUES ('21874', '2', '39736', '9719', '2', '407500', '1294113984', '0', '0', '399350', '0');
INSERT INTO `auction` VALUES ('22437', '2', '40299', '1394', '2', '42365', '1294114044', '0', '0', '38975', '0');
INSERT INTO `auction` VALUES ('21147', '6', '38995', '18588', '2', '27000', '1294060898', '0', '0', '25650', '0');
INSERT INTO `auction` VALUES ('22469', '6', '40331', '5524', '2', '489', '1294078044', '0', '0', '405', '0');
INSERT INTO `auction` VALUES ('20958', '2', '38806', '18588', '2', '17472', '1294060898', '0', '0', '12929', '0');
INSERT INTO `auction` VALUES ('21954', '6', '39816', '5079', '2', '206312', '1294077984', '0', '0', '179491', '0');
INSERT INTO `auction` VALUES ('22059', '6', '39921', '24999', '2', '1783605', '1294131984', '0', '0', '1676588', '0');
INSERT INTO `auction` VALUES ('19679', '2', '37525', '8151', '2', '37240', '1294060778', '0', '0', '35005', '0');
INSERT INTO `auction` VALUES ('20571', '6', '38417', '6364', '2', '3615', '1294078838', '0', '0', '3145', '0');
INSERT INTO `auction` VALUES ('22223', '7', '40085', '36413', '2', '1714402', '1294077984', '0', '0', '1577249', '0');
INSERT INTO `auction` VALUES ('19883', '6', '37729', '9719', '2', '435500', '1294078778', '0', '0', '365820', '0');
INSERT INTO `auction` VALUES ('21240', '6', '39088', '36382', '2', '2001968', '1294071698', '0', '0', '1781751', '0');
INSERT INTO `auction` VALUES ('21170', '6', '39018', '31270', '2', '55076', '1294078898', '0', '0', '47916', '0');
INSERT INTO `auction` VALUES ('22222', '7', '40084', '2057', '2', '122', '1294092384', '0', '0', '114', '0');
INSERT INTO `auction` VALUES ('22731', '7', '40593', '13882', '2', '412', '1294083668', '0', '0', '399', '0');
INSERT INTO `auction` VALUES ('21464', '2', '39313', '32715', '2', '853000', '1294053758', '0', '0', '767700', '0');
INSERT INTO `auction` VALUES ('21742', '7', '39591', '25000', '2', '2123431', '1294064558', '0', '0', '1741213', '0');
INSERT INTO `auction` VALUES ('22159', '7', '40021', '9262', '2', '57280', '1294110384', '0', '0', '50406', '0');
INSERT INTO `auction` VALUES ('22322', '7', '40184', '1457', '2', '128126', '1294106784', '0', '0', '121719', '0');
INSERT INTO `auction` VALUES ('19765', '2', '37611', '44475', '2', '176', '1294064378', '0', '0', '147', '0');
INSERT INTO `auction` VALUES ('21867', '2', '39729', '40195', '2', '85320', '1294106784', '0', '0', '76788', '0');
INSERT INTO `auction` VALUES ('20665', '7', '38511', '4359', '2', '1900', '1294053638', '0', '0', '1539', '0');
INSERT INTO `auction` VALUES ('21644', '6', '39493', '36458', '2', '3475501', '1294064558', '0', '0', '2954175', '0');
INSERT INTO `auction` VALUES ('20193', '7', '38039', '18676', '2', '980656', '1294057178', '0', '0', '755105', '0');
INSERT INTO `auction` VALUES ('20368', '2', '38214', '9719', '2', '394250', '1294075238', '0', '0', '350882', '0');
INSERT INTO `auction` VALUES ('22398', '2', '40260', '8251', '2', '486832', '1294128444', '0', '0', '438148', '0');
INSERT INTO `auction` VALUES ('22718', '6', '40580', '24605', '2', '719951', '1294101668', '0', '0', '583160', '0');
INSERT INTO `auction` VALUES ('21905', '2', '39767', '24621', '2', '801546', '1294095984', '0', '0', '673298', '0');
INSERT INTO `auction` VALUES ('21741', '7', '39590', '1625', '2', '986345', '1294057358', '0', '0', '976481', '0');
INSERT INTO `auction` VALUES ('22579', '7', '40441', '19943', '2', '37920', '1294088844', '0', '0', '28819', '0');
INSERT INTO `auction` VALUES ('21558', '2', '39407', '9327', '2', '21000', '1294075358', '0', '0', '21000', '0');
INSERT INTO `auction` VALUES ('21812', '2', '39674', '31562', '2', '3745890', '1294095984', '0', '0', '3408759', '0');
INSERT INTO `auction` VALUES ('22373', '2', '40235', '36486', '2', '7515996', '1294117644', '0', '0', '7440836', '0');
INSERT INTO `auction` VALUES ('21517', '2', '39366', '14826', '2', '227016', '1294064558', '0', '0', '208854', '0');
INSERT INTO `auction` VALUES ('22220', '7', '40082', '9719', '2', '349750', '1294110384', '0', '0', '300785', '0');
INSERT INTO `auction` VALUES ('22132', '6', '39994', '5524', '2', '3265', '1294131984', '0', '0', '2481', '0');
INSERT INTO `auction` VALUES ('22576', '7', '40438', '28496', '2', '916434', '1294124844', '0', '0', '742311', '0');
INSERT INTO `auction` VALUES ('21643', '6', '39492', '36781', '2', '38560', '1294071758', '0', '0', '31233', '0');
INSERT INTO `auction` VALUES ('21897', '2', '39759', '6359', '2', '277', '1294117584', '0', '0', '221', '0');
INSERT INTO `auction` VALUES ('19994', '6', '37840', '867', '2', '803203', '1294071578', '0', '0', '787138', '0');
INSERT INTO `auction` VALUES ('20126', '7', '37972', '31268', '2', '53906', '1294082378', '0', '0', '45281', '0');
INSERT INTO `auction` VALUES ('21946', '2', '39808', '814', '2', '2996', '1294113984', '0', '0', '2456', '0');
INSERT INTO `auction` VALUES ('21642', '6', '39491', '18512', '2', '107520', '1294082558', '0', '0', '80640', '0');
INSERT INTO `auction` VALUES ('22540', '6', '40402', '10559', '2', '109140', '1294081644', '0', '0', '82946', '0');
INSERT INTO `auction` VALUES ('21721', '7', '39570', '3330', '2', '19234', '1294057358', '0', '0', '15964', '0');
INSERT INTO `auction` VALUES ('21925', '2', '39787', '34846', '2', '264795', '1294121184', '0', '0', '243611', '0');
INSERT INTO `auction` VALUES ('20106', '7', '37952', '27513', '2', '153', '1294064378', '0', '0', '120', '0');
INSERT INTO `auction` VALUES ('22487', '6', '40349', '44700', '2', '5500', '1294121244', '0', '0', '4290', '0');
INSERT INTO `auction` VALUES ('21864', '2', '39726', '44475', '2', '156', '1294113984', '0', '0', '124', '0');
INSERT INTO `auction` VALUES ('21926', '2', '39788', '6358', '2', '382', '1294077984', '0', '0', '374', '0');
INSERT INTO `auction` VALUES ('20917', '2', '38765', '4394', '2', '131400', '1294060898', '0', '0', '122202', '0');
INSERT INTO `auction` VALUES ('21489', '2', '39338', '2078', '2', '53670', '1294057358', '0', '0', '49913', '0');
INSERT INTO `auction` VALUES ('21934', '2', '39796', '4611', '2', '9480', '1294135584', '0', '0', '9480', '0');
INSERT INTO `auction` VALUES ('20593', '6', '38439', '16654', '2', '422', '1294078838', '0', '0', '375', '0');
INSERT INTO `auction` VALUES ('21648', '6', '39497', '1288', '2', '8584', '1294071758', '0', '0', '7124', '0');
INSERT INTO `auction` VALUES ('22244', '7', '40106', '9719', '2', '355500', '1294124784', '0', '0', '287955', '0');
INSERT INTO `auction` VALUES ('20542', '6', '38388', '754', '2', '2023529', '1294060838', '0', '0', '1537882', '0');
INSERT INTO `auction` VALUES ('20033', '6', '37879', '4402', '2', '1670', '1294064378', '0', '0', '1519', '0');
INSERT INTO `auction` VALUES ('20367', '2', '38213', '9719', '2', '387500', '1294064438', '0', '0', '348750', '0');
INSERT INTO `auction` VALUES ('22734', '7', '40596', '31161', '2', '2748206', '1294137668', '0', '0', '2198564', '0');
INSERT INTO `auction` VALUES ('22249', '7', '40111', '31248', '2', '2708915', '1294128384', '0', '0', '2627647', '0');
INSERT INTO `auction` VALUES ('22280', '7', '40142', '24780', '2', '708255', '1294110384', '0', '0', '665759', '0');
INSERT INTO `auction` VALUES ('20287', '2', '38133', '34827', '2', '1381844', '1294060838', '0', '0', '1160748', '0');
INSERT INTO `auction` VALUES ('19982', '6', '37828', '9719', '2', '399250', '1294064378', '0', '0', '383280', '0');
INSERT INTO `auction` VALUES ('20195', '7', '38041', '4302', '2', '1537', '1294067978', '0', '0', '1244', '0');
INSERT INTO `auction` VALUES ('22500', '6', '40362', '2822', '2', '88293', '1294124844', '0', '0', '82995', '0');
INSERT INTO `auction` VALUES ('20538', '6', '38384', '24776', '2', '1062501', '1294057238', '0', '0', '977500', '0');
INSERT INTO `auction` VALUES ('22183', '7', '40045', '31564', '2', '3457883', '1294124784', '0', '0', '2662569', '0');
INSERT INTO `auction` VALUES ('22179', '7', '40041', '30740', '2', '10939085', '1294095984', '0', '0', '9298222', '0');
INSERT INTO `auction` VALUES ('20715', '7', '38561', '8151', '2', '35400', '1294071638', '0', '0', '29382', '0');
INSERT INTO `auction` VALUES ('20312', '2', '38158', '5267', '2', '4665090', '1294071638', '0', '0', '3872024', '0');
INSERT INTO `auction` VALUES ('19981', '6', '37827', '44700', '2', '4300', '1294071578', '0', '0', '3483', '0');
INSERT INTO `auction` VALUES ('21108', '6', '38956', '36148', '2', '2485746', '1294075298', '0', '0', '2386316', '0');
INSERT INTO `auction` VALUES ('21119', '6', '38967', '24599', '2', '991345', '1294064498', '0', '0', '961604', '0');
INSERT INTO `auction` VALUES ('21900', '2', '39762', '36050', '2', '971214', '1294088784', '0', '0', '835244', '0');
INSERT INTO `auction` VALUES ('20307', '2', '38153', '5635', '2', '1935', '1294057238', '0', '0', '1548', '0');
INSERT INTO `auction` VALUES ('22538', '6', '40400', '9061', '2', '15890', '1294117644', '0', '0', '14301', '0');
INSERT INTO `auction` VALUES ('21758', '2', '39620', '22393', '2', '843700', '1294081584', '0', '0', '708708', '0');
INSERT INTO `auction` VALUES ('20952', '2', '38800', '36540', '2', '7838756', '1294068098', '0', '0', '6741330', '0');
INSERT INTO `auction` VALUES ('21583', '6', '39432', '1440', '2', '61889', '1294078958', '0', '0', '59413', '0');
INSERT INTO `auction` VALUES ('21906', '2', '39768', '4387', '2', '36800', '1294121184', '0', '0', '26864', '0');
INSERT INTO `auction` VALUES ('20885', '2', '38733', '4387', '2', '26320', '1294068098', '0', '0', '18950', '0');
INSERT INTO `auction` VALUES ('20638', '6', '38484', '1929', '2', '28149', '1294053638', '0', '0', '22519', '0');
INSERT INTO `auction` VALUES ('20259', '7', '38105', '9719', '2', '429250', '1294064378', '0', '0', '394910', '0');
INSERT INTO `auction` VALUES ('22114', '6', '39976', '24938', '2', '2065206', '1294099584', '0', '0', '2044553', '0');
INSERT INTO `auction` VALUES ('20893', '2', '38741', '6359', '2', '192', '1294068098', '0', '0', '147', '0');
INSERT INTO `auction` VALUES ('21026', '2', '38874', '1994', '2', '1002594', '1294078898', '0', '0', '822127', '0');
INSERT INTO `auction` VALUES ('21795', '2', '39657', '39681', '2', '229600', '1294088784', '0', '0', '195160', '0');
INSERT INTO `auction` VALUES ('22185', '7', '40047', '13887', '2', '480', '1294085184', '0', '0', '470', '0');
INSERT INTO `auction` VALUES ('22328', '7', '40190', '1214', '2', '40146', '1294117584', '0', '0', '36532', '0');
INSERT INTO `auction` VALUES ('22585', '7', '40447', '10505', '2', '30240', '1294121244', '0', '0', '27820', '0');
INSERT INTO `auction` VALUES ('22225', '7', '40087', '13882', '2', '369', '1294124784', '0', '0', '335', '0');
INSERT INTO `auction` VALUES ('20892', '2', '38740', '10562', '2', '21240', '1294060898', '0', '0', '17204', '0');
INSERT INTO `auction` VALUES ('20561', '6', '38407', '7973', '2', '2874', '1294075238', '0', '0', '2500', '0');
INSERT INTO `auction` VALUES ('22460', '6', '40322', '9061', '2', '9080', '1294078044', '0', '0', '8989', '0');
INSERT INTO `auction` VALUES ('20398', '2', '38244', '36160', '2', '2750558', '1294064438', '0', '0', '2255457', '0');
INSERT INTO `auction` VALUES ('22393', '2', '40255', '5523', '2', '709', '1294085244', '0', '0', '595', '0');
INSERT INTO `auction` VALUES ('21959', '6', '39821', '5523', '2', '1890', '1294106784', '0', '0', '1512', '0');
INSERT INTO `auction` VALUES ('22153', '7', '40015', '4611', '2', '5790', '1294103184', '0', '0', '4458', '0');
INSERT INTO `auction` VALUES ('21508', '2', '39357', '37147', '2', '10010', '1294053758', '0', '0', '7507', '0');
INSERT INTO `auction` VALUES ('21945', '2', '39807', '36041', '2', '1854141', '1294092384', '0', '0', '1687268', '0');
INSERT INTO `auction` VALUES ('20257', '7', '38103', '6352', '2', '7', '1294071578', '0', '0', '6', '0');
INSERT INTO `auction` VALUES ('22710', '6', '40572', '1219', '2', '34146', '1294134068', '0', '0', '33463', '0');
INSERT INTO `auction` VALUES ('21790', '2', '39652', '41119', '2', '15840', '1294131984', '0', '0', '12513', '0');
INSERT INTO `auction` VALUES ('20485', '6', '38331', '1394', '2', '45769', '1294075238', '0', '0', '44853', '0');
INSERT INTO `auction` VALUES ('22511', '6', '40373', '37159', '2', '4580', '1294114044', '0', '0', '3343', '0');
INSERT INTO `auction` VALUES ('21567', '6', '39416', '25299', '2', '2942694', '1294053758', '0', '0', '2736705', '0');
INSERT INTO `auction` VALUES ('21960', '6', '39822', '12550', '2', '909703', '1294095984', '0', '0', '900605', '0');
INSERT INTO `auction` VALUES ('19943', '6', '37789', '27515', '2', '8880', '1294078778', '0', '0', '7192', '0');
INSERT INTO `auction` VALUES ('22610', '7', '40472', '36597', '2', '7467691', '1294106844', '0', '0', '7467691', '0');
INSERT INTO `auction` VALUES ('21010', '2', '38858', '21882', '2', '196000', '1294064498', '0', '0', '137200', '0');
INSERT INTO `auction` VALUES ('22372', '2', '40234', '28495', '2', '619830', '1294124844', '0', '0', '520657', '0');
INSERT INTO `auction` VALUES ('22716', '6', '40578', '24599', '2', '1066697', '1294105268', '0', '0', '874691', '0');
INSERT INTO `auction` VALUES ('21210', '6', '39058', '9060', '2', '18240', '1294071698', '0', '0', '14956', '0');
INSERT INTO `auction` VALUES ('22104', '6', '39966', '36441', '2', '1281036', '1294088784', '0', '0', '1101690', '0');
INSERT INTO `auction` VALUES ('20663', '6', '38509', '1288', '2', '5298', '1294053638', '0', '0', '4238', '0');
INSERT INTO `auction` VALUES ('22160', '7', '40022', '30740', '2', '12739306', '1294103184', '0', '0', '12102340', '0');
INSERT INTO `auction` VALUES ('21025', '2', '38873', '36056', '2', '1758946', '1294082498', '0', '0', '1653409', '0');
INSERT INTO `auction` VALUES ('19944', '6', '37790', '20697', '2', '1277959', '1294075178', '0', '0', '996808', '0');
INSERT INTO `auction` VALUES ('20416', '2', '38262', '9361', '2', '2816', '1294064438', '0', '0', '2112', '0');
INSERT INTO `auction` VALUES ('20053', '6', '37899', '3281', '2', '472', '1294064378', '0', '0', '330', '0');
INSERT INTO `auction` VALUES ('20827', '7', '38673', '9719', '2', '387000', '1294064438', '0', '0', '305730', '0');
INSERT INTO `auction` VALUES ('20871', '2', '38719', '36653', '2', '3592965', '1294060898', '0', '0', '3233668', '0');
INSERT INTO `auction` VALUES ('21480', '2', '39329', '37147', '2', '8145', '1294078958', '0', '0', '5701', '0');
INSERT INTO `auction` VALUES ('19880', '6', '37726', '8364', '2', '30800', '1294082378', '0', '0', '21560', '0');
INSERT INTO `auction` VALUES ('21880', '2', '39742', '37159', '2', '12920', '1294092384', '0', '0', '12015', '0');
INSERT INTO `auction` VALUES ('21220', '6', '39068', '2175', '2', '129732', '1294060898', '0', '0', '127137', '0');
INSERT INTO `auction` VALUES ('22496', '6', '40358', '5637', '2', '1470', '1294081644', '0', '0', '1367', '0');
INSERT INTO `auction` VALUES ('22178', '7', '40040', '36058', '2', '847367', '1294124784', '0', '0', '720261', '0');
INSERT INTO `auction` VALUES ('19788', '2', '37634', '6353', '2', '9', '1294075178', '0', '0', '7', '0');
INSERT INTO `auction` VALUES ('22498', '6', '40360', '14897', '2', '190391', '1294103244', '0', '0', '167544', '0');
INSERT INTO `auction` VALUES ('22630', '2', '40492', '7755', '2', '281133', '1294101668', '0', '0', '222095', '0');
INSERT INTO `auction` VALUES ('22744', '7', '40606', '8151', '2', '28000', '1294098068', '0', '0', '26040', '0');
INSERT INTO `auction` VALUES ('21175', '6', '39023', '5743', '2', '87878', '1294078898', '0', '0', '78211', '0');
INSERT INTO `auction` VALUES ('22613', '7', '40475', '1475', '2', '1752', '1294103244', '0', '0', '1436', '0');
INSERT INTO `auction` VALUES ('22379', '2', '40241', '2823', '2', '108756', '1294081644', '0', '0', '107668', '0');
INSERT INTO `auction` VALUES ('19961', '6', '37807', '1388', '2', '169', '1294067978', '0', '0', '152', '0');
INSERT INTO `auction` VALUES ('21673', '7', '39522', '10559', '2', '48930', '1294053758', '0', '0', '43058', '0');
INSERT INTO `auction` VALUES ('20823', '7', '38669', '9719', '2', '318500', '1294082438', '0', '0', '283465', '0');
INSERT INTO `auction` VALUES ('22090', '6', '39952', '4723', '2', '89013', '1294128384', '0', '0', '88122', '0');
INSERT INTO `auction` VALUES ('22459', '6', '40321', '4611', '2', '6290', '1294121244', '0', '0', '5409', '0');
INSERT INTO `auction` VALUES ('20879', '2', '38727', '13757', '2', '11232', '1294082498', '0', '0', '9434', '0');
INSERT INTO `auction` VALUES ('22461', '6', '40323', '4724', '2', '110552', '1294128444', '0', '0', '88441', '0');
INSERT INTO `auction` VALUES ('21443', '7', '39291', '14832', '2', '275653', '1294060898', '0', '0', '275653', '0');
INSERT INTO `auction` VALUES ('21948', '2', '39810', '10562', '2', '112800', '1294131984', '0', '0', '86856', '0');
INSERT INTO `auction` VALUES ('19969', '6', '37815', '19943', '2', '17600', '1294082378', '0', '0', '16544', '0');
INSERT INTO `auction` VALUES ('21036', '2', '38884', '24669', '2', '761213', '1294075298', '0', '0', '761213', '0');
INSERT INTO `auction` VALUES ('20305', '2', '38151', '39682', '2', '443520', '1294060838', '0', '0', '363686', '0');
INSERT INTO `auction` VALUES ('21313', '7', '39161', '40195', '2', '110880', '1294071698', '0', '0', '105336', '0');
INSERT INTO `auction` VALUES ('21358', '7', '39206', '20694', '2', '574077', '1294060898', '0', '0', '487965', '0');
INSERT INTO `auction` VALUES ('22261', '7', '40123', '4589', '2', '41212', '1294110384', '0', '0', '37502', '0');
INSERT INTO `auction` VALUES ('22176', '7', '40038', '25256', '2', '2723686', '1294088784', '0', '0', '2396843', '0');
INSERT INTO `auction` VALUES ('22462', '6', '40324', '36401', '2', '2813531', '1294092444', '0', '0', '2644719', '0');
INSERT INTO `auction` VALUES ('22258', '7', '40120', '11018', '2', '62852', '1294088784', '0', '0', '47139', '0');
INSERT INTO `auction` VALUES ('21844', '2', '39706', '9719', '2', '408750', '1294103184', '0', '0', '310650', '0');
INSERT INTO `auction` VALUES ('20826', '7', '38672', '6197', '2', '57378', '1294057238', '0', '0', '56230', '0');
INSERT INTO `auction` VALUES ('20883', '2', '38731', '39681', '2', '255360', '1294068098', '0', '0', '214502', '0');
INSERT INTO `auction` VALUES ('20304', '2', '38150', '9719', '2', '400500', '1294078838', '0', '0', '364455', '0');
INSERT INTO `auction` VALUES ('21365', '7', '39213', '45909', '2', '79680', '1294071698', '0', '0', '79680', '0');
INSERT INTO `auction` VALUES ('19914', '6', '37760', '9719', '2', '334750', '1294067978', '0', '0', '277842', '0');
INSERT INTO `auction` VALUES ('20255', '7', '38101', '36667', '2', '4860759', '1294078778', '0', '0', '3888607', '0');
INSERT INTO `auction` VALUES ('20322', '2', '38168', '31268', '2', '52040', '1294060838', '0', '0', '50478', '0');
INSERT INTO `auction` VALUES ('20920', '2', '38768', '36011', '2', '1357636', '1294060898', '0', '0', '1303330', '0');
INSERT INTO `auction` VALUES ('19967', '6', '37813', '36035', '2', '962438', '1294082378', '0', '0', '837321', '0');
INSERT INTO `auction` VALUES ('21197', '6', '39045', '37159', '2', '10230', '1294078898', '0', '0', '9513', '0');
INSERT INTO `auction` VALUES ('22466', '6', '40328', '6359', '2', '579', '1294081644', '0', '0', '428', '0');
INSERT INTO `auction` VALUES ('21799', '2', '39661', '35287', '2', '1620', '1294121184', '0', '0', '1134', '0');
INSERT INTO `auction` VALUES ('22011', '6', '39873', '31580', '2', '4717050', '1294131984', '0', '0', '4151004', '0');
INSERT INTO `auction` VALUES ('21652', '6', '39501', '40195', '2', '30600', '1294064558', '0', '0', '23562', '0');
INSERT INTO `auction` VALUES ('22028', '6', '39890', '31231', '2', '1117207', '1294110384', '0', '0', '949625', '0');
INSERT INTO `auction` VALUES ('20035', '6', '37881', '44649', '2', '3157816', '1294078778', '0', '0', '2873612', '0');
INSERT INTO `auction` VALUES ('20661', '6', '38507', '13757', '2', '2400', '1294053638', '0', '0', '2088', '0');
INSERT INTO `auction` VALUES ('22623', '2', '40485', '27516', '2', '18560', '1294080068', '0', '0', '17260', '0');
INSERT INTO `auction` VALUES ('20541', '6', '38387', '19258', '2', '847000', '1294071638', '0', '0', '652190', '0');
INSERT INTO `auction` VALUES ('21706', '7', '39555', '37160', '2', '20400', '1294082558', '0', '0', '16728', '0');
INSERT INTO `auction` VALUES ('20079', '7', '37925', '21561', '2', '832', '1294053578', '0', '0', '640', '0');
INSERT INTO `auction` VALUES ('20303', '2', '38149', '24575', '2', '426280', '1294060838', '0', '0', '413491', '0');
INSERT INTO `auction` VALUES ('22073', '6', '39935', '9719', '2', '359500', '1294128384', '0', '0', '309170', '0');
INSERT INTO `auction` VALUES ('21091', '6', '38939', '4359', '2', '118', '1294082498', '0', '0', '96', '0');
INSERT INTO `auction` VALUES ('20302', '2', '38148', '2728', '2', '21240', '1294071638', '0', '0', '14868', '0');
INSERT INTO `auction` VALUES ('22370', '2', '40232', '13422', '2', '408', '1294132044', '0', '0', '289', '0');
INSERT INTO `auction` VALUES ('20301', '2', '38147', '9719', '2', '353250', '1294064438', '0', '0', '317925', '0');
INSERT INTO `auction` VALUES ('21932', '2', '39794', '36393', '2', '3784536', '1294121184', '0', '0', '3595309', '0');
INSERT INTO `auction` VALUES ('21947', '2', '39809', '1475', '2', '2079', '1294128384', '0', '0', '1871', '0');
INSERT INTO `auction` VALUES ('20300', '2', '38146', '31199', '2', '1265410', '1294064438', '0', '0', '974365', '0');
INSERT INTO `auction` VALUES ('20951', '2', '38799', '10514', '2', '81510', '1294071698', '0', '0', '74989', '0');
INSERT INTO `auction` VALUES ('20611', '6', '38457', '6148', '2', '472', '1294053638', '0', '0', '330', '0');
INSERT INTO `auction` VALUES ('20598', '6', '38444', '10559', '2', '64800', '1294057238', '0', '0', '58968', '0');
INSERT INTO `auction` VALUES ('22673', '6', '40535', '21113', '2', '21', '1294137668', '0', '0', '20', '0');
INSERT INTO `auction` VALUES ('21366', '7', '39214', '24714', '2', '1602333', '1294064498', '0', '0', '1313913', '0');
INSERT INTO `auction` VALUES ('21987', '6', '39849', '7973', '2', '592', '1294088784', '0', '0', '592', '0');
INSERT INTO `auction` VALUES ('19842', '2', '37688', '13757', '2', '2832', '1294057178', '0', '0', '2124', '0');
INSERT INTO `auction` VALUES ('22005', '6', '39867', '9719', '2', '428500', '1294110384', '0', '0', '347085', '0');
INSERT INTO `auction` VALUES ('21107', '6', '38955', '18588', '2', '10176', '1294082498', '0', '0', '8547', '0');
INSERT INTO `auction` VALUES ('22752', '7', '40614', '28498', '2', '1469028', '1294119668', '0', '0', '1439647', '0');
INSERT INTO `auction` VALUES ('22151', '6', '40013', '31952', '2', '25410', '1294117584', '0', '0', '23631', '0');
INSERT INTO `auction` VALUES ('22095', '6', '39957', '9719', '2', '323750', '1294131984', '0', '0', '281662', '0');
INSERT INTO `auction` VALUES ('21121', '6', '38969', '9061', '2', '7120', '1294078898', '0', '0', '5411', '0');
INSERT INTO `auction` VALUES ('20891', '2', '38739', '36027', '2', '867204', '1294064498', '0', '0', '858531', '0');
INSERT INTO `auction` VALUES ('22715', '6', '40577', '36151', '2', '2539062', '1294080068', '0', '0', '2437499', '0');
INSERT INTO `auction` VALUES ('20099', '7', '37945', '10514', '2', '115560', '1294053578', '0', '0', '97070', '0');
INSERT INTO `auction` VALUES ('21737', '7', '39586', '36611', '2', '6516954', '1294060958', '0', '0', '6125936', '0');
INSERT INTO `auction` VALUES ('21766', '2', '39628', '25062', '2', '1620799', '1294088784', '0', '0', '1329055', '0');
INSERT INTO `auction` VALUES ('22504', '6', '40366', '36597', '2', '7828248', '1294106844', '0', '0', '6340880', '0');
INSERT INTO `auction` VALUES ('20168', '7', '38014', '20695', '2', '1927209', '1294078778', '0', '0', '1927209', '0');
INSERT INTO `auction` VALUES ('22395', '2', '40257', '18588', '2', '18920', '1294081644', '0', '0', '16838', '0');
INSERT INTO `auction` VALUES ('22158', '7', '40020', '13018', '2', '2327197', '1294081584', '0', '0', '2210837', '0');
INSERT INTO `auction` VALUES ('21635', '6', '39484', '21882', '2', '172900', '1294075358', '0', '0', '138320', '0');
INSERT INTO `auction` VALUES ('21523', '2', '39372', '4387', '2', '14400', '1294075358', '0', '0', '11232', '0');
INSERT INTO `auction` VALUES ('22584', '7', '40446', '24779', '2', '1828975', '1294121244', '0', '0', '1646077', '0');
INSERT INTO `auction` VALUES ('20331', '2', '38177', '5635', '2', '568', '1294060838', '0', '0', '408', '0');
INSERT INTO `auction` VALUES ('22649', '2', '40511', '5971', '2', '42950', '1294130468', '0', '0', '39943', '0');
INSERT INTO `auction` VALUES ('22001', '6', '39863', '1288', '2', '4995', '1294085184', '0', '0', '4345', '0');
INSERT INTO `auction` VALUES ('21012', '2', '38860', '36157', '2', '2896645', '1294071698', '0', '0', '2317316', '0');
INSERT INTO `auction` VALUES ('21640', '6', '39489', '31264', '2', '19119', '1294057358', '0', '0', '17207', '0');
INSERT INTO `auction` VALUES ('22296', '7', '40158', '5971', '2', '36859', '1294095984', '0', '0', '36490', '0');
INSERT INTO `auction` VALUES ('22473', '6', '40335', '24669', '2', '981698', '1294117644', '0', '0', '971881', '0');
INSERT INTO `auction` VALUES ('21334', '7', '39182', '36283', '2', '1578737', '1294082498', '0', '0', '1310351', '0');
INSERT INTO `auction` VALUES ('20012', '6', '37858', '9719', '2', '332750', '1294082378', '0', '0', '316112', '0');
INSERT INTO `auction` VALUES ('21504', '2', '39353', '36270', '2', '1802818', '1294068158', '0', '0', '1442254', '0');
INSERT INTO `auction` VALUES ('22751', '7', '40613', '2017', '2', '47366', '1294090868', '0', '0', '38840', '0');
INSERT INTO `auction` VALUES ('22629', '2', '40491', '16672', '2', '1165557', '1294126868', '0', '0', '1060656', '0');
INSERT INTO `auction` VALUES ('22335', '7', '40197', '24824', '2', '1993751', '1294103184', '0', '0', '1654813', '0');
INSERT INTO `auction` VALUES ('22725', '7', '40587', '3262', '2', '86', '1294123268', '0', '0', '66', '0');
INSERT INTO `auction` VALUES ('21792', '2', '39654', '22891', '2', '591600', '1294117584', '0', '0', '496944', '0');
INSERT INTO `auction` VALUES ('21719', '7', '39568', '4771', '2', '12580', '1294064558', '0', '0', '11196', '0');
INSERT INTO `auction` VALUES ('20356', '2', '38202', '37147', '2', '3240', '1294053638', '0', '0', '2559', '0');
INSERT INTO `auction` VALUES ('21681', '7', '39530', '8152', '2', '36300', '1294064558', '0', '0', '26862', '0');
INSERT INTO `auction` VALUES ('22288', '7', '40150', '4387', '2', '2912', '1294099584', '0', '0', '2242', '0');
INSERT INTO `auction` VALUES ('21682', '7', '39531', '4387', '2', '8640', '1294068158', '0', '0', '7344', '0');
INSERT INTO `auction` VALUES ('20745', '7', '38591', '13035', '2', '1713386', '1294064438', '0', '0', '1696252', '0');
INSERT INTO `auction` VALUES ('22702', '6', '40564', '18512', '2', '38720', '1294130468', '0', '0', '27878', '0');
INSERT INTO `auction` VALUES ('22502', '6', '40364', '18512', '2', '152960', '1294085244', '0', '0', '128486', '0');
INSERT INTO `auction` VALUES ('20672', '7', '38518', '4700', '2', '3000', '1294053638', '0', '0', '2490', '0');
INSERT INTO `auction` VALUES ('21917', '2', '39779', '27511', '2', '234', '1294088784', '0', '0', '173', '0');
INSERT INTO `auction` VALUES ('20373', '2', '38219', '19943', '2', '392000', '1294078838', '0', '0', '341040', '0');
INSERT INTO `auction` VALUES ('21846', '2', '39708', '10562', '2', '105450', '1294077984', '0', '0', '83305', '0');
INSERT INTO `auction` VALUES ('20512', '6', '38358', '3213', '2', '1019', '1294082438', '0', '0', '805', '0');
INSERT INTO `auction` VALUES ('20377', '2', '38223', '31213', '2', '3570696', '1294071638', '0', '0', '3249333', '0');
INSERT INTO `auction` VALUES ('22021', '6', '39883', '3008', '2', '311', '1294131984', '0', '0', '248', '0');
INSERT INTO `auction` VALUES ('21573', '6', '39422', '10562', '2', '57600', '1294053758', '0', '0', '43200', '0');
INSERT INTO `auction` VALUES ('19938', '6', '37784', '22528', '2', '145992', '1294057178', '0', '0', '143072', '0');
INSERT INTO `auction` VALUES ('20184', '7', '38030', '30735', '2', '5938316', '1294060778', '0', '0', '5641400', '0');
INSERT INTO `auction` VALUES ('20288', '2', '38134', '3260', '2', '54', '1294057238', '0', '0', '37', '0');
INSERT INTO `auction` VALUES ('22096', '6', '39958', '9719', '2', '413750', '1294117584', '0', '0', '372375', '0');
INSERT INTO `auction` VALUES ('20990', '2', '38838', '36388', '2', '2492122', '1294071698', '0', '0', '2417358', '0');
INSERT INTO `auction` VALUES ('20681', '7', '38527', '36696', '2', '5165720', '1294068038', '0', '0', '4494176', '0');
INSERT INTO `auction` VALUES ('20699', '7', '38545', '2108', '2', '82', '1294064438', '0', '0', '77', '0');
INSERT INTO `auction` VALUES ('21875', '2', '39737', '5245', '2', '246688', '1294103184', '0', '0', '204751', '0');
INSERT INTO `auction` VALUES ('20804', '7', '38650', '37160', '2', '6400', '1294075238', '0', '0', '5952', '0');
INSERT INTO `auction` VALUES ('22331', '7', '40193', '37160', '2', '11580', '1294081584', '0', '0', '9264', '0');
INSERT INTO `auction` VALUES ('21679', '7', '39528', '27515', '2', '9560', '1294064558', '0', '0', '7648', '0');
INSERT INTO `auction` VALUES ('20355', '2', '38201', '31174', '2', '1719499', '1294078838', '0', '0', '1409989', '0');
INSERT INTO `auction` VALUES ('21865', '2', '39727', '9719', '2', '369750', '1294110384', '0', '0', '284707', '0');
INSERT INTO `auction` VALUES ('20354', '2', '38200', '9719', '2', '316750', '1294060838', '0', '0', '247065', '0');
INSERT INTO `auction` VALUES ('21965', '6', '39827', '12804', '2', '52800', '1294135584', '0', '0', '49632', '0');
INSERT INTO `auction` VALUES ('21966', '6', '39828', '6566', '2', '4315', '1294106784', '0', '0', '3365', '0');
INSERT INTO `auction` VALUES ('22609', '7', '40471', '44700', '2', '4400', '1294088844', '0', '0', '3696', '0');
INSERT INTO `auction` VALUES ('22088', '6', '39950', '18339', '2', '782865', '1294099584', '0', '0', '641949', '0');
INSERT INTO `auction` VALUES ('19926', '6', '37772', '9755', '2', '552', '1294060778', '0', '0', '513', '0');
INSERT INTO `auction` VALUES ('21785', '2', '39647', '16681', '2', '1078995', '1294121184', '0', '0', '884775', '0');
INSERT INTO `auction` VALUES ('22698', '6', '40560', '1475', '2', '1029', '1294101668', '0', '0', '967', '0');
INSERT INTO `auction` VALUES ('21032', '2', '38880', '40199', '2', '3860', '1294075298', '0', '0', '3165', '0');
INSERT INTO `auction` VALUES ('22681', '6', '40543', '9719', '2', '410250', '1294123268', '0', '0', '352815', '0');
INSERT INTO `auction` VALUES ('21968', '6', '39830', '9719', '2', '324500', '1294113984', '0', '0', '266090', '0');
INSERT INTO `auction` VALUES ('21033', '2', '38881', '25229', '2', '4408226', '1294082498', '0', '0', '3879238', '0');
INSERT INTO `auction` VALUES ('22625', '2', '40487', '17054', '2', '1829515', '1294119668', '0', '0', '1811219', '0');
INSERT INTO `auction` VALUES ('22479', '6', '40341', '13757', '2', '23136', '1294106844', '0', '0', '18508', '0');
INSERT INTO `auction` VALUES ('20284', '2', '38130', '19943', '2', '48000', '1294053638', '0', '0', '44640', '0');
INSERT INTO `auction` VALUES ('21149', '6', '38997', '899', '2', '65478', '1294082498', '0', '0', '63513', '0');
INSERT INTO `auction` VALUES ('22599', '7', '40461', '25229', '2', '4418986', '1294103244', '0', '0', '4286416', '0');
INSERT INTO `auction` VALUES ('22360', '2', '40222', '40195', '2', '54720', '1294088844', '0', '0', '39945', '0');
INSERT INTO `auction` VALUES ('21274', '7', '39122', '44475', '2', '143', '1294053698', '0', '0', '134', '0');
INSERT INTO `auction` VALUES ('20352', '2', '38198', '9719', '2', '413750', '1294082438', '0', '0', '318587', '0');
INSERT INTO `auction` VALUES ('21019', '2', '38867', '24719', '2', '1764478', '1294078898', '0', '0', '1446871', '0');
INSERT INTO `auction` VALUES ('22748', '7', '40610', '37145', '2', '12220', '1294108868', '0', '0', '8798', '0');
INSERT INTO `auction` VALUES ('21908', '2', '39770', '21882', '2', '406300', '1294110384', '0', '0', '357544', '0');
INSERT INTO `auction` VALUES ('19874', '6', '37720', '10505', '2', '4220', '1294053578', '0', '0', '3207', '0');
INSERT INTO `auction` VALUES ('22591', '7', '40453', '40195', '2', '5580', '1294092444', '0', '0', '4408', '0');
INSERT INTO `auction` VALUES ('22367', '2', '40229', '4611', '2', '8400', '1294132044', '0', '0', '5964', '0');
INSERT INTO `auction` VALUES ('21909', '2', '39771', '39681', '2', '176400', '1294077984', '0', '0', '176400', '0');
INSERT INTO `auction` VALUES ('21726', '7', '39575', '4044', '2', '306682', '1294071758', '0', '0', '263746', '0');
INSERT INTO `auction` VALUES ('21784', '2', '39646', '36162', '2', '1675365', '1294128384', '0', '0', '1541335', '0');
INSERT INTO `auction` VALUES ('21787', '2', '39649', '9719', '2', '409750', '1294135584', '0', '0', '376970', '0');
INSERT INTO `auction` VALUES ('20766', '7', '38612', '18588', '2', '22960', '1294064438', '0', '0', '21812', '0');
INSERT INTO `auction` VALUES ('21247', '6', '39095', '36396', '2', '3197962', '1294057298', '0', '0', '3134002', '0');
INSERT INTO `auction` VALUES ('21436', '7', '39284', '4387', '2', '7776', '1294064498', '0', '0', '6920', '0');
INSERT INTO `auction` VALUES ('22247', '7', '40109', '37117', '2', '2141574', '1294124784', '0', '0', '1927416', '0');
INSERT INTO `auction` VALUES ('22042', '6', '39904', '3415', '2', '305718', '1294092384', '0', '0', '281260', '0');
INSERT INTO `auction` VALUES ('20555', '6', '38401', '6359', '2', '744', '1294068038', '0', '0', '677', '0');
INSERT INTO `auction` VALUES ('19748', '2', '37594', '2244', '2', '10908330', '1294064378', '0', '0', '10253830', '0');
INSERT INTO `auction` VALUES ('21435', '7', '39283', '13757', '2', '13440', '1294064498', '0', '0', '11558', '0');
INSERT INTO `auction` VALUES ('21563', '6', '39412', '35995', '2', '844236', '1294082558', '0', '0', '793581', '0');
INSERT INTO `auction` VALUES ('21943', '2', '39805', '20659', '2', '722951', '1294117584', '0', '0', '628967', '0');
INSERT INTO `auction` VALUES ('21902', '2', '39764', '10560', '2', '66880', '1294121184', '0', '0', '60192', '0');
INSERT INTO `auction` VALUES ('21434', '7', '39282', '19441', '2', '13020', '1294060898', '0', '0', '9114', '0');
INSERT INTO `auction` VALUES ('20596', '6', '38442', '13755', '2', '1327', '1294057238', '0', '0', '968', '0');
INSERT INTO `auction` VALUES ('22611', '7', '40473', '36066', '2', '1371468', '1294078044', '0', '0', '1206891', '0');
INSERT INTO `auction` VALUES ('21783', '2', '39645', '18678', '2', '1369051', '1294088784', '0', '0', '1245836', '0');
INSERT INTO `auction` VALUES ('21155', '6', '39003', '44475', '2', '197', '1294078898', '0', '0', '179', '0');
INSERT INTO `auction` VALUES ('21803', '2', '39665', '9719', '2', '359000', '1294131984', '0', '0', '312330', '0');
INSERT INTO `auction` VALUES ('20617', '6', '38463', '41119', '2', '18400', '1294068038', '0', '0', '13800', '0');
INSERT INTO `auction` VALUES ('20283', '2', '38129', '31203', '2', '2663027', '1294068038', '0', '0', '2103791', '0');
INSERT INTO `auction` VALUES ('22342', '7', '40204', '4388', '2', '8760', '1294081584', '0', '0', '7183', '0');
INSERT INTO `auction` VALUES ('21315', '7', '39163', '27513', '2', '194', '1294082498', '0', '0', '137', '0');
INSERT INTO `auction` VALUES ('20801', '7', '38647', '37159', '2', '5425', '1294060838', '0', '0', '4394', '0');
INSERT INTO `auction` VALUES ('21971', '6', '39833', '9719', '2', '381750', '1294103184', '0', '0', '320670', '0');
INSERT INTO `auction` VALUES ('21657', '7', '39506', '2274', '2', '18087', '1294057358', '0', '0', '15916', '0');
INSERT INTO `auction` VALUES ('20457', '2', '38303', '9719', '2', '358000', '1294060838', '0', '0', '282820', '0');
INSERT INTO `auction` VALUES ('21213', '6', '39061', '36514', '2', '6090992', '1294057298', '0', '0', '5420982', '0');
INSERT INTO `auction` VALUES ('19940', '6', '37786', '1927', '2', '27711', '1294057178', '0', '0', '23831', '0');
INSERT INTO `auction` VALUES ('22334', '7', '40196', '36149', '2', '3317108', '1294113984', '0', '0', '2786370', '0');
INSERT INTO `auction` VALUES ('21658', '7', '39507', '3018', '2', '27187', '1294071758', '0', '0', '26371', '0');
INSERT INTO `auction` VALUES ('21034', '2', '38882', '36395', '2', '2010406', '1294057298', '0', '0', '1668636', '0');
INSERT INTO `auction` VALUES ('22228', '7', '40090', '6147', '2', '447', '1294128384', '0', '0', '411', '0');
INSERT INTO `auction` VALUES ('20351', '2', '38197', '1965', '2', '401', '1294082438', '0', '0', '292', '0');
INSERT INTO `auction` VALUES ('20040', '6', '37886', '1996', '2', '77468', '1294064378', '0', '0', '62749', '0');
INSERT INTO `auction` VALUES ('22665', '2', '40527', '44475', '2', '173', '1294094468', '0', '0', '145', '0');
INSERT INTO `auction` VALUES ('21782', '2', '39644', '1982', '2', '4391623', '1294099584', '0', '0', '3601130', '0');
INSERT INTO `auction` VALUES ('22682', '6', '40544', '24723', '2', '1231750', '1294119668', '0', '0', '1219432', '0');
INSERT INTO `auction` VALUES ('22508', '6', '40370', '10559', '2', '52380', '1294110444', '0', '0', '47142', '0');
INSERT INTO `auction` VALUES ('20349', '2', '38195', '1445', '2', '4526', '1294078838', '0', '0', '4118', '0');
INSERT INTO `auction` VALUES ('22568', '7', '40430', '39681', '2', '254016', '1294117644', '0', '0', '193052', '0');
INSERT INTO `auction` VALUES ('22675', '6', '40537', '727', '2', '16170', '1294087268', '0', '0', '16170', '0');
INSERT INTO `auction` VALUES ('22359', '2', '40221', '40199', '2', '9440', '1294117644', '0', '0', '8307', '0');
INSERT INTO `auction` VALUES ('20814', '7', '38660', '1389', '2', '607', '1294082438', '0', '0', '437', '0');
INSERT INTO `auction` VALUES ('19830', '2', '37676', '40195', '2', '41580', '1294060778', '0', '0', '35343', '0');
INSERT INTO `auction` VALUES ('22336', '7', '40198', '8151', '2', '30660', '1294121184', '0', '0', '25447', '0');
INSERT INTO `auction` VALUES ('22206', '7', '40068', '25327', '2', '3563488', '1294113984', '0', '0', '2957695', '0');
INSERT INTO `auction` VALUES ('20242', '7', '38088', '31203', '2', '2021161', '1294078778', '0', '0', '1657352', '0');
INSERT INTO `auction` VALUES ('20435', '2', '38281', '9719', '2', '323500', '1294064438', '0', '0', '297620', '0');
INSERT INTO `auction` VALUES ('20253', '7', '38099', '9719', '2', '315500', '1294057178', '0', '0', '274485', '0');
INSERT INTO `auction` VALUES ('19808', '2', '37654', '36399', '2', '3067380', '1294067978', '0', '0', '2699294', '0');
INSERT INTO `auction` VALUES ('22450', '6', '40312', '8152', '2', '24840', '1294078044', '0', '0', '17884', '0');
INSERT INTO `auction` VALUES ('22146', '6', '40008', '37145', '2', '930', '1294135584', '0', '0', '771', '0');
INSERT INTO `auction` VALUES ('22284', '7', '40146', '4359', '2', '1687', '1294135584', '0', '0', '1315', '0');
INSERT INTO `auction` VALUES ('22291', '7', '40153', '16648', '2', '562', '1294081584', '0', '0', '483', '0');
INSERT INTO `auction` VALUES ('21918', '2', '39780', '6358', '2', '29', '1294095984', '0', '0', '21', '0');
INSERT INTO `auction` VALUES ('21308', '7', '39156', '25054', '2', '1733722', '1294082498', '0', '0', '1491000', '0');
INSERT INTO `auction` VALUES ('22031', '6', '39893', '2018', '2', '163776', '1294131984', '0', '0', '150673', '0');
INSERT INTO `auction` VALUES ('22299', '7', '40161', '1355', '2', '9868', '1294128384', '0', '0', '8486', '0');
INSERT INTO `auction` VALUES ('21378', '7', '39226', '24892', '2', '2094136', '1294053698', '0', '0', '2073194', '0');
INSERT INTO `auction` VALUES ('22523', '6', '40385', '36624', '2', '4270779', '1294110444', '0', '0', '3886408', '0');
INSERT INTO `auction` VALUES ('21381', '7', '39229', '4377', '2', '8244', '1294064498', '0', '0', '7172', '0');
INSERT INTO `auction` VALUES ('21997', '6', '39859', '2065', '2', '1314', '1294099584', '0', '0', '972', '0');
INSERT INTO `auction` VALUES ('22628', '2', '40490', '2271', '2', '282097', '1294137668', '0', '0', '265171', '0');
INSERT INTO `auction` VALUES ('20363', '2', '38209', '7072', '2', '4272', '1294075238', '0', '0', '4186', '0');
INSERT INTO `auction` VALUES ('22652', '2', '40514', '24368', '2', '858400', '1294087268', '0', '0', '635216', '0');
INSERT INTO `auction` VALUES ('22380', '2', '40242', '4476', '2', '185118', '1294088844', '0', '0', '185118', '0');
INSERT INTO `auction` VALUES ('21587', '6', '39436', '9262', '2', '44800', '1294082558', '0', '0', '42112', '0');
INSERT INTO `auction` VALUES ('21272', '7', '39120', '45909', '2', '77760', '1294060898', '0', '0', '62985', '0');
INSERT INTO `auction` VALUES ('21571', '6', '39420', '40199', '2', '5436', '1294082558', '0', '0', '5272', '0');
INSERT INTO `auction` VALUES ('19905', '6', '37751', '9719', '2', '414000', '1294057178', '0', '0', '314640', '0');
INSERT INTO `auction` VALUES ('22100', '6', '39962', '9719', '2', '435750', '1294135584', '0', '0', '326812', '0');
INSERT INTO `auction` VALUES ('20445', '2', '38291', '5523', '2', '784', '1294057238', '0', '0', '580', '0');
INSERT INTO `auction` VALUES ('22070', '6', '39932', '4465', '2', '95465', '1294081584', '0', '0', '92601', '0');
INSERT INTO `auction` VALUES ('19698', '2', '37544', '36652', '2', '3570062', '1294060778', '0', '0', '3248756', '0');
INSERT INTO `auction` VALUES ('22474', '6', '40336', '5523', '2', '1326', '1294078044', '0', '0', '1206', '0');
INSERT INTO `auction` VALUES ('22517', '6', '40379', '36781', '2', '24240', '1294092444', '0', '0', '18664', '0');
INSERT INTO `auction` VALUES ('21991', '6', '39853', '3225', '2', '1145', '1294128384', '0', '0', '1064', '0');
INSERT INTO `auction` VALUES ('19813', '2', '37659', '5423', '2', '182280', '1294060778', '0', '0', '147646', '0');
INSERT INTO `auction` VALUES ('19697', '2', '37543', '9719', '2', '436750', '1294057178', '0', '0', '375605', '0');
INSERT INTO `auction` VALUES ('21771', '2', '39633', '1930', '2', '13243', '1294077984', '0', '0', '12713', '0');
INSERT INTO `auction` VALUES ('20726', '7', '38572', '3057', '2', '46007', '1294057238', '0', '0', '39566', '0');
INSERT INTO `auction` VALUES ('22150', '6', '40012', '40199', '2', '3472', '1294095984', '0', '0', '3228', '0');
INSERT INTO `auction` VALUES ('21017', '2', '38865', '9060', '2', '151200', '1294053698', '0', '0', '111888', '0');
INSERT INTO `auction` VALUES ('22411', '2', '40273', '8303', '2', '1392860', '1294099644', '0', '0', '1351074', '0');
INSERT INTO `auction` VALUES ('19853', '2', '37699', '7728', '2', '263545', '1294053578', '0', '0', '253003', '0');
INSERT INTO `auction` VALUES ('21386', '7', '39234', '6358', '2', '252', '1294075298', '0', '0', '224', '0');
INSERT INTO `auction` VALUES ('20640', '6', '38486', '9719', '2', '377750', '1294057238', '0', '0', '366417', '0');
INSERT INTO `auction` VALUES ('21103', '6', '38951', '24889', '2', '970745', '1294068098', '0', '0', '776596', '0');
INSERT INTO `auction` VALUES ('20630', '6', '38476', '25187', '2', '3141983', '1294082438', '0', '0', '3079143', '0');
INSERT INTO `auction` VALUES ('20480', '6', '38326', '44475', '2', '144', '1294071638', '0', '0', '108', '0');
INSERT INTO `auction` VALUES ('20724', '7', '38570', '36513', '2', '6195302', '1294071638', '0', '0', '5327959', '0');
INSERT INTO `auction` VALUES ('20947', '2', '38795', '37147', '2', '9560', '1294078898', '0', '0', '8317', '0');
INSERT INTO `auction` VALUES ('21884', '2', '39746', '7072', '2', '6660', '1294077984', '0', '0', '5727', '0');
INSERT INTO `auction` VALUES ('20181', '7', '38027', '31168', '2', '3083387', '1294060778', '0', '0', '2374207', '0');
INSERT INTO `auction` VALUES ('22108', '6', '39970', '9719', '2', '364500', '1294131984', '0', '0', '306180', '0');
INSERT INTO `auction` VALUES ('21992', '6', '39854', '9719', '2', '383250', '1294110384', '0', '0', '329595', '0');
INSERT INTO `auction` VALUES ('20317', '2', '38163', '9719', '2', '435750', '1294068038', '0', '0', '335527', '0');
INSERT INTO `auction` VALUES ('22539', '6', '40401', '44700', '2', '5525', '1294106844', '0', '0', '4641', '0');
INSERT INTO `auction` VALUES ('21326', '7', '39174', '31268', '2', '61851', '1294057298', '0', '0', '51336', '0');
INSERT INTO `auction` VALUES ('21873', '2', '39735', '31180', '2', '1816576', '1294081584', '0', '0', '1398763', '0');
INSERT INTO `auction` VALUES ('20187', '7', '38033', '9719', '2', '363500', '1294064378', '0', '0', '312610', '0');
INSERT INTO `auction` VALUES ('21300', '7', '39148', '3164', '2', '1474', '1294078898', '0', '0', '1415', '0');
INSERT INTO `auction` VALUES ('22314', '7', '40176', '5608', '2', '212628', '1294099584', '0', '0', '182860', '0');
INSERT INTO `auction` VALUES ('19814', '2', '37660', '9719', '2', '312500', '1294071578', '0', '0', '259375', '0');
INSERT INTO `auction` VALUES ('21860', '2', '39722', '24601', '2', '987189', '1294081584', '0', '0', '967445', '0');
INSERT INTO `auction` VALUES ('22333', '7', '40195', '27513', '2', '132', '1294128384', '0', '0', '102', '0');
INSERT INTO `auction` VALUES ('22648', '2', '40510', '6358', '2', '376', '1294101668', '0', '0', '263', '0');
INSERT INTO `auction` VALUES ('21030', '2', '38878', '36065', '2', '1812761', '1294075298', '0', '0', '1722122', '0');
INSERT INTO `auction` VALUES ('21993', '6', '39855', '25215', '2', '4805695', '1294099584', '0', '0', '3844556', '0');
INSERT INTO `auction` VALUES ('21280', '7', '39128', '37145', '2', '20520', '1294060898', '0', '0', '20109', '0');
INSERT INTO `auction` VALUES ('22388', '2', '40250', '4394', '2', '10020', '1294110444', '0', '0', '7414', '0');
INSERT INTO `auction` VALUES ('20734', '7', '38580', '25298', '2', '2705323', '1294082438', '0', '0', '2461843', '0');
INSERT INTO `auction` VALUES ('22197', '7', '40059', '36485', '2', '5928642', '1294113984', '0', '0', '5513637', '0');
INSERT INTO `auction` VALUES ('22260', '7', '40122', '16647', '2', '452', '1294099584', '0', '0', '415', '0');
INSERT INTO `auction` VALUES ('20876', '2', '38724', '6358', '2', '450', '1294078898', '0', '0', '315', '0');
INSERT INTO `auction` VALUES ('21667', '7', '39516', '14812', '2', '1933823', '1294057358', '0', '0', '1663087', '0');
INSERT INTO `auction` VALUES ('21495', '2', '39344', '10514', '2', '66000', '1294068158', '0', '0', '63360', '0');
INSERT INTO `auction` VALUES ('22546', '7', '40408', '25131', '2', '2962838', '1294128444', '0', '0', '2873952', '0');
INSERT INTO `auction` VALUES ('21725', '7', '39574', '2140', '2', '19472', '1294082558', '0', '0', '17524', '0');
INSERT INTO `auction` VALUES ('20171', '7', '38017', '30734', '2', '8976026', '1294057178', '0', '0', '7270581', '0');
INSERT INTO `auction` VALUES ('21789', '2', '39651', '9480', '2', '2442840', '1294077984', '0', '0', '2027557', '0');
INSERT INTO `auction` VALUES ('22656', '2', '40518', '36066', '2', '1329372', '1294101668', '0', '0', '1183141', '0');
INSERT INTO `auction` VALUES ('21324', '7', '39172', '32717', '2', '480000', '1294071698', '0', '0', '470400', '0');
INSERT INTO `auction` VALUES ('22192', '7', '40054', '36157', '2', '3539758', '1294135584', '0', '0', '3185782', '0');
INSERT INTO `auction` VALUES ('22177', '7', '40039', '4479', '2', '1451', '1294099584', '0', '0', '1363', '0');
INSERT INTO `auction` VALUES ('22420', '2', '40282', '4476', '2', '175685', '1294124844', '0', '0', '173928', '0');
INSERT INTO `auction` VALUES ('22154', '7', '40016', '9719', '2', '417000', '1294092384', '0', '0', '375300', '0');
INSERT INTO `auction` VALUES ('22175', '7', '40037', '867', '2', '1078419', '1294099584', '0', '0', '916656', '0');
INSERT INTO `auction` VALUES ('21485', '2', '39334', '36011', '2', '1137131', '1294064558', '0', '0', '1114388', '0');
INSERT INTO `auction` VALUES ('22745', '7', '40607', '21882', '2', '96000', '1294116068', '0', '0', '90240', '0');
INSERT INTO `auction` VALUES ('22324', '7', '40186', '37147', '2', '10560', '1294088784', '0', '0', '8870', '0');
INSERT INTO `auction` VALUES ('22435', '2', '40297', '9262', '2', '15920', '1294135644', '0', '0', '12736', '0');
INSERT INTO `auction` VALUES ('21457', '7', '39305', '36708', '2', '8732136', '1294082498', '0', '0', '7247672', '0');
INSERT INTO `auction` VALUES ('22617', '7', '40479', '36781', '2', '26160', '1294085244', '0', '0', '23805', '0');
INSERT INTO `auction` VALUES ('22315', '7', '40177', '36043', '2', '955773', '1294128384', '0', '0', '783733', '0');
INSERT INTO `auction` VALUES ('19835', '2', '37681', '3164', '2', '2220', '1294082378', '0', '0', '2131', '0');
INSERT INTO `auction` VALUES ('22513', '6', '40375', '20670', '2', '606690', '1294085244', '0', '0', '503552', '0');
INSERT INTO `auction` VALUES ('22214', '7', '40076', '24246', '2', '473984', '1294110384', '0', '0', '346008', '0');
INSERT INTO `auction` VALUES ('21307', '7', '39155', '3188', '2', '35975', '1294057298', '0', '0', '34536', '0');
INSERT INTO `auction` VALUES ('20686', '7', '38532', '9719', '2', '436000', '1294060838', '0', '0', '401120', '0');
INSERT INTO `auction` VALUES ('21509', '2', '39358', '1664', '2', '879507', '1294068158', '0', '0', '861916', '0');
INSERT INTO `auction` VALUES ('19694', '2', '37540', '9719', '2', '423750', '1294060778', '0', '0', '355950', '0');
INSERT INTO `auction` VALUES ('22633', '2', '40495', '31952', '2', '36210', '1294098068', '0', '0', '30778', '0');
INSERT INTO `auction` VALUES ('21951', '2', '39813', '4377', '2', '2208', '1294124784', '0', '0', '2119', '0');
INSERT INTO `auction` VALUES ('22405', '2', '40267', '5523', '2', '2311', '1294117644', '0', '0', '2172', '0');
INSERT INTO `auction` VALUES ('20475', '6', '38321', '31940', '2', '1399073', '1294068038', '0', '0', '1329119', '0');
INSERT INTO `auction` VALUES ('20742', '7', '38588', '9719', '2', '349500', '1294075238', '0', '0', '307560', '0');
INSERT INTO `auction` VALUES ('21287', '7', '39135', '1944', '2', '16394', '1294075298', '0', '0', '13115', '0');
INSERT INTO `auction` VALUES ('21646', '6', '39495', '24717', '2', '635174', '1294078958', '0', '0', '584360', '0');
INSERT INTO `auction` VALUES ('22478', '6', '40340', '753', '2', '200765', '1294132044', '0', '0', '170650', '0');
INSERT INTO `auction` VALUES ('22306', '7', '40168', '25005', '2', '1309090', '1294099584', '0', '0', '1047272', '0');
INSERT INTO `auction` VALUES ('19693', '2', '37539', '13907', '2', '322', '1294060778', '0', '0', '309', '0');
INSERT INTO `auction` VALUES ('22746', '7', '40608', '1482', '2', '238337', '1294098068', '0', '0', '221653', '0');
INSERT INTO `auction` VALUES ('22103', '6', '39965', '9719', '2', '361000', '1294081584', '0', '0', '310460', '0');
INSERT INTO `auction` VALUES ('22549', '7', '40411', '37147', '2', '3165', '1294135644', '0', '0', '3070', '0');
INSERT INTO `auction` VALUES ('20254', '7', '38100', '20543', '2', '9150', '1294075178', '0', '0', '8326', '0');
INSERT INTO `auction` VALUES ('20662', '6', '38508', '9719', '2', '379750', '1294082438', '0', '0', '300002', '0');
INSERT INTO `auction` VALUES ('21817', '2', '39679', '9428', '2', '174630', '1294128384', '0', '0', '148435', '0');
INSERT INTO `auction` VALUES ('21996', '6', '39858', '4377', '2', '23370', '1294099584', '0', '0', '16826', '0');
INSERT INTO `auction` VALUES ('22259', '7', '40121', '22642', '2', '2720', '1294088784', '0', '0', '2284', '0');
INSERT INTO `auction` VALUES ('21377', '7', '39225', '36279', '2', '3464737', '1294075298', '0', '0', '3464737', '0');
INSERT INTO `auction` VALUES ('20985', '2', '38833', '3336', '2', '185974', '1294075298', '0', '0', '184114', '0');
INSERT INTO `auction` VALUES ('21281', '7', '39129', '4394', '2', '36960', '1294078898', '0', '0', '34372', '0');
INSERT INTO `auction` VALUES ('21458', '7', '39306', '27516', '2', '16880', '1294082498', '0', '0', '15192', '0');
INSERT INTO `auction` VALUES ('21994', '6', '39856', '4565', '2', '347', '1294113984', '0', '0', '336', '0');
INSERT INTO `auction` VALUES ('21322', '7', '39170', '36665', '2', '3565016', '1294078898', '0', '0', '3279814', '0');
INSERT INTO `auction` VALUES ('21215', '6', '39063', '36394', '2', '2164543', '1294068098', '0', '0', '2099606', '0');
INSERT INTO `auction` VALUES ('21798', '2', '39660', '2203', '2', '69639', '1294081584', '0', '0', '64764', '0');
INSERT INTO `auction` VALUES ('22691', '6', '40553', '8152', '2', '7560', '1294137668', '0', '0', '5518', '0');
INSERT INTO `auction` VALUES ('20779', '7', '38625', '36781', '2', '33760', '1294057238', '0', '0', '25657', '0');
INSERT INTO `auction` VALUES ('22133', '6', '39995', '25271', '2', '1972439', '1294135584', '0', '0', '1617399', '0');
INSERT INTO `auction` VALUES ('20158', '7', '38004', '2244', '2', '9015513', '1294078778', '0', '0', '7753341', '0');
INSERT INTO `auction` VALUES ('19854', '2', '37700', '2749', '2', '23760', '1294075178', '0', '0', '16632', '0');
INSERT INTO `auction` VALUES ('19772', '2', '37618', '13914', '2', '960', '1294057178', '0', '0', '960', '0');
INSERT INTO `auction` VALUES ('20908', '2', '38756', '9262', '2', '27240', '1294068098', '0', '0', '23698', '0');
INSERT INTO `auction` VALUES ('22369', '2', '40231', '44475', '2', '147', '1294110444', '0', '0', '130', '0');
INSERT INTO `auction` VALUES ('22471', '6', '40333', '24776', '2', '1122870', '1294132044', '0', '0', '954439', '0');
INSERT INTO `auction` VALUES ('22062', '6', '39924', '10400', '2', '25981', '1294099584', '0', '0', '21564', '0');
INSERT INTO `auction` VALUES ('22164', '7', '40026', '25874', '2', '0', '1294088784', '0', '0', '0', '0');
INSERT INTO `auction` VALUES ('22035', '6', '39897', '6195', '2', '23254', '1294121184', '0', '0', '19533', '0');
INSERT INTO `auction` VALUES ('21861', '2', '39723', '36595', '2', '5768446', '1294099584', '0', '0', '5595392', '0');
INSERT INTO `auction` VALUES ('20869', '2', '38717', '37159', '2', '12480', '1294064498', '0', '0', '10483', '0');
INSERT INTO `auction` VALUES ('21403', '7', '39251', '14826', '2', '166397', '1294064498', '0', '0', '154749', '0');
INSERT INTO `auction` VALUES ('21216', '6', '39064', '15687', '2', '1728314', '1294068098', '0', '0', '1693747', '0');
INSERT INTO `auction` VALUES ('19707', '2', '37553', '2798', '2', '190', '1294078778', '0', '0', '190', '0');
INSERT INTO `auction` VALUES ('21813', '2', '39675', '9719', '2', '378250', '1294095984', '0', '0', '310165', '0');
INSERT INTO `auction` VALUES ('20478', '6', '38324', '14169', '2', '3412', '1294068038', '0', '0', '2490', '0');
INSERT INTO `auction` VALUES ('20170', '7', '38016', '9719', '2', '321750', '1294053578', '0', '0', '312097', '0');
INSERT INTO `auction` VALUES ('20642', '6', '38488', '1405', '2', '69903', '1294060838', '0', '0', '56621', '0');
INSERT INTO `auction` VALUES ('21402', '7', '39250', '2073', '2', '47576', '1294053698', '0', '0', '41391', '0');
INSERT INTO `auction` VALUES ('22316', '7', '40178', '1930', '2', '20355', '1294081584', '0', '0', '18726', '0');
INSERT INTO `auction` VALUES ('22482', '6', '40344', '32715', '2', '2052000', '1294114044', '0', '0', '1805760', '0');
INSERT INTO `auction` VALUES ('22464', '6', '40326', '18588', '2', '12096', '1294110444', '0', '0', '11249', '0');
INSERT INTO `auction` VALUES ('21976', '6', '39838', '4445', '2', '120886', '1294103184', '0', '0', '106379', '0');
INSERT INTO `auction` VALUES ('21320', '7', '39168', '27511', '2', '218', '1294071698', '0', '0', '202', '0');
INSERT INTO `auction` VALUES ('21899', '2', '39761', '8152', '2', '13980', '1294085184', '0', '0', '10904', '0');
INSERT INTO `auction` VALUES ('22374', '2', '40236', '36054', '2', '1176216', '1294124844', '0', '0', '1082118', '0');
INSERT INTO `auction` VALUES ('21656', '7', '39505', '8292', '2', '465376', '1294075358', '0', '0', '451414', '0');
INSERT INTO `auction` VALUES ('21319', '7', '39167', '25215', '2', '4027980', '1294068098', '0', '0', '3866860', '0');
INSERT INTO `auction` VALUES ('22664', '2', '40526', '8152', '2', '62400', '1294090868', '0', '0', '54912', '0');
INSERT INTO `auction` VALUES ('19901', '6', '37747', '9719', '2', '436000', '1294082378', '0', '0', '392400', '0');
INSERT INTO `auction` VALUES ('21318', '7', '39166', '25088', '2', '1253740', '1294078898', '0', '0', '1002992', '0');
INSERT INTO `auction` VALUES ('20123', '7', '37969', '3053', '2', '145039', '1294082378', '0', '0', '121832', '0');
INSERT INTO `auction` VALUES ('20128', '7', '37974', '2020', '2', '51660', '1294071578', '0', '0', '44427', '0');
INSERT INTO `auction` VALUES ('22317', '7', '40179', '36555', '2', '6630312', '1294121184', '0', '0', '6298796', '0');
INSERT INTO `auction` VALUES ('21401', '7', '39249', '4387', '2', '33120', '1294064498', '0', '0', '30139', '0');
INSERT INTO `auction` VALUES ('21337', '7', '39185', '2955', '2', '209206', '1294078898', '0', '0', '177825', '0');
INSERT INTO `auction` VALUES ('22692', '6', '40554', '5637', '2', '1038', '1294108868', '0', '0', '1038', '0');
INSERT INTO `auction` VALUES ('22486', '6', '40348', '6358', '2', '372', '1294110444', '0', '0', '271', '0');
INSERT INTO `auction` VALUES ('22152', '7', '40014', '811', '2', '11817931', '1294099584', '0', '0', '9808882', '0');
INSERT INTO `auction` VALUES ('22707', '6', '40569', '6358', '2', '248', '1294090868', '0', '0', '245', '0');
INSERT INTO `auction` VALUES ('22634', '2', '40496', '6359', '2', '585', '1294098068', '0', '0', '497', '0');
INSERT INTO `auction` VALUES ('22058', '6', '39920', '8292', '2', '554319', '1294092384', '0', '0', '493343', '0');
INSERT INTO `auction` VALUES ('22318', '7', '40180', '8152', '2', '44160', '1294081584', '0', '0', '41952', '0');
INSERT INTO `auction` VALUES ('21282', '7', '39130', '12804', '2', '197120', '1294071698', '0', '0', '195148', '0');
INSERT INTO `auction` VALUES ('20396', '2', '38242', '9719', '2', '433250', '1294071638', '0', '0', '433250', '0');
INSERT INTO `auction` VALUES ('19848', '2', '37694', '13757', '2', '27456', '1294071578', '0', '0', '25534', '0');
INSERT INTO `auction` VALUES ('22147', '6', '40009', '756', '2', '340268', '1294113984', '0', '0', '275617', '0');
INSERT INTO `auction` VALUES ('20789', '7', '38635', '3322', '2', '127', '1294068038', '0', '0', '123', '0');
INSERT INTO `auction` VALUES ('22643', '2', '40505', '9719', '2', '322750', '1294126868', '0', '0', '322750', '0');
INSERT INTO `auction` VALUES ('22078', '6', '39940', '31151', '2', '1547115', '1294088784', '0', '0', '1175807', '0');
INSERT INTO `auction` VALUES ('21797', '2', '39659', '3260', '2', '76', '1294099584', '0', '0', '63', '0');
INSERT INTO `auction` VALUES ('21043', '2', '38891', '44475', '2', '191', '1294075298', '0', '0', '148', '0');
INSERT INTO `auction` VALUES ('20061', '6', '37907', '3227', '2', '167773', '1294078778', '0', '0', '140929', '0');
INSERT INTO `auction` VALUES ('20115', '7', '37961', '24825', '2', '958959', '1294053578', '0', '0', '843883', '0');
INSERT INTO `auction` VALUES ('20310', '2', '38156', '25334', '2', '5050778', '1294053638', '0', '0', '5000270', '0');
INSERT INTO `auction` VALUES ('20778', '7', '38624', '16680', '2', '1106503', '1294078838', '0', '0', '829877', '0');
INSERT INTO `auction` VALUES ('22442', '2', '40304', '9060', '2', '167280', '1294128444', '0', '0', '150552', '0');
INSERT INTO `auction` VALUES ('20379', '2', '38225', '34828', '2', '854809', '1294082438', '0', '0', '837712', '0');
INSERT INTO `auction` VALUES ('21916', '2', '39778', '37147', '2', '2430', '1294092384', '0', '0', '1895', '0');
INSERT INTO `auction` VALUES ('22109', '6', '39971', '37771', '2', '2016036', '1294124784', '0', '0', '1532187', '0');
INSERT INTO `auction` VALUES ('21944', '2', '39806', '36397', '2', '4491792', '1294092384', '0', '0', '4357038', '0');
INSERT INTO `auction` VALUES ('22669', '6', '40531', '36743', '2', '408600', '1294080068', '0', '0', '314622', '0');
INSERT INTO `auction` VALUES ('20439', '2', '38285', '9061', '2', '31220', '1294053638', '0', '0', '23727', '0');
INSERT INTO `auction` VALUES ('22264', '7', '40126', '9719', '2', '423250', '1294077984', '0', '0', '355530', '0');
INSERT INTO `auction` VALUES ('20328', '2', '38174', '10562', '2', '56760', '1294071638', '0', '0', '41434', '0');
INSERT INTO `auction` VALUES ('22515', '6', '40377', '9061', '2', '18320', '1294106844', '0', '0', '16121', '0');
INSERT INTO `auction` VALUES ('20183', '7', '38029', '13422', '2', '1557', '1294064378', '0', '0', '1401', '0');
INSERT INTO `auction` VALUES ('21114', '6', '38962', '3164', '2', '631', '1294075298', '0', '0', '460', '0');
INSERT INTO `auction` VALUES ('22242', '7', '40104', '9719', '2', '348750', '1294092384', '0', '0', '306900', '0');
INSERT INTO `auction` VALUES ('22677', '6', '40539', '5112', '2', '42753', '1294083668', '0', '0', '41897', '0');
INSERT INTO `auction` VALUES ('21000', '2', '38848', '36637', '2', '4652178', '1294068098', '0', '0', '3861307', '0');
INSERT INTO `auction` VALUES ('19753', '2', '37599', '2292', '2', '93035', '1294057178', '0', '0', '79079', '0');
INSERT INTO `auction` VALUES ('20849', '7', '38695', '4476', '2', '111700', '1294053638', '0', '0', '107232', '0');
INSERT INTO `auction` VALUES ('20556', '6', '38402', '17683', '2', '898570', '1294057238', '0', '0', '871612', '0');
INSERT INTO `auction` VALUES ('20178', '7', '38024', '37117', '2', '2525037', '1294078778', '0', '0', '1969528', '0');
INSERT INTO `auction` VALUES ('19712', '2', '37558', '28494', '2', '3394981', '1294057178', '0', '0', '2648085', '0');
INSERT INTO `auction` VALUES ('21076', '6', '38924', '36581', '2', '7180479', '1294075298', '0', '0', '6534235', '0');
INSERT INTO `auction` VALUES ('22046', '6', '39908', '25874', '2', '0', '1294092384', '0', '0', '0', '0');
INSERT INTO `auction` VALUES ('20141', '7', '37987', '4263', '2', '996', '1294082378', '0', '0', '926', '0');
INSERT INTO `auction` VALUES ('21275', '7', '39123', '25117', '2', '3833745', '1294071698', '0', '0', '3565382', '0');
INSERT INTO `auction` VALUES ('20027', '6', '37873', '31216', '2', '1807308', '1294071578', '0', '0', '1753088', '0');
INSERT INTO `auction` VALUES ('22292', '7', '40154', '22282', '2', '12', '1294117584', '0', '0', '11', '0');
INSERT INTO `auction` VALUES ('19860', '2', '37706', '2080', '2', '354255', '1294071578', '0', '0', '301116', '0');
INSERT INTO `auction` VALUES ('22193', '7', '40055', '2011', '2', '286286', '1294103184', '0', '0', '243343', '0');
INSERT INTO `auction` VALUES ('21820', '2', '39682', '25463', '2', '515200', '1294128384', '0', '0', '468832', '0');
INSERT INTO `auction` VALUES ('20848', '7', '38694', '2057', '2', '174', '1294064438', '0', '0', '123', '0');
INSERT INTO `auction` VALUES ('21416', '7', '39264', '4638', '2', '9000', '1294064498', '0', '0', '7920', '0');
INSERT INTO `auction` VALUES ('21637', '6', '39486', '36288', '2', '2897481', '1294068158', '0', '0', '2839531', '0');
INSERT INTO `auction` VALUES ('20190', '7', '38036', '37759', '2', '2111756', '1294075178', '0', '0', '1816110', '0');
INSERT INTO `auction` VALUES ('19962', '6', '37808', '3008', '2', '428', '1294053578', '0', '0', '410', '0');
INSERT INTO `auction` VALUES ('21972', '6', '39834', '13000', '2', '4214507', '1294113984', '0', '0', '3877346', '0');
INSERT INTO `auction` VALUES ('21226', '6', '39074', '10562', '2', '36120', '1294068098', '0', '0', '26367', '0');
INSERT INTO `auction` VALUES ('21821', '2', '39683', '20527', '2', '59500', '1294135584', '0', '0', '42840', '0');
INSERT INTO `auction` VALUES ('22614', '7', '40476', '9262', '2', '6160', '1294088844', '0', '0', '5420', '0');
INSERT INTO `auction` VALUES ('22408', '2', '40270', '6180', '2', '23160', '1294078044', '0', '0', '20380', '0');
INSERT INTO `auction` VALUES ('21870', '2', '39732', '24603', '2', '953824', '1294128384', '0', '0', '839365', '0');
INSERT INTO `auction` VALUES ('22289', '7', '40151', '24685', '2', '997522', '1294081584', '0', '0', '947645', '0');
INSERT INTO `auction` VALUES ('20220', '7', '38066', '9719', '2', '404750', '1294078778', '0', '0', '364275', '0');
INSERT INTO `auction` VALUES ('22384', '2', '40246', '4402', '2', '3180', '1294117644', '0', '0', '2734', '0');
INSERT INTO `auction` VALUES ('22592', '7', '40454', '40199', '2', '2754', '1294121244', '0', '0', '2120', '0');
INSERT INTO `auction` VALUES ('20225', '7', '38071', '1717', '2', '253629', '1294053578', '0', '0', '195294', '0');
INSERT INTO `auction` VALUES ('22697', '6', '40559', '4611', '2', '5412', '1294098068', '0', '0', '5249', '0');
INSERT INTO `auction` VALUES ('22337', '7', '40199', '2175', '2', '129061', '1294124784', '0', '0', '110992', '0');
INSERT INTO `auction` VALUES ('20592', '6', '38438', '9719', '2', '417000', '1294078838', '0', '0', '404490', '0');
INSERT INTO `auction` VALUES ('20615', '6', '38461', '13755', '2', '2784', '1294060838', '0', '0', '1976', '0');
INSERT INTO `auction` VALUES ('20454', '2', '38300', '9719', '2', '384500', '1294071638', '0', '0', '326825', '0');
INSERT INTO `auction` VALUES ('22068', '6', '39930', '36667', '2', '3679525', '1294085184', '0', '0', '3090801', '0');
INSERT INTO `auction` VALUES ('21985', '6', '39847', '31217', '2', '3408962', '1294124784', '0', '0', '3068065', '0');
INSERT INTO `auction` VALUES ('20880', '2', '38728', '6358', '2', '587', '1294060898', '0', '0', '575', '0');
INSERT INTO `auction` VALUES ('22286', '7', '40148', '3018', '2', '31906', '1294085184', '0', '0', '31586', '0');
INSERT INTO `auction` VALUES ('21046', '2', '38894', '13757', '2', '30732', '1294075298', '0', '0', '22741', '0');
INSERT INTO `auction` VALUES ('22670', '6', '40532', '9719', '2', '315000', '1294094468', '0', '0', '255150', '0');
INSERT INTO `auction` VALUES ('22205', '7', '40067', '9719', '2', '409750', '1294081584', '0', '0', '344190', '0');
INSERT INTO `auction` VALUES ('22705', '6', '40567', '36164', '2', '2369333', '1294094468', '0', '0', '2227173', '0');
INSERT INTO `auction` VALUES ('21904', '2', '39766', '25061', '2', '1293083', '1294106784', '0', '0', '1293083', '0');
INSERT INTO `auction` VALUES ('22686', '6', '40548', '9719', '2', '418250', '1294134068', '0', '0', '330417', '0');
INSERT INTO `auction` VALUES ('21124', '6', '38972', '1927', '2', '42033', '1294053698', '0', '0', '39090', '0');
INSERT INTO `auction` VALUES ('22294', '7', '40156', '10514', '2', '79920', '1294121184', '0', '0', '65534', '0');
INSERT INTO `auction` VALUES ('21978', '6', '39840', '24712', '2', '632831', '1294085184', '0', '0', '556891', '0');
INSERT INTO `auction` VALUES ('22509', '6', '40371', '3058', '2', '30691', '1294081644', '0', '0', '27314', '0');
INSERT INTO `auction` VALUES ('22319', '7', '40181', '25187', '2', '3327141', '1294135584', '0', '0', '2761527', '0');
INSERT INTO `auction` VALUES ('20847', '7', '38693', '18255', '2', '2388', '1294078838', '0', '0', '2029', '0');
INSERT INTO `auction` VALUES ('22531', '6', '40393', '7973', '2', '7030', '1294132044', '0', '0', '6819', '0');
INSERT INTO `auction` VALUES ('20437', '2', '38283', '2069', '2', '1427', '1294071638', '0', '0', '1369', '0');
INSERT INTO `auction` VALUES ('20534', '6', '38380', '4611', '2', '4510', '1294071638', '0', '0', '3247', '0');
INSERT INTO `auction` VALUES ('20182', '7', '38028', '1720', '2', '2137392', '1294075178', '0', '0', '1859531', '0');
INSERT INTO `auction` VALUES ('21890', '2', '39752', '727', '2', '10657', '1294117584', '0', '0', '9697', '0');
INSERT INTO `auction` VALUES ('21169', '6', '39017', '36693', '2', '6934335', '1294060898', '0', '0', '6448931', '0');
INSERT INTO `auction` VALUES ('21990', '6', '39852', '9719', '2', '314500', '1294124784', '0', '0', '298775', '0');
INSERT INTO `auction` VALUES ('21650', '6', '39499', '10559', '2', '24450', '1294053758', '0', '0', '19804', '0');
INSERT INTO `auction` VALUES ('22638', '2', '40500', '36997', '2', '1873314', '1294137668', '0', '0', '1554850', '0');
INSERT INTO `auction` VALUES ('21453', '7', '39301', '41119', '2', '33660', '1294071698', '0', '0', '30630', '0');
INSERT INTO `auction` VALUES ('21506', '2', '39355', '39682', '2', '196800', '1294078958', '0', '0', '175152', '0');
INSERT INTO `auction` VALUES ('22138', '6', '40000', '25326', '2', '4332303', '1294113984', '0', '0', '3682457', '0');
INSERT INTO `auction` VALUES ('22732', '7', '40594', '36271', '2', '1985628', '1294098068', '0', '0', '1926059', '0');
INSERT INTO `auction` VALUES ('20614', '6', '38460', '6359', '2', '140', '1294057238', '0', '0', '130', '0');
INSERT INTO `auction` VALUES ('20207', '7', '38053', '36267', '2', '1303984', '1294082378', '0', '0', '1199665', '0');
INSERT INTO `auction` VALUES ('22365', '2', '40227', '3164', '2', '2686', '1294117644', '0', '0', '2471', '0');
INSERT INTO `auction` VALUES ('20197', '7', '38043', '17055', '2', '2182805', '1294075178', '0', '0', '1986352', '0');
INSERT INTO `auction` VALUES ('19751', '2', '37597', '30738', '2', '5707448', '1294078778', '0', '0', '5250852', '0');
INSERT INTO `auction` VALUES ('22134', '6', '39996', '2233', '2', '70743', '1294131984', '0', '0', '62253', '0');
INSERT INTO `auction` VALUES ('19837', '2', '37683', '9719', '2', '370750', '1294067978', '0', '0', '341090', '0');
INSERT INTO `auction` VALUES ('22186', '7', '40048', '9061', '2', '9200', '1294117584', '0', '0', '7452', '0');
INSERT INTO `auction` VALUES ('20730', '7', '38576', '36057', '2', '1502071', '1294071638', '0', '0', '1291781', '0');
INSERT INTO `auction` VALUES ('22231', '7', '40093', '25200', '2', '3304113', '1294081584', '0', '0', '2973701', '0');
INSERT INTO `auction` VALUES ('22586', '7', '40448', '5749', '2', '120297', '1294099644', '0', '0', '120297', '0');
INSERT INTO `auction` VALUES ('21522', '2', '39371', '1560', '2', '33730', '1294075358', '0', '0', '32380', '0');
INSERT INTO `auction` VALUES ('21355', '7', '39203', '27515', '2', '13860', '1294060898', '0', '0', '11642', '0');
INSERT INTO `auction` VALUES ('22526', '6', '40388', '44475', '2', '123', '1294078044', '0', '0', '102', '0');
INSERT INTO `auction` VALUES ('22699', '6', '40561', '14554', '2', '9286719', '1294108868', '0', '0', '9008117', '0');
INSERT INTO `auction` VALUES ('20380', '2', '38226', '25046', '2', '1252598', '1294060838', '0', '0', '1139864', '0');
INSERT INTO `auction` VALUES ('20937', '2', '38785', '36610', '2', '6170367', '1294053698', '0', '0', '5491626', '0');
INSERT INTO `auction` VALUES ('21979', '6', '39841', '2259', '2', '676', '1294135584', '0', '0', '642', '0');
INSERT INTO `auction` VALUES ('22654', '2', '40516', '24826', '2', '1079383', '1294105268', '0', '0', '1079383', '0');
INSERT INTO `auction` VALUES ('20205', '7', '38051', '9719', '2', '436250', '1294075178', '0', '0', '366450', '0');
INSERT INTO `auction` VALUES ('22279', '7', '40141', '9719', '2', '435000', '1294092384', '0', '0', '404550', '0');
INSERT INTO `auction` VALUES ('19908', '6', '37754', '9719', '2', '344000', '1294075178', '0', '0', '261440', '0');
INSERT INTO `auction` VALUES ('20820', '7', '38666', '6354', '2', '9', '1294082438', '0', '0', '6', '0');
INSERT INTO `auction` VALUES ('20016', '6', '37862', '14170', '2', '3144', '1294064378', '0', '0', '2892', '0');
INSERT INTO `auction` VALUES ('21980', '6', '39842', '5524', '2', '3502', '1294113984', '0', '0', '3396', '0');
INSERT INTO `auction` VALUES ('22352', '2', '40214', '814', '2', '4180', '1294081644', '0', '0', '4096', '0');
INSERT INTO `auction` VALUES ('22422', '2', '40284', '1288', '2', '1598', '1294099644', '0', '0', '1502', '0');
INSERT INTO `auction` VALUES ('19963', '6', '37809', '25033', '2', '1215305', '1294078778', '0', '0', '1142386', '0');
INSERT INTO `auction` VALUES ('20177', '7', '38023', '9719', '2', '366000', '1294082378', '0', '0', '314760', '0');
INSERT INTO `auction` VALUES ('22010', '6', '39872', '4047', '2', '226896', '1294106784', '0', '0', '186054', '0');
INSERT INTO `auction` VALUES ('20189', '7', '38035', '811', '2', '7044212', '1294071578', '0', '0', '6692001', '0');
INSERT INTO `auction` VALUES ('21734', '7', '39583', '4474', '2', '271587', '1294060958', '0', '0', '258007', '0');
INSERT INTO `auction` VALUES ('20452', '2', '38298', '25068', '2', '1855835', '1294057238', '0', '0', '1800159', '0');
INSERT INTO `auction` VALUES ('20936', '2', '38784', '4636', '2', '5944', '1294057298', '0', '0', '5765', '0');
INSERT INTO `auction` VALUES ('21957', '6', '39819', '18295', '2', '984521', '1294095984', '0', '0', '974675', '0');
INSERT INTO `auction` VALUES ('22232', '7', '40094', '6643', '2', '51', '1294077984', '0', '0', '37', '0');
INSERT INTO `auction` VALUES ('20623', '6', '38469', '5967', '2', '12719', '1294068038', '0', '0', '12337', '0');
INSERT INTO `auction` VALUES ('22700', '6', '40562', '5180', '2', '95434', '1294112468', '0', '0', '94479', '0');
INSERT INTO `auction` VALUES ('21452', '7', '39300', '5753', '2', '106385', '1294075298', '0', '0', '88299', '0');
INSERT INTO `auction` VALUES ('21958', '6', '39820', '6363', '2', '2350', '1294117584', '0', '0', '1927', '0');
INSERT INTO `auction` VALUES ('19722', '2', '37568', '9719', '2', '426750', '1294071578', '0', '0', '367005', '0');
INSERT INTO `auction` VALUES ('21695', '7', '39544', '18512', '2', '56640', '1294075358', '0', '0', '54374', '0');
INSERT INTO `auction` VALUES ('20203', '7', '38049', '6579', '2', '6644', '1294064378', '0', '0', '5647', '0');
INSERT INTO `auction` VALUES ('22742', '7', '40604', '44673', '2', '2425366', '1294098068', '0', '0', '1916039', '0');
INSERT INTO `auction` VALUES ('20719', '7', '38565', '4402', '2', '1780', '1294057238', '0', '0', '1246', '0');
INSERT INTO `auction` VALUES ('19954', '6', '37800', '24949', '2', '1421738', '1294078778', '0', '0', '1236912', '0');
INSERT INTO `auction` VALUES ('20434', '2', '38280', '4290', '2', '32729', '1294082438', '0', '0', '29456', '0');
INSERT INTO `auction` VALUES ('22726', '7', '40588', '9719', '2', '345250', '1294098068', '0', '0', '338345', '0');
INSERT INTO `auction` VALUES ('22749', '7', '40611', '1523', '2', '650547', '1294112468', '0', '0', '585492', '0');
INSERT INTO `auction` VALUES ('22723', '7', '40585', '9719', '2', '423500', '1294137668', '0', '0', '326095', '0');
INSERT INTO `auction` VALUES ('22050', '6', '39912', '24888', '2', '2573301', '1294092384', '0', '0', '2110106', '0');
INSERT INTO `auction` VALUES ('22378', '2', '40240', '37147', '2', '9200', '1294110444', '0', '0', '8464', '0');
INSERT INTO `auction` VALUES ('22139', '6', '40001', '24667', '2', '1081026', '1294081584', '0', '0', '1037784', '0');
INSERT INTO `auction` VALUES ('22020', '6', '39882', '18744', '2', '935899', '1294085184', '0', '0', '917181', '0');
INSERT INTO `auction` VALUES ('22536', '6', '40398', '41119', '2', '32370', '1294085244', '0', '0', '24601', '0');
INSERT INTO `auction` VALUES ('20286', '2', '38132', '19943', '2', '50880', '1294068038', '0', '0', '35616', '0');
INSERT INTO `auction` VALUES ('20829', '7', '38675', '9719', '2', '332000', '1294057238', '0', '0', '275560', '0');
INSERT INTO `auction` VALUES ('22566', '7', '40428', '3018', '2', '33906', '1294103244', '0', '0', '28481', '0');
INSERT INTO `auction` VALUES ('20777', '7', '38623', '9719', '2', '382250', '1294075238', '0', '0', '309622', '0');
INSERT INTO `auction` VALUES ('20934', '2', '38782', '36173', '2', '2956677', '1294071698', '0', '0', '2897543', '0');
INSERT INTO `auction` VALUES ('22650', '2', '40512', '9360', '2', '3040', '1294090868', '0', '0', '2675', '0');
INSERT INTO `auction` VALUES ('22149', '6', '40011', '40199', '2', '8436', '1294099584', '0', '0', '8182', '0');
INSERT INTO `auction` VALUES ('19907', '6', '37753', '1981', '2', '3008228', '1294071578', '0', '0', '2587076', '0');
INSERT INTO `auction` VALUES ('22091', '6', '39953', '9061', '2', '8480', '1294113984', '0', '0', '6868', '0');
INSERT INTO `auction` VALUES ('21727', '7', '39576', '1462', '2', '62909', '1294082558', '0', '0', '55989', '0');
INSERT INTO `auction` VALUES ('20539', '6', '38385', '4359', '2', '410', '1294064438', '0', '0', '397', '0');
INSERT INTO `auction` VALUES ('22071', '6', '39933', '36456', '2', '3266419', '1294128384', '0', '0', '2678463', '0');
INSERT INTO `auction` VALUES ('22174', '7', '40036', '1204', '2', '1797281', '1294103184', '0', '0', '1509716', '0');
INSERT INTO `auction` VALUES ('22140', '6', '40002', '4359', '2', '1162', '1294106784', '0', '0', '1057', '0');
INSERT INTO `auction` VALUES ('22303', '7', '40165', '1462', '2', '43785', '1294103184', '0', '0', '39406', '0');
INSERT INTO `auction` VALUES ('22025', '6', '39887', '9719', '2', '353250', '1294092384', '0', '0', '272002', '0');
INSERT INTO `auction` VALUES ('22363', '2', '40225', '24832', '2', '1661484', '1294106844', '0', '0', '1644869', '0');
INSERT INTO `auction` VALUES ('20654', '6', '38500', '9719', '2', '363250', '1294071638', '0', '0', '326925', '0');
INSERT INTO `auction` VALUES ('21999', '6', '39861', '9719', '2', '376750', '1294121184', '0', '0', '361680', '0');
INSERT INTO `auction` VALUES ('22622', '7', '40484', '4394', '2', '70560', '1294117644', '0', '0', '66326', '0');
INSERT INTO `auction` VALUES ('20124', '7', '37970', '2566', '2', '86365', '1294057178', '0', '0', '79455', '0');
INSERT INTO `auction` VALUES ('21962', '6', '39824', '2744', '2', '12000', '1294095984', '0', '0', '9600', '0');
INSERT INTO `auction` VALUES ('21696', '7', '39545', '5029', '2', '213624', '1294082558', '0', '0', '183716', '0');
INSERT INTO `auction` VALUES ('20013', '6', '37859', '31232', '2', '2428252', '1294057178', '0', '0', '2355404', '0');
INSERT INTO `auction` VALUES ('20828', '7', '38674', '10505', '2', '15750', '1294053638', '0', '0', '11182', '0');
INSERT INTO `auction` VALUES ('21770', '2', '39632', '9719', '2', '364750', '1294099584', '0', '0', '328275', '0');
INSERT INTO `auction` VALUES ('20783', '7', '38629', '36281', '2', '3577696', '1294078838', '0', '0', '3255703', '0');
INSERT INTO `auction` VALUES ('20656', '6', '38502', '10559', '2', '21000', '1294078838', '0', '0', '20370', '0');
INSERT INTO `auction` VALUES ('21922', '2', '39784', '5754', '2', '83271', '1294131984', '0', '0', '71613', '0');
INSERT INTO `auction` VALUES ('20045', '6', '37891', '2110', '2', '75', '1294075178', '0', '0', '72', '0');
INSERT INTO `auction` VALUES ('20929', '2', '38777', '10562', '2', '111360', '1294075298', '0', '0', '85747', '0');
INSERT INTO `auction` VALUES ('22141', '6', '40003', '36570', '2', '7375468', '1294110384', '0', '0', '6564166', '0');
INSERT INTO `auction` VALUES ('21349', '7', '39197', '19441', '2', '28560', '1294071698', '0', '0', '24847', '0');
INSERT INTO `auction` VALUES ('21697', '7', '39546', '25144', '2', '2764143', '1294053758', '0', '0', '2349521', '0');
INSERT INTO `auction` VALUES ('21981', '6', '39843', '24939', '2', '2632296', '1294113984', '0', '0', '2342743', '0');
INSERT INTO `auction` VALUES ('22561', '7', '40423', '1925', '2', '38680', '1294135644', '0', '0', '32104', '0');
INSERT INTO `auction` VALUES ('21937', '2', '39799', '36569', '2', '6856581', '1294103184', '0', '0', '5896659', '0');
INSERT INTO `auction` VALUES ('22052', '6', '39914', '3331', '2', '797', '1294117584', '0', '0', '781', '0');
INSERT INTO `auction` VALUES ('21629', '6', '39478', '789', '2', '85865', '1294082558', '0', '0', '69550', '0');
INSERT INTO `auction` VALUES ('20979', '2', '38827', '4387', '2', '18240', '1294053698', '0', '0', '15504', '0');
INSERT INTO `auction` VALUES ('20511', '6', '38357', '3164', '2', '2563', '1294057238', '0', '0', '2255', '0');
INSERT INTO `auction` VALUES ('21212', '6', '39060', '920', '2', '165475', '1294071698', '0', '0', '137344', '0');
INSERT INTO `auction` VALUES ('20030', '6', '37876', '5109', '2', '2276', '1294075178', '0', '0', '2184', '0');
INSERT INTO `auction` VALUES ('22457', '6', '40319', '10560', '2', '19080', '1294099644', '0', '0', '18507', '0');
INSERT INTO `auction` VALUES ('20919', '2', '38767', '1220', '2', '81983', '1294068098', '0', '0', '81163', '0');
INSERT INTO `auction` VALUES ('22049', '6', '39911', '2754', '2', '135', '1294095984', '0', '0', '106', '0');
INSERT INTO `auction` VALUES ('22569', '7', '40431', '24939', '2', '1912705', '1294085244', '0', '0', '1568418', '0');
INSERT INTO `auction` VALUES ('22065', '6', '39927', '10514', '2', '39360', '1294088784', '0', '0', '37392', '0');
INSERT INTO `auction` VALUES ('22229', '7', '40091', '36430', '2', '1833300', '1294099584', '0', '0', '1631637', '0');
INSERT INTO `auction` VALUES ('20239', '7', '38085', '10403', '2', '42727', '1294060778', '0', '0', '32899', '0');
INSERT INTO `auction` VALUES ('20211', '7', '38057', '2911', '2', '36485', '1294071578', '0', '0', '28458', '0');
INSERT INTO `auction` VALUES ('20625', '6', '38471', '4768', '2', '7126', '1294071638', '0', '0', '6413', '0');
INSERT INTO `auction` VALUES ('21231', '6', '39079', '27516', '2', '18560', '1294068098', '0', '0', '16889', '0');
INSERT INTO `auction` VALUES ('21802', '2', '39664', '4694', '2', '6287', '1294106784', '0', '0', '4840', '0');
INSERT INTO `auction` VALUES ('20281', '2', '38127', '3296', '2', '120', '1294057238', '0', '0', '92', '0');
INSERT INTO `auction` VALUES ('22196', '7', '40058', '9061', '2', '17050', '1294135584', '0', '0', '17050', '0');
INSERT INTO `auction` VALUES ('21888', '2', '39750', '41119', '2', '13300', '1294117584', '0', '0', '9842', '0');
INSERT INTO `auction` VALUES ('22492', '6', '40354', '10246', '2', '729559', '1294132044', '0', '0', '729559', '0');
INSERT INTO `auction` VALUES ('21467', '2', '39316', '10505', '2', '28560', '1294071758', '0', '0', '20277', '0');
INSERT INTO `auction` VALUES ('21179', '6', '39027', '36166', '2', '1246582', '1294078898', '0', '0', '1171787', '0');
INSERT INTO `auction` VALUES ('21093', '6', '38941', '21882', '2', '419900', '1294071698', '0', '0', '293930', '0');
INSERT INTO `auction` VALUES ('21301', '7', '39149', '4462', '2', '88433', '1294060898', '0', '0', '87548', '0');
INSERT INTO `auction` VALUES ('22712', '6', '40574', '17969', '2', '248425', '1294105268', '0', '0', '206192', '0');
INSERT INTO `auction` VALUES ('20464', '6', '38310', '9719', '2', '363500', '1294064438', '0', '0', '276260', '0');
INSERT INTO `auction` VALUES ('19931', '6', '37777', '30726', '2', '16534884', '1294078778', '0', '0', '15046744', '0');
INSERT INTO `auction` VALUES ('22572', '7', '40434', '10329', '2', '158605', '1294110444', '0', '0', '158605', '0');
INSERT INTO `auction` VALUES ('22054', '6', '39916', '9719', '2', '410750', '1294124784', '0', '0', '377890', '0');
INSERT INTO `auction` VALUES ('20852', '7', '38698', '4611', '2', '7296', '1294060838', '0', '0', '6712', '0');
INSERT INTO `auction` VALUES ('21763', '2', '39625', '36277', '2', '4246944', '1294117584', '0', '0', '3524963', '0');
INSERT INTO `auction` VALUES ('20523', '6', '38369', '39970', '2', '84780', '1294071638', '0', '0', '76302', '0');
INSERT INTO `auction` VALUES ('19906', '6', '37752', '14901', '2', '295738', '1294082378', '0', '0', '251377', '0');
INSERT INTO `auction` VALUES ('22564', '7', '40426', '8152', '2', '4140', '1294099644', '0', '0', '2939', '0');
INSERT INTO `auction` VALUES ('22503', '6', '40365', '24613', '2', '754060', '1294128444', '0', '0', '701275', '0');
INSERT INTO `auction` VALUES ('21466', '2', '39315', '3345', '2', '126761', '1294071758', '0', '0', '122958', '0');
INSERT INTO `auction` VALUES ('20671', '7', '38517', '44669', '2', '3199178', '1294057238', '0', '0', '3071210', '0');
INSERT INTO `auction` VALUES ('22404', '2', '40266', '17963', '2', '9735', '1294121244', '0', '0', '9150', '0');
INSERT INTO `auction` VALUES ('20851', '7', '38697', '39682', '2', '449280', '1294060838', '0', '0', '413337', '0');
INSERT INTO `auction` VALUES ('21562', '6', '39411', '36056', '2', '2878655', '1294075358', '0', '0', '2418070', '0');
INSERT INTO `auction` VALUES ('22570', '7', '40432', '3429', '2', '27824', '1294078044', '0', '0', '24485', '0');
INSERT INTO `auction` VALUES ('22602', '7', '40464', '27513', '2', '151', '1294078044', '0', '0', '146', '0');
INSERT INTO `auction` VALUES ('20071', '7', '37917', '10246', '2', '1194563', '1294082378', '0', '0', '1075106', '0');
INSERT INTO `auction` VALUES ('22714', '6', '40576', '36283', '2', '1832491', '1294130468', '0', '0', '1814166', '0');
INSERT INTO `auction` VALUES ('22481', '6', '40343', '5637', '2', '1884', '1294135644', '0', '0', '1507', '0');
INSERT INTO `auction` VALUES ('21245', '6', '39093', '36265', '2', '1997057', '1294060898', '0', '0', '1697498', '0');
INSERT INTO `auction` VALUES ('20587', '6', '38433', '9276', '2', '880', '1294082438', '0', '0', '651', '0');
INSERT INTO `auction` VALUES ('22414', '2', '40276', '10505', '2', '33820', '1294103244', '0', '0', '32129', '0');
INSERT INTO `auction` VALUES ('21805', '2', '39667', '2034', '2', '62976', '1294092384', '0', '0', '57937', '0');
INSERT INTO `auction` VALUES ('22573', '7', '40435', '36053', '2', '2702800', '1294099644', '0', '0', '2459548', '0');
INSERT INTO `auction` VALUES ('22470', '6', '40332', '2075', '2', '21668', '1294088844', '0', '0', '21668', '0');
INSERT INTO `auction` VALUES ('22092', '6', '39954', '34829', '2', '1086800', '1294106784', '0', '0', '912912', '0');
INSERT INTO `auction` VALUES ('21447', '7', '39295', '4445', '2', '85416', '1294078898', '0', '0', '72603', '0');
INSERT INTO `auction` VALUES ('21967', '6', '39829', '2546', '2', '692', '1294081584', '0', '0', '505', '0');
INSERT INTO `auction` VALUES ('22606', '7', '40468', '4394', '2', '107400', '1294114044', '0', '0', '85920', '0');
INSERT INTO `auction` VALUES ('22230', '7', '40092', '31238', '2', '2311407', '1294128384', '0', '0', '1802897', '0');
INSERT INTO `auction` VALUES ('22293', '7', '40155', '10561', '2', '54360', '1294135584', '0', '0', '45118', '0');
INSERT INTO `auction` VALUES ('21163', '6', '39011', '13757', '2', '30912', '1294057298', '0', '0', '23493', '0');
INSERT INTO `auction` VALUES ('22246', '7', '40108', '10505', '2', '29400', '1294117584', '0', '0', '27930', '0');
INSERT INTO `auction` VALUES ('22362', '2', '40224', '4589', '2', '12804', '1294078044', '0', '0', '8962', '0');
INSERT INTO `auction` VALUES ('21548', '2', '39397', '13422', '2', '952', '1294075358', '0', '0', '847', '0');
INSERT INTO `auction` VALUES ('19872', '6', '37718', '27511', '2', '178', '1294075178', '0', '0', '167', '0');
INSERT INTO `auction` VALUES ('21638', '6', '39487', '28497', '2', '968952', '1294057358', '0', '0', '852677', '0');
INSERT INTO `auction` VALUES ('21929', '2', '39791', '36288', '2', '4491914', '1294088784', '0', '0', '4267318', '0');
INSERT INTO `auction` VALUES ('22265', '7', '40127', '36485', '2', '7643216', '1294113984', '0', '0', '7184623', '0');
INSERT INTO `auction` VALUES ('21827', '2', '39689', '2730', '2', '9180', '1294113984', '0', '0', '6701', '0');
INSERT INTO `auction` VALUES ('21956', '6', '39818', '20664', '2', '539018', '1294113984', '0', '0', '436604', '0');
INSERT INTO `auction` VALUES ('22604', '7', '40466', '6359', '2', '296', '1294135644', '0', '0', '213', '0');
INSERT INTO `auction` VALUES ('20669', '7', '38515', '37145', '2', '7550', '1294053638', '0', '0', '7172', '0');
INSERT INTO `auction` VALUES ('21833', '2', '39695', '2742', '2', '22560', '1294106784', '0', '0', '17371', '0');
INSERT INTO `auction` VALUES ('21211', '6', '39059', '3231', '2', '77515', '1294071698', '0', '0', '67438', '0');
INSERT INTO `auction` VALUES ('21774', '2', '39636', '9719', '2', '364000', '1294117584', '0', '0', '338520', '0');
INSERT INTO `auction` VALUES ('22525', '6', '40387', '7973', '2', '4761', '1294128444', '0', '0', '3475', '0');
INSERT INTO `auction` VALUES ('22320', '7', '40182', '36498', '2', '4843321', '1294077984', '0', '0', '3874656', '0');
INSERT INTO `auction` VALUES ('21777', '2', '39639', '45998', '2', '537', '1294128384', '0', '0', '494', '0');
INSERT INTO `auction` VALUES ('22276', '7', '40138', '1213', '2', '805', '1294088784', '0', '0', '652', '0');
INSERT INTO `auction` VALUES ('21694', '7', '39543', '5180', '2', '129098', '1294068158', '0', '0', '105860', '0');
INSERT INTO `auction` VALUES ('22238', '7', '40100', '36390', '2', '2565399', '1294099584', '0', '0', '2514091', '0');
INSERT INTO `auction` VALUES ('20887', '2', '38735', '4633', '2', '2374', '1294075298', '0', '0', '2017', '0');
INSERT INTO `auction` VALUES ('21938', '2', '39800', '1521', '2', '1308861', '1294113984', '0', '0', '1099443', '0');
INSERT INTO `auction` VALUES ('21828', '2', '39690', '9719', '2', '391250', '1294081584', '0', '0', '320825', '0');
INSERT INTO `auction` VALUES ('20402', '2', '38248', '4388', '2', '8200', '1294068038', '0', '0', '5740', '0');
INSERT INTO `auction` VALUES ('20147', '7', '37993', '36525', '2', '5595973', '1294057178', '0', '0', '4644657', '0');
INSERT INTO `auction` VALUES ('21404', '7', '39252', '5742', '2', '540684', '1294075298', '0', '0', '513649', '0');
INSERT INTO `auction` VALUES ('21889', '2', '39751', '5079', '2', '159516', '1294088784', '0', '0', '133993', '0');
INSERT INTO `auction` VALUES ('21977', '6', '39839', '9719', '2', '423000', '1294103184', '0', '0', '384930', '0');
INSERT INTO `auction` VALUES ('20371', '2', '38217', '49227', '2', '11158603', '1294082438', '0', '0', '10489086', '0');
INSERT INTO `auction` VALUES ('21455', '7', '39303', '816', '2', '13614', '1294057298', '0', '0', '13614', '0');
INSERT INTO `auction` VALUES ('21896', '2', '39758', '14900', '2', '459569', '1294085184', '0', '0', '381442', '0');
INSERT INTO `auction` VALUES ('21285', '7', '39133', '10562', '2', '62100', '1294057298', '0', '0', '50922', '0');
INSERT INTO `auction` VALUES ('20795', '7', '38641', '20677', '2', '54480', '1294075238', '0', '0', '44128', '0');
INSERT INTO `auction` VALUES ('22248', '7', '40110', '44686', '2', '2274320', '1294099584', '0', '0', '1819456', '0');
INSERT INTO `auction` VALUES ('22295', '7', '40157', '6333', '2', '128471', '1294113984', '0', '0', '113054', '0');
INSERT INTO `auction` VALUES ('22668', '6', '40530', '9719', '2', '437500', '1294123268', '0', '0', '350000', '0');
INSERT INTO `auction` VALUES ('19750', '2', '37596', '870', '2', '2984857', '1294067978', '0', '0', '2895311', '0');
INSERT INTO `auction` VALUES ('21778', '2', '39640', '21561', '2', '724', '1294103184', '0', '0', '702', '0');
INSERT INTO `auction` VALUES ('20080', '7', '37926', '2164', '2', '5068500', '1294067978', '0', '0', '4156170', '0');
INSERT INTO `auction` VALUES ('20081', '7', '37927', '6358', '2', '107', '1294067978', '0', '0', '77', '0');
INSERT INTO `auction` VALUES ('22199', '7', '40061', '17965', '2', '11674', '1294099584', '0', '0', '10856', '0');
INSERT INTO `auction` VALUES ('22597', '7', '40459', '27515', '2', '10140', '1294081644', '0', '0', '8112', '0');
INSERT INTO `auction` VALUES ('22111', '6', '39973', '9420', '2', '346884', '1294103184', '0', '0', '291382', '0');
INSERT INTO `auction` VALUES ('22051', '6', '39913', '1973', '2', '264192', '1294088784', '0', '0', '229847', '0');
INSERT INTO `auction` VALUES ('21501', '2', '39350', '24476', '2', '5952', '1294078958', '0', '0', '4285', '0');
INSERT INTO `auction` VALUES ('22588', '7', '40450', '36155', '2', '1200661', '1294132044', '0', '0', '996548', '0');
INSERT INTO `auction` VALUES ('22690', '6', '40552', '24715', '2', '1163518', '1294098068', '0', '0', '1035531', '0');
INSERT INTO `auction` VALUES ('22364', '2', '40226', '41119', '2', '25500', '1294078044', '0', '0', '17850', '0');
INSERT INTO `auction` VALUES ('22287', '7', '40149', '13879', '2', '326', '1294077984', '0', '0', '244', '0');
INSERT INTO `auction` VALUES ('21090', '6', '38938', '41119', '2', '29250', '1294064498', '0', '0', '26032', '0');
INSERT INTO `auction` VALUES ('22739', '7', '40601', '45986', '2', '31420', '1294101668', '0', '0', '29220', '0');
INSERT INTO `auction` VALUES ('22524', '6', '40386', '2084', '2', '244370', '1294088844', '0', '0', '215045', '0');
INSERT INTO `auction` VALUES ('22272', '7', '40134', '4589', '2', '17172', '1294124784', '0', '0', '17000', '0');
INSERT INTO `auction` VALUES ('22428', '2', '40290', '5637', '2', '2172', '1294110444', '0', '0', '1867', '0');
INSERT INTO `auction` VALUES ('20370', '2', '38216', '36151', '2', '2087211', '1294068038', '0', '0', '2024594', '0');
INSERT INTO `auction` VALUES ('22463', '6', '40325', '2624', '2', '259293', '1294096044', '0', '0', '222991', '0');
INSERT INTO `auction` VALUES ('20490', '6', '38336', '9719', '2', '405000', '1294060838', '0', '0', '332100', '0');
INSERT INTO `auction` VALUES ('20543', '6', '38389', '44475', '2', '190', '1294078838', '0', '0', '153', '0');
INSERT INTO `auction` VALUES ('22060', '6', '39922', '36041', '2', '1243743', '1294092384', '0', '0', '1106931', '0');
INSERT INTO `auction` VALUES ('22661', '2', '40523', '5523', '2', '1112', '1294087268', '0', '0', '922', '0');
INSERT INTO `auction` VALUES ('21038', '2', '38886', '39681', '2', '242928', '1294068098', '0', '0', '201630', '0');
INSERT INTO `auction` VALUES ('22002', '6', '39864', '31284', '2', '2091315', '1294099584', '0', '0', '2049488', '0');
INSERT INTO `auction` VALUES ('21193', '6', '39041', '886', '2', '158825', '1294057298', '0', '0', '131824', '0');
INSERT INTO `auction` VALUES ('20186', '7', '38032', '1459', '2', '131279', '1294060778', '0', '0', '128653', '0');
INSERT INTO `auction` VALUES ('21858', '2', '39720', '43695', '2', '2370', '1294128384', '0', '0', '2014', '0');
INSERT INTO `auction` VALUES ('22415', '2', '40277', '4377', '2', '10314', '1294088844', '0', '0', '9488', '0');
INSERT INTO `auction` VALUES ('22182', '7', '40044', '10505', '2', '39000', '1294077984', '0', '0', '29640', '0');
INSERT INTO `auction` VALUES ('22535', '6', '40397', '44475', '2', '145', '1294117644', '0', '0', '140', '0');
INSERT INTO `auction` VALUES ('22257', '7', '40119', '20540', '2', '118300', '1294135584', '0', '0', '115934', '0');
INSERT INTO `auction` VALUES ('22512', '6', '40374', '1391', '2', '65781', '1294128444', '0', '0', '65781', '0');
INSERT INTO `auction` VALUES ('22119', '6', '39981', '4377', '2', '9954', '1294081584', '0', '0', '9655', '0');
INSERT INTO `auction` VALUES ('21277', '7', '39125', '4477', '2', '221725', '1294064498', '0', '0', '210638', '0');
INSERT INTO `auction` VALUES ('22475', '6', '40337', '36525', '2', '4786390', '1294085244', '0', '0', '4594934', '0');
INSERT INTO `auction` VALUES ('21089', '6', '38937', '8151', '2', '16470', '1294075298', '0', '0', '15317', '0');
INSERT INTO `auction` VALUES ('20421', '2', '38267', '19943', '2', '283200', '1294064438', '0', '0', '226560', '0');
INSERT INTO `auction` VALUES ('22120', '6', '39982', '18588', '2', '24752', '1294128384', '0', '0', '18068', '0');
INSERT INTO `auction` VALUES ('22653', '2', '40515', '24834', '2', '1275846', '1294123268', '0', '0', '1263087', '0');
INSERT INTO `auction` VALUES ('21963', '6', '39825', '34837', '2', '1469000', '1294099584', '0', '0', '1454310', '0');
INSERT INTO `auction` VALUES ('22559', '7', '40421', '4047', '2', '251843', '1294099644', '0', '0', '219103', '0');
INSERT INTO `auction` VALUES ('19793', '2', '37639', '9719', '2', '341500', '1294082378', '0', '0', '334670', '0');
INSERT INTO `auction` VALUES ('20564', '6', '38410', '36708', '2', '8705185', '1294068038', '0', '0', '8444029', '0');
INSERT INTO `auction` VALUES ('22290', '7', '40152', '36062', '2', '1057498', '1294113984', '0', '0', '909448', '0');
INSERT INTO `auction` VALUES ('22022', '6', '39884', '18588', '2', '18720', '1294113984', '0', '0', '17035', '0');
INSERT INTO `auction` VALUES ('20169', '7', '38015', '13903', '2', '151', '1294057178', '0', '0', '117', '0');
INSERT INTO `auction` VALUES ('20594', '6', '38440', '36485', '2', '7142204', '1294078838', '0', '0', '6070873', '0');
INSERT INTO `auction` VALUES ('19993', '6', '37839', '6299', '2', '244', '1294078778', '0', '0', '190', '0');
INSERT INTO `auction` VALUES ('21964', '6', '39826', '2725', '2', '6090', '1294135584', '0', '0', '6090', '0');
INSERT INTO `auction` VALUES ('20751', '7', '38597', '39682', '2', '254880', '1294075238', '0', '0', '216648', '0');
INSERT INTO `auction` VALUES ('22548', '7', '40410', '24779', '2', '1830283', '1294110444', '0', '0', '1775374', '0');
INSERT INTO `auction` VALUES ('22115', '6', '39977', '10401', '2', '12700', '1294103184', '0', '0', '12192', '0');
INSERT INTO `auction` VALUES ('21507', '2', '39356', '24773', '2', '683833', '1294060958', '0', '0', '649641', '0');
INSERT INTO `auction` VALUES ('21244', '6', '39092', '25236', '2', '3753019', '1294075298', '0', '0', '3190066', '0');
INSERT INTO `auction` VALUES ('21243', '6', '39091', '10562', '2', '86400', '1294068098', '0', '0', '66528', '0');
INSERT INTO `auction` VALUES ('20474', '6', '38320', '37143', '2', '3820', '1294082438', '0', '0', '3056', '0');
INSERT INTO `auction` VALUES ('20651', '6', '38497', '24935', '2', '1675438', '1294075238', '0', '0', '1658683', '0');
INSERT INTO `auction` VALUES ('22121', '6', '39983', '10141', '2', '730117', '1294106784', '0', '0', '598695', '0');
INSERT INTO `auction` VALUES ('20149', '7', '37995', '9719', '2', '371750', '1294060778', '0', '0', '289965', '0');
INSERT INTO `auction` VALUES ('19955', '6', '37801', '4388', '2', '6640', '1294057178', '0', '0', '6042', '0');
INSERT INTO `auction` VALUES ('20811', '7', '38657', '37145', '2', '3120', '1294082438', '0', '0', '2652', '0');
INSERT INTO `auction` VALUES ('22271', '7', '40133', '19943', '2', '113120', '1294103184', '0', '0', '108595', '0');
INSERT INTO `auction` VALUES ('22069', '6', '39931', '2749', '2', '2310', '1294092384', '0', '0', '1871', '0');
INSERT INTO `auction` VALUES ('20913', '2', '38761', '8151', '2', '6000', '1294082498', '0', '0', '4860', '0');
INSERT INTO `auction` VALUES ('20781', '7', '38627', '27511', '2', '197', '1294068038', '0', '0', '155', '0');
INSERT INTO `auction` VALUES ('20235', '7', '38081', '18588', '2', '14960', '1294067978', '0', '0', '14062', '0');
INSERT INTO `auction` VALUES ('21970', '6', '39832', '25222', '2', '5245673', '1294110384', '0', '0', '5193216', '0');
INSERT INTO `auction` VALUES ('20449', '2', '38295', '9719', '2', '329750', '1294057238', '0', '0', '309965', '0');
INSERT INTO `auction` VALUES ('20267', '2', '38113', '2622', '2', '176613', '1294057238', '0', '0', '174846', '0');
INSERT INTO `auction` VALUES ('21641', '6', '39490', '36598', '2', '5862004', '1294057358', '0', '0', '5803383', '0');
INSERT INTO `auction` VALUES ('22593', '7', '40455', '5635', '2', '331', '1294121244', '0', '0', '278', '0');
INSERT INTO `auction` VALUES ('20112', '7', '37958', '7787', '2', '300000', '1294067978', '0', '0', '264000', '0');
INSERT INTO `auction` VALUES ('19889', '6', '37735', '42780', '2', '261120', '1294078778', '0', '0', '198451', '0');
INSERT INTO `auction` VALUES ('22131', '6', '39993', '4394', '2', '26550', '1294081584', '0', '0', '24957', '0');
INSERT INTO `auction` VALUES ('22122', '6', '39984', '1287', '2', '40245', '1294095984', '0', '0', '32598', '0');
INSERT INTO `auction` VALUES ('20266', '2', '38112', '36281', '2', '3055082', '1294057238', '0', '0', '2780124', '0');
INSERT INTO `auction` VALUES ('21271', '7', '39119', '25243', '2', '2750880', '1294053698', '0', '0', '2723371', '0');
INSERT INTO `auction` VALUES ('19990', '6', '37836', '9719', '2', '328250', '1294078778', '0', '0', '272447', '0');
INSERT INTO `auction` VALUES ('20060', '6', '37906', '36147', '2', '1745855', '1294064378', '0', '0', '1536352', '0');
INSERT INTO `auction` VALUES ('21636', '6', '39485', '8151', '2', '4920', '1294064558', '0', '0', '3837', '0');
INSERT INTO `auction` VALUES ('20786', '7', '38632', '9719', '2', '430750', '1294071638', '0', '0', '426442', '0');
INSERT INTO `auction` VALUES ('20165', '7', '38011', '40199', '2', '348', '1294057178', '0', '0', '271', '0');
INSERT INTO `auction` VALUES ('22354', '2', '40216', '10561', '2', '66080', '1294132044', '0', '0', '65419', '0');
INSERT INTO `auction` VALUES ('20971', '2', '38819', '4611', '2', '960', '1294057298', '0', '0', '748', '0');
INSERT INTO `auction` VALUES ('21730', '7', '39579', '20673', '2', '953316', '1294060958', '0', '0', '819851', '0');
INSERT INTO `auction` VALUES ('21574', '6', '39423', '5524', '2', '268', '1294064558', '0', '0', '195', '0');
INSERT INTO `auction` VALUES ('20010', '6', '37856', '36500', '2', '5703322', '1294053578', '0', '0', '5703322', '0');
INSERT INTO `auction` VALUES ('21788', '2', '39650', '39681', '2', '416640', '1294135584', '0', '0', '304147', '0');
INSERT INTO `auction` VALUES ('20234', '7', '38080', '6359', '2', '588', '1294071578', '0', '0', '540', '0');
INSERT INTO `auction` VALUES ('22672', '6', '40534', '1288', '2', '5483', '1294087268', '0', '0', '3947', '0');
INSERT INTO `auction` VALUES ('22033', '6', '39895', '44676', '2', '3843491', '1294095984', '0', '0', '3113227', '0');
INSERT INTO `auction` VALUES ('21257', '6', '39105', '4402', '2', '9000', '1294057298', '0', '0', '8370', '0');
INSERT INTO `auction` VALUES ('19945', '6', '37791', '2807', '2', '162007', '1294064378', '0', '0', '153906', '0');
INSERT INTO `auction` VALUES ('22631', '2', '40493', '31219', '2', '2448957', '1294112468', '0', '0', '2253040', '0');
INSERT INTO `auction` VALUES ('22081', '6', '39943', '36611', '2', '8158060', '1294077984', '0', '0', '7342254', '0');
INSERT INTO `auction` VALUES ('19665', '2', '37511', '5635', '2', '849', '1294075178', '0', '0', '798', '0');
INSERT INTO `auction` VALUES ('22693', '6', '40555', '14832', '2', '276069', '1294080068', '0', '0', '245701', '0');
INSERT INTO `auction` VALUES ('21931', '2', '39793', '9262', '2', '86400', '1294088784', '0', '0', '69984', '0');
INSERT INTO `auction` VALUES ('22123', '6', '39985', '7973', '2', '7252', '1294092384', '0', '0', '6164', '0');
INSERT INTO `auction` VALUES ('20682', '7', '38528', '9719', '2', '391000', '1294060838', '0', '0', '293250', '0');
INSERT INTO `auction` VALUES ('21850', '2', '39712', '9719', '2', '398000', '1294085184', '0', '0', '338300', '0');
INSERT INTO `auction` VALUES ('22445', '2', '40307', '897', '2', '58390', '1294106844', '0', '0', '58390', '0');
INSERT INTO `auction` VALUES ('21087', '6', '38935', '1930', '2', '13913', '1294071698', '0', '0', '13634', '0');
INSERT INTO `auction` VALUES ('20566', '6', '38412', '37769', '2', '4145289', '1294082438', '0', '0', '4020930', '0');
INSERT INTO `auction` VALUES ('22660', '2', '40522', '45909', '2', '21312', '1294137668', '0', '0', '17688', '0');
INSERT INTO `auction` VALUES ('21630', '6', '39479', '886', '2', '153958', '1294068158', '0', '0', '153958', '0');
INSERT INTO `auction` VALUES ('21137', '6', '38985', '18588', '2', '13824', '1294064498', '0', '0', '13271', '0');
INSERT INTO `auction` VALUES ('21086', '6', '38934', '3341', '2', '96416', '1294071698', '0', '0', '93523', '0');
INSERT INTO `auction` VALUES ('22429', '2', '40291', '3229', '2', '24869', '1294106844', '0', '0', '22630', '0');
INSERT INTO `auction` VALUES ('22519', '6', '40381', '19441', '2', '26160', '1294135644', '0', '0', '25375', '0');
INSERT INTO `auction` VALUES ('21395', '7', '39243', '25334', '2', '4294090', '1294075298', '0', '0', '3564094', '0');
INSERT INTO `auction` VALUES ('22255', '7', '40117', '4388', '2', '7760', '1294110384', '0', '0', '6906', '0');
INSERT INTO `auction` VALUES ('22737', '7', '40599', '8226', '2', '488546', '1294119668', '0', '0', '420149', '0');
INSERT INTO `auction` VALUES ('20969', '2', '38817', '832', '2', '8789', '1294075298', '0', '0', '8261', '0');
INSERT INTO `auction` VALUES ('22389', '2', '40251', '5635', '2', '1350', '1294121244', '0', '0', '1336', '0');
INSERT INTO `auction` VALUES ('22240', '7', '40102', '31192', '2', '1020410', '1294135584', '0', '0', '979593', '0');
INSERT INTO `auction` VALUES ('20701', '7', '38547', '9719', '2', '377250', '1294082438', '0', '0', '358387', '0');
INSERT INTO `auction` VALUES ('21955', '6', '39817', '30722', '2', '32706822', '1294099584', '0', '0', '32052685', '0');
INSERT INTO `auction` VALUES ('22157', '7', '40019', '1446', '2', '23673', '1294128384', '0', '0', '23673', '0');
INSERT INTO `auction` VALUES ('20376', '2', '38222', '4772', '2', '704', '1294078838', '0', '0', '556', '0');
INSERT INTO `auction` VALUES ('20054', '6', '37900', '4436', '2', '22236', '1294067978', '0', '0', '21124', '0');
INSERT INTO `auction` VALUES ('20889', '2', '38737', '20653', '2', '676802', '1294068098', '0', '0', '642961', '0');
INSERT INTO `auction` VALUES ('21895', '2', '39757', '36555', '2', '8916152', '1294121184', '0', '0', '8292021', '0');
INSERT INTO `auction` VALUES ('22391', '2', '40253', '40199', '2', '8664', '1294110444', '0', '0', '6931', '0');
INSERT INTO `auction` VALUES ('19947', '6', '37793', '6364', '2', '2295', '1294082378', '0', '0', '2157', '0');
INSERT INTO `auction` VALUES ('22198', '7', '40060', '31185', '2', '1642113', '1294106784', '0', '0', '1592849', '0');
INSERT INTO `auction` VALUES ('22184', '7', '40046', '25744', '2', '261303', '1294131984', '0', '0', '188138', '0');
INSERT INTO `auction` VALUES ('22212', '7', '40074', '37755', '2', '3293413', '1294128384', '0', '0', '2733532', '0');
INSERT INTO `auction` VALUES ('21141', '6', '38989', '13422', '2', '1274', '1294082498', '0', '0', '904', '0');
INSERT INTO `auction` VALUES ('20055', '6', '37901', '13905', '2', '155', '1294067978', '0', '0', '128', '0');
INSERT INTO `auction` VALUES ('20888', '2', '38736', '27516', '2', '14480', '1294064498', '0', '0', '10425', '0');
INSERT INTO `auction` VALUES ('19666', '2', '37512', '9719', '2', '337750', '1294060778', '0', '0', '293842', '0');
INSERT INTO `auction` VALUES ('20989', '2', '38837', '4388', '2', '7280', '1294060898', '0', '0', '6115', '0');
INSERT INTO `auction` VALUES ('19992', '6', '37838', '1443', '2', '2083770', '1294078778', '0', '0', '1937906', '0');
INSERT INTO `auction` VALUES ('22605', '7', '40467', '37145', '2', '16900', '1294088844', '0', '0', '13689', '0');
INSERT INTO `auction` VALUES ('20264', '2', '38110', '27515', '2', '13600', '1294053638', '0', '0', '10880', '0');
INSERT INTO `auction` VALUES ('21070', '6', '38918', '32718', '2', '559000', '1294075298', '0', '0', '547820', '0');
INSERT INTO `auction` VALUES ('21804', '2', '39666', '10578', '2', '256667', '1294095984', '0', '0', '256667', '0');
INSERT INTO `auction` VALUES ('22434', '2', '40296', '24603', '2', '1142798', '1294088844', '0', '0', '1062802', '0');
INSERT INTO `auction` VALUES ('22234', '7', '40096', '13884', '2', '576', '1294128384', '0', '0', '501', '0');
INSERT INTO `auction` VALUES ('22250', '7', '40112', '27513', '2', '155', '1294095984', '0', '0', '155', '0');
INSERT INTO `auction` VALUES ('22590', '7', '40452', '4638', '2', '9832', '1294121244', '0', '0', '9143', '0');
INSERT INTO `auction` VALUES ('22263', '7', '40125', '32620', '2', '1420850', '1294106784', '0', '0', '1179305', '0');
INSERT INTO `auction` VALUES ('19713', '2', '37559', '9719', '2', '323250', '1294078778', '0', '0', '284460', '0');
INSERT INTO `auction` VALUES ('20575', '6', '38421', '9719', '2', '407750', '1294082438', '0', '0', '362897', '0');
INSERT INTO `auction` VALUES ('22368', '2', '40230', '44475', '2', '154', '1294110444', '0', '0', '127', '0');
INSERT INTO `auction` VALUES ('20185', '7', '38031', '936', '2', '869816', '1294082378', '0', '0', '852419', '0');
INSERT INTO `auction` VALUES ('20116', '7', '37962', '9719', '2', '348750', '1294064378', '0', '0', '265050', '0');
INSERT INTO `auction` VALUES ('22541', '7', '40403', '19441', '2', '59100', '1294106844', '0', '0', '57918', '0');
INSERT INTO `auction` VALUES ('21327', '7', '39175', '4589', '2', '28111', '1294057298', '0', '0', '24456', '0');
INSERT INTO `auction` VALUES ('20383', '2', '38229', '9719', '2', '381250', '1294068038', '0', '0', '305000', '0');
INSERT INTO `auction` VALUES ('22216', '7', '40078', '22529', '2', '16080', '1294110384', '0', '0', '13346', '0');
INSERT INTO `auction` VALUES ('21394', '7', '39242', '10505', '2', '31680', '1294057298', '0', '0', '28512', '0');

-- ----------------------------
-- Table structure for `auctionhousebot`
-- ----------------------------
DROP TABLE IF EXISTS `auctionhousebot`;
CREATE TABLE `auctionhousebot` (
  `auctionhouse` int(11) NOT NULL default '0' COMMENT 'mapID of the auctionhouse.',
  `name` char(25) default NULL COMMENT 'Text name of the auctionhouse.',
  `minitems` int(11) default '0' COMMENT 'This is the minimum number of items you want to keep in the auction house. a 0 here will make it the same as the maximum.',
  `maxitems` int(11) default '0' COMMENT 'This is the number of items you want to keep in the auction house.',
  `mintime` int(11) default '8' COMMENT 'Sets the minimum number of hours for an auction.',
  `maxtime` int(11) default '24' COMMENT 'Sets the maximum number of hours for an auction.',
  `percentgreytradegoods` int(11) default '0' COMMENT 'Sets the percentage of the Grey Trade Goods auction items',
  `percentwhitetradegoods` int(11) default '27' COMMENT 'Sets the percentage of the White Trade Goods auction items',
  `percentgreentradegoods` int(11) default '12' COMMENT 'Sets the percentage of the Green Trade Goods auction items',
  `percentbluetradegoods` int(11) default '10' COMMENT 'Sets the percentage of the Blue Trade Goods auction items',
  `percentpurpletradegoods` int(11) default '1' COMMENT 'Sets the percentage of the Purple Trade Goods auction items',
  `percentorangetradegoods` int(11) default '0' COMMENT 'Sets the percentage of the Orange Trade Goods auction items',
  `percentyellowtradegoods` int(11) default '0' COMMENT 'Sets the percentage of the Yellow Trade Goods auction items',
  `percentgreyitems` int(11) default '0' COMMENT 'Sets the percentage of the non trade Grey auction items',
  `percentwhiteitems` int(11) default '10' COMMENT 'Sets the percentage of the non trade White auction items',
  `percentgreenitems` int(11) default '30' COMMENT 'Sets the percentage of the non trade Green auction items',
  `percentblueitems` int(11) default '8' COMMENT 'Sets the percentage of the non trade Blue auction items',
  `percentpurpleitems` int(11) default '2' COMMENT 'Sets the percentage of the non trade Purple auction items',
  `percentorangeitems` int(11) default '0' COMMENT 'Sets the percentage of the non trade Orange auction items',
  `percentyellowitems` int(11) default '0' COMMENT 'Sets the percentage of the non trade Yellow auction items',
  `minpricegrey` int(11) default '100' COMMENT 'Minimum price of Grey items (percentage).',
  `maxpricegrey` int(11) default '150' COMMENT 'Maximum price of Grey items (percentage).',
  `minpricewhite` int(11) default '150' COMMENT 'Minimum price of White items (percentage).',
  `maxpricewhite` int(11) default '250' COMMENT 'Maximum price of White items (percentage).',
  `minpricegreen` int(11) default '800' COMMENT 'Minimum price of Green items (percentage).',
  `maxpricegreen` int(11) default '1400' COMMENT 'Maximum price of Green items (percentage).',
  `minpriceblue` int(11) default '1250' COMMENT 'Minimum price of Blue items (percentage).',
  `maxpriceblue` int(11) default '1750' COMMENT 'Maximum price of Blue items (percentage).',
  `minpricepurple` int(11) default '2250' COMMENT 'Minimum price of Purple items (percentage).',
  `maxpricepurple` int(11) default '4550' COMMENT 'Maximum price of Purple items (percentage).',
  `minpriceorange` int(11) default '3250' COMMENT 'Minimum price of Orange items (percentage).',
  `maxpriceorange` int(11) default '5550' COMMENT 'Maximum price of Orange items (percentage).',
  `minpriceyellow` int(11) default '5250' COMMENT 'Minimum price of Yellow items (percentage).',
  `maxpriceyellow` int(11) default '6550' COMMENT 'Maximum price of Yellow items (percentage).',
  `minbidpricegrey` int(11) default '70' COMMENT 'Starting bid price of Grey items as a percentage of the randomly chosen buyout price. Default: 70',
  `maxbidpricegrey` int(11) default '100' COMMENT 'Starting bid price of Grey items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpricewhite` int(11) default '70' COMMENT 'Starting bid price of White items as a percentage of the randomly chosen buyout price. Default: 70',
  `maxbidpricewhite` int(11) default '100' COMMENT 'Starting bid price of White items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpricegreen` int(11) default '80' COMMENT 'Starting bid price of Green items as a percentage of the randomly chosen buyout price. Default: 80',
  `maxbidpricegreen` int(11) default '100' COMMENT 'Starting bid price of Green items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpriceblue` int(11) default '75' COMMENT 'Starting bid price of Blue items as a percentage of the randomly chosen buyout price. Default: 75',
  `maxbidpriceblue` int(11) default '100' COMMENT 'Starting bid price of Blue items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpricepurple` int(11) default '80' COMMENT 'Starting bid price of Purple items as a percentage of the randomly chosen buyout price. Default: 80',
  `maxbidpricepurple` int(11) default '100' COMMENT 'Starting bid price of Purple items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpriceorange` int(11) default '80' COMMENT 'Starting bid price of Orange items as a percentage of the randomly chosen buyout price. Default: 80',
  `maxbidpriceorange` int(11) default '100' COMMENT 'Starting bid price of Orange items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpriceyellow` int(11) default '80' COMMENT 'Starting bid price of Yellow items as a percentage of the randomly chosen buyout price. Default: 80',
  `maxbidpriceyellow` int(11) default '100' COMMENT 'Starting bid price of Yellow items as a percentage of the randomly chosen buyout price. Default: 100',
  `maxstackgrey` int(11) default '0' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackwhite` int(11) default '0' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackgreen` int(11) default '3' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackblue` int(11) default '2' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackpurple` int(11) default '1' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackorange` int(11) default '1' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackyellow` int(11) default '1' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `buyerpricegrey` int(11) default '1' COMMENT 'Multiplier to vendorprice when buying grey items from auctionhouse',
  `buyerpricewhite` int(11) default '1' COMMENT 'Multiplier to vendorprice when buying white items from auctionhouse',
  `buyerpricegreen` int(11) default '5' COMMENT 'Multiplier to vendorprice when buying green items from auctionhouse',
  `buyerpriceblue` int(11) default '12' COMMENT 'Multiplier to vendorprice when buying blue items from auctionhouse',
  `buyerpricepurple` int(11) default '15' COMMENT 'Multiplier to vendorprice when buying purple items from auctionhouse',
  `buyerpriceorange` int(11) default '20' COMMENT 'Multiplier to vendorprice when buying orange items from auctionhouse',
  `buyerpriceyellow` int(11) default '22' COMMENT 'Multiplier to vendorprice when buying yellow items from auctionhouse',
  `buyerbiddinginterval` int(11) default '1' COMMENT 'Interval how frequently AHB bids on each AH. Time in minutes',
  `buyerbidsperinterval` int(11) default '1' COMMENT 'number of bids to put in per bidding interval',
  PRIMARY KEY  (`auctionhouse`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of auctionhousebot
-- ----------------------------
INSERT INTO `auctionhousebot` VALUES ('2', 'Alliance', '800', '800', '8', '24', '0', '27', '12', '10', '1', '0', '0', '0', '10', '30', '8', '2', '0', '0', '100', '150', '150', '250', '800', '1400', '1250', '1750', '2250', '4550', '3250', '5550', '5250', '6550', '70', '100', '70', '100', '80', '100', '75', '100', '80', '100', '80', '100', '80', '100', '0', '0', '3', '2', '1', '1', '1', '1', '1', '5', '12', '15', '20', '22', '1', '1');
INSERT INTO `auctionhousebot` VALUES ('6', 'Horde', '800', '800', '8', '24', '0', '27', '12', '10', '1', '0', '0', '0', '10', '30', '8', '2', '0', '0', '100', '150', '150', '250', '800', '1400', '1250', '1750', '2250', '4550', '3250', '5550', '5250', '6550', '70', '100', '70', '100', '80', '100', '75', '100', '80', '100', '80', '100', '80', '100', '0', '0', '3', '2', '1', '1', '1', '1', '1', '5', '12', '15', '20', '22', '1', '1');
INSERT INTO `auctionhousebot` VALUES ('7', 'Neutral', '800', '800', '8', '24', '0', '27', '12', '10', '1', '0', '0', '0', '10', '30', '8', '2', '0', '0', '100', '150', '150', '250', '800', '1400', '1250', '1750', '2250', '4550', '3250', '5550', '5250', '6550', '70', '100', '70', '100', '80', '100', '75', '100', '80', '100', '80', '100', '80', '100', '0', '0', '3', '2', '1', '1', '1', '1', '1', '5', '12', '15', '20', '22', '1', '1');

-- ----------------------------
-- Table structure for `autobroadcast`
-- ----------------------------
DROP TABLE IF EXISTS `autobroadcast`;
CREATE TABLE `autobroadcast` (
  `id` int(11) NOT NULL auto_increment,
  `text` longtext NOT NULL,
  `next` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of autobroadcast
-- ----------------------------
INSERT INTO `autobroadcast` VALUES ('1', 'Hello', '0');

-- ----------------------------
-- Table structure for `bugreport`
-- ----------------------------
DROP TABLE IF EXISTS `bugreport`;
CREATE TABLE `bugreport` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Identifier',
  `type` longtext NOT NULL,
  `content` longtext NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Debug System';

-- ----------------------------
-- Records of bugreport
-- ----------------------------

-- ----------------------------
-- Table structure for `character_account_data`
-- ----------------------------
DROP TABLE IF EXISTS `character_account_data`;
CREATE TABLE `character_account_data` (
  `guid` int(11) unsigned NOT NULL default '0',
  `type` int(11) unsigned NOT NULL default '0',
  `time` bigint(11) unsigned NOT NULL default '0',
  `data` longblob NOT NULL,
  PRIMARY KEY  (`guid`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_account_data
-- ----------------------------
INSERT INTO `character_account_data` VALUES ('6', '3', '1290957658', 0x42494E44494E474D4F444520300D0A62696E6420494E534552542053435245454E53484F540D0A62696E642050414745555020464C495043414D4552415941570D0A62696E64205052494E5453435245454E2053435245454E53484F540D0A62696E642053484946542D4C205147545F544F47474C455F545241434B45525F4B420D0A);
INSERT INTO `character_account_data` VALUES ('6', '7', '1293995906', 0x56455253494F4E20350A0A414444454456455253494F4E2031330A0A4F5054494F4E5F4755494C445F524543525549544D454E545F4348414E4E454C204155544F0A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C532035323432383830330A0A434F4C4F52530A53595354454D20323535203235352030204E0A534159203235352032353520323535204E0A5041525459203137302031373020323535204E0A5241494420323535203132372030204E0A4755494C4420363420323535203634204E0A4F46464943455220363420313932203634204E0A59454C4C20323535203634203634204E0A57484953504552203235352031323820323535204E0A574849535045525F464F524549474E203235352031323820323535204E0A574849535045525F494E464F524D203235352031323820323535204E0A454D4F54452032353520313238203634204E0A544558545F454D4F54452032353520313238203634204E0A4D4F4E535445525F534159203235352032353520313539204E0A4D4F4E535445525F5041525459203137302031373020323535204E0A4D4F4E535445525F59454C4C20323535203634203634204E0A4D4F4E535445525F57484953504552203235352031383120323335204E0A4D4F4E535445525F454D4F54452032353520313238203634204E0A4348414E4E454C203235352031393220313932204E0A4348414E4E454C5F4A4F494E203139322031323820313238204E0A4348414E4E454C5F4C45415645203139322031323820313238204E0A4348414E4E454C5F4C495354203139322031323820313238204E0A4348414E4E454C5F4E4F54494345203139322031393220313932204E0A4348414E4E454C5F4E4F544943455F55534552203139322031393220313932204E0A41464B203235352031323820323535204E0A444E44203235352031323820323535204E0A49474E4F5245442032353520302030204E0A534B494C4C20383520383520323535204E0A4C4F4F542030203137302030204E0A4D4F4E455920323535203235352030204E0A4F50454E494E47203132382031323820323535204E0A5452414445534B494C4C53203235352032353520323535204E0A5045545F494E464F203132382031323820323535204E0A434F4D4241545F4D4953435F494E464F203132382031323820323535204E0A434F4D4241545F58505F4741494E203131312031313120323535204E0A434F4D4241545F484F4E4F525F4741494E2032323420323032203130204E0A434F4D4241545F46414354494F4E5F4348414E4745203132382031323820323535204E0A42475F53595354454D5F4E45555452414C2032353520313230203130204E0A42475F53595354454D5F414C4C49414E434520302031373420323339204E0A42475F53595354454D5F484F5244452032353520302030204E0A524149445F4C4541444552203235352037322039204E0A524149445F5741524E494E47203235352037322030204E0A524149445F424F53535F454D4F544520323535203232312030204E0A524149445F424F53535F5748495350455220323535203232312030204E0A46494C54455245442032353520302030204E0A424154544C4547524F554E4420323535203132372030204E0A424154544C4547524F554E445F4C4541444552203235352032313920313833204E0A524553545249435445442032353520302030204E0A424154544C454E4554203235352032353520323535204E0A414348494556454D454E5420323535203235352030204E0A4755494C445F414348494556454D454E5420363420323535203634204E0A4152454E415F504F494E5453203235352032353520323535204E0A50415254595F4C4541444552203131382032303020323535204E0A54415247455449434F4E5320323535203235352030204E0A424E5F5748495350455220302032353520323436204E0A424E5F574849535045525F494E464F524D20302032353520323436204E0A424E5F434F4E564552534154494F4E20302031373720323430204E0A424E5F434F4E564552534154494F4E5F4E4F5449434520302031373720323430204E0A424E5F434F4E564552534154494F4E5F4C49535420302031373720323430204E0A424E5F494E4C494E455F544F4153545F414C455254203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F414443415354203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F4144434153545F494E464F524D203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F434F4E564552534154494F4E203133302031393720323535204E0A4348414E4E454C31203235352031393220313932204E0A4348414E4E454C32203235352031393220313932204E0A4348414E4E454C33203235352031393220313932204E0A4348414E4E454C34203235352031393220313932204E0A4348414E4E454C35203235352031393220313932204E0A4348414E4E454C36203235352031393220313932204E0A4348414E4E454C37203235352031393220313932204E0A4348414E4E454C38203235352031393220313932204E0A4348414E4E454C39203235352031393220313932204E0A4348414E4E454C3130203235352031393220313932204E0A454E440A0A57494E444F5720310A4E414D452047656E6572616C0A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420310A53484F574E20310A4D455353414745530A53595354454D0A53595354454D5F4E4F4D454E550A5341590A454D4F54450A59454C4C0A574849535045520A50415254590A50415254595F4C45414445520A524149440A524149445F4C45414445520A524149445F5741524E494E470A424154544C4547524F554E440A424154544C4547524F554E445F4C45414445520A4755494C440A4F4646494345520A4D4F4E535445525F5341590A4D4F4E535445525F59454C4C0A4D4F4E535445525F454D4F54450A4D4F4E535445525F574849535045520A4D4F4E535445525F424F53535F454D4F54450A4D4F4E535445525F424F53535F574849535045520A4552524F52530A41464B0A444E440A49474E4F5245440A42475F484F5244450A42475F414C4C49414E43450A42475F4E45555452414C0A434F4D4241545F46414354494F4E5F4348414E47450A534B494C4C0A4C4F4F540A4D4F4E45590A4348414E4E454C0A414348494556454D454E540A4755494C445F414348494556454D454E540A54415247455449434F4E530A424E5F574849535045520A424E5F574849535045525F494E464F524D0A424E5F434F4E564552534154494F4E0A424E5F494E4C494E455F544F4153545F414C4552540A454E440A0A4348414E4E454C530A5472697669610A454E440A0A5A4F4E454348414E4E454C532035323432383830330A0A454E440A0A57494E444F5720320A4E414D4520436F6D626174204C6F670A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420320A53484F574E20300A4D455353414745530A4F50454E494E470A5452414445534B494C4C530A5045545F494E464F0A434F4D4241545F58505F4741494E0A434F4D4241545F484F4E4F525F4741494E0A434F4D4241545F4D4953435F494E464F0A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720330A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720340A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720350A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720360A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720370A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720380A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720390A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F572031300A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A);
INSERT INTO `character_account_data` VALUES ('7', '7', '1293596234', 0x56455253494F4E20350A0A414444454456455253494F4E2031330A0A4F5054494F4E5F4755494C445F524543525549544D454E545F4348414E4E454C204155544F0A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C532035323432383830330A0A434F4C4F52530A53595354454D20323535203235352030204E0A534159203235352032353520323535204E0A5041525459203137302031373020323535204E0A5241494420323535203132372030204E0A4755494C4420363420323535203634204E0A4F46464943455220363420313932203634204E0A59454C4C20323535203634203634204E0A57484953504552203235352031323820323535204E0A574849535045525F464F524549474E203235352031323820323535204E0A574849535045525F494E464F524D203235352031323820323535204E0A454D4F54452032353520313238203634204E0A544558545F454D4F54452032353520313238203634204E0A4D4F4E535445525F534159203235352032353520313539204E0A4D4F4E535445525F5041525459203137302031373020323535204E0A4D4F4E535445525F59454C4C20323535203634203634204E0A4D4F4E535445525F57484953504552203235352031383120323335204E0A4D4F4E535445525F454D4F54452032353520313238203634204E0A4348414E4E454C203235352031393220313932204E0A4348414E4E454C5F4A4F494E203139322031323820313238204E0A4348414E4E454C5F4C45415645203139322031323820313238204E0A4348414E4E454C5F4C495354203139322031323820313238204E0A4348414E4E454C5F4E4F54494345203139322031393220313932204E0A4348414E4E454C5F4E4F544943455F55534552203139322031393220313932204E0A41464B203235352031323820323535204E0A444E44203235352031323820323535204E0A49474E4F5245442032353520302030204E0A534B494C4C20383520383520323535204E0A4C4F4F542030203137302030204E0A4D4F4E455920323535203235352030204E0A4F50454E494E47203132382031323820323535204E0A5452414445534B494C4C53203235352032353520323535204E0A5045545F494E464F203132382031323820323535204E0A434F4D4241545F4D4953435F494E464F203132382031323820323535204E0A434F4D4241545F58505F4741494E203131312031313120323535204E0A434F4D4241545F484F4E4F525F4741494E2032323420323032203130204E0A434F4D4241545F46414354494F4E5F4348414E4745203132382031323820323535204E0A42475F53595354454D5F4E45555452414C2032353520313230203130204E0A42475F53595354454D5F414C4C49414E434520302031373420323339204E0A42475F53595354454D5F484F5244452032353520302030204E0A524149445F4C4541444552203235352037322039204E0A524149445F5741524E494E47203235352037322030204E0A524149445F424F53535F454D4F544520323535203232312030204E0A524149445F424F53535F5748495350455220323535203232312030204E0A46494C54455245442032353520302030204E0A424154544C4547524F554E4420323535203132372030204E0A424154544C4547524F554E445F4C4541444552203235352032313920313833204E0A524553545249435445442032353520302030204E0A424154544C454E4554203235352032353520323535204E0A414348494556454D454E5420323535203235352030204E0A4755494C445F414348494556454D454E5420363420323535203634204E0A4152454E415F504F494E5453203235352032353520323535204E0A50415254595F4C4541444552203131382032303020323535204E0A54415247455449434F4E5320323535203235352030204E0A424E5F5748495350455220302032353520323436204E0A424E5F574849535045525F494E464F524D20302032353520323436204E0A424E5F434F4E564552534154494F4E20302031373720323430204E0A424E5F434F4E564552534154494F4E5F4E4F5449434520302031373720323430204E0A424E5F434F4E564552534154494F4E5F4C49535420302031373720323430204E0A424E5F494E4C494E455F544F4153545F414C455254203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F414443415354203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F4144434153545F494E464F524D203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F434F4E564552534154494F4E203133302031393720323535204E0A4348414E4E454C31203235352031393220313932204E0A4348414E4E454C32203235352031393220313932204E0A4348414E4E454C33203235352031393220313932204E0A4348414E4E454C34203235352031393220313932204E0A4348414E4E454C35203235352031393220313932204E0A4348414E4E454C36203235352031393220313932204E0A4348414E4E454C37203235352031393220313932204E0A4348414E4E454C38203235352031393220313932204E0A4348414E4E454C39203235352031393220313932204E0A4348414E4E454C3130203235352031393220313932204E0A454E440A0A57494E444F5720310A4E414D452047656E6572616C0A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420310A53484F574E20310A4D455353414745530A53595354454D0A53595354454D5F4E4F4D454E550A5341590A454D4F54450A59454C4C0A574849535045520A50415254590A50415254595F4C45414445520A524149440A524149445F4C45414445520A524149445F5741524E494E470A424154544C4547524F554E440A424154544C4547524F554E445F4C45414445520A4755494C440A4F4646494345520A4D4F4E535445525F5341590A4D4F4E535445525F59454C4C0A4D4F4E535445525F454D4F54450A4D4F4E535445525F574849535045520A4D4F4E535445525F424F53535F454D4F54450A4D4F4E535445525F424F53535F574849535045520A4552524F52530A41464B0A444E440A49474E4F5245440A42475F484F5244450A42475F414C4C49414E43450A42475F4E45555452414C0A434F4D4241545F46414354494F4E5F4348414E47450A534B494C4C0A4C4F4F540A4D4F4E45590A4348414E4E454C0A414348494556454D454E540A4755494C445F414348494556454D454E540A54415247455449434F4E530A424E5F574849535045520A424E5F574849535045525F494E464F524D0A424E5F434F4E564552534154494F4E0A424E5F494E4C494E455F544F4153545F414C4552540A454E440A0A4348414E4E454C530A5472697669610A454E440A0A5A4F4E454348414E4E454C532031383837343337310A0A454E440A0A57494E444F5720320A4E414D4520436F6D626174204C6F670A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420320A53484F574E20300A4D455353414745530A4F50454E494E470A5452414445534B494C4C530A5045545F494E464F0A434F4D4241545F58505F4741494E0A434F4D4241545F484F4E4F525F4741494E0A434F4D4241545F4D4953435F494E464F0A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720330A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720340A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720350A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720360A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720370A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720380A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720390A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F572031300A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A);
INSERT INTO `character_account_data` VALUES ('2', '7', '1290821039', 0x56455253494F4E20350A0A414444454456455253494F4E2031330A0A4F5054494F4E5F4755494C445F524543525549544D454E545F4348414E4E454C204155544F0A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C532035323432383830330A0A434F4C4F52530A53595354454D20323535203235352030204E0A534159203235352032353520323535204E0A5041525459203137302031373020323535204E0A5241494420323535203132372030204E0A4755494C4420363420323535203634204E0A4F46464943455220363420313932203634204E0A59454C4C20323535203634203634204E0A57484953504552203235352031323820323535204E0A574849535045525F464F524549474E203235352031323820323535204E0A574849535045525F494E464F524D203235352031323820323535204E0A454D4F54452032353520313238203634204E0A544558545F454D4F54452032353520313238203634204E0A4D4F4E535445525F534159203235352032353520313539204E0A4D4F4E535445525F5041525459203137302031373020323535204E0A4D4F4E535445525F59454C4C20323535203634203634204E0A4D4F4E535445525F57484953504552203235352031383120323335204E0A4D4F4E535445525F454D4F54452032353520313238203634204E0A4348414E4E454C203235352031393220313932204E0A4348414E4E454C5F4A4F494E203139322031323820313238204E0A4348414E4E454C5F4C45415645203139322031323820313238204E0A4348414E4E454C5F4C495354203139322031323820313238204E0A4348414E4E454C5F4E4F54494345203139322031393220313932204E0A4348414E4E454C5F4E4F544943455F55534552203139322031393220313932204E0A41464B203235352031323820323535204E0A444E44203235352031323820323535204E0A49474E4F5245442032353520302030204E0A534B494C4C20383520383520323535204E0A4C4F4F542030203137302030204E0A4D4F4E455920323535203235352030204E0A4F50454E494E47203132382031323820323535204E0A5452414445534B494C4C53203235352032353520323535204E0A5045545F494E464F203132382031323820323535204E0A434F4D4241545F4D4953435F494E464F203132382031323820323535204E0A434F4D4241545F58505F4741494E203131312031313120323535204E0A434F4D4241545F484F4E4F525F4741494E2032323420323032203130204E0A434F4D4241545F46414354494F4E5F4348414E4745203132382031323820323535204E0A42475F53595354454D5F4E45555452414C2032353520313230203130204E0A42475F53595354454D5F414C4C49414E434520302031373420323339204E0A42475F53595354454D5F484F5244452032353520302030204E0A524149445F4C4541444552203235352037322039204E0A524149445F5741524E494E47203235352037322030204E0A524149445F424F53535F454D4F544520323535203232312030204E0A524149445F424F53535F5748495350455220323535203232312030204E0A46494C54455245442032353520302030204E0A424154544C4547524F554E4420323535203132372030204E0A424154544C4547524F554E445F4C4541444552203235352032313920313833204E0A524553545249435445442032353520302030204E0A424154544C454E4554203235352032353520323535204E0A414348494556454D454E5420323535203235352030204E0A4755494C445F414348494556454D454E5420363420323535203634204E0A4152454E415F504F494E5453203235352032353520323535204E0A50415254595F4C4541444552203131382032303020323535204E0A54415247455449434F4E5320323535203235352030204E0A424E5F5748495350455220302032353520323436204E0A424E5F574849535045525F494E464F524D20302032353520323436204E0A424E5F434F4E564552534154494F4E20302031373720323430204E0A424E5F434F4E564552534154494F4E5F4E4F5449434520302031373720323430204E0A424E5F434F4E564552534154494F4E5F4C49535420302031373720323430204E0A424E5F494E4C494E455F544F4153545F414C455254203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F414443415354203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F4144434153545F494E464F524D203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F434F4E564552534154494F4E203133302031393720323535204E0A4348414E4E454C31203235352031393220313932204E0A4348414E4E454C32203235352031393220313932204E0A4348414E4E454C33203235352031393220313932204E0A4348414E4E454C34203235352031393220313932204E0A4348414E4E454C35203235352031393220313932204E0A4348414E4E454C36203235352031393220313932204E0A4348414E4E454C37203235352031393220313932204E0A4348414E4E454C38203235352031393220313932204E0A4348414E4E454C39203235352031393220313932204E0A4348414E4E454C3130203235352031393220313932204E0A454E440A0A57494E444F5720310A4E414D452047656E6572616C0A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420310A53484F574E20310A4D455353414745530A53595354454D0A53595354454D5F4E4F4D454E550A5341590A454D4F54450A59454C4C0A574849535045520A50415254590A50415254595F4C45414445520A524149440A524149445F4C45414445520A524149445F5741524E494E470A424154544C4547524F554E440A424154544C4547524F554E445F4C45414445520A4755494C440A4F4646494345520A4D4F4E535445525F5341590A4D4F4E535445525F59454C4C0A4D4F4E535445525F454D4F54450A4D4F4E535445525F574849535045520A4D4F4E535445525F424F53535F454D4F54450A4D4F4E535445525F424F53535F574849535045520A4552524F52530A41464B0A444E440A49474E4F5245440A42475F484F5244450A42475F414C4C49414E43450A42475F4E45555452414C0A434F4D4241545F46414354494F4E5F4348414E47450A534B494C4C0A4C4F4F540A4D4F4E45590A4348414E4E454C0A414348494556454D454E540A4755494C445F414348494556454D454E540A54415247455449434F4E530A424E5F574849535045520A424E5F574849535045525F494E464F524D0A424E5F434F4E564552534154494F4E0A424E5F494E4C494E455F544F4153545F414C4552540A454E440A0A4348414E4E454C530A4C6F6F6B696E67466F7247726F75700A5472697669610A454E440A0A5A4F4E454348414E4E454C532031383837343337310A0A454E440A0A57494E444F5720320A4E414D4520436F6D626174204C6F670A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420320A53484F574E20300A4D455353414745530A4F50454E494E470A5452414445534B494C4C530A5045545F494E464F0A434F4D4241545F58505F4741494E0A434F4D4241545F484F4E4F525F4741494E0A434F4D4241545F4D4953435F494E464F0A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720330A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720340A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720350A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720360A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720370A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720380A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720390A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F572031300A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A);
INSERT INTO `character_account_data` VALUES ('6', '1', '1293995907', 0x534554206D696E696D61705A6F6F6D202230220A534554206D696E696D6170496E736964655A6F6F6D202230220A5345542071756573744C6F67436F6C6C6170736546696C74657220222D31220A53455420747261636B656451756573747320227601220A53455420747261636B6564416368696576656D656E747320227601220A5345542063616D657261536176656444697374616E63652022392E303032333938220A5345542063616D65726153617665645069746368202232322E343939393936220A53455420706C61796572537461744C65667444726F70646F776E2022504C41594552535441545F424153455F5354415453220A53455420706C6179657253746174526967687444726F70646F776E2022504C41594552535441545F4D454C45455F434F4D424154220A);
INSERT INTO `character_account_data` VALUES ('9', '1', '1293326790', 0x534554206D696E696D61705A6F6F6D202230220A534554206D696E696D6170496E736964655A6F6F6D202230220A5345542071756573744C6F67436F6C6C6170736546696C74657220222D31220A53455420747261636B656451756573747320227601244D79220A53455420747261636B6564416368696576656D656E747320227601220A5345542063616D657261536176656444697374616E63652022382E303038373734220A5345542063616D657261536176656456656869636C6544697374616E6365202233322E393038393839220A5345542063616D65726153617665645069746368202231332E363439393937220A53455420706C61796572537461744C65667444726F70646F776E2022504C41594552535441545F424153455F5354415453220A53455420706C6179657253746174526967687444726F70646F776E2022504C41594552535441545F52414E4745445F434F4D424154220A);
INSERT INTO `character_account_data` VALUES ('9', '3', '1290847749', 0x42494E44494E474D4F444520300D0A62696E6420494E534552542053435245454E53484F540D0A62696E642050414745555020464C495043414D4552415941570D0A62696E64205052494E5453435245454E2053435245454E53484F540D0A62696E642053484946542D4C205147545F544F47474C455F545241434B45525F4B420D0A);
INSERT INTO `character_account_data` VALUES ('9', '7', '1293326661', 0x56455253494F4E20350A0A414444454456455253494F4E2031330A0A4F5054494F4E5F4755494C445F524543525549544D454E545F4348414E4E454C204155544F0A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C532035323432383830330A0A434F4C4F52530A53595354454D20323535203235352030204E0A534159203235352032353520323535204E0A5041525459203137302031373020323535204E0A5241494420323535203132372030204E0A4755494C4420363420323535203634204E0A4F46464943455220363420313932203634204E0A59454C4C20323535203634203634204E0A57484953504552203235352031323820323535204E0A574849535045525F464F524549474E203235352031323820323535204E0A574849535045525F494E464F524D203235352031323820323535204E0A454D4F54452032353520313238203634204E0A544558545F454D4F54452032353520313238203634204E0A4D4F4E535445525F534159203235352032353520313539204E0A4D4F4E535445525F5041525459203137302031373020323535204E0A4D4F4E535445525F59454C4C20323535203634203634204E0A4D4F4E535445525F57484953504552203235352031383120323335204E0A4D4F4E535445525F454D4F54452032353520313238203634204E0A4348414E4E454C203235352031393220313932204E0A4348414E4E454C5F4A4F494E203139322031323820313238204E0A4348414E4E454C5F4C45415645203139322031323820313238204E0A4348414E4E454C5F4C495354203139322031323820313238204E0A4348414E4E454C5F4E4F54494345203139322031393220313932204E0A4348414E4E454C5F4E4F544943455F55534552203139322031393220313932204E0A41464B203235352031323820323535204E0A444E44203235352031323820323535204E0A49474E4F5245442032353520302030204E0A534B494C4C20383520383520323535204E0A4C4F4F542030203137302030204E0A4D4F4E455920323535203235352030204E0A4F50454E494E47203132382031323820323535204E0A5452414445534B494C4C53203235352032353520323535204E0A5045545F494E464F203132382031323820323535204E0A434F4D4241545F4D4953435F494E464F203132382031323820323535204E0A434F4D4241545F58505F4741494E203131312031313120323535204E0A434F4D4241545F484F4E4F525F4741494E2032323420323032203130204E0A434F4D4241545F46414354494F4E5F4348414E4745203132382031323820323535204E0A42475F53595354454D5F4E45555452414C2032353520313230203130204E0A42475F53595354454D5F414C4C49414E434520302031373420323339204E0A42475F53595354454D5F484F5244452032353520302030204E0A524149445F4C4541444552203235352037322039204E0A524149445F5741524E494E47203235352037322030204E0A524149445F424F53535F454D4F544520323535203232312030204E0A524149445F424F53535F5748495350455220323535203232312030204E0A46494C54455245442032353520302030204E0A424154544C4547524F554E4420323535203132372030204E0A424154544C4547524F554E445F4C4541444552203235352032313920313833204E0A524553545249435445442032353520302030204E0A424154544C454E4554203235352032353520323535204E0A414348494556454D454E5420323535203235352030204E0A4755494C445F414348494556454D454E5420363420323535203634204E0A4152454E415F504F494E5453203235352032353520323535204E0A50415254595F4C4541444552203131382032303020323535204E0A54415247455449434F4E5320323535203235352030204E0A424E5F5748495350455220302032353520323436204E0A424E5F574849535045525F494E464F524D20302032353520323436204E0A424E5F434F4E564552534154494F4E20302031373720323430204E0A424E5F434F4E564552534154494F4E5F4E4F5449434520302031373720323430204E0A424E5F434F4E564552534154494F4E5F4C49535420302031373720323430204E0A424E5F494E4C494E455F544F4153545F414C455254203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F414443415354203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F4144434153545F494E464F524D203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F434F4E564552534154494F4E203133302031393720323535204E0A4348414E4E454C31203235352031393220313932204E0A4348414E4E454C32203235352031393220313932204E0A4348414E4E454C33203235352031393220313932204E0A4348414E4E454C34203235352031393220313932204E0A4348414E4E454C35203235352031393220313932204E0A4348414E4E454C36203235352031393220313932204E0A4348414E4E454C37203235352031393220313932204E0A4348414E4E454C38203235352031393220313932204E0A4348414E4E454C39203235352031393220313932204E0A4348414E4E454C3130203235352031393220313932204E0A454E440A0A57494E444F5720310A4E414D452047656E6572616C0A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420310A53484F574E20300A4D455353414745530A53595354454D0A53595354454D5F4E4F4D454E550A5341590A454D4F54450A59454C4C0A574849535045520A50415254590A50415254595F4C45414445520A524149440A524149445F4C45414445520A524149445F5741524E494E470A424154544C4547524F554E440A424154544C4547524F554E445F4C45414445520A4755494C440A4F4646494345520A4D4F4E535445525F5341590A4D4F4E535445525F59454C4C0A4D4F4E535445525F454D4F54450A4D4F4E535445525F574849535045520A4D4F4E535445525F424F53535F454D4F54450A4D4F4E535445525F424F53535F574849535045520A4552524F52530A41464B0A444E440A49474E4F5245440A42475F484F5244450A42475F414C4C49414E43450A42475F4E45555452414C0A434F4D4241545F46414354494F4E5F4348414E47450A534B494C4C0A4C4F4F540A4D4F4E45590A4348414E4E454C0A414348494556454D454E540A4755494C445F414348494556454D454E540A54415247455449434F4E530A424E5F574849535045520A424E5F574849535045525F494E464F524D0A424E5F434F4E564552534154494F4E0A424E5F494E4C494E455F544F4153545F414C4552540A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C532031383837343337310A0A454E440A0A57494E444F5720320A4E414D4520436F6D626174204C6F670A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420320A53484F574E20300A4D455353414745530A4F50454E494E470A5452414445534B494C4C530A5045545F494E464F0A434F4D4241545F58505F4741494E0A434F4D4241545F484F4E4F525F4741494E0A434F4D4241545F4D4953435F494E464F0A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720330A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720340A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720350A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720360A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720370A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720380A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720390A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F572031300A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A);
INSERT INTO `character_account_data` VALUES ('7', '1', '1293596540', 0x534554206D696E696D61705A6F6F6D202230220A534554206D696E696D6170496E736964655A6F6F6D202230220A5345542071756573744C6F67436F6C6C6170736546696C74657220222D31220A53455420747261636B656451756573747320227601220A53455420747261636B6564416368696576656D656E747320227601220A5345542063616D657261536176656444697374616E63652022362E353439363030220A5345542063616D657261536176656450697463682022312E303439393934220A53455420706C61796572537461744C65667444726F70646F776E2022504C41594552535441545F424153455F5354415453220A53455420706C6179657253746174526967687444726F70646F776E2022504C41594552535441545F4D454C45455F434F4D424154220A);
INSERT INTO `character_account_data` VALUES ('7', '3', '1293596233', 0x42494E44494E474D4F444520300D0A62696E642053484946542D4C205147545F544F47474C455F545241434B45525F4B420D0A);
INSERT INTO `character_account_data` VALUES ('2', '1', '1290821038', 0x534554206D696E696D61705A6F6F6D202230220A5345542071756573744C6F67436F6C6C6170736546696C74657220222D31220A53455420747261636B656451756573747320227601220A53455420747261636B6564416368696576656D656E747320227601220A5345542063616D657261536176656444697374616E6365202232302E343639303238220A5345542063616D65726153617665645069746368202231332E343137353436220A53455420706C61796572537461744C65667444726F70646F776E2022504C41594552535441545F424153455F5354415453220A53455420706C6179657253746174526967687444726F70646F776E2022504C41594552535441545F4D454C45455F434F4D424154220A);
INSERT INTO `character_account_data` VALUES ('2', '3', '1290503503', 0x42494E44494E474D4F444520300D0A62696E642053484946542D4C205147545F544F47474C455F545241434B45525F4B420D0A);

-- ----------------------------
-- Table structure for `character_achievement`
-- ----------------------------
DROP TABLE IF EXISTS `character_achievement`;
CREATE TABLE `character_achievement` (
  `guid` int(11) unsigned NOT NULL,
  `achievement` int(11) unsigned NOT NULL,
  `date` bigint(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`achievement`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_achievement
-- ----------------------------
INSERT INTO `character_achievement` VALUES ('7', '7', '1293596540');
INSERT INTO `character_achievement` VALUES ('7', '6', '1293596540');
INSERT INTO `character_achievement` VALUES ('7', '133', '1293596540');
INSERT INTO `character_achievement` VALUES ('7', '132', '1293596540');
INSERT INTO `character_achievement` VALUES ('7', '891', '1293596540');
INSERT INTO `character_achievement` VALUES ('7', '131', '1293596540');
INSERT INTO `character_achievement` VALUES ('7', '10', '1293596540');
INSERT INTO `character_achievement` VALUES ('7', '889', '1293596540');
INSERT INTO `character_achievement` VALUES ('6', '6', '1292600097');
INSERT INTO `character_achievement` VALUES ('7', '9', '1293596540');
INSERT INTO `character_achievement` VALUES ('7', '8', '1293596540');
INSERT INTO `character_achievement` VALUES ('6', '503', '1292744030');

-- ----------------------------
-- Table structure for `character_achievement_progress`
-- ----------------------------
DROP TABLE IF EXISTS `character_achievement_progress`;
CREATE TABLE `character_achievement_progress` (
  `guid` int(11) unsigned NOT NULL,
  `criteria` int(11) unsigned NOT NULL,
  `counter` int(11) unsigned NOT NULL,
  `date` bigint(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`criteria`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_achievement_progress
-- ----------------------------
INSERT INTO `character_achievement_progress` VALUES ('7', '5592', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5576', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '840', '150', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '40', '55', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('6', '5215', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '9686', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '3510', '1007', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '5316', '5345', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '1526', '1', '1292744170');
INSERT INTO `character_achievement_progress` VALUES ('6', '1531', '1', '1292599841');
INSERT INTO `character_achievement_progress` VALUES ('6', '996', '13085', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '2239', '54', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '36', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '3506', '1007', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '10505', '1', '1292577449');
INSERT INTO `character_achievement_progress` VALUES ('6', '3355', '6810', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '5577', '60', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '233', '54', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '1513', '1', '1292577187');
INSERT INTO `character_achievement_progress` VALUES ('6', '73', '54', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '5371', '184', '1290610616');
INSERT INTO `character_achievement_progress` VALUES ('6', '41', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '992', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '3361', '3413', '1290752521');
INSERT INTO `character_achievement_progress` VALUES ('6', '9687', '5345', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '841', '75', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '5376', '87', '1290753226');
INSERT INTO `character_achievement_progress` VALUES ('6', '3511', '1007', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '6752', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '4224', '8915', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '1518', '1', '1292577167');
INSERT INTO `character_achievement_progress` VALUES ('6', '5701', '1', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '4960', '2', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '613', '75', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '5317', '13085', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '7891', '15', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '1504', '1', '1293996035');
INSERT INTO `character_achievement_progress` VALUES ('6', '842', '75', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '1527', '1', '1292744435');
INSERT INTO `character_achievement_progress` VALUES ('6', '6753', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '5230', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5249', '1', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('7', '756', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '36', '30', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5579', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '4763', '3500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '843', '300', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5314', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '994', '3100', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '754', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '34', '10', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5577', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '841', '225', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '41', '55', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '1872', '75', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '992', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '656', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '9687', '3100', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '4743', '3200', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '167', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '39', '55', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '9598', '40', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5230', '55', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '1870', '150', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '9685', '4000', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '8821', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5589', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5317', '4000', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5301', '7', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '37', '40', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5212', '55', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '1884', '3500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '844', '300', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '9683', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '8819', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5315', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5219', '55', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '995', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '755', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '35', '20', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '6394', '26', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5578', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5562', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '842', '300', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5313', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5249', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '2417', '3200', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '1873', '150', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '993', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '753', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '641', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('6', '37', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5592', '1', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '6751', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '111', '4', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '5372', '8885', '1290610616');
INSERT INTO `character_achievement_progress` VALUES ('6', '5212', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '7222', '2', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '9683', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '1514', '1', '1292577063');
INSERT INTO `character_achievement_progress` VALUES ('6', '3507', '1007', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '4092', '6810', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '5313', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '4091', '3413', '1290752521');
INSERT INTO `character_achievement_progress` VALUES ('6', '993', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '614', '75', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '1528', '1', '1292204627');
INSERT INTO `character_achievement_progress` VALUES ('6', '4961', '2', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '3512', '1007', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '2072', '2326', '1292228115');
INSERT INTO `character_achievement_progress` VALUES ('6', '232', '54', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '40', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '755', '60', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5967', '36', '1290959143');
INSERT INTO `character_achievement_progress` VALUES ('6', '5375', '2770', '1290753226');
INSERT INTO `character_achievement_progress` VALUES ('6', '1546', '1', '1293995978');
INSERT INTO `character_achievement_progress` VALUES ('7', '1871', '150', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '9686', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '8822', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '7222', '26', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5590', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '38', '50', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '9684', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '8820', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5316', '3100', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '2020', '200', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '996', '4000', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('6', '4959', '2', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '234', '54', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '4943', '2770', '1290753226');
INSERT INTO `character_achievement_progress` VALUES ('6', '4093', '1007', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '230', '50', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '3631', '54', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '612', '75', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '9684', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5314', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5373', '42', '1290610616');
INSERT INTO `character_achievement_progress` VALUES ('6', '5563', '1', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '843', '75', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '6754', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '1510', '1', '1290959910');
INSERT INTO `character_achievement_progress` VALUES ('6', '1524', '1', '1292604600');
INSERT INTO `character_achievement_progress` VALUES ('6', '38', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '6393', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '615', '75', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '1517', '1', '1292204133');
INSERT INTO `character_achievement_progress` VALUES ('6', '994', '5345', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5300', '1', '1292204532');
INSERT INTO `character_achievement_progress` VALUES ('6', '756', '60', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5323', '250', '1293996053');
INSERT INTO `character_achievement_progress` VALUES ('6', '5593', '4', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '1529', '1', '1292599639');
INSERT INTO `character_achievement_progress` VALUES ('6', '1515', '1', '1292200294');
INSERT INTO `character_achievement_progress` VALUES ('6', '34', '10', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '162', '27825', '1290610616');
INSERT INTO `character_achievement_progress` VALUES ('6', '7221', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '1511', '1', '1292204791');
INSERT INTO `character_achievement_progress` VALUES ('6', '1520', '1', '1292604806');
INSERT INTO `character_achievement_progress` VALUES ('6', '3513', '6810', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '844', '75', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '5968', '2', '1293885466');
INSERT INTO `character_achievement_progress` VALUES ('6', '5374', '87', '1290753226');
INSERT INTO `character_achievement_progress` VALUES ('6', '231', '54', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '8822', '500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '167', '60', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '9685', '13085', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '39', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '8821', '500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '6755', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '5301', '8', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '9598', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5315', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '149', '2', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '8820', '500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '995', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '1521', '1', '1292229317');
INSERT INTO `character_achievement_progress` VALUES ('6', '2020', '200', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '1884', '3500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '1508', '1', '1290502447');
INSERT INTO `character_achievement_progress` VALUES ('6', '6394', '2', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '5562', '1', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '1509', '1', '1290828299');
INSERT INTO `character_achievement_progress` VALUES ('6', '5242', '1', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '8819', '500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5589', '60', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '4763', '3500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '3354', '1007', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '236', '54', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '35', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '1512', '1', '1290959319');
INSERT INTO `character_achievement_progress` VALUES ('6', '840', '75', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '753', '60', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '168', '75', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '5576', '60', '1290502430');

-- ----------------------------
-- Table structure for `character_action`
-- ----------------------------
DROP TABLE IF EXISTS `character_action`;
CREATE TABLE `character_action` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `spec` tinyint(3) unsigned NOT NULL default '0',
  `button` tinyint(3) unsigned NOT NULL default '0',
  `action` int(11) unsigned NOT NULL default '0',
  `type` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spec`,`button`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_action
-- ----------------------------
INSERT INTO `character_action` VALUES ('9', '0', '6', '1', '64');
INSERT INTO `character_action` VALUES ('9', '0', '4', '45902', '0');
INSERT INTO `character_action` VALUES ('9', '0', '5', '47541', '0');
INSERT INTO `character_action` VALUES ('9', '0', '10', '20577', '0');
INSERT INTO `character_action` VALUES ('6', '0', '5', '20271', '0');
INSERT INTO `character_action` VALUES ('6', '0', '4', '21084', '0');
INSERT INTO `character_action` VALUES ('6', '0', '3', '28730', '0');
INSERT INTO `character_action` VALUES ('6', '0', '1', '19740', '0');
INSERT INTO `character_action` VALUES ('9', '0', '3', '45462', '0');
INSERT INTO `character_action` VALUES ('6', '0', '2', '635', '0');
INSERT INTO `character_action` VALUES ('6', '0', '0', '6603', '0');
INSERT INTO `character_action` VALUES ('9', '0', '7', '2', '64');
INSERT INTO `character_action` VALUES ('9', '0', '8', '5', '64');
INSERT INTO `character_action` VALUES ('9', '0', '9', '4', '64');
INSERT INTO `character_action` VALUES ('9', '0', '11', '3', '64');
INSERT INTO `character_action` VALUES ('7', '0', '0', '6603', '0');
INSERT INTO `character_action` VALUES ('7', '0', '1', '49576', '0');
INSERT INTO `character_action` VALUES ('7', '0', '2', '45477', '0');
INSERT INTO `character_action` VALUES ('7', '0', '3', '45462', '0');
INSERT INTO `character_action` VALUES ('7', '0', '4', '45902', '0');
INSERT INTO `character_action` VALUES ('7', '0', '5', '47541', '0');
INSERT INTO `character_action` VALUES ('7', '0', '6', '2', '64');
INSERT INTO `character_action` VALUES ('7', '0', '7', '1', '64');
INSERT INTO `character_action` VALUES ('7', '0', '8', '5', '64');
INSERT INTO `character_action` VALUES ('7', '0', '9', '3', '64');
INSERT INTO `character_action` VALUES ('7', '0', '10', '4', '64');
INSERT INTO `character_action` VALUES ('9', '0', '2', '45477', '0');
INSERT INTO `character_action` VALUES ('9', '0', '1', '49576', '0');
INSERT INTO `character_action` VALUES ('9', '0', '0', '6603', '0');

-- ----------------------------
-- Table structure for `character_aura`
-- ----------------------------
DROP TABLE IF EXISTS `character_aura`;
CREATE TABLE `character_aura` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `caster_guid` bigint(20) unsigned NOT NULL default '0' COMMENT 'Full Global Unique Identifier',
  `item_guid` int(11) unsigned NOT NULL default '0',
  `spell` int(11) unsigned NOT NULL default '0',
  `stackcount` int(11) NOT NULL default '1',
  `remaincharges` int(11) NOT NULL default '0',
  `basepoints0` int(11) NOT NULL default '0',
  `basepoints1` int(11) NOT NULL default '0',
  `basepoints2` int(11) NOT NULL default '0',
  `maxduration0` int(11) NOT NULL default '0',
  `maxduration1` int(11) NOT NULL default '0',
  `maxduration2` int(11) NOT NULL default '0',
  `remaintime0` int(11) NOT NULL default '0',
  `remaintime1` int(11) NOT NULL default '0',
  `remaintime2` int(11) NOT NULL default '0',
  `effIndexMask` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guid`,`caster_guid`,`item_guid`,`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_aura
-- ----------------------------
INSERT INTO `character_aura` VALUES ('6', '6', '0', '63531', '0', '0', '0', '0', '0', '0', '-1', '-1', '0', '-1', '-1', '6');
INSERT INTO `character_aura` VALUES ('7', '7', '0', '48266', '1', '0', '15', '0', '-20', '-1', '-1', '-1', '-1', '-1', '-1', '7');
INSERT INTO `character_aura` VALUES ('7', '7', '0', '51915', '1', '0', '0', '0', '0', '-1', '0', '0', '-1', '0', '0', '1');
INSERT INTO `character_aura` VALUES ('7', '7', '0', '63611', '1', '0', '0', '4', '0', '0', '-1', '0', '0', '-1', '0', '2');
INSERT INTO `character_aura` VALUES ('9', '9', '0', '48266', '0', '0', '15', '0', '-28', '-1', '-1', '-1', '-1', '-1', '-1', '7');
INSERT INTO `character_aura` VALUES ('9', '9', '0', '63611', '0', '0', '0', '4', '0', '0', '-1', '0', '0', '-1', '0', '2');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '63514', '0', '0', '0', '0', '0', '0', '-1', '0', '0', '-1', '0', '2');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '63510', '0', '0', '0', '0', '0', '0', '-1', '-1', '0', '-1', '-1', '6');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '21084', '0', '0', '0', '0', '20187', '1800000', '1800000', '1800000', '501008', '501008', '501008', '7');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '465', '0', '0', '55', '0', '0', '-1', '0', '0', '-1', '0', '0', '1');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '19740', '1', '0', '20', '20', '0', '600000', '600000', '0', '143200', '143200', '0', '3');

-- ----------------------------
-- Table structure for `character_battleground_data`
-- ----------------------------
DROP TABLE IF EXISTS `character_battleground_data`;
CREATE TABLE `character_battleground_data` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `instance_id` int(11) unsigned NOT NULL default '0',
  `team` int(11) unsigned NOT NULL default '0',
  `join_x` float NOT NULL default '0',
  `join_y` float NOT NULL default '0',
  `join_z` float NOT NULL default '0',
  `join_o` float NOT NULL default '0',
  `join_map` int(11) NOT NULL default '0',
  `taxi_start` int(11) NOT NULL default '0',
  `taxi_end` int(11) NOT NULL default '0',
  `mount_spell` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_battleground_data
-- ----------------------------

-- ----------------------------
-- Table structure for `character_battleground_random`
-- ----------------------------
DROP TABLE IF EXISTS `character_battleground_random`;
CREATE TABLE `character_battleground_random` (
  `guid` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_battleground_random
-- ----------------------------

-- ----------------------------
-- Table structure for `character_db_version`
-- ----------------------------
DROP TABLE IF EXISTS `character_db_version`;
CREATE TABLE `character_db_version` (
  `required_10862_01_characters_mail` bit(1) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Last applied sql update to DB';

-- ----------------------------
-- Records of character_db_version
-- ----------------------------
INSERT INTO `character_db_version` VALUES (null);

-- ----------------------------
-- Table structure for `character_declinedname`
-- ----------------------------
DROP TABLE IF EXISTS `character_declinedname`;
CREATE TABLE `character_declinedname` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `genitive` varchar(15) NOT NULL default '',
  `dative` varchar(15) NOT NULL default '',
  `accusative` varchar(15) NOT NULL default '',
  `instrumental` varchar(15) NOT NULL default '',
  `prepositional` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of character_declinedname
-- ----------------------------

-- ----------------------------
-- Table structure for `character_equipmentsets`
-- ----------------------------
DROP TABLE IF EXISTS `character_equipmentsets`;
CREATE TABLE `character_equipmentsets` (
  `guid` int(11) NOT NULL default '0',
  `setguid` bigint(20) NOT NULL auto_increment,
  `setindex` tinyint(4) NOT NULL default '0',
  `name` varchar(100) NOT NULL,
  `iconname` varchar(100) NOT NULL,
  `item0` int(11) NOT NULL default '0',
  `item1` int(11) NOT NULL default '0',
  `item2` int(11) NOT NULL default '0',
  `item3` int(11) NOT NULL default '0',
  `item4` int(11) NOT NULL default '0',
  `item5` int(11) NOT NULL default '0',
  `item6` int(11) NOT NULL default '0',
  `item7` int(11) NOT NULL default '0',
  `item8` int(11) NOT NULL default '0',
  `item9` int(11) NOT NULL default '0',
  `item10` int(11) NOT NULL default '0',
  `item11` int(11) NOT NULL default '0',
  `item12` int(11) NOT NULL default '0',
  `item13` int(11) NOT NULL default '0',
  `item14` int(11) NOT NULL default '0',
  `item15` int(11) NOT NULL default '0',
  `item16` int(11) NOT NULL default '0',
  `item17` int(11) NOT NULL default '0',
  `item18` int(11) NOT NULL default '0',
  PRIMARY KEY  (`setguid`),
  UNIQUE KEY `idx_set` (`guid`,`setguid`,`setindex`),
  KEY `Idx_setindex` (`setindex`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_equipmentsets
-- ----------------------------

-- ----------------------------
-- Table structure for `character_feed_log`
-- ----------------------------
DROP TABLE IF EXISTS `character_feed_log`;
CREATE TABLE `character_feed_log` (
  `guid` int(11) NOT NULL,
  `type` smallint(1) NOT NULL,
  `data` int(11) NOT NULL,
  `date` int(11) default NULL,
  `counter` int(11) NOT NULL,
  `difficulty` smallint(6) default '-1',
  `item_guid` int(11) NOT NULL,
  PRIMARY KEY  (`guid`,`type`,`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_feed_log
-- ----------------------------

-- ----------------------------
-- Table structure for `character_gifts`
-- ----------------------------
DROP TABLE IF EXISTS `character_gifts`;
CREATE TABLE `character_gifts` (
  `guid` int(20) unsigned NOT NULL default '0',
  `item_guid` int(11) unsigned NOT NULL default '0',
  `entry` int(20) unsigned NOT NULL default '0',
  `flags` int(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`item_guid`),
  KEY `idx_guid` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_gifts
-- ----------------------------

-- ----------------------------
-- Table structure for `character_glyphs`
-- ----------------------------
DROP TABLE IF EXISTS `character_glyphs`;
CREATE TABLE `character_glyphs` (
  `guid` int(11) unsigned NOT NULL,
  `spec` tinyint(3) unsigned NOT NULL default '0',
  `slot` tinyint(3) unsigned NOT NULL default '0',
  `glyph` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spec`,`slot`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_glyphs
-- ----------------------------

-- ----------------------------
-- Table structure for `character_homebind`
-- ----------------------------
DROP TABLE IF EXISTS `character_homebind`;
CREATE TABLE `character_homebind` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `map` int(11) unsigned NOT NULL default '0' COMMENT 'Map Identifier',
  `zone` int(11) unsigned NOT NULL default '0' COMMENT 'Zone Identifier',
  `position_x` float NOT NULL default '0',
  `position_y` float NOT NULL default '0',
  `position_z` float NOT NULL default '0',
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_homebind
-- ----------------------------
INSERT INTO `character_homebind` VALUES ('9', '609', '4298', '2356.21', '-5662.21', '426.026');
INSERT INTO `character_homebind` VALUES ('6', '530', '3665', '9478.2', '-6858.35', '17.372');
INSERT INTO `character_homebind` VALUES ('7', '609', '4298', '2355.84', '-5664.77', '426.028');
INSERT INTO `character_homebind` VALUES ('2', '0', '1', '-6240', '331', '383');

-- ----------------------------
-- Table structure for `character_instance`
-- ----------------------------
DROP TABLE IF EXISTS `character_instance`;
CREATE TABLE `character_instance` (
  `guid` int(11) unsigned NOT NULL default '0',
  `instance` int(11) unsigned NOT NULL default '0',
  `permanent` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_instance
-- ----------------------------

-- ----------------------------
-- Table structure for `character_inventory`
-- ----------------------------
DROP TABLE IF EXISTS `character_inventory`;
CREATE TABLE `character_inventory` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `bag` int(11) unsigned NOT NULL default '0',
  `slot` tinyint(3) unsigned NOT NULL default '0',
  `item` int(11) unsigned NOT NULL default '0' COMMENT 'Item Global Unique Identifier',
  `item_template` int(11) unsigned NOT NULL default '0' COMMENT 'Item Identifier',
  PRIMARY KEY  (`item`),
  KEY `idx_guid` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_inventory
-- ----------------------------
INSERT INTO `character_inventory` VALUES ('2', '0', '4', '36', '56');
INSERT INTO `character_inventory` VALUES ('2', '0', '7', '42', '55');
INSERT INTO `character_inventory` VALUES ('2', '0', '15', '44', '35');
INSERT INTO `character_inventory` VALUES ('2', '0', '23', '46', '6948');
INSERT INTO `character_inventory` VALUES ('6', '7855', '0', '39607', '6293');
INSERT INTO `character_inventory` VALUES ('6', '0', '21', '13504', '4496');
INSERT INTO `character_inventory` VALUES ('9', '0', '1', '11051', '34657');
INSERT INTO `character_inventory` VALUES ('7', '0', '24', '9874', '40582');
INSERT INTO `character_inventory` VALUES ('6', '13504', '3', '28442', '1179');
INSERT INTO `character_inventory` VALUES ('9', '0', '9', '11043', '34649');
INSERT INTO `character_inventory` VALUES ('7', '0', '23', '9872', '41751');
INSERT INTO `character_inventory` VALUES ('7', '0', '11', '9870', '38147');
INSERT INTO `character_inventory` VALUES ('7', '0', '8', '358', '34653');
INSERT INTO `character_inventory` VALUES ('6', '0', '23', '630', '6948');
INSERT INTO `character_inventory` VALUES ('7', '0', '23', '382', '41751');
INSERT INTO `character_inventory` VALUES ('6', '0', '3', '622', '24143');
INSERT INTO `character_inventory` VALUES ('9', '0', '23', '11065', '41751');
INSERT INTO `character_inventory` VALUES ('9', '0', '11', '11063', '38147');
INSERT INTO `character_inventory` VALUES ('9', '0', '22', '11061', '38145');
INSERT INTO `character_inventory` VALUES ('9', '0', '21', '11059', '38145');
INSERT INTO `character_inventory` VALUES ('9', '0', '20', '11057', '38145');
INSERT INTO `character_inventory` VALUES ('9', '0', '19', '11055', '38145');
INSERT INTO `character_inventory` VALUES ('6', '0', '5', '28432', '2635');
INSERT INTO `character_inventory` VALUES ('6', '0', '26', '37504', '118');
INSERT INTO `character_inventory` VALUES ('6', '0', '27', '37506', '858');
INSERT INTO `character_inventory` VALUES ('6', '0', '30', '37507', '2318');
INSERT INTO `character_inventory` VALUES ('6', '0', '16', '10296', '20841');
INSERT INTO `character_inventory` VALUES ('7', '0', '21', '376', '38145');
INSERT INTO `character_inventory` VALUES ('7', '0', '22', '378', '38145');
INSERT INTO `character_inventory` VALUES ('6', '0', '35', '39601', '22570');
INSERT INTO `character_inventory` VALUES ('6', '0', '36', '39602', '15925');
INSERT INTO `character_inventory` VALUES ('6', '0', '29', '25959', '27668');
INSERT INTO `character_inventory` VALUES ('7', '0', '5', '362', '34651');
INSERT INTO `character_inventory` VALUES ('7', '0', '6', '364', '34656');
INSERT INTO `character_inventory` VALUES ('7', '0', '4', '356', '34650');
INSERT INTO `character_inventory` VALUES ('6', '0', '24', '10500', '159');
INSERT INTO `character_inventory` VALUES ('6', '7855', '2', '39612', '12223');
INSERT INTO `character_inventory` VALUES ('6', '0', '14', '23656', '1421');
INSERT INTO `character_inventory` VALUES ('7', '0', '1', '368', '34657');
INSERT INTO `character_inventory` VALUES ('7', '0', '2', '352', '34655');
INSERT INTO `character_inventory` VALUES ('6', '0', '20', '10279', '4496');
INSERT INTO `character_inventory` VALUES ('7', '0', '19', '372', '38145');
INSERT INTO `character_inventory` VALUES ('9', '0', '7', '11049', '34648');
INSERT INTO `character_inventory` VALUES ('6', '0', '31', '37508', '4537');
INSERT INTO `character_inventory` VALUES ('6', '0', '32', '26233', '6507');
INSERT INTO `character_inventory` VALUES ('9', '0', '14', '11037', '34659');
INSERT INTO `character_inventory` VALUES ('6', '0', '25', '25964', '23500');
INSERT INTO `character_inventory` VALUES ('9', '0', '10', '11053', '34658');
INSERT INTO `character_inventory` VALUES ('6', '0', '34', '39312', '4814');
INSERT INTO `character_inventory` VALUES ('6', '0', '33', '23868', '22976');
INSERT INTO `character_inventory` VALUES ('9', '0', '5', '11045', '34651');
INSERT INTO `character_inventory` VALUES ('9', '0', '0', '11033', '34652');
INSERT INTO `character_inventory` VALUES ('9', '0', '2', '11035', '34655');
INSERT INTO `character_inventory` VALUES ('6', '7855', '1', '39609', '2967');
INSERT INTO `character_inventory` VALUES ('6', '0', '9', '23867', '23376');
INSERT INTO `character_inventory` VALUES ('6', '0', '4', '22916', '22953');
INSERT INTO `character_inventory` VALUES ('6', '0', '15', '13503', '2488');
INSERT INTO `character_inventory` VALUES ('9', '0', '6', '11047', '34656');
INSERT INTO `character_inventory` VALUES ('2', '0', '3', '500', '49');
INSERT INTO `character_inventory` VALUES ('2', '0', '6', '502', '48');
INSERT INTO `character_inventory` VALUES ('7', '0', '20', '9864', '38145');
INSERT INTO `character_inventory` VALUES ('2', '0', '17', '510', '28979');
INSERT INTO `character_inventory` VALUES ('7', '0', '10', '9860', '34658');
INSERT INTO `character_inventory` VALUES ('7', '0', '7', '9856', '34648');
INSERT INTO `character_inventory` VALUES ('7', '0', '9', '9850', '34649');
INSERT INTO `character_inventory` VALUES ('7', '0', '14', '9844', '34659');
INSERT INTO `character_inventory` VALUES ('7', '0', '0', '9840', '34652');
INSERT INTO `character_inventory` VALUES ('6', '0', '8', '38710', '28148');
INSERT INTO `character_inventory` VALUES ('6', '0', '22', '38711', '22571');
INSERT INTO `character_inventory` VALUES ('6', '0', '38', '26232', '15969');
INSERT INTO `character_inventory` VALUES ('6', '0', '28', '26110', '4604');
INSERT INTO `character_inventory` VALUES ('6', '7855', '3', '39613', '6506');
INSERT INTO `character_inventory` VALUES ('6', '0', '37', '39606', '6296');
INSERT INTO `character_inventory` VALUES ('6', '0', '7', '28141', '2642');
INSERT INTO `character_inventory` VALUES ('6', '0', '19', '7855', '20474');
INSERT INTO `character_inventory` VALUES ('9', '0', '8', '11041', '34653');
INSERT INTO `character_inventory` VALUES ('6', '0', '6', '26229', '2646');
INSERT INTO `character_inventory` VALUES ('9', '0', '4', '11039', '34650');

-- ----------------------------
-- Table structure for `character_pet`
-- ----------------------------
DROP TABLE IF EXISTS `character_pet`;
CREATE TABLE `character_pet` (
  `id` int(11) unsigned NOT NULL default '0',
  `entry` int(11) unsigned NOT NULL default '0',
  `owner` int(11) unsigned NOT NULL default '0',
  `modelid` int(11) unsigned default '0',
  `CreatedBySpell` int(11) unsigned NOT NULL default '0',
  `PetType` tinyint(3) unsigned NOT NULL default '0',
  `level` int(11) unsigned NOT NULL default '1',
  `exp` int(11) unsigned NOT NULL default '0',
  `Reactstate` tinyint(1) unsigned NOT NULL default '0',
  `name` varchar(100) default 'Pet',
  `renamed` tinyint(1) unsigned NOT NULL default '0',
  `slot` int(11) unsigned NOT NULL default '0',
  `curhealth` int(11) unsigned NOT NULL default '1',
  `curmana` int(11) unsigned NOT NULL default '0',
  `curhappiness` int(11) unsigned NOT NULL default '0',
  `savetime` bigint(20) unsigned NOT NULL default '0',
  `resettalents_cost` int(11) unsigned NOT NULL default '0',
  `resettalents_time` bigint(20) unsigned NOT NULL default '0',
  `abdata` longtext,
  PRIMARY KEY  (`id`),
  KEY `owner` (`owner`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Pet System';

-- ----------------------------
-- Records of character_pet
-- ----------------------------

-- ----------------------------
-- Table structure for `character_pet_declinedname`
-- ----------------------------
DROP TABLE IF EXISTS `character_pet_declinedname`;
CREATE TABLE `character_pet_declinedname` (
  `id` int(11) unsigned NOT NULL default '0',
  `owner` int(11) unsigned NOT NULL default '0',
  `genitive` varchar(12) NOT NULL default '',
  `dative` varchar(12) NOT NULL default '',
  `accusative` varchar(12) NOT NULL default '',
  `instrumental` varchar(12) NOT NULL default '',
  `prepositional` varchar(12) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `owner_key` (`owner`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of character_pet_declinedname
-- ----------------------------

-- ----------------------------
-- Table structure for `character_queststatus`
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus`;
CREATE TABLE `character_queststatus` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `quest` int(11) unsigned NOT NULL default '0' COMMENT 'Quest Identifier',
  `status` int(11) unsigned NOT NULL default '0',
  `rewarded` tinyint(1) unsigned NOT NULL default '0',
  `explored` tinyint(1) unsigned NOT NULL default '0',
  `timer` bigint(20) unsigned NOT NULL default '0',
  `mobcount1` int(11) unsigned NOT NULL default '0',
  `mobcount2` int(11) unsigned NOT NULL default '0',
  `mobcount3` int(11) unsigned NOT NULL default '0',
  `mobcount4` int(11) unsigned NOT NULL default '0',
  `itemcount1` int(11) unsigned NOT NULL default '0',
  `itemcount2` int(11) unsigned NOT NULL default '0',
  `itemcount3` int(11) unsigned NOT NULL default '0',
  `itemcount4` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`quest`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus
-- ----------------------------
INSERT INTO `character_queststatus` VALUES ('6', '9705', '1', '1', '0', '1290828900', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9704', '1', '1', '0', '1290828900', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8350', '1', '1', '0', '1290832144', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8347', '1', '1', '0', '1290828900', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8338', '1', '1', '0', '1290828900', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8335', '1', '1', '0', '1290828900', '8', '2', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9147', '3', '0', '0', '1293996958', '0', '0', '0', '0', '3', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '10166', '1', '1', '1', '1292744602', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8490', '1', '1', '0', '1293885505', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8474', '1', '1', '0', '1292744602', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9253', '1', '1', '0', '1292744602', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8473', '1', '1', '0', '1292605919', '10', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9255', '1', '1', '0', '1292604448', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8488', '1', '1', '1', '1292603548', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9144', '1', '1', '0', '1293885505', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8887', '1', '1', '0', '1292600870', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8487', '1', '1', '0', '1292600870', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('9', '12641', '3', '0', '0', '1292575453', '1', '1', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9359', '1', '1', '0', '1292577505', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9252', '1', '1', '0', '1292604448', '4', '4', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8475', '1', '1', '0', '1292228887', '8', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9076', '1', '1', '0', '1292600870', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9067', '1', '1', '0', '1292577505', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8886', '1', '1', '0', '1292600870', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8480', '1', '1', '0', '1292227716', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9395', '1', '1', '0', '1292205026', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9358', '1', '1', '0', '1292577505', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9258', '1', '1', '0', '1292605105', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9254', '1', '1', '0', '1292577505', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8892', '1', '1', '0', '1292228887', '5', '5', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8491', '1', '1', '0', '1292204688', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9066', '1', '1', '0', '1292229337', '1', '1', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9064', '1', '1', '0', '1292200383', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8334', '1', '1', '0', '1290827822', '7', '7', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8346', '1', '1', '0', '1290753393', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8345', '1', '1', '0', '1290753393', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9062', '1', '1', '0', '1292200383', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8330', '1', '1', '0', '1290753393', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '10069', '1', '1', '0', '1290747446', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9676', '1', '1', '0', '1290612331', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8336', '1', '1', '0', '1290753616', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8327', '1', '1', '0', '1290753616', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8326', '1', '1', '0', '1290753393', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8325', '1', '1', '0', '1290612331', '8', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8463', '1', '1', '0', '1290959548', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9035', '1', '1', '0', '1292200383', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9256', '1', '1', '0', '1292204688', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8483', '1', '1', '0', '1292149404', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8482', '1', '1', '0', '1292149404', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('9', '12593', '1', '0', '0', '1291572981', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8486', '1', '1', '0', '1292149404', '5', '5', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9352', '1', '1', '0', '1292149404', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8895', '1', '1', '0', '1290959548', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9119', '1', '1', '0', '1290960448', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8472', '1', '1', '0', '1290959548', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8468', '1', '1', '0', '1290959548', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9148', '1', '1', '0', '1293996958', '0', '0', '0', '0', '0', '0', '0', '0');

-- ----------------------------
-- Table structure for `character_queststatus_daily`
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus_daily`;
CREATE TABLE `character_queststatus_daily` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `quest` int(11) unsigned NOT NULL default '0' COMMENT 'Quest Identifier',
  PRIMARY KEY  (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus_daily
-- ----------------------------

-- ----------------------------
-- Table structure for `character_queststatus_monthly`
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus_monthly`;
CREATE TABLE `character_queststatus_monthly` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `quest` int(11) unsigned NOT NULL default '0' COMMENT 'Quest Identifier',
  PRIMARY KEY  (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus_monthly
-- ----------------------------

-- ----------------------------
-- Table structure for `character_queststatus_weekly`
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus_weekly`;
CREATE TABLE `character_queststatus_weekly` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `quest` int(11) unsigned NOT NULL default '0' COMMENT 'Quest Identifier',
  PRIMARY KEY  (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus_weekly
-- ----------------------------

-- ----------------------------
-- Table structure for `character_reputation`
-- ----------------------------
DROP TABLE IF EXISTS `character_reputation`;
CREATE TABLE `character_reputation` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `faction` int(11) unsigned NOT NULL default '0',
  `standing` int(11) NOT NULL default '0',
  `flags` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guid`,`faction`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_reputation
-- ----------------------------
INSERT INTO `character_reputation` VALUES ('9', '1156', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1155', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '1154', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '1137', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '1136', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '1126', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '1124', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1119', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '1118', '0', '12');
INSERT INTO `character_reputation` VALUES ('9', '1117', '0', '12');
INSERT INTO `character_reputation` VALUES ('9', '1106', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1105', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1104', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1098', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1094', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '1097', '0', '12');
INSERT INTO `character_reputation` VALUES ('9', '1037', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '952', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '948', '0', '8');
INSERT INTO `character_reputation` VALUES ('9', '949', '0', '24');
INSERT INTO `character_reputation` VALUES ('9', '1090', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1091', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1082', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '1085', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1077', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1073', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1068', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '1067', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1064', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1052', '0', '152');
INSERT INTO `character_reputation` VALUES ('9', '1050', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '1038', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1031', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1015', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '1012', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1011', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1005', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '989', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '978', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '970', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '942', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '967', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '934', '0', '80');
INSERT INTO `character_reputation` VALUES ('9', '941', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '933', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '936', '0', '28');
INSERT INTO `character_reputation` VALUES ('9', '932', '0', '80');
INSERT INTO `character_reputation` VALUES ('9', '990', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '922', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '911', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '910', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '509', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '510', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '270', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '909', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '930', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '892', '0', '24');
INSERT INTO `character_reputation` VALUES ('9', '891', '0', '14');
INSERT INTO `character_reputation` VALUES ('9', '889', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '890', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '809', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '980', '0', '24');
INSERT INTO `character_reputation` VALUES ('9', '749', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '729', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '730', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '935', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '946', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '947', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '609', '0', '1');
INSERT INTO `character_reputation` VALUES ('9', '576', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '574', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '569', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '571', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '570', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '289', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '46', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '577', '0', '64');
INSERT INTO `character_reputation` VALUES ('9', '589', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '550', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '551', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '549', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '83', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '86', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '69', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '47', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '72', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '54', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '68', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '81', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '530', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '76', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '529', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '67', '0', '25');
INSERT INTO `character_reputation` VALUES ('9', '469', '0', '14');
INSERT INTO `character_reputation` VALUES ('9', '169', '0', '12');
INSERT INTO `character_reputation` VALUES ('9', '470', '0', '64');
INSERT INTO `character_reputation` VALUES ('9', '471', '0', '22');
INSERT INTO `character_reputation` VALUES ('9', '369', '0', '64');
INSERT INTO `character_reputation` VALUES ('9', '70', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '349', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '59', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '93', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '92', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '21', '0', '64');
INSERT INTO `character_reputation` VALUES ('9', '87', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '729', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '730', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '935', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '947', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '609', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '574', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '576', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '571', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '589', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '577', '0', '64');
INSERT INTO `character_reputation` VALUES ('6', '46', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '289', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '570', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '550', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '551', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '47', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '946', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '549', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '83', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '86', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '69', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '72', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '369', '0', '64');
INSERT INTO `character_reputation` VALUES ('6', '471', '0', '22');
INSERT INTO `character_reputation` VALUES ('6', '470', '0', '64');
INSERT INTO `character_reputation` VALUES ('6', '93', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '54', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '68', '2245', '17');
INSERT INTO `character_reputation` VALUES ('6', '81', '2245', '17');
INSERT INTO `character_reputation` VALUES ('6', '67', '0', '25');
INSERT INTO `character_reputation` VALUES ('6', '569', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '530', '2245', '17');
INSERT INTO `character_reputation` VALUES ('6', '76', '2245', '17');
INSERT INTO `character_reputation` VALUES ('6', '529', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '21', '0', '64');
INSERT INTO `character_reputation` VALUES ('6', '469', '0', '14');
INSERT INTO `character_reputation` VALUES ('6', '169', '0', '12');
INSERT INTO `character_reputation` VALUES ('6', '70', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '349', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '59', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '92', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '87', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '87', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '21', '0', '64');
INSERT INTO `character_reputation` VALUES ('7', '92', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '93', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '59', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '349', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '70', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '369', '0', '64');
INSERT INTO `character_reputation` VALUES ('7', '471', '0', '20');
INSERT INTO `character_reputation` VALUES ('7', '470', '0', '64');
INSERT INTO `character_reputation` VALUES ('7', '169', '0', '12');
INSERT INTO `character_reputation` VALUES ('7', '469', '0', '25');
INSERT INTO `character_reputation` VALUES ('7', '67', '0', '14');
INSERT INTO `character_reputation` VALUES ('7', '529', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '76', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '530', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '81', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '68', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '54', '0', '273');
INSERT INTO `character_reputation` VALUES ('7', '72', '0', '17');
INSERT INTO `character_reputation` VALUES ('7', '47', '0', '273');
INSERT INTO `character_reputation` VALUES ('7', '69', '0', '273');
INSERT INTO `character_reputation` VALUES ('7', '86', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '83', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '549', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '551', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '550', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '589', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '577', '0', '64');
INSERT INTO `character_reputation` VALUES ('7', '46', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '289', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '570', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '571', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '569', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '574', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '576', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '609', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '947', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '946', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '935', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '730', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '729', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '749', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '980', '0', '24');
INSERT INTO `character_reputation` VALUES ('7', '809', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '890', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '889', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '891', '0', '24');
INSERT INTO `character_reputation` VALUES ('7', '892', '0', '14');
INSERT INTO `character_reputation` VALUES ('7', '930', '0', '273');
INSERT INTO `character_reputation` VALUES ('7', '909', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '270', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '510', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '509', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '910', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '911', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '922', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '990', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '932', '0', '80');
INSERT INTO `character_reputation` VALUES ('7', '936', '0', '28');
INSERT INTO `character_reputation` VALUES ('7', '933', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '941', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '934', '0', '80');
INSERT INTO `character_reputation` VALUES ('7', '967', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '942', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '970', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '978', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '989', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1005', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '1011', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1012', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1015', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '1031', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1038', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1050', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1052', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '1064', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '1067', '0', '3');
INSERT INTO `character_reputation` VALUES ('7', '1068', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1073', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1077', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1085', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '1082', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '1091', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1090', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '949', '0', '24');
INSERT INTO `character_reputation` VALUES ('7', '948', '0', '8');
INSERT INTO `character_reputation` VALUES ('7', '952', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '1037', '0', '136');
INSERT INTO `character_reputation` VALUES ('7', '1097', '0', '12');
INSERT INTO `character_reputation` VALUES ('7', '1094', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1098', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1104', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1105', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1106', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1117', '0', '12');
INSERT INTO `character_reputation` VALUES ('7', '1118', '0', '12');
INSERT INTO `character_reputation` VALUES ('7', '1119', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '1124', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '1126', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1136', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '1137', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '1154', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '1155', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '1156', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '87', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '21', '0', '64');
INSERT INTO `character_reputation` VALUES ('2', '92', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '93', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '59', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '349', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '70', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '369', '0', '64');
INSERT INTO `character_reputation` VALUES ('2', '471', '0', '20');
INSERT INTO `character_reputation` VALUES ('2', '470', '0', '64');
INSERT INTO `character_reputation` VALUES ('2', '169', '0', '12');
INSERT INTO `character_reputation` VALUES ('2', '469', '0', '25');
INSERT INTO `character_reputation` VALUES ('2', '67', '0', '14');
INSERT INTO `character_reputation` VALUES ('2', '529', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '76', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '530', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '81', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '68', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '54', '0', '17');
INSERT INTO `character_reputation` VALUES ('2', '72', '0', '273');
INSERT INTO `character_reputation` VALUES ('2', '47', '0', '273');
INSERT INTO `character_reputation` VALUES ('2', '69', '0', '273');
INSERT INTO `character_reputation` VALUES ('2', '86', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '83', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '549', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '551', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '550', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '589', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '577', '0', '64');
INSERT INTO `character_reputation` VALUES ('2', '46', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '289', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '570', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '571', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '569', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '574', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '576', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '609', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '947', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '946', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '935', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '730', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '729', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '749', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '980', '0', '24');
INSERT INTO `character_reputation` VALUES ('2', '809', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '890', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '889', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '891', '0', '24');
INSERT INTO `character_reputation` VALUES ('2', '892', '0', '14');
INSERT INTO `character_reputation` VALUES ('2', '930', '0', '273');
INSERT INTO `character_reputation` VALUES ('2', '909', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '270', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '510', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '509', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '910', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '911', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '922', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '990', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '932', '0', '80');
INSERT INTO `character_reputation` VALUES ('2', '936', '0', '28');
INSERT INTO `character_reputation` VALUES ('2', '933', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '941', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '934', '0', '80');
INSERT INTO `character_reputation` VALUES ('2', '967', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '942', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '970', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '978', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '989', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1005', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1011', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1012', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1015', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '1031', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1038', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1050', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1052', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '1064', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '1067', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '1068', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1073', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1077', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1085', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '1082', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1091', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1090', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '949', '0', '24');
INSERT INTO `character_reputation` VALUES ('2', '948', '0', '8');
INSERT INTO `character_reputation` VALUES ('2', '952', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '1037', '0', '136');
INSERT INTO `character_reputation` VALUES ('2', '1097', '0', '12');
INSERT INTO `character_reputation` VALUES ('2', '1094', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1098', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1104', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1105', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1106', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1117', '0', '12');
INSERT INTO `character_reputation` VALUES ('2', '1118', '0', '12');
INSERT INTO `character_reputation` VALUES ('2', '1119', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '1124', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '1126', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1136', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1137', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1154', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1155', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1156', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '749', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '980', '0', '24');
INSERT INTO `character_reputation` VALUES ('6', '809', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '890', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '889', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '891', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '892', '0', '24');
INSERT INTO `character_reputation` VALUES ('6', '930', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '909', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '270', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '510', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '509', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '910', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '911', '9085', '17');
INSERT INTO `character_reputation` VALUES ('6', '922', '250', '17');
INSERT INTO `character_reputation` VALUES ('6', '990', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '932', '0', '80');
INSERT INTO `character_reputation` VALUES ('6', '936', '0', '28');
INSERT INTO `character_reputation` VALUES ('6', '933', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '941', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '934', '0', '80');
INSERT INTO `character_reputation` VALUES ('6', '967', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '942', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '970', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '978', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '989', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1005', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '1011', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1012', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1015', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '1031', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1038', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1050', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '1052', '0', '152');
INSERT INTO `character_reputation` VALUES ('6', '1064', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1067', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1068', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '1073', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1077', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1085', '0', '17');
INSERT INTO `character_reputation` VALUES ('6', '1082', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '1091', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1090', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '949', '0', '24');
INSERT INTO `character_reputation` VALUES ('6', '948', '0', '8');
INSERT INTO `character_reputation` VALUES ('6', '952', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '1037', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '1097', '0', '12');
INSERT INTO `character_reputation` VALUES ('6', '1094', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '1098', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1104', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1105', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1106', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1117', '0', '12');
INSERT INTO `character_reputation` VALUES ('6', '1118', '0', '12');
INSERT INTO `character_reputation` VALUES ('6', '1119', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '1124', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1126', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '1136', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '1137', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '1154', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '1155', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '1156', '0', '16');

-- ----------------------------
-- Table structure for `character_skills`
-- ----------------------------
DROP TABLE IF EXISTS `character_skills`;
CREATE TABLE `character_skills` (
  `guid` int(11) unsigned NOT NULL COMMENT 'Global Unique Identifier',
  `skill` mediumint(9) unsigned NOT NULL,
  `value` mediumint(9) unsigned NOT NULL,
  `max` mediumint(9) unsigned NOT NULL,
  PRIMARY KEY  (`guid`,`skill`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_skills
-- ----------------------------
INSERT INTO `character_skills` VALUES ('2', '8', '1', '1');
INSERT INTO `character_skills` VALUES ('2', '136', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '313', '300', '300');
INSERT INTO `character_skills` VALUES ('2', '98', '300', '300');
INSERT INTO `character_skills` VALUES ('2', '162', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '228', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '6', '1', '1');
INSERT INTO `character_skills` VALUES ('2', '95', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '415', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '172', '295', '295');
INSERT INTO `character_skills` VALUES ('9', '44', '295', '295');
INSERT INTO `character_skills` VALUES ('9', '771', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '43', '295', '295');
INSERT INTO `character_skills` VALUES ('9', '770', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '762', '150', '150');
INSERT INTO `character_skills` VALUES ('9', '162', '295', '295');
INSERT INTO `character_skills` VALUES ('9', '673', '300', '300');
INSERT INTO `character_skills` VALUES ('9', '129', '270', '300');
INSERT INTO `character_skills` VALUES ('6', '594', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '162', '60', '60');
INSERT INTO `character_skills` VALUES ('6', '433', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '137', '300', '300');
INSERT INTO `character_skills` VALUES ('9', '772', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '109', '300', '300');
INSERT INTO `character_skills` VALUES ('9', '229', '295', '295');
INSERT INTO `character_skills` VALUES ('9', '293', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '413', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '118', '295', '295');
INSERT INTO `character_skills` VALUES ('9', '414', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '55', '295', '295');
INSERT INTO `character_skills` VALUES ('9', '95', '295', '295');
INSERT INTO `character_skills` VALUES ('9', '415', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '129', '270', '300');
INSERT INTO `character_skills` VALUES ('7', '98', '300', '300');
INSERT INTO `character_skills` VALUES ('7', '162', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '762', '150', '150');
INSERT INTO `character_skills` VALUES ('7', '770', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '43', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '771', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '44', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '172', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '772', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '229', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '293', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '413', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '118', '1', '275');
INSERT INTO `character_skills` VALUES ('7', '414', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '55', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '95', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '415', '1', '1');
INSERT INTO `character_skills` VALUES ('2', '176', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '173', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '253', '1', '1');
INSERT INTO `character_skills` VALUES ('2', '38', '1', '1');
INSERT INTO `character_skills` VALUES ('2', '118', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '414', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '109', '300', '300');
INSERT INTO `character_skills` VALUES ('7', '756', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '137', '300', '300');
INSERT INTO `character_skills` VALUES ('6', '185', '1', '75');
INSERT INTO `character_skills` VALUES ('6', '129', '1', '75');
INSERT INTO `character_skills` VALUES ('6', '43', '60', '60');
INSERT INTO `character_skills` VALUES ('6', '756', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '109', '300', '300');
INSERT INTO `character_skills` VALUES ('6', '413', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '414', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '55', '60', '60');
INSERT INTO `character_skills` VALUES ('6', '95', '60', '60');
INSERT INTO `character_skills` VALUES ('6', '415', '1', '1');

-- ----------------------------
-- Table structure for `character_social`
-- ----------------------------
DROP TABLE IF EXISTS `character_social`;
CREATE TABLE `character_social` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Character Global Unique Identifier',
  `friend` int(11) unsigned NOT NULL default '0' COMMENT 'Friend Global Unique Identifier',
  `flags` tinyint(1) unsigned NOT NULL default '0' COMMENT 'Friend Flags',
  `note` varchar(48) NOT NULL default '' COMMENT 'Friend Note',
  PRIMARY KEY  (`guid`,`friend`,`flags`),
  KEY `guid` (`guid`),
  KEY `friend` (`friend`),
  KEY `guid_flags` (`guid`,`flags`),
  KEY `friend_flags` (`friend`,`flags`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_social
-- ----------------------------

-- ----------------------------
-- Table structure for `character_spell`
-- ----------------------------
DROP TABLE IF EXISTS `character_spell`;
CREATE TABLE `character_spell` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `spell` int(11) unsigned NOT NULL default '0' COMMENT 'Spell Identifier',
  `active` tinyint(3) unsigned NOT NULL default '1',
  `disabled` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spell`),
  KEY `Idx_spell` (`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_spell
-- ----------------------------
INSERT INTO `character_spell` VALUES ('6', '37836', '1', '0');
INSERT INTO `character_spell` VALUES ('6', '3273', '1', '0');
INSERT INTO `character_spell` VALUES ('6', '2550', '1', '0');
INSERT INTO `character_spell` VALUES ('6', '20271', '1', '0');
INSERT INTO `character_spell` VALUES ('6', '19740', '1', '0');
INSERT INTO `character_spell` VALUES ('6', '465', '1', '0');

-- ----------------------------
-- Table structure for `character_spell_cooldown`
-- ----------------------------
DROP TABLE IF EXISTS `character_spell_cooldown`;
CREATE TABLE `character_spell_cooldown` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier, Low part',
  `spell` int(11) unsigned NOT NULL default '0' COMMENT 'Spell Identifier',
  `item` int(11) unsigned NOT NULL default '0' COMMENT 'Item Identifier',
  `time` bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_spell_cooldown
-- ----------------------------

-- ----------------------------
-- Table structure for `character_stats`
-- ----------------------------
DROP TABLE IF EXISTS `character_stats`;
CREATE TABLE `character_stats` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier, Low part',
  `maxhealth` int(10) unsigned NOT NULL default '0',
  `maxpower1` int(10) unsigned NOT NULL default '0',
  `maxpower2` int(10) unsigned NOT NULL default '0',
  `maxpower3` int(10) unsigned NOT NULL default '0',
  `maxpower4` int(10) unsigned NOT NULL default '0',
  `maxpower5` int(10) unsigned NOT NULL default '0',
  `maxpower6` int(10) unsigned NOT NULL default '0',
  `maxpower7` int(10) unsigned NOT NULL default '0',
  `strength` int(10) unsigned NOT NULL default '0',
  `agility` int(10) unsigned NOT NULL default '0',
  `stamina` int(10) unsigned NOT NULL default '0',
  `intellect` int(10) unsigned NOT NULL default '0',
  `spirit` int(10) unsigned NOT NULL default '0',
  `armor` int(10) unsigned NOT NULL default '0',
  `resHoly` int(10) unsigned NOT NULL default '0',
  `resFire` int(10) unsigned NOT NULL default '0',
  `resNature` int(10) unsigned NOT NULL default '0',
  `resFrost` int(10) unsigned NOT NULL default '0',
  `resShadow` int(10) unsigned NOT NULL default '0',
  `resArcane` int(10) unsigned NOT NULL default '0',
  `blockPct` float unsigned NOT NULL default '0',
  `dodgePct` float unsigned NOT NULL default '0',
  `parryPct` float unsigned NOT NULL default '0',
  `critPct` float unsigned NOT NULL default '0',
  `rangedCritPct` float unsigned NOT NULL default '0',
  `spellCritPct` float unsigned NOT NULL default '0',
  `attackPower` int(10) unsigned NOT NULL default '0',
  `rangedAttackPower` int(10) unsigned NOT NULL default '0',
  `spellPower` int(10) unsigned NOT NULL default '0',
  `apmelee` int(11) NOT NULL,
  `ranged` int(11) NOT NULL,
  `blockrating` int(11) NOT NULL,
  `defrating` int(11) NOT NULL,
  `dodgerating` int(11) NOT NULL,
  `parryrating` int(11) NOT NULL,
  `resilience` int(11) NOT NULL,
  `manaregen` float NOT NULL,
  `melee_hitrating` int(11) NOT NULL,
  `melee_critrating` int(11) NOT NULL,
  `melee_hasterating` int(11) NOT NULL,
  `melee_mainmindmg` float NOT NULL,
  `melee_mainmaxdmg` float NOT NULL,
  `melee_offmindmg` float NOT NULL,
  `melee_offmaxdmg` float NOT NULL,
  `melee_maintime` float NOT NULL,
  `melee_offtime` float NOT NULL,
  `ranged_critrating` int(11) NOT NULL,
  `ranged_hasterating` int(11) NOT NULL,
  `ranged_hitrating` int(11) NOT NULL,
  `ranged_mindmg` float NOT NULL,
  `ranged_maxdmg` float NOT NULL,
  `ranged_attacktime` float NOT NULL,
  `spell_hitrating` int(11) NOT NULL,
  `spell_critrating` int(11) NOT NULL,
  `spell_hasterating` int(11) NOT NULL,
  `spell_bonusdmg` int(11) NOT NULL,
  `spell_bonusheal` int(11) NOT NULL,
  `spell_critproc` float NOT NULL,
  `account` int(11) unsigned NOT NULL default '0',
  `name` varchar(12) NOT NULL default '',
  `race` tinyint(3) unsigned NOT NULL default '0',
  `class` tinyint(3) unsigned NOT NULL default '0',
  `gender` tinyint(3) unsigned NOT NULL default '0',
  `level` tinyint(3) unsigned NOT NULL default '0',
  `map` int(11) unsigned NOT NULL default '0',
  `money` int(10) unsigned NOT NULL default '0',
  `totaltime` int(11) unsigned NOT NULL default '0',
  `online` int(10) unsigned NOT NULL default '0',
  `arenaPoints` int(10) unsigned NOT NULL default '0',
  `totalHonorPoints` int(10) unsigned NOT NULL default '0',
  `totalKills` int(10) unsigned NOT NULL default '0',
  `equipmentCache` longtext NOT NULL,
  `specCount` tinyint(3) unsigned NOT NULL default '1',
  `activeSpec` tinyint(3) unsigned NOT NULL default '0',
  `data` longtext NOT NULL,
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_stats
-- ----------------------------
INSERT INTO `character_stats` VALUES ('6', '266', '404', '1000', '0', '100', '0', '0', '0', '33', '29', '33', '31', '28', '533', '0', '0', '0', '0', '0', '0', '5', '7.86195', '0', '8.2913', '5.8913', '0', '82', '19', '0', '102', '39', '0', '0', '0', '0', '0', '3.10298', '0', '0', '0', '20.3', '26.3', '20.3', '26.3', '2100', '2100', '0', '0', '0', '6.57143', '7.57143', '2000', '0', '0', '0', '0', '0', '5.2451', '6', 'Franklin', '10', '2', '0', '12', '530', '8915', '41905', '1', '0', '0', '0', '6 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 522 266 404 0 0 100 0 0 0 266 404 1000 0 100 0 0 0 1078368065 0 0 0 0 0 0 0 0 0 0 0 0 0 12 1610 0 0 0 262152 2048 4194320 1157840896 1157234688 1157234688 1053038739 1069547520 15476 15476 0 1101162086 1104307814 0 0 1 0 0 0 0 0 1065353216 0 0 0 33 29 33 31 28 1065353216 0 0 0 0 0 0 0 0 0 533 0 0 0 0 0 0 1113325568 0 0 0 0 0 0 0 0 0 0 0 0 0 219 116 0 82 20 0 19 20 0 1087523109 1089620261 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 0 0 0 100795142 16777216 0 0 0 9147 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 24143 0 22953 0 2635 0 2646 0 2642 0 28148 0 23376 0 0 0 0 0 0 0 0 0 1421 0 2488 0 20841 0 0 0 0 0 0 0 0 0 0 0 0 0 0 622 1191182336 22916 1191182336 28432 1191182336 26229 1191182336 28141 1191182336 38710 1191182336 23867 1191182336 0 0 0 0 0 0 0 0 23656 1191182336 13503 1191182336 10296 1191182336 0 0 0 0 7855 1191182336 10279 1191182336 13504 1191182336 38711 1191182336 630 1191182336 10500 1191182336 25964 1191182336 37504 1191182336 37506 1191182336 26110 1191182336 25959 1191182336 37507 1191182336 37508 1191182336 26233 1191182336 23868 1191182336 39312 1191182336 39601 1191182336 39602 1191182336 39606 1191182336 26232 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 513 9800 43 3932220 0 55 3932220 0 95 3932220 0 109 19661100 0 65665 4915201 0 137 19661100 0 162 3932220 0 65721 4915201 0 413 65537 0 414 65537 0 415 65537 0 433 65537 0 594 65537 0 756 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 2 0 0 1084227584 1090229533 0 0 0 1090824491 1086096777 1086096777 0 1084741596 1084741596 1084741596 1084741596 1084741596 1084741596 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 3221225472 29889405 0 56 0 0 0 832 0 0 0 0 0 128 3221225472 3 122880 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4443 8915 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 1065353216 1065353216 1065353216 1065353216 1065353216 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 0 0 ', '1', '0', '6 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 522 266 404 0 0 100 0 0 0 266 404 1000 0 100 0 0 0 1078368065 0 0 0 0 0 0 0 0 0 0 0 0 0 12 1610 0 0 0 262152 2048 4194320 1157840896 1157234688 1157234688 1053038739 1069547520 15476 15476 0 1101162086 1104307814 0 0 1 0 0 0 0 0 1065353216 0 0 0 33 29 33 31 28 1065353216 0 0 0 0 0 0 0 0 0 533 0 0 0 0 0 0 1113325568 0 0 0 0 0 0 0 0 0 0 0 0 0 219 116 0 82 20 0 19 20 0 1087523109 1089620261 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 0 0 0 100795142 16777216 0 0 0 9147 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 24143 0 22953 0 2635 0 2646 0 2642 0 28148 0 23376 0 0 0 0 0 0 0 0 0 1421 0 2488 0 20841 0 0 0 0 0 0 0 0 0 0 0 0 0 0 622 1191182336 22916 1191182336 28432 1191182336 26229 1191182336 28141 1191182336 38710 1191182336 23867 1191182336 0 0 0 0 0 0 0 0 23656 1191182336 13503 1191182336 10296 1191182336 0 0 0 0 7855 1191182336 10279 1191182336 13504 1191182336 38711 1191182336 630 1191182336 10500 1191182336 25964 1191182336 37504 1191182336 37506 1191182336 26110 1191182336 25959 1191182336 37507 1191182336 37508 1191182336 26233 1191182336 23868 1191182336 39312 1191182336 39601 1191182336 39602 1191182336 39606 1191182336 26232 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 513 9800 43 3932220 0 55 3932220 0 95 3932220 0 109 19661100 0 65665 4915201 0 137 19661100 0 162 3932220 0 65721 4915201 0 413 65537 0 414 65537 0 415 65537 0 433 65537 0 594 65537 0 756 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 2 0 0 1084227584 1090229533 0 0 0 1090824491 1086096777 1086096777 0 1084741596 1084741596 1084741596 1084741596 1084741596 1084741596 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 3221225472 29889405 0 56 0 0 0 832 0 0 0 0 0 128 3221225472 3 122880 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4443 8915 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 1065353216 1065353216 1065353216 1065353216 1065353216 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 0 0 ');
INSERT INTO `character_stats` VALUES ('9', '2147483647', '0', '1000', '0', '100', '0', '8', '1000', '263', '115', '209', '28', '49', '3545', '0', '0', '0', '0', '0', '0', '0', '8.0996', '9.8025', '12.2663', '0.466253', '0', '683', '105', '0', '683', '105', '0', '0', '0', '65', '0', '0', '13', '43', '0', '113.357', '114.507', '113.357', '114.507', '2000', '2000', '43', '0', '13', '18.4', '19.55', '2000', '13', '43', '0', '0', '0', '3.13165', '5', 'Sora', '5', '6', '1', '59', '724', '23516', '11688', '1', '0', '0', '0', '9 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100730373 2143395150 0 0 0 100 0 0 580 2147483647 0 1000 0 100 0 8 1000 0 0 0 0 0 0 0 0 0 0 0 0 0 0 59 5 0 0 0 8 2048 4194304 1157234688 1157234688 1157234688 1053038739 1069547520 58 58 0 1122154203 1122304936 0 0 0 0 0 0 0 0 1065353216 0 0 0 263 115 209 28 49 1125122048 1108869120 1120403456 0 0 0 0 0 0 0 3545 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1619 0 683 0 0 105 0 0 1100165939 1100768870 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 0 0 0 135680 16777216 1 0 0 12593 1 0 0 0 12641 0 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 0 0 0 11033 1191182336 11051 1191182336 11035 1191182336 0 0 11039 1191182336 11045 1191182336 11047 1191182336 11049 1191182336 11041 1191182336 11043 1191182336 11053 1191182336 11063 1191182336 0 0 0 0 11037 1191182336 0 0 0 0 0 0 0 0 11055 1191182336 11057 1191182336 11059 1191182336 11061 1191182336 11065 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 26770 172000 43 19333415 0 44 19333415 0 55 19333415 0 95 19333415 0 109 19661100 0 118 19333415 0 262273 19661070 0 162 19333415 0 172 19333415 0 229 19333415 0 293 65537 0 413 65537 0 414 65537 0 415 65537 0 673 19661100 0 131834 9830550 0 770 65537 0 771 65537 0 772 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 2 0 0 0 1090623475 1092409098 0 0 1094992530 1055832239 1055832239 0 1078488318 1078488318 1078488318 1078488318 1078488318 1078488318 121 0 8388609 0 0 8388608 0 4194304 0 0 0 128 0 12582912 32768 0 1 0 872415236 4096 0 512 64 8 0 0 269746240 0 1572864 536870912 0 17039360 256 0 0 2147483648 0 134217728 0 0 0 0 0 0 66 0 0 0 524288 0 0 0 0 0 0 0 0 2147483648 4194304 0 0 512 32768 0 0 0 268435457 0 0 0 0 0 0 0 0 0 0 128 0 0 0 0 0 0 0 0 0 0 0 33554432 131072 0 0 0 0 0 0 0 0 0 0 4096 0 0 0 0 0 0 0 0 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 79142 23516 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 65 0 13 13 13 43 43 43 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1036831949 1036831949 1036831949 1036831949 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 15 0 ', '1', '0', '9 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100730373 2143395150 0 0 0 100 0 0 580 2147483647 0 1000 0 100 0 8 1000 0 0 0 0 0 0 0 0 0 0 0 0 0 0 59 5 0 0 0 8 2048 4194304 1157234688 1157234688 1157234688 1053038739 1069547520 58 58 0 1122154203 1122304936 0 0 0 0 0 0 0 0 1065353216 0 0 0 263 115 209 28 49 1125122048 1108869120 1120403456 0 0 0 0 0 0 0 3545 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1619 0 683 0 0 105 0 0 1100165939 1100768870 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 0 0 0 135680 16777216 1 0 0 12593 1 0 0 0 12641 0 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 0 0 0 11033 1191182336 11051 1191182336 11035 1191182336 0 0 11039 1191182336 11045 1191182336 11047 1191182336 11049 1191182336 11041 1191182336 11043 1191182336 11053 1191182336 11063 1191182336 0 0 0 0 11037 1191182336 0 0 0 0 0 0 0 0 11055 1191182336 11057 1191182336 11059 1191182336 11061 1191182336 11065 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 26770 172000 43 19333415 0 44 19333415 0 55 19333415 0 95 19333415 0 109 19661100 0 118 19333415 0 262273 19661070 0 162 19333415 0 172 19333415 0 229 19333415 0 293 65537 0 413 65537 0 414 65537 0 415 65537 0 673 19661100 0 131834 9830550 0 770 65537 0 771 65537 0 772 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 2 0 0 0 1090623475 1092409098 0 0 1094992530 1055832239 1055832239 0 1078488318 1078488318 1078488318 1078488318 1078488318 1078488318 121 0 8388609 0 0 8388608 0 4194304 0 0 0 128 0 12582912 32768 0 1 0 872415236 4096 0 512 64 8 0 0 269746240 0 1572864 536870912 0 17039360 256 0 0 2147483648 0 134217728 0 0 0 0 0 0 66 0 0 0 524288 0 0 0 0 0 0 0 0 2147483648 4194304 0 0 512 32768 0 0 0 268435457 0 0 0 0 0 0 0 0 0 0 128 0 0 0 0 0 0 0 0 0 0 0 33554432 131072 0 0 0 0 0 0 0 0 0 0 4096 0 0 0 0 0 0 0 0 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 79142 23516 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 65 0 13 13 13 43 43 43 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1036831949 1036831949 1036831949 1036831949 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 15 0 ');
INSERT INTO `character_stats` VALUES ('7', '3149', '0', '1000', '0', '100', '0', '8', '1000', '249', '113', '197', '33', '41', '3541', '0', '0', '0', '0', '0', '0', '0', '8.09132', '9.77071', '12.591', '1.79098', '0', '643', '103', '0', '643', '103', '0', '0', '0', '62', '0', '0', '13', '43', '0', '106.786', '107.936', '106.786', '107.936', '2000', '2000', '43', '0', '13', '18.0714', '19.2214', '2000', '13', '43', '0', '0', '0', '3.39818', '6', 'Emma', '10', '6', '1', '55', '609', '0', '2756', '1', '0', '0', '0', '7 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 1979807634 4046454883 0 0 0 100730378 3149 0 0 0 100 0 0 0 3149 0 1000 0 100 0 8 1000 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 1610 0 0 0 262152 2048 4194304 1157234688 1157234688 1157234688 1053038739 1069547520 15475 15475 0 1121292872 1121443605 1112753532 1112753532 1 0 0 0 0 0 1065353216 0 0 0 249 113 197 33 41 1125122048 1108869120 1120403456 0 0 0 0 0 0 0 3541 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1359 256 643 0 0 103 0 0 1099993673 1100596604 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 2 0 0 34343432 16777217 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 0 0 0 9840 1191182336 368 1191182336 352 1191182336 0 0 356 1191182336 362 1191182336 364 1191182336 9856 1191182336 358 1191182336 9850 1191182336 9860 1191182336 9870 1191182336 0 0 0 0 9844 1191182336 0 0 0 0 0 0 0 0 372 1191182336 9864 1191182336 376 1191182336 378 1191182336 382 1191182336 9874 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 560 148200 43 17694990 0 44 17694990 0 55 17694990 0 95 17694990 0 98 19661100 0 118 18022401 0 262273 19661070 0 162 17694990 0 172 17694990 0 229 17694990 0 293 65537 0 413 65537 0 414 65537 0 415 65537 0 131834 9830550 0 770 65537 0 771 65537 0 772 65537 0 109 19661100 0 137 19661100 0 756 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 0 0 0 1090614800 1092375760 0 0 1095333028 1071988410 1071988410 0 1079606200 1079606200 1079606200 1079606200 1079606200 1079606200 114 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 111150 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 62 0 13 13 13 43 43 43 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1036831949 1036831949 1036831949 1036831949 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 15 0 ', '1', '0', '7 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 1979807634 4046454883 0 0 0 100730378 3149 0 0 0 100 0 0 0 3149 0 1000 0 100 0 8 1000 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 1610 0 0 0 262152 2048 4194304 1157234688 1157234688 1157234688 1053038739 1069547520 15475 15475 0 1121292872 1121443605 1112753532 1112753532 1 0 0 0 0 0 1065353216 0 0 0 249 113 197 33 41 1125122048 1108869120 1120403456 0 0 0 0 0 0 0 3541 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1359 256 643 0 0 103 0 0 1099993673 1100596604 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 2 0 0 34343432 16777217 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 0 0 0 9840 1191182336 368 1191182336 352 1191182336 0 0 356 1191182336 362 1191182336 364 1191182336 9856 1191182336 358 1191182336 9850 1191182336 9860 1191182336 9870 1191182336 0 0 0 0 9844 1191182336 0 0 0 0 0 0 0 0 372 1191182336 9864 1191182336 376 1191182336 378 1191182336 382 1191182336 9874 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 560 148200 43 17694990 0 44 17694990 0 55 17694990 0 95 17694990 0 98 19661100 0 118 18022401 0 262273 19661070 0 162 17694990 0 172 17694990 0 229 17694990 0 293 65537 0 413 65537 0 414 65537 0 415 65537 0 131834 9830550 0 770 65537 0 771 65537 0 772 65537 0 109 19661100 0 137 19661100 0 756 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 0 0 0 1090614800 1092375760 0 0 1095333028 1071988410 1071988410 0 1079606200 1079606200 1079606200 1079606200 1079606200 1079606200 114 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 111150 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 62 0 13 13 13 43 43 43 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1036831949 1036831949 1036831949 1036831949 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 15 0 ');

-- ----------------------------
-- Table structure for `character_talent`
-- ----------------------------
DROP TABLE IF EXISTS `character_talent`;
CREATE TABLE `character_talent` (
  `guid` int(11) unsigned NOT NULL,
  `talent_id` int(11) unsigned NOT NULL,
  `current_rank` tinyint(3) unsigned NOT NULL default '0',
  `spec` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`talent_id`,`spec`),
  KEY `guid_key` (`guid`),
  KEY `talent_key` (`talent_id`),
  KEY `spec_key` (`spec`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_talent
-- ----------------------------
INSERT INTO `character_talent` VALUES ('9', '1945', '0', '0');
INSERT INTO `character_talent` VALUES ('9', '2017', '0', '0');
INSERT INTO `character_talent` VALUES ('6', '1403', '0', '0');
INSERT INTO `character_talent` VALUES ('6', '1442', '0', '0');
INSERT INTO `character_talent` VALUES ('9', '1939', '0', '0');

-- ----------------------------
-- Table structure for `character_ticket`
-- ----------------------------
DROP TABLE IF EXISTS `character_ticket`;
CREATE TABLE `character_ticket` (
  `ticket_id` int(11) unsigned NOT NULL auto_increment,
  `guid` int(11) unsigned NOT NULL default '0',
  `ticket_text` text,
  `response_text` text,
  `ticket_lastchange` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`ticket_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_ticket
-- ----------------------------

-- ----------------------------
-- Table structure for `character_tutorial`
-- ----------------------------
DROP TABLE IF EXISTS `character_tutorial`;
CREATE TABLE `character_tutorial` (
  `account` bigint(20) unsigned NOT NULL auto_increment COMMENT 'Account Identifier',
  `tut0` int(11) unsigned NOT NULL default '0',
  `tut1` int(11) unsigned NOT NULL default '0',
  `tut2` int(11) unsigned NOT NULL default '0',
  `tut3` int(11) unsigned NOT NULL default '0',
  `tut4` int(11) unsigned NOT NULL default '0',
  `tut5` int(11) unsigned NOT NULL default '0',
  `tut6` int(11) unsigned NOT NULL default '0',
  `tut7` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`account`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_tutorial
-- ----------------------------
INSERT INTO `character_tutorial` VALUES ('5', '4294950903', '133564151', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_tutorial` VALUES ('6', '4193828855', '130026151', '0', '0', '0', '0', '0', '0');

-- ----------------------------
-- Table structure for `characters`
-- ----------------------------
DROP TABLE IF EXISTS `characters`;
CREATE TABLE `characters` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `account` int(11) unsigned NOT NULL default '0' COMMENT 'Account Identifier',
  `data` longtext NOT NULL,
  `name` varchar(12) NOT NULL default '',
  `race` tinyint(3) unsigned NOT NULL default '0',
  `class` tinyint(3) unsigned NOT NULL default '0',
  `gender` tinyint(3) unsigned NOT NULL default '0',
  `level` tinyint(3) unsigned NOT NULL default '0',
  `xp` int(10) unsigned NOT NULL default '0',
  `money` int(10) unsigned NOT NULL default '0',
  `playerBytes` int(10) unsigned NOT NULL default '0',
  `playerBytes2` int(10) unsigned NOT NULL default '0',
  `playerFlags` int(10) unsigned NOT NULL default '0',
  `position_x` float NOT NULL default '0',
  `position_y` float NOT NULL default '0',
  `position_z` float NOT NULL default '0',
  `map` int(11) unsigned NOT NULL default '0' COMMENT 'Map Identifier',
  `dungeon_difficulty` tinyint(1) unsigned NOT NULL default '0',
  `orientation` float NOT NULL default '0',
  `taximask` longtext,
  `online` tinyint(3) unsigned NOT NULL default '0',
  `cinematic` tinyint(3) unsigned NOT NULL default '0',
  `totaltime` int(11) unsigned NOT NULL default '0',
  `leveltime` int(11) unsigned NOT NULL default '0',
  `logout_time` bigint(20) unsigned NOT NULL default '0',
  `is_logout_resting` tinyint(3) unsigned NOT NULL default '0',
  `rest_bonus` float NOT NULL default '0',
  `resettalents_cost` int(11) unsigned NOT NULL default '0',
  `resettalents_time` bigint(20) unsigned NOT NULL default '0',
  `trans_x` float NOT NULL default '0',
  `trans_y` float NOT NULL default '0',
  `trans_z` float NOT NULL default '0',
  `trans_o` float NOT NULL default '0',
  `transguid` bigint(20) unsigned NOT NULL default '0',
  `extra_flags` int(11) unsigned NOT NULL default '0',
  `stable_slots` tinyint(1) unsigned NOT NULL default '0',
  `at_login` int(11) unsigned NOT NULL default '0',
  `zone` int(11) unsigned NOT NULL default '0',
  `death_expire_time` bigint(20) unsigned NOT NULL default '0',
  `taxi_path` text,
  `arenaPoints` int(10) unsigned NOT NULL default '0',
  `totalHonorPoints` int(10) unsigned NOT NULL default '0',
  `todayHonorPoints` int(10) unsigned NOT NULL default '0',
  `yesterdayHonorPoints` int(10) unsigned NOT NULL default '0',
  `totalKills` int(10) unsigned NOT NULL default '0',
  `todayKills` smallint(5) unsigned NOT NULL default '0',
  `yesterdayKills` smallint(5) unsigned NOT NULL default '0',
  `chosenTitle` int(10) unsigned NOT NULL default '0',
  `knownCurrencies` bigint(20) unsigned NOT NULL default '0',
  `watchedFaction` int(10) unsigned NOT NULL default '0',
  `drunk` smallint(5) unsigned NOT NULL default '0',
  `health` int(10) unsigned NOT NULL default '0',
  `power1` int(10) unsigned NOT NULL default '0',
  `power2` int(10) unsigned NOT NULL default '0',
  `power3` int(10) unsigned NOT NULL default '0',
  `power4` int(10) unsigned NOT NULL default '0',
  `power5` int(10) unsigned NOT NULL default '0',
  `power6` int(10) unsigned NOT NULL default '0',
  `power7` int(10) unsigned NOT NULL default '0',
  `specCount` tinyint(3) unsigned NOT NULL default '1',
  `activeSpec` tinyint(3) unsigned NOT NULL default '0',
  `exploredZones` longtext,
  `equipmentCache` longtext,
  `ammoId` int(10) unsigned NOT NULL default '0',
  `knownTitles` longtext,
  `actionBars` tinyint(3) unsigned NOT NULL default '0',
  `deleteInfos_Account` int(11) unsigned default NULL,
  `deleteInfos_Name` varchar(12) default NULL,
  `deleteDate` bigint(20) default NULL,
  PRIMARY KEY  (`guid`),
  KEY `idx_account` (`account`),
  KEY `idx_online` (`online`),
  KEY `idx_name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of characters
-- ----------------------------
INSERT INTO `characters` VALUES ('9', '5', '9 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100730373 2143395150 0 0 0 100 0 0 580 2147483647 0 1000 0 100 0 8 1000 0 0 0 0 0 0 0 0 0 0 0 0 0 0 59 5 0 0 0 8 2048 4194304 1157234688 1157234688 1157234688 1053038739 1069547520 58 58 0 1122154203 1122304936 0 0 0 0 0 0 0 0 1065353216 0 0 0 263 115 209 28 49 1125122048 1108869120 1120403456 0 0 0 0 0 0 0 3545 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1619 0 683 0 0 105 0 0 1100165939 1100768870 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 0 0 0 135680 16777216 1 0 0 12593 1 0 0 0 12641 0 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 0 0 0 11033 1191182336 11051 1191182336 11035 1191182336 0 0 11039 1191182336 11045 1191182336 11047 1191182336 11049 1191182336 11041 1191182336 11043 1191182336 11053 1191182336 11063 1191182336 0 0 0 0 11037 1191182336 0 0 0 0 0 0 0 0 11055 1191182336 11057 1191182336 11059 1191182336 11061 1191182336 11065 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 26770 172000 43 19333415 0 44 19333415 0 55 19333415 0 95 19333415 0 109 19661100 0 118 19333415 0 262273 19661070 0 162 19333415 0 172 19333415 0 229 19333415 0 293 65537 0 413 65537 0 414 65537 0 415 65537 0 673 19661100 0 131834 9830550 0 770 65537 0 771 65537 0 772 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 2 0 0 0 1090623475 1092409098 0 0 1094992530 1055832239 1055832239 0 1078488318 1078488318 1078488318 1078488318 1078488318 1078488318 121 0 8388609 0 0 8388608 0 4194304 0 0 0 128 0 12582912 32768 0 1 0 872415236 4096 0 512 64 8 0 0 269746240 0 1572864 536870912 0 17039360 256 0 0 2147483648 0 134217728 0 0 0 0 0 0 66 0 0 0 524288 0 0 0 0 0 0 0 0 2147483648 4194304 0 0 512 32768 0 0 0 268435457 0 0 0 0 0 0 0 0 0 0 128 0 0 0 0 0 0 0 0 0 0 0 33554432 131072 0 0 0 0 0 0 0 0 0 0 4096 0 0 0 0 0 0 0 0 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 79142 23516 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 65 0 13 13 13 43 43 43 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1036831949 1036831949 1036831949 1036831949 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 15 0 ', 'Sora', '5', '6', '1', '59', '26770', '23516', '135680', '16777216', '0', '3269', '515.725', '87.2235', '724', '0', '4.27212', '4294967295 4093640703 830406655 4 33570816 1310944 3250593812 73752 896 67111952 2281701376 4190109713 1049856 12582912 ', '0', '1', '11688', '1546', '1293326995', '0', '79142.1', '0', '0', '0', '0', '0', '0', '0', '2', '0', '0', '0', '1292576540', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '4294967295', '0', '2143395150', '0', '0', '0', '100', '0', '0', '580', '1', '0', '8388609 0 0 8388608 0 4194304 0 0 0 128 0 12582912 32768 0 1 0 872415236 4096 0 512 64 8 0 0 269746240 0 1572864 536870912 0 17039360 256 0 0 2147483648 0 134217728 0 0 0 0 0 0 66 0 0 0 524288 0 0 0 0 0 0 0 0 2147483648 4194304 0 0 512 32768 0 0 0 268435457 0 0 0 0 0 0 0 0 0 0 128 0 0 0 0 0 0 0 0 0 0 0 33554432 131072 0 0 0 0 0 0 0 0 0 0 4096 0 0 0 0 0 0 0 0 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 ', '0', '0 0 0 0 0 0 ', '0', null, null, null);
INSERT INTO `characters` VALUES ('6', '6', '6 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 522 266 404 0 0 100 0 0 0 266 404 1000 0 100 0 0 0 1078368065 0 0 0 0 0 0 0 0 0 0 0 0 0 12 1610 0 0 0 262152 2048 4194320 1157840896 1157234688 1157234688 1053038739 1069547520 15476 15476 0 1101162086 1104307814 0 0 1 0 0 0 0 0 1065353216 0 0 0 33 29 33 31 28 1065353216 0 0 0 0 0 0 0 0 0 533 0 0 0 0 0 0 1113325568 0 0 0 0 0 0 0 0 0 0 0 0 0 219 116 0 82 20 0 19 20 0 1087523109 1089620261 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 0 0 0 100795142 16777216 0 0 0 9147 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 24143 0 22953 0 2635 0 2646 0 2642 0 28148 0 23376 0 0 0 0 0 0 0 0 0 1421 0 2488 0 20841 0 0 0 0 0 0 0 0 0 0 0 0 0 0 622 1191182336 22916 1191182336 28432 1191182336 26229 1191182336 28141 1191182336 38710 1191182336 23867 1191182336 0 0 0 0 0 0 0 0 23656 1191182336 13503 1191182336 10296 1191182336 0 0 0 0 7855 1191182336 10279 1191182336 13504 1191182336 38711 1191182336 630 1191182336 10500 1191182336 25964 1191182336 37504 1191182336 37506 1191182336 26110 1191182336 25959 1191182336 37507 1191182336 37508 1191182336 26233 1191182336 23868 1191182336 39312 1191182336 39601 1191182336 39602 1191182336 39606 1191182336 26232 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 513 9800 43 3932220 0 55 3932220 0 95 3932220 0 109 19661100 0 65665 4915201 0 137 19661100 0 162 3932220 0 65721 4915201 0 413 65537 0 414 65537 0 415 65537 0 433 65537 0 594 65537 0 756 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 2 0 0 1084227584 1090229533 0 0 0 1090824491 1086096777 1086096777 0 1084741596 1084741596 1084741596 1084741596 1084741596 1084741596 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 3221225472 29889405 0 56 0 0 0 832 0 0 0 0 0 128 3221225472 3 122880 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4443 8915 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 1065353216 1065353216 1065353216 1065353216 1065353216 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 0 0 ', 'Franklin', '10', '2', '0', '12', '513', '8915', '100795142', '16777216', '0', '8039.86', '-6915.24', '59.3757', '530', '0', '2.40112', '0 0 131072 4 0 0 0 0 0 0 0 0 0 0 ', '0', '1', '41905', '631', '1293996958', '0', '4443.37', '0', '0', '0', '0', '0', '0', '0', '4', '0', '0', '3430', '1293883513', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '4294967295', '0', '266', '404', '0', '0', '100', '0', '0', '0', '1', '0', '0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 3221225472 29889405 0 56 0 0 0 832 0 0 0 0 0 128 3221225472 3 122880 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '0 0 0 0 0 0 24143 0 22953 0 2635 0 2646 0 2642 0 28148 0 23376 0 0 0 0 0 0 0 0 0 1421 0 2488 0 20841 0 0 0 0 0 ', '0', '0 0 0 0 0 0 ', '0', null, null, null);
INSERT INTO `characters` VALUES ('2', '5', '', 'Isellyoubuy', '7', '4', '1', '5', '85', '0', '100795140', '16777216', '0', '-6437.93', '-287.903', '3.9304', '1', '0', '1.95643', '32 0 0 8 0 0 0 0 0 0 0 0 0 0 ', '0', '1', '252', '252', '1290821047', '0', '480.587', '0', '0', '0', '0', '0', '0', '0', '2', '0', '0', '1377', '1290503813', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '4294967295', '0', '113', '0', '0', '0', '100', '0', '0', '0', '1', '0', '0 0 0 0 0 0 1048576 0 0 0 0 4194304 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 131072 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '0 0 0 0 0 0 49 0 56 0 0 0 48 0 55 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 0 0 0 28979 0 0 0 ', '0', '0 0 0 0 0 0 ', '0', null, null, null);
INSERT INTO `characters` VALUES ('7', '6', '7 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 1979807634 4046454883 0 0 0 100730378 3149 0 0 0 100 0 0 0 3149 0 1000 0 100 0 8 1000 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 1610 0 0 0 262152 2048 4194304 1157234688 1157234688 1157234688 1053038739 1069547520 15475 15475 0 1121292872 1121443605 1112753532 1112753532 1 0 0 0 0 0 1065353216 0 0 0 249 113 197 33 41 1125122048 1108869120 1120403456 0 0 0 0 0 0 0 3541 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1359 256 643 0 0 103 0 0 1099993673 1100596604 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 2 0 0 34343432 16777217 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 0 0 0 9840 1191182336 368 1191182336 352 1191182336 0 0 356 1191182336 362 1191182336 364 1191182336 9856 1191182336 358 1191182336 9850 1191182336 9860 1191182336 9870 1191182336 0 0 0 0 9844 1191182336 0 0 0 0 0 0 0 0 372 1191182336 9864 1191182336 376 1191182336 378 1191182336 382 1191182336 9874 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 560 148200 43 17694990 0 44 17694990 0 55 17694990 0 95 17694990 0 98 19661100 0 118 18022401 0 262273 19661070 0 162 17694990 0 172 17694990 0 229 17694990 0 293 65537 0 413 65537 0 414 65537 0 415 65537 0 131834 9830550 0 770 65537 0 771 65537 0 772 65537 0 109 19661100 0 137 19661100 0 756 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 0 0 0 1090614800 1092375760 0 0 1095333028 1071988410 1071988410 0 1079606200 1079606200 1079606200 1079606200 1079606200 1079606200 114 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 111150 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 62 0 13 13 13 43 43 43 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1036831949 1036831949 1036831949 1036831949 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 15 0 ', 'Emma', '10', '6', '1', '55', '560', '0', '34343432', '16777217', '2', '2366.5', '-5656.04', '426.096', '609', '0', '0.578849', '4294967295 4093640703 830406655 4 33570816 1310944 3250593812 73752 896 67111952 2281701376 4190109713 1049856 12582912 ', '0', '1', '2756', '2756', '1293599229', '0', '111150', '0', '0', '0', '0', '0', '0', '0', '4', '0', '0', '4298', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '4294967295', '0', '3149', '0', '0', '0', '100', '0', '0', '0', '1', '0', '0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 ', '0', '0 0 0 0 0 0 ', '0', null, null, null);

-- ----------------------------
-- Table structure for `corpse`
-- ----------------------------
DROP TABLE IF EXISTS `corpse`;
CREATE TABLE `corpse` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `player` int(11) unsigned NOT NULL default '0' COMMENT 'Character Global Unique Identifier',
  `position_x` float NOT NULL default '0',
  `position_y` float NOT NULL default '0',
  `position_z` float NOT NULL default '0',
  `orientation` float NOT NULL default '0',
  `map` int(11) unsigned NOT NULL default '0' COMMENT 'Map Identifier',
  `phaseMask` smallint(5) unsigned NOT NULL default '1',
  `time` bigint(20) unsigned NOT NULL default '0',
  `corpse_type` tinyint(3) unsigned NOT NULL default '0',
  `instance` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`),
  KEY `idx_type` (`corpse_type`),
  KEY `instance` (`instance`),
  KEY `Idx_player` (`player`),
  KEY `Idx_time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Death System';

-- ----------------------------
-- Records of corpse
-- ----------------------------

-- ----------------------------
-- Table structure for `creature_respawn`
-- ----------------------------
DROP TABLE IF EXISTS `creature_respawn`;
CREATE TABLE `creature_respawn` (
  `guid` int(10) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `respawntime` bigint(20) NOT NULL default '0',
  `instance` mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Grid Loading System';

-- ----------------------------
-- Records of creature_respawn
-- ----------------------------

-- ----------------------------
-- Table structure for `gameobject_respawn`
-- ----------------------------
DROP TABLE IF EXISTS `gameobject_respawn`;
CREATE TABLE `gameobject_respawn` (
  `guid` int(10) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `respawntime` bigint(20) NOT NULL default '0',
  `instance` mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Grid Loading System';

-- ----------------------------
-- Records of gameobject_respawn
-- ----------------------------

-- ----------------------------
-- Table structure for `group_instance`
-- ----------------------------
DROP TABLE IF EXISTS `group_instance`;
CREATE TABLE `group_instance` (
  `leaderGuid` int(11) unsigned NOT NULL default '0',
  `instance` int(11) unsigned NOT NULL default '0',
  `permanent` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`leaderGuid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of group_instance
-- ----------------------------

-- ----------------------------
-- Table structure for `group_member`
-- ----------------------------
DROP TABLE IF EXISTS `group_member`;
CREATE TABLE `group_member` (
  `groupId` int(11) unsigned NOT NULL,
  `memberGuid` int(11) unsigned NOT NULL,
  `assistant` tinyint(1) unsigned NOT NULL,
  `subgroup` smallint(6) unsigned NOT NULL,
  PRIMARY KEY  (`groupId`,`memberGuid`),
  KEY `Idx_memberGuid` (`memberGuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Groups';

-- ----------------------------
-- Records of group_member
-- ----------------------------

-- ----------------------------
-- Table structure for `groups`
-- ----------------------------
DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `groupId` int(11) unsigned NOT NULL,
  `leaderGuid` int(11) unsigned NOT NULL,
  `mainTank` int(11) unsigned NOT NULL,
  `mainAssistant` int(11) unsigned NOT NULL,
  `lootMethod` tinyint(4) unsigned NOT NULL,
  `looterGuid` int(11) unsigned NOT NULL,
  `lootThreshold` tinyint(4) unsigned NOT NULL,
  `icon1` int(11) unsigned NOT NULL,
  `icon2` int(11) unsigned NOT NULL,
  `icon3` int(11) unsigned NOT NULL,
  `icon4` int(11) unsigned NOT NULL,
  `icon5` int(11) unsigned NOT NULL,
  `icon6` int(11) unsigned NOT NULL,
  `icon7` int(11) unsigned NOT NULL,
  `icon8` int(11) unsigned NOT NULL,
  `groupType` tinyint(1) unsigned NOT NULL,
  `difficulty` tinyint(3) unsigned NOT NULL default '0',
  `raiddifficulty` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`groupId`),
  UNIQUE KEY `leaderGuid` (`leaderGuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Groups';

-- ----------------------------
-- Records of groups
-- ----------------------------

-- ----------------------------
-- Table structure for `guild`
-- ----------------------------
DROP TABLE IF EXISTS `guild`;
CREATE TABLE `guild` (
  `guildid` int(6) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `leaderguid` int(6) unsigned NOT NULL default '0',
  `EmblemStyle` int(5) NOT NULL default '0',
  `EmblemColor` int(5) NOT NULL default '0',
  `BorderStyle` int(5) NOT NULL default '0',
  `BorderColor` int(5) NOT NULL default '0',
  `BackgroundColor` int(5) NOT NULL default '0',
  `info` text NOT NULL,
  `motd` varchar(255) NOT NULL default '',
  `createdate` bigint(20) NOT NULL default '0',
  `BankMoney` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`guildid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';

-- ----------------------------
-- Records of guild
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_bank_eventlog`
-- ----------------------------
DROP TABLE IF EXISTS `guild_bank_eventlog`;
CREATE TABLE `guild_bank_eventlog` (
  `guildid` int(11) unsigned NOT NULL default '0' COMMENT 'Guild Identificator',
  `LogGuid` int(11) unsigned NOT NULL default '0' COMMENT 'Log record identificator - auxiliary column',
  `TabId` tinyint(3) unsigned NOT NULL default '0' COMMENT 'Guild bank TabId',
  `EventType` tinyint(3) unsigned NOT NULL default '0' COMMENT 'Event type',
  `PlayerGuid` int(11) unsigned NOT NULL default '0',
  `ItemOrMoney` int(11) unsigned NOT NULL default '0',
  `ItemStackCount` tinyint(3) unsigned NOT NULL default '0',
  `DestTabId` tinyint(1) unsigned NOT NULL default '0' COMMENT 'Destination Tab Id',
  `TimeStamp` bigint(20) unsigned NOT NULL default '0' COMMENT 'Event UNIX time',
  PRIMARY KEY  (`guildid`,`LogGuid`,`TabId`),
  KEY `guildid_key` (`guildid`),
  KEY `Idx_PlayerGuid` (`PlayerGuid`),
  KEY `Idx_LogGuid` (`LogGuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_bank_eventlog
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_bank_item`
-- ----------------------------
DROP TABLE IF EXISTS `guild_bank_item`;
CREATE TABLE `guild_bank_item` (
  `guildid` int(11) unsigned NOT NULL default '0',
  `TabId` tinyint(1) unsigned NOT NULL default '0',
  `SlotId` tinyint(3) unsigned NOT NULL default '0',
  `item_guid` int(11) unsigned NOT NULL default '0',
  `item_entry` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guildid`,`TabId`,`SlotId`),
  KEY `guildid_key` (`guildid`),
  KEY `Idx_item_guid` (`item_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_bank_item
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_bank_right`
-- ----------------------------
DROP TABLE IF EXISTS `guild_bank_right`;
CREATE TABLE `guild_bank_right` (
  `guildid` int(11) unsigned NOT NULL default '0',
  `TabId` tinyint(1) unsigned NOT NULL default '0',
  `rid` int(11) unsigned NOT NULL default '0',
  `gbright` tinyint(3) unsigned NOT NULL default '0',
  `SlotPerDay` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guildid`,`TabId`,`rid`),
  KEY `guildid_key` (`guildid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_bank_right
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_bank_tab`
-- ----------------------------
DROP TABLE IF EXISTS `guild_bank_tab`;
CREATE TABLE `guild_bank_tab` (
  `guildid` int(11) unsigned NOT NULL default '0',
  `TabId` tinyint(1) unsigned NOT NULL default '0',
  `TabName` varchar(100) NOT NULL default '',
  `TabIcon` varchar(100) NOT NULL default '',
  `TabText` text,
  PRIMARY KEY  (`guildid`,`TabId`),
  KEY `guildid_key` (`guildid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_bank_tab
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_eventlog`
-- ----------------------------
DROP TABLE IF EXISTS `guild_eventlog`;
CREATE TABLE `guild_eventlog` (
  `guildid` int(11) NOT NULL COMMENT 'Guild Identificator',
  `LogGuid` int(11) NOT NULL COMMENT 'Log record identificator - auxiliary column',
  `EventType` tinyint(1) NOT NULL COMMENT 'Event type',
  `PlayerGuid1` int(11) NOT NULL COMMENT 'Player 1',
  `PlayerGuid2` int(11) NOT NULL COMMENT 'Player 2',
  `NewRank` tinyint(2) NOT NULL COMMENT 'New rank(in case promotion/demotion)',
  `TimeStamp` bigint(20) NOT NULL COMMENT 'Event UNIX time',
  PRIMARY KEY  (`guildid`,`LogGuid`),
  KEY `Idx_PlayerGuid1` (`PlayerGuid1`),
  KEY `Idx_PlayerGuid2` (`PlayerGuid2`),
  KEY `Idx_LogGuid` (`LogGuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Guild Eventlog';

-- ----------------------------
-- Records of guild_eventlog
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_member`
-- ----------------------------
DROP TABLE IF EXISTS `guild_member`;
CREATE TABLE `guild_member` (
  `guildid` int(6) unsigned NOT NULL default '0',
  `guid` int(11) unsigned NOT NULL default '0',
  `rank` tinyint(2) unsigned NOT NULL default '0',
  `pnote` varchar(255) NOT NULL default '',
  `offnote` varchar(255) NOT NULL default '',
  `BankResetTimeMoney` int(11) unsigned NOT NULL default '0',
  `BankRemMoney` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab0` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab0` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab1` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab1` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab2` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab2` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab3` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab3` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab4` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab4` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab5` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab5` int(11) unsigned NOT NULL default '0',
  UNIQUE KEY `guid_key` (`guid`),
  KEY `guildid_key` (`guildid`),
  KEY `guildid_rank_key` (`guildid`,`rank`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Guild System';

-- ----------------------------
-- Records of guild_member
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_rank`
-- ----------------------------
DROP TABLE IF EXISTS `guild_rank`;
CREATE TABLE `guild_rank` (
  `guildid` int(6) unsigned NOT NULL default '0',
  `rid` int(11) unsigned NOT NULL,
  `rname` varchar(255) NOT NULL default '',
  `rights` int(3) unsigned NOT NULL default '0',
  `BankMoneyPerDay` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guildid`,`rid`),
  KEY `Idx_rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';

-- ----------------------------
-- Records of guild_rank
-- ----------------------------

-- ----------------------------
-- Table structure for `instance`
-- ----------------------------
DROP TABLE IF EXISTS `instance`;
CREATE TABLE `instance` (
  `id` int(11) unsigned NOT NULL default '0',
  `map` int(11) unsigned NOT NULL default '0',
  `resettime` bigint(40) NOT NULL default '0',
  `difficulty` tinyint(1) unsigned NOT NULL default '0',
  `data` longtext,
  PRIMARY KEY  (`id`),
  KEY `map` (`map`),
  KEY `resettime` (`resettime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of instance
-- ----------------------------

-- ----------------------------
-- Table structure for `instance_reset`
-- ----------------------------
DROP TABLE IF EXISTS `instance_reset`;
CREATE TABLE `instance_reset` (
  `mapid` int(11) unsigned NOT NULL default '0',
  `difficulty` tinyint(1) unsigned NOT NULL default '0',
  `resettime` bigint(40) NOT NULL default '0',
  PRIMARY KEY  (`mapid`,`difficulty`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of instance_reset
-- ----------------------------
INSERT INTO `instance_reset` VALUES ('249', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('309', '0', '1294171200');
INSERT INTO `instance_reset` VALUES ('409', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('469', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('509', '0', '1294171200');
INSERT INTO `instance_reset` VALUES ('531', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('532', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('533', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('534', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('544', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('548', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('550', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('564', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('565', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('568', '0', '1294102800');
INSERT INTO `instance_reset` VALUES ('580', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('603', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('615', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('616', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('624', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('631', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('649', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('724', '0', '1294189200');
INSERT INTO `instance_reset` VALUES ('249', '1', '1294189200');
INSERT INTO `instance_reset` VALUES ('269', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('533', '1', '1294189200');
INSERT INTO `instance_reset` VALUES ('540', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('542', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('543', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('545', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('546', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('547', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('552', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('553', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('554', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('555', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('556', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('557', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('558', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('560', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('574', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('575', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('576', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('578', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('585', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('595', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('598', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('599', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('600', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('601', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('602', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('603', '1', '1294189200');
INSERT INTO `instance_reset` VALUES ('604', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('608', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('615', '1', '1294189200');
INSERT INTO `instance_reset` VALUES ('616', '1', '1294189200');
INSERT INTO `instance_reset` VALUES ('619', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('624', '1', '1294189200');
INSERT INTO `instance_reset` VALUES ('631', '1', '1294189200');
INSERT INTO `instance_reset` VALUES ('632', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('649', '1', '1294189200');
INSERT INTO `instance_reset` VALUES ('650', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('658', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('668', '1', '1294102800');
INSERT INTO `instance_reset` VALUES ('724', '1', '1294189200');
INSERT INTO `instance_reset` VALUES ('631', '2', '1294189200');
INSERT INTO `instance_reset` VALUES ('649', '2', '1294189200');
INSERT INTO `instance_reset` VALUES ('724', '2', '1294189200');
INSERT INTO `instance_reset` VALUES ('631', '3', '1294189200');
INSERT INTO `instance_reset` VALUES ('649', '3', '1294189200');
INSERT INTO `instance_reset` VALUES ('724', '3', '1294189200');

-- ----------------------------
-- Table structure for `item_instance`
-- ----------------------------
DROP TABLE IF EXISTS `item_instance`;
CREATE TABLE `item_instance` (
  `guid` int(11) unsigned NOT NULL default '0',
  `owner_guid` int(11) unsigned NOT NULL default '0',
  `data` longtext,
  `text` longtext,
  PRIMARY KEY  (`guid`),
  KEY `idx_owner_guid` (`owner_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Item System';

-- ----------------------------
-- Records of item_instance
-- ----------------------------
INSERT INTO `item_instance` VALUES ('11061', '9', '11061 1191182336 7 38145 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11059', '9', '11059 1191182336 7 38145 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11057', '9', '11057 1191182336 7 38145 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11055', '9', '11055 1191182336 7 38145 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11053', '9', '11053 1191182336 3 34658 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11051', '9', '11051 1191182336 3 34657 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11047', '9', '11047 1191182336 3 34656 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 77 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11049', '9', '11049 1191182336 3 34648 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11043', '9', '11043 1191182336 3 34649 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 36 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11045', '9', '11045 1191182336 3 34651 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 36 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11041', '9', '11041 1191182336 3 34653 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11037', '9', '11037 1191182336 3 34659 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11039', '9', '11039 1191182336 3 34650 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 104 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11035', '9', '11035 1191182336 3 34655 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 63 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11033', '9', '11033 1191182336 3 34652 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 63 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('36', '2', '36 1191182336 3 56 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 24 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38', '2', '38 1191182336 3 1395 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40', '2', '40 1191182336 3 6096 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('42', '2', '42 1191182336 3 55 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44', '2', '44 1191182336 3 35 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 17 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('46', '2', '46 1191182336 3 6948 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('13504', '6', '13504 1191182336 7 4496 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 28438 1191182336 28439 1191182336 28440 1191182336 28442 1191182336 28443 1191182336 28444 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('22916', '6', '22916 1191182336 3 22953 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('10279', '6', '10279 1191182336 7 4496 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 22761 1191182336 28431 1191182336 13501 1191182336 28435 1191182336 28436 1191182336 28437 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('362', '7', '362 1191182336 3 34651 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('366', '7', '366 1191182336 3 34648 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 54 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('368', '7', '368 1191182336 3 34657 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('352', '7', '352 1191182336 3 34655 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 68 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('630', '6', '630 1191182336 3 6948 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('622', '6', '622 1191182336 3 24143 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('370', '7', '370 1191182336 3 34658 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('350', '7', '350 1191182336 3 34652 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 69 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('380', '7', '380 1191182336 3 38147 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('382', '7', '382 1191182336 3 41751 1065353216 0 7 0 7 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('354', '7', '354 1191182336 3 34659 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('356', '7', '356 1191182336 3 34650 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('358', '7', '358 1191182336 3 34653 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 39 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('360', '7', '360 1191182336 3 34649 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 39 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('364', '7', '364 1191182336 3 34656 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('372', '7', '372 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('374', '7', '374 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('376', '7', '376 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('378', '7', '378 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('500', '2', '500 1191182336 3 49 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('502', '2', '502 1191182336 3 48 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 17 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('504', '2', '504 1191182336 3 47 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('506', '2', '506 1191182336 3 2092 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 0 0 ', '');
INSERT INTO `item_instance` VALUES ('508', '2', '508 1191182336 3 50055 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 0 0 ', '');
INSERT INTO `item_instance` VALUES ('510', '2', '510 1191182336 3 28979 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('512', '2', '512 1191182336 3 6948 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9874', '7', '9874 1191182336 3 40582 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9872', '7', '9872 1191182336 3 41751 1065353216 0 7 0 7 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9870', '7', '9870 1191182336 3 38147 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9868', '7', '9868 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9866', '7', '9866 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9864', '7', '9864 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9862', '7', '9862 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9860', '7', '9860 1191182336 3 34658 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9840', '7', '9840 1191182336 3 34652 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9842', '7', '9842 1191182336 3 34655 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9844', '7', '9844 1191182336 3 34659 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9846', '7', '9846 1191182336 3 34650 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9848', '7', '9848 1191182336 3 34653 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9850', '7', '9850 1191182336 3 34649 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9852', '7', '9852 1191182336 3 34651 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9854', '7', '9854 1191182336 3 34656 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9856', '7', '9856 1191182336 3 34648 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9858', '7', '9858 1191182336 3 34657 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('10296', '6', '10296 1191182336 3 20841 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('10500', '6', '10500 1191182336 3 159 1065353216 0 6 0 6 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('7855', '6', '7855 1191182336 7 20474 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 39607 1191182336 39609 1191182336 39612 1191182336 39613 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('23867', '6', '23867 1191182336 3 23376 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('13503', '6', '13503 1191182336 3 2488 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39636', '2', '39636 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39552', '2', '39552 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39635', '2', '39635 1191182336 3 31168 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 47 4294967251 135 135 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40485', '2', '40485 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39555', '2', '39555 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39634', '2', '39634 1191182336 3 14551 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39557', '2', '39557 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39633', '2', '39633 1191182336 3 1930 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39632', '2', '39632 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39631', '2', '39631 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39561', '2', '39561 1191182336 3 5755 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39562', '2', '39562 1191182336 3 24677 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 41 4294967260 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39630', '2', '39630 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39629', '2', '39629 1191182336 3 3844 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39628', '2', '39628 1191182336 3 25062 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 24 4294967258 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39566', '2', '39566 1191182336 3 3283 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('28442', '6', '28442 1191182336 3 1179 1065353216 0 6 0 13504 1191182336 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38710', '6', '38710 1191182336 3 28148 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38711', '6', '38711 1191182336 7 22571 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37504', '6', '37504 1191182336 3 118 1065353216 0 6 0 6 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('28432', '6', '28432 1191182336 3 2635 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('28141', '6', '28141 1191182336 3 2642 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40508', '2', '40508 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38579', '2', '38579 1191182336 3 28533 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 12 4294967286 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38580', '2', '38580 1191182336 3 25298 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 17 4294967290 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39792', '2', '39792 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38582', '2', '38582 1191182336 3 15968 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39791', '2', '39791 1191182336 3 36288 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 108 4294967284 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38585', '2', '38585 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38586', '2', '38586 1191182336 3 35654 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38587', '2', '38587 1191182336 3 44147 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38588', '2', '38588 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38589', '2', '38589 1191182336 3 14368 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39790', '2', '39790 1191182336 3 35979 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 56 4294967257 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38591', '2', '38591 1191182336 3 13035 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39789', '2', '39789 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38593', '2', '38593 1191182336 3 16651 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38594', '2', '38594 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38595', '2', '38595 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38596', '2', '38596 1191182336 3 31268 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2825 0 0 2803 0 0 2802 0 0 0 0 0 0 0 0 2 4294967236 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38597', '2', '38597 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39788', '2', '39788 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39787', '2', '39787 1191182336 3 34846 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38600', '2', '38600 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38601', '2', '38601 1191182336 3 44143 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38602', '2', '38602 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39786', '2', '39786 1191182336 3 36513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 104 4294967290 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38604', '2', '38604 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38605', '2', '38605 1191182336 3 16653 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39785', '2', '39785 1191182336 3 24836 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 31 4294967263 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('23868', '6', '23868 1191182336 7 22976 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39417', '2', '39417 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40205', '2', '40205 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40204', '2', '40204 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39420', '2', '39420 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40203', '2', '40203 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39422', '2', '39422 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39423', '2', '39423 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39424', '2', '39424 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39425', '2', '39425 1191182336 3 36045 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 101 4294967257 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40202', '2', '40202 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39427', '2', '39427 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40201', '2', '40201 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40200', '2', '40200 1191182336 3 36395 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2820 0 0 0 0 0 0 0 0 0 0 0 81 4294967262 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40199', '2', '40199 1191182336 3 2175 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39431', '2', '39431 1191182336 3 36379 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 75 4294967290 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39432', '2', '39432 1191182336 3 1440 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39433', '2', '39433 1191182336 3 36556 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 108 4294967257 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40198', '2', '40198 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39435', '2', '39435 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39436', '2', '39436 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40197', '2', '40197 1191182336 3 24824 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 40 4294967252 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40196', '2', '40196 1191182336 3 36149 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 97 4294967282 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40195', '2', '40195 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39440', '2', '39440 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40194', '2', '40194 1191182336 3 1955 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39443', '2', '39443 1191182336 3 24712 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 4294967275 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40193', '2', '40193 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40192', '2', '40192 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('23656', '6', '23656 1191182336 3 1421 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40167', '2', '40167 1191182336 3 3076 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37512', '2', '37512 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37511', '2', '37511 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37513', '2', '37513 1191182336 3 36041 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 72 4294967258 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37514', '2', '37514 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37515', '2', '37515 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37516', '2', '37516 1191182336 3 13876 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40166', '2', '40166 1191182336 3 2267 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40165', '2', '40165 1191182336 3 1462 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40164', '2', '40164 1191182336 3 5182 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37521', '2', '37521 1191182336 3 14901 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 351 0 0 352 0 0 0 0 0 0 1115 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40163', '2', '40163 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37523', '2', '37523 1191182336 3 14368 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40162', '2', '40162 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37525', '2', '37525 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37526', '2', '37526 1191182336 3 30736 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40558', '2', '40558 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40161', '2', '40161 1191182336 3 1355 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40557', '2', '40557 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40160', '2', '40160 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37531', '2', '37531 1191182336 3 2824 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37532', '2', '37532 1191182336 3 5760 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37533', '2', '37533 1191182336 3 13911 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37534', '2', '37534 1191182336 3 13884 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40159', '2', '40159 1191182336 3 727 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 71 0 0 0 0 0 0 0 0 0 15 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40158', '2', '40158 1191182336 3 5971 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40157', '2', '40157 1191182336 3 6333 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40156', '2', '40156 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37539', '2', '37539 1191182336 3 13907 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37540', '2', '37540 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40155', '2', '40155 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40154', '2', '40154 1191182336 3 22282 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37543', '2', '37543 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37544', '2', '37544 1191182336 3 36652 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 32 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40153', '2', '40153 1191182336 3 16648 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40152', '2', '40152 1191182336 3 36062 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 81 4294967281 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37547', '2', '37547 1191182336 3 20540 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40151', '2', '40151 1191182336 3 24685 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 42 4294967259 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37549', '2', '37549 1191182336 3 31228 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 40 4294967284 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37550', '2', '37550 1191182336 3 35580 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40150', '2', '40150 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40149', '2', '40149 1191182336 3 13879 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37553', '2', '37553 1191182336 3 2798 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40148', '2', '40148 1191182336 3 3018 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37555', '2', '37555 1191182336 3 2740 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40147', '2', '40147 1191182336 3 17964 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37558', '2', '37558 1191182336 3 28494 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2804 0 0 2813 0 0 0 0 0 0 0 0 41 4294967244 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37559', '2', '37559 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37560', '2', '37560 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37561', '2', '37561 1191182336 3 2057 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40146', '2', '40146 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37563', '2', '37563 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37564', '2', '37564 1191182336 3 16648 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40145', '2', '40145 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37566', '2', '37566 1191182336 3 2282 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40144', '2', '40144 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37568', '2', '37568 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40143', '2', '40143 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37570', '2', '37570 1191182336 3 9276 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37571', '2', '37571 1191182336 3 1265 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37572', '2', '37572 1191182336 3 2244 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37573', '2', '37573 1191182336 3 36499 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 45 4294967291 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40142', '2', '40142 1191182336 3 24780 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 29 4294967256 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37575', '2', '37575 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40141', '2', '40141 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37577', '2', '37577 1191182336 3 30741 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40140', '2', '40140 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37579', '2', '37579 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37580', '2', '37580 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40139', '2', '40139 1191182336 3 24833 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 31 4294967253 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37582', '2', '37582 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37583', '2', '37583 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40138', '2', '40138 1191182336 3 1213 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37585', '2', '37585 1191182336 3 873 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40137', '2', '40137 1191182336 3 25047 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 23 4294967258 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40136', '2', '40136 1191182336 3 39970 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40135', '2', '40135 1191182336 3 3340 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40556', '2', '40556 1191182336 3 14899 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 366 0 0 367 0 0 0 0 0 0 1209 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40555', '2', '40555 1191182336 3 14832 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40134', '2', '40134 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40133', '2', '40133 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37594', '2', '37594 1191182336 3 2244 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40132', '2', '40132 1191182336 3 20679 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37596', '2', '37596 1191182336 3 870 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37597', '2', '37597 1191182336 3 30738 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40131', '2', '40131 1191182336 3 36286 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 81 4294967280 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37599', '2', '37599 1191182336 3 2292 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40130', '2', '40130 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37601', '2', '37601 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40554', '2', '40554 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37603', '2', '37603 1191182336 3 36386 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 56 4294967287 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37604', '2', '37604 1191182336 3 2748 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37605', '2', '37605 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37606', '2', '37606 1191182336 3 18612 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40129', '2', '40129 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37608', '2', '37608 1191182336 3 37781 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37609', '2', '37609 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40128', '2', '40128 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37611', '2', '37611 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37612', '2', '37612 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40127', '2', '40127 1191182336 3 36485 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 45 4294967256 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40126', '2', '40126 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40125', '2', '40125 1191182336 3 32620 1065353216 0 2 0 2 0 0 0 0 0 157 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40124', '2', '40124 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40123', '2', '40123 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37618', '2', '37618 1191182336 3 13914 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40122', '2', '40122 1191182336 3 16647 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40553', '2', '40553 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40121', '2', '40121 1191182336 3 22642 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40120', '2', '40120 1191182336 3 11018 1065353216 0 2 0 2 0 0 0 0 0 68 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37623', '2', '37623 1191182336 3 2258 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37624', '2', '37624 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40119', '2', '40119 1191182336 3 20540 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37626', '2', '37626 1191182336 3 35665 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40118', '2', '40118 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37629', '2', '37629 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37630', '2', '37630 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40117', '2', '40117 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37632', '2', '37632 1191182336 3 24368 1065353216 0 2 0 2 0 0 0 0 0 117 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37634', '2', '37634 1191182336 3 6353 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37635', '2', '37635 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40116', '2', '40116 1191182336 3 6307 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37637', '2', '37637 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40115', '2', '40115 1191182336 3 13885 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37639', '2', '37639 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40114', '2', '40114 1191182336 3 36267 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 75 4294967285 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37641', '2', '37641 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40113', '2', '40113 1191182336 3 31165 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 44 4294967285 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40552', '2', '40552 1191182336 3 24715 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 30 4294967285 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40112', '2', '40112 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40111', '2', '40111 1191182336 3 31248 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 38 4294967284 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37646', '2', '37646 1191182336 3 9378 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40110', '2', '40110 1191182336 3 44686 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 3726 0 0 2824 0 0 0 0 0 0 0 0 87 4294967208 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40109', '2', '40109 1191182336 3 37117 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40108', '2', '40108 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40107', '2', '40107 1191182336 3 2194 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37651', '2', '37651 1191182336 3 23381 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37652', '2', '37652 1191182336 3 44157 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37653', '2', '37653 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37654', '2', '37654 1191182336 3 36399 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 108 4294967277 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37655', '2', '37655 1191182336 3 13908 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40106', '2', '40106 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40105', '2', '40105 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40104', '2', '40104 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37659', '2', '37659 1191182336 3 5423 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37660', '2', '37660 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40103', '2', '40103 1191182336 3 1717 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40102', '2', '40102 1191182336 3 31192 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 30 4294967260 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40551', '2', '40551 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40101', '2', '40101 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40550', '2', '40550 1191182336 3 30736 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40549', '2', '40549 1191182336 3 25250 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 16 4294967283 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40100', '2', '40100 1191182336 3 36390 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 78 4294967263 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40099', '2', '40099 1191182336 3 44677 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 116 4294967255 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37669', '2', '37669 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37670', '2', '37670 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40098', '2', '40098 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40548', '2', '40548 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40097', '2', '40097 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37675', '2', '37675 1191182336 3 31882 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37676', '2', '37676 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40096', '2', '40096 1191182336 3 13884 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37678', '2', '37678 1191182336 3 18295 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1352 0 0 0 0 0 0 0 0 0 1416 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40095', '2', '40095 1191182336 3 2066 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37680', '2', '37680 1191182336 3 22890 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37681', '2', '37681 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37682', '2', '37682 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37683', '2', '37683 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40094', '2', '40094 1191182336 3 6643 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37685', '2', '37685 1191182336 3 18711 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40093', '2', '40093 1191182336 3 25200 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 17 4294967255 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37687', '2', '37687 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37688', '2', '37688 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37689', '2', '37689 1191182336 3 24836 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 31 4294967291 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40092', '2', '40092 1191182336 3 31238 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 30 4294967263 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37691', '2', '37691 1191182336 3 1318 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40091', '2', '40091 1191182336 3 36430 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 60 4294967259 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37693', '2', '37693 1191182336 3 12546 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37694', '2', '37694 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40547', '2', '40547 1191182336 3 30724 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37696', '2', '37696 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40090', '2', '40090 1191182336 3 6147 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40089', '2', '40089 1191182336 3 24401 1065353216 0 2 0 2 0 0 0 0 0 74 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37699', '2', '37699 1191182336 3 7728 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37700', '2', '37700 1191182336 3 2749 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40088', '2', '40088 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40087', '2', '40087 1191182336 3 13882 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37703', '2', '37703 1191182336 3 24938 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 4294967270 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37704', '2', '37704 1191182336 3 22529 1065353216 0 2 0 2 0 0 0 0 0 210 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37705', '2', '37705 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37706', '2', '37706 1191182336 3 2080 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 76 0 0 84 0 0 0 0 0 0 505 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40086', '2', '40086 1191182336 3 36679 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 42 4294967252 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40085', '2', '40085 1191182336 3 36413 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 54 4294967282 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40546', '2', '40546 1191182336 3 36694 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 43 4294967252 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40443', '2', '40443 1191182336 3 36528 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 46 4294967286 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40442', '2', '40442 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40441', '2', '40441 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40440', '2', '40440 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37714', '2', '37714 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40439', '2', '40439 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37716', '2', '37716 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40607', '2', '40607 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37718', '2', '37718 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40438', '2', '40438 1191182336 3 28496 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2825 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 34 4294967239 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37720', '2', '37720 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40437', '2', '40437 1191182336 3 25004 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 39 4294967255 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37722', '2', '37722 1191182336 3 1728 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40436', '2', '40436 1191182336 3 8245 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40435', '2', '40435 1191182336 3 36053 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2817 0 0 0 0 0 0 0 0 0 0 0 104 4294967265 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40434', '2', '40434 1191182336 3 10329 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37726', '2', '37726 1191182336 3 8364 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40433', '2', '40433 1191182336 3 17963 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40606', '2', '40606 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37729', '2', '37729 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37730', '2', '37730 1191182336 3 3075 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37731', '2', '37731 1191182336 3 25000 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 52 4294967251 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40432', '2', '40432 1191182336 3 3429 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37733', '2', '37733 1191182336 3 2622 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37734', '2', '37734 1191182336 3 16714 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37735', '2', '37735 1191182336 3 42780 1065353216 0 2 0 2 0 0 0 0 0 136 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40605', '2', '40605 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37737', '2', '37737 1191182336 3 1678 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37738', '2', '37738 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37739', '2', '37739 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40431', '2', '40431 1191182336 3 24939 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2821 0 0 0 0 0 0 0 0 0 0 0 40 4294967261 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37741', '2', '37741 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40604', '2', '40604 1191182336 3 44673 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 81 4294967257 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40430', '2', '40430 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40603', '2', '40603 1191182336 3 36168 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 104 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40429', '2', '40429 1191182336 3 1677 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37746', '2', '37746 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37747', '2', '37747 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40428', '2', '40428 1191182336 3 3018 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40427', '2', '40427 1191182336 3 885 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40426', '2', '40426 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37751', '2', '37751 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37752', '2', '37752 1191182336 3 14901 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 356 0 0 357 0 0 0 0 0 0 1203 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37753', '2', '37753 1191182336 3 1981 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 140 140 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37754', '2', '37754 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40425', '2', '40425 1191182336 3 2080 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 73 0 0 70 0 0 0 0 0 0 1185 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40424', '2', '40424 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37757', '2', '37757 1191182336 3 3293 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37758', '2', '37758 1191182336 3 10623 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40423', '2', '40423 1191182336 3 1925 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37760', '2', '37760 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37761', '2', '37761 1191182336 3 1981 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 140 140 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40422', '2', '40422 1191182336 3 20655 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 366 0 0 2316 0 0 2372 0 0 0 2147 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40421', '2', '40421 1191182336 3 4047 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37764', '2', '37764 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37765', '2', '37765 1191182336 3 4694 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40602', '2', '40602 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37769', '2', '37769 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40420', '2', '40420 1191182336 3 25075 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 23 4294967251 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37771', '2', '37771 1191182336 3 31228 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 40 4294967285 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37772', '2', '37772 1191182336 3 9755 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40419', '2', '40419 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40418', '2', '40418 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37775', '2', '37775 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37776', '2', '37776 1191182336 3 44683 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 65 4294967253 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37777', '2', '37777 1191182336 3 30726 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40417', '2', '40417 1191182336 3 2020 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37779', '2', '37779 1191182336 3 29425 1065353216 0 2 0 2 0 0 0 0 0 175 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40601', '2', '40601 1191182336 3 45986 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37781', '2', '37781 1191182336 3 17413 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40416', '2', '40416 1191182336 3 920 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40415', '2', '40415 1191182336 3 24685 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 42 4294967257 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37784', '2', '37784 1191182336 3 22528 1065353216 0 2 0 2 0 0 0 0 0 77 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37785', '2', '37785 1191182336 3 13915 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37786', '2', '37786 1191182336 3 1927 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40414', '2', '40414 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40600', '2', '40600 1191182336 3 44677 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 116 4294967251 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37789', '2', '37789 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37790', '2', '37790 1191182336 3 20697 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37791', '2', '37791 1191182336 3 2807 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40413', '2', '40413 1191182336 3 866 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 358 0 0 365 0 0 0 0 0 0 528 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37793', '2', '37793 1191182336 3 6364 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40412', '2', '40412 1191182336 3 24837 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 23 4294967289 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40599', '2', '40599 1191182336 3 8226 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37797', '2', '37797 1191182336 3 811 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40411', '2', '40411 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40598', '2', '40598 1191182336 3 36526 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 43 4294967256 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37800', '2', '37800 1191182336 3 24949 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 23 4294967290 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37801', '2', '37801 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40410', '2', '40410 1191182336 3 24779 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 39 4294967254 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40597', '2', '40597 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40409', '2', '40409 1191182336 3 3000 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37805', '2', '37805 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37806', '2', '37806 1191182336 3 20518 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37807', '2', '37807 1191182336 3 1388 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37808', '2', '37808 1191182336 3 3008 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37809', '2', '37809 1191182336 3 25033 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 23 4294967252 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37810', '2', '37810 1191182336 3 10627 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40408', '2', '40408 1191182336 3 25131 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 41 4294967257 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40407', '2', '40407 1191182336 3 10135 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1122 0 0 1147 0 0 0 0 0 0 806 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37813', '2', '37813 1191182336 3 36035 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 72 4294967274 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40406', '2', '40406 1191182336 3 832 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37815', '2', '37815 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37816', '2', '37816 1191182336 3 45998 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40405', '2', '40405 1191182336 3 36457 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2817 0 0 0 0 0 0 0 0 0 0 0 58 4294967265 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37818', '2', '37818 1191182336 3 30728 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40404', '2', '40404 1191182336 3 24777 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 52 4294967254 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40403', '2', '40403 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40402', '2', '40402 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37822', '2', '37822 1191182336 3 13918 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40401', '2', '40401 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40400', '2', '40400 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40399', '2', '40399 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40398', '2', '40398 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37827', '2', '37827 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37828', '2', '37828 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37829', '2', '37829 1191182336 3 44732 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2825 0 0 3726 0 0 0 0 0 0 0 0 126 4294967207 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37830', '2', '37830 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37831', '2', '37831 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40397', '2', '40397 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37833', '2', '37833 1191182336 3 5066 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40396', '2', '40396 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40395', '2', '40395 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37836', '2', '37836 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40394', '2', '40394 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37838', '2', '37838 1191182336 3 1443 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37839', '2', '37839 1191182336 3 6299 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37840', '2', '37840 1191182336 3 867 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37841', '2', '37841 1191182336 3 30739 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40393', '2', '40393 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40392', '2', '40392 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40391', '2', '40391 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40596', '2', '40596 1191182336 3 31161 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 46 4294967256 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40390', '2', '40390 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37848', '2', '37848 1191182336 3 4436 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40389', '2', '40389 1191182336 3 36428 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 56 4294967252 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40595', '2', '40595 1191182336 3 36394 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 58 4294967251 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40388', '2', '40388 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40594', '2', '40594 1191182336 3 36271 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 0 0 0 0 0 0 0 0 0 0 0 0 101 4294967278 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37853', '2', '37853 1191182336 3 9378 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37854', '2', '37854 1191182336 3 20526 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40387', '2', '40387 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37856', '2', '37856 1191182336 3 36500 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 46 4294967290 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40386', '2', '40386 1191182336 3 2084 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37858', '2', '37858 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37859', '2', '37859 1191182336 3 31232 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 40 4294967290 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37860', '2', '37860 1191182336 3 31564 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 63 4294967257 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37861', '2', '37861 1191182336 3 4454 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37862', '2', '37862 1191182336 3 14170 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40385', '2', '40385 1191182336 3 36624 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 32 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40384', '2', '40384 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40383', '2', '40383 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37866', '2', '37866 1191182336 3 36582 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 43 4294967291 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40382', '2', '40382 1191182336 3 36665 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 30 4294967257 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37868', '2', '37868 1191182336 3 7517 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 406 0 0 411 0 0 0 0 0 0 878 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37869', '2', '37869 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40381', '2', '40381 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37871', '2', '37871 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37872', '2', '37872 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37873', '2', '37873 1191182336 3 31216 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 46 4294967274 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40380', '2', '40380 1191182336 3 20655 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 366 0 0 359 0 0 2607 0 0 0 2144 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40379', '2', '40379 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37876', '2', '37876 1191182336 3 5109 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37877', '2', '37877 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37878', '2', '37878 1191182336 3 3294 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37879', '2', '37879 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40378', '2', '40378 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37881', '2', '37881 1191182336 3 44649 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 75 4294967259 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37882', '2', '37882 1191182336 3 27481 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40377', '2', '40377 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40376', '2', '40376 1191182336 3 24998 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 39 4294967251 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37886', '2', '37886 1191182336 3 1996 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40375', '2', '40375 1191182336 3 20670 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 367 0 0 363 0 0 366 0 0 0 2154 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37888', '2', '37888 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40593', '2', '40593 1191182336 3 13882 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40374', '2', '40374 1191182336 3 1391 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37891', '2', '37891 1191182336 3 2110 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40373', '2', '40373 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40372', '2', '40372 1191182336 3 24832 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 41 4294967257 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40371', '2', '40371 1191182336 3 3058 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40370', '2', '40370 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40369', '2', '40369 1191182336 3 25102 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 17 4294967289 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40592', '2', '40592 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37898', '2', '37898 1191182336 3 31197 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 44 4294967285 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37899', '2', '37899 1191182336 3 3281 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37900', '2', '37900 1191182336 3 4436 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37901', '2', '37901 1191182336 3 13905 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40368', '2', '40368 1191182336 3 3073 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40591', '2', '40591 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37904', '2', '37904 1191182336 3 25320 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 22 4294967252 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40367', '2', '40367 1191182336 3 1639 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1098 0 0 0 0 0 0 0 0 0 363 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37906', '2', '37906 1191182336 3 36147 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2817 0 0 0 0 0 0 0 0 0 0 0 72 4294967265 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37907', '2', '37907 1191182336 3 3227 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37908', '2', '37908 1191182336 3 21595 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40366', '2', '40366 1191182336 3 36597 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 104 4294967284 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40517', '2', '40517 1191182336 3 24887 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 39 4294967289 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39886', '2', '39886 1191182336 3 36978 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40516', '2', '40516 1191182336 3 24826 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 40 4294967287 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37914', '2', '37914 1191182336 3 1659 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37915', '2', '37915 1191182336 3 1722 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39885', '2', '39885 1191182336 3 31254 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 31 4294967279 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37917', '2', '37917 1191182336 3 10246 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2107 0 0 0 0 0 0 0 0 0 1827 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37918', '2', '37918 1191182336 3 2725 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37919', '2', '37919 1191182336 3 36444 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 60 4294967257 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37920', '2', '37920 1191182336 3 14552 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37921', '2', '37921 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39884', '2', '39884 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37923', '2', '37923 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37924', '2', '37924 1191182336 3 14552 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37925', '2', '37925 1191182336 3 21561 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37926', '2', '37926 1191182336 3 2164 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37927', '2', '37927 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39883', '2', '39883 1191182336 3 3008 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37929', '2', '37929 1191182336 3 45998 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37930', '2', '37930 1191182336 3 2624 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37931', '2', '37931 1191182336 3 14157 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37932', '2', '37932 1191182336 3 51958 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 3727 0 0 2824 0 0 0 0 0 0 0 0 108 4294967206 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39882', '2', '39882 1191182336 3 18744 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39881', '2', '39881 1191182336 3 6364 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39880', '2', '39880 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39879', '2', '39879 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37937', '2', '37937 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37938', '2', '37938 1191182336 3 3200 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39878', '2', '39878 1191182336 3 6205 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37940', '2', '37940 1191182336 3 8245 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37941', '2', '37941 1191182336 3 31275 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39877', '2', '39877 1191182336 3 2018 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37943', '2', '37943 1191182336 3 31164 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 44 4294967257 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37944', '2', '37944 1191182336 3 25187 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 17 4294967256 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37945', '2', '37945 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39876', '2', '39876 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39875', '2', '39875 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39874', '2', '39874 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37949', '2', '37949 1191182336 3 3475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40515', '2', '40515 1191182336 3 24834 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2820 0 0 0 0 0 0 0 0 0 0 0 41 4294967262 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39873', '2', '39873 1191182336 3 31580 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 63 4294967259 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37952', '2', '37952 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39872', '2', '39872 1191182336 3 4047 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39871', '2', '39871 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37956', '2', '37956 1191182336 3 31564 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 63 4294967255 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39870', '2', '39870 1191182336 3 31156 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 60 4294967288 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37958', '2', '37958 1191182336 3 7787 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40514', '2', '40514 1191182336 3 24368 1065353216 0 2 0 2 0 0 0 0 0 185 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39869', '2', '39869 1191182336 3 3008 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37961', '2', '37961 1191182336 3 24825 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 30 4294967253 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37962', '2', '37962 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39868', '2', '39868 1191182336 3 13904 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39867', '2', '39867 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39866', '2', '39866 1191182336 3 9361 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39865', '2', '39865 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37967', '2', '37967 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39864', '2', '39864 1191182336 3 31284 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37969', '2', '37969 1191182336 3 3053 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37970', '2', '37970 1191182336 3 2566 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37971', '2', '37971 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37972', '2', '37972 1191182336 3 31268 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2825 0 0 2803 0 0 2802 0 0 0 0 0 0 0 0 2 4294967236 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39863', '2', '39863 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37974', '2', '37974 1191182336 3 2020 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37975', '2', '37975 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39862', '2', '39862 1191182336 3 31562 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 63 4294967255 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39861', '2', '39861 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37978', '2', '37978 1191182336 3 10627 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37979', '2', '37979 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37980', '2', '37980 1191182336 3 31188 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 30 4294967288 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37981', '2', '37981 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39860', '2', '39860 1191182336 3 5020 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40513', '2', '40513 1191182336 3 36393 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2822 0 0 2824 0 0 0 0 0 0 0 0 78 4294967229 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37984', '2', '37984 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39859', '2', '39859 1191182336 3 2065 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37986', '2', '37986 1191182336 3 22276 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37987', '2', '37987 1191182336 3 4263 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39858', '2', '39858 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37989', '2', '37989 1191182336 3 13913 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37990', '2', '37990 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37991', '2', '37991 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37992', '2', '37992 1191182336 3 2034 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37993', '2', '37993 1191182336 3 36525 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 42 4294967256 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39857', '2', '39857 1191182336 3 36039 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 97 4294967257 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37995', '2', '37995 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39856', '2', '39856 1191182336 3 4565 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39855', '2', '39855 1191182336 3 25215 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 41 4294967281 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37998', '2', '37998 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39854', '2', '39854 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39853', '2', '39853 1191182336 3 3225 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38001', '2', '38001 1191182336 3 2879 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39852', '2', '39852 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39851', '2', '39851 1191182336 3 44750 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38004', '2', '38004 1191182336 3 2244 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38005', '2', '38005 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39850', '2', '39850 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39849', '2', '39849 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39848', '2', '39848 1191182336 3 25874 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39847', '2', '39847 1191182336 3 31217 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 60 4294967251 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38011', '2', '38011 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39846', '2', '39846 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38013', '2', '38013 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38014', '2', '38014 1191182336 3 20695 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38015', '2', '38015 1191182336 3 13903 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38016', '2', '38016 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38017', '2', '38017 1191182336 3 30734 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38018', '2', '38018 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39845', '2', '39845 1191182336 3 44145 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39844', '2', '39844 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39843', '2', '39843 1191182336 3 24939 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 40 4294967255 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39842', '2', '39842 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38023', '2', '38023 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38024', '2', '38024 1191182336 3 37117 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39841', '2', '39841 1191182336 3 2259 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39840', '2', '39840 1191182336 3 24712 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 30 4294967285 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38027', '2', '38027 1191182336 3 31168 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 47 4294967252 135 135 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38028', '2', '38028 1191182336 3 1720 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38029', '2', '38029 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38030', '2', '38030 1191182336 3 30735 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38031', '2', '38031 1191182336 3 936 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38032', '2', '38032 1191182336 3 1459 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38033', '2', '38033 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38034', '2', '38034 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38035', '2', '38035 1191182336 3 811 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38036', '2', '38036 1191182336 3 37759 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40512', '2', '40512 1191182336 3 9360 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39839', '2', '39839 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38039', '2', '38039 1191182336 3 18676 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38040', '2', '38040 1191182336 3 2975 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38041', '2', '38041 1191182336 3 4302 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39838', '2', '39838 1191182336 3 4445 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38043', '2', '38043 1191182336 3 17055 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38044', '2', '38044 1191182336 3 2055 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38045', '2', '38045 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38046', '2', '38046 1191182336 3 31198 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 44 4294967277 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38047', '2', '38047 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39837', '2', '39837 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38049', '2', '38049 1191182336 3 6579 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39836', '2', '39836 1191182336 3 12550 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38051', '2', '38051 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39835', '2', '39835 1191182336 3 27481 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38053', '2', '38053 1191182336 3 36267 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 75 4294967256 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39834', '2', '39834 1191182336 3 13000 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39833', '2', '39833 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39832', '2', '39832 1191182336 3 25222 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 52 4294967256 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38057', '2', '38057 1191182336 3 2911 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38058', '2', '38058 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39831', '2', '39831 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38060', '2', '38060 1191182336 3 2284 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38061', '2', '38061 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39830', '2', '39830 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39829', '2', '39829 1191182336 3 2546 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38064', '2', '38064 1191182336 3 32535 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38065', '2', '38065 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38066', '2', '38066 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39828', '2', '39828 1191182336 3 6566 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38068', '2', '38068 1191182336 3 13884 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38069', '2', '38069 1191182336 3 20653 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 367 0 0 363 0 0 366 0 0 0 2154 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39827', '2', '39827 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38071', '2', '38071 1191182336 3 1717 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39826', '2', '39826 1191182336 3 2725 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38073', '2', '38073 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38074', '2', '38074 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39825', '2', '39825 1191182336 3 34837 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38076', '2', '38076 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38077', '2', '38077 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38078', '2', '38078 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38079', '2', '38079 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38080', '2', '38080 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38081', '2', '38081 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39824', '2', '39824 1191182336 3 2744 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38083', '2', '38083 1191182336 3 35979 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 56 4294967259 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39823', '2', '39823 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38085', '2', '38085 1191182336 3 10403 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38086', '2', '38086 1191182336 3 31233 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 40 4294967256 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38087', '2', '38087 1191182336 3 13023 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38088', '2', '38088 1191182336 3 31203 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 33 4294967288 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39822', '2', '39822 1191182336 3 12550 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39821', '2', '39821 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39820', '2', '39820 1191182336 3 6363 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39819', '2', '39819 1191182336 3 18295 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1306 0 0 0 0 0 0 0 0 0 1370 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39818', '2', '39818 1191182336 3 20664 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 366 0 0 364 0 0 2608 0 0 0 2152 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40511', '2', '40511 1191182336 3 5971 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38095', '2', '38095 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38096', '2', '38096 1191182336 3 20692 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1298 0 0 0 0 0 0 0 0 0 1362 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39817', '2', '39817 1191182336 3 30722 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38098', '2', '38098 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38099', '2', '38099 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38100', '2', '38100 1191182336 3 20543 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38101', '2', '38101 1191182336 3 36667 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 33 4294967275 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39816', '2', '39816 1191182336 3 5079 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38103', '2', '38103 1191182336 3 6352 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39815', '2', '39815 1191182336 3 866 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1147 0 0 0 0 0 0 0 0 0 412 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38105', '2', '38105 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38106', '2', '38106 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38107', '2', '38107 1191182336 3 25061 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 23 4294967253 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38108', '2', '38108 1191182336 3 1401 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38109', '2', '38109 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38110', '2', '38110 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40084', '2', '40084 1191182336 3 2057 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38112', '2', '38112 1191182336 3 36281 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 78 4294967284 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38113', '2', '38113 1191182336 3 2622 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40083', '2', '40083 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40082', '2', '40082 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38116', '2', '38116 1191182336 3 22528 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40081', '2', '40081 1191182336 3 3279 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40080', '2', '40080 1191182336 3 2799 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38120', '2', '38120 1191182336 3 1703 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40079', '2', '40079 1191182336 3 31231 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 40 4294967260 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40078', '2', '40078 1191182336 3 22529 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40077', '2', '40077 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40076', '2', '40076 1191182336 3 24246 1065353216 0 2 0 2 0 0 0 0 0 184 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40545', '2', '40545 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40075', '2', '40075 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38127', '2', '38127 1191182336 3 3296 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40074', '2', '40074 1191182336 3 37755 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38129', '2', '38129 1191182336 3 31203 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 33 4294967288 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38130', '2', '38130 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40073', '2', '40073 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38132', '2', '38132 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38133', '2', '38133 1191182336 3 34827 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38134', '2', '38134 1191182336 3 3260 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38135', '2', '38135 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38136', '2', '38136 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38137', '2', '38137 1191182336 3 2084 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38138', '2', '38138 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38139', '2', '38139 1191182336 3 31246 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 51 4294967260 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38140', '2', '38140 1191182336 3 6351 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38141', '2', '38141 1191182336 3 4444 1065353216 0 2 0 2 0 0 0 0 0 1 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38142', '2', '38142 1191182336 3 36539 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 97 4294967287 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38143', '2', '38143 1191182336 3 24101 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40072', '2', '40072 1191182336 3 25292 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 4294967275 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40071', '2', '40071 1191182336 3 5267 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38146', '2', '38146 1191182336 3 31199 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 44 4294967263 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38147', '2', '38147 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38148', '2', '38148 1191182336 3 2728 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38149', '2', '38149 1191182336 3 24575 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 27 4294967287 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38150', '2', '38150 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38151', '2', '38151 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40070', '2', '40070 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38153', '2', '38153 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40069', '2', '40069 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38155', '2', '38155 1191182336 3 13884 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38156', '2', '38156 1191182336 3 25334 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 52 4294967280 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40068', '2', '40068 1191182336 3 25327 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 41 4294967289 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38158', '2', '38158 1191182336 3 5267 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38159', '2', '38159 1191182336 3 44682 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 3726 0 0 2824 0 0 0 0 0 0 0 0 70 4294967208 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38161', '2', '38161 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38162', '2', '38162 1191182336 3 1929 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38163', '2', '38163 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40067', '2', '40067 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40066', '2', '40066 1191182336 3 6331 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40065', '2', '40065 1191182336 3 2911 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38167', '2', '38167 1191182336 3 6206 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38168', '2', '38168 1191182336 3 31268 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2825 0 0 2803 0 0 2802 0 0 0 0 0 0 0 0 2 4294967236 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40064', '2', '40064 1191182336 3 13909 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38170', '2', '38170 1191182336 3 36511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 97 4294967252 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40063', '2', '40063 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40062', '2', '40062 1191182336 3 5109 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40061', '2', '40061 1191182336 3 17965 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38174', '2', '38174 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40060', '2', '40060 1191182336 3 31185 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 49 4294967277 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40544', '2', '40544 1191182336 3 24723 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 31 4294967257 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38177', '2', '38177 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40059', '2', '40059 1191182336 3 36485 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 45 4294967251 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38179', '2', '38179 1191182336 3 1608 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 91 0 0 104 0 0 0 0 0 0 598 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40058', '2', '40058 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38181', '2', '38181 1191182336 3 1318 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38182', '2', '38182 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38183', '2', '38183 1191182336 3 24834 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 41 4294967286 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40057', '2', '40057 1191182336 3 20543 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40056', '2', '40056 1191182336 3 4302 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38186', '2', '38186 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40055', '2', '40055 1191182336 3 2011 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38188', '2', '38188 1191182336 3 3429 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38190', '2', '38190 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40054', '2', '40054 1191182336 3 36157 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 101 4294967282 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40543', '2', '40543 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40053', '2', '40053 1191182336 3 36498 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 43 4294967289 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38195', '2', '38195 1191182336 3 1445 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40542', '2', '40542 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38197', '2', '38197 1191182336 3 1965 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38198', '2', '38198 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40541', '2', '40541 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38200', '2', '38200 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38201', '2', '38201 1191182336 3 31174 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 47 4294967257 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38202', '2', '38202 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40052', '2', '40052 1191182336 3 25214 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 40 4294967256 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38204', '2', '38204 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38205', '2', '38205 1191182336 3 36526 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 43 4294967279 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38206', '2', '38206 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38207', '2', '38207 1191182336 3 36260 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 72 4294967256 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40051', '2', '40051 1191182336 3 1986 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38209', '2', '38209 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40050', '2', '40050 1191182336 3 6294 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40049', '2', '40049 1191182336 3 1457 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40048', '2', '40048 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38213', '2', '38213 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38214', '2', '38214 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40540', '2', '40540 1191182336 3 18710 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38216', '2', '38216 1191182336 3 36151 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 97 4294967279 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38217', '2', '38217 1191182336 3 49227 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 3726 0 0 2824 0 0 0 0 0 0 0 0 56 4294967208 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40047', '2', '40047 1191182336 3 13887 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38219', '2', '38219 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38220', '2', '38220 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40046', '2', '40046 1191182336 3 25744 1065353216 0 2 0 2 0 0 0 0 0 46 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38222', '2', '38222 1191182336 3 4772 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38223', '2', '38223 1191182336 3 31213 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 46 4294967270 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40045', '2', '40045 1191182336 3 31564 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 63 4294967255 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38225', '2', '38225 1191182336 3 34828 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38226', '2', '38226 1191182336 3 25046 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 22 4294967258 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40044', '2', '40044 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40043', '2', '40043 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38229', '2', '38229 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38230', '2', '38230 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38231', '2', '38231 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38232', '2', '38232 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40042', '2', '40042 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40041', '2', '40041 1191182336 3 30740 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38235', '2', '38235 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40040', '2', '40040 1191182336 3 36058 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 58 4294967287 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38237', '2', '38237 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38238', '2', '38238 1191182336 3 16737 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40039', '2', '40039 1191182336 3 4479 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38240', '2', '38240 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40038', '2', '40038 1191182336 3 25256 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 12 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38242', '2', '38242 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40037', '2', '40037 1191182336 3 867 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38244', '2', '38244 1191182336 3 36160 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 101 4294967291 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38245', '2', '38245 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40036', '2', '40036 1191182336 3 1204 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40539', '2', '40539 1191182336 3 5112 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38248', '2', '38248 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40035', '2', '40035 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40034', '2', '40034 1191182336 3 9428 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 0 0 104 0 0 0 0 0 0 1024 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38251', '2', '38251 1191182336 3 44688 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 3726 0 0 2824 0 0 0 0 0 0 0 0 65 4294967208 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40538', '2', '40538 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40033', '2', '40033 1191182336 3 2825 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38254', '2', '38254 1191182336 3 3311 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40537', '2', '40537 1191182336 3 727 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 68 0 0 0 0 0 0 0 0 0 6 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40032', '2', '40032 1191182336 3 20518 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38257', '2', '38257 1191182336 3 20652 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 366 0 0 359 0 0 2607 0 0 0 2144 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38258', '2', '38258 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40031', '2', '40031 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38260', '2', '38260 1191182336 3 10634 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40030', '2', '40030 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38262', '2', '38262 1191182336 3 9361 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40536', '2', '40536 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38264', '2', '38264 1191182336 3 20722 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38265', '2', '38265 1191182336 3 6522 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40029', '2', '40029 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38267', '2', '38267 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38268', '2', '38268 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38269', '2', '38269 1191182336 3 3321 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40028', '2', '40028 1191182336 3 2879 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40027', '2', '40027 1191182336 3 22526 1065353216 0 2 0 2 0 0 0 0 0 140 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40026', '2', '40026 1191182336 3 25874 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40025', '2', '40025 1191182336 3 5756 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40024', '2', '40024 1191182336 3 30736 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40023', '2', '40023 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40022', '2', '40022 1191182336 3 30740 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38277', '2', '38277 1191182336 3 9759 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38278', '2', '38278 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38279', '2', '38279 1191182336 3 3429 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38280', '2', '38280 1191182336 3 4290 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38281', '2', '38281 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38282', '2', '38282 1191182336 3 13887 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38283', '2', '38283 1191182336 3 2069 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40021', '2', '40021 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38285', '2', '38285 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40020', '2', '40020 1191182336 3 13018 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38287', '2', '38287 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40019', '2', '40019 1191182336 3 1446 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38289', '2', '38289 1191182336 3 2327 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38290', '2', '38290 1191182336 3 1440 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38291', '2', '38291 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38292', '2', '38292 1191182336 3 24723 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 31 4294967255 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38293', '2', '38293 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40018', '2', '40018 1191182336 3 19258 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38295', '2', '38295 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40017', '2', '40017 1191182336 3 1973 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38297', '2', '38297 1191182336 3 8303 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38298', '2', '38298 1191182336 3 25068 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 29 4294967259 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38299', '2', '38299 1191182336 3 24890 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 52 4294967281 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38300', '2', '38300 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40016', '2', '40016 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38302', '2', '38302 1191182336 3 20670 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 367 0 0 363 0 0 366 0 0 0 2154 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38303', '2', '38303 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38304', '2', '38304 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40535', '2', '40535 1191182336 3 21113 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38306', '2', '38306 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38307', '2', '38307 1191182336 3 1958 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40015', '2', '40015 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40014', '2', '40014 1191182336 3 811 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38310', '2', '38310 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40365', '2', '40365 1191182336 3 24613 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2820 0 0 0 0 0 0 0 0 0 0 0 32 4294967262 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40364', '2', '40364 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40363', '2', '40363 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40362', '2', '40362 1191182336 3 2822 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38316', '2', '38316 1191182336 3 2072 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2373 0 0 0 0 0 0 0 0 0 2077 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38317', '2', '38317 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38318', '2', '38318 1191182336 3 9253 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38319', '2', '38319 1191182336 3 44708 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38320', '2', '38320 1191182336 3 37143 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38321', '2', '38321 1191182336 3 31940 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 35 4294967259 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40361', '2', '40361 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40360', '2', '40360 1191182336 3 14897 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 353 0 0 357 0 0 0 0 0 0 1202 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38324', '2', '38324 1191182336 3 14169 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40359', '2', '40359 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38326', '2', '38326 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40358', '2', '40358 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38328', '2', '38328 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40357', '2', '40357 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40356', '2', '40356 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38331', '2', '38331 1191182336 3 1394 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40355', '2', '40355 1191182336 3 36277 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 104 4294967285 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38333', '2', '38333 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38334', '2', '38334 1191182336 3 36456 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 56 4294967255 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40354', '2', '40354 1191182336 3 10246 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2106 0 0 0 0 0 0 0 0 0 1826 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38336', '2', '38336 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40353', '2', '40353 1191182336 3 36154 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 54 4294967256 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38338', '2', '38338 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40352', '2', '40352 1191182336 3 1461 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40351', '2', '40351 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40350', '2', '40350 1191182336 3 2168 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40349', '2', '40349 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40348', '2', '40348 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38344', '2', '38344 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40347', '2', '40347 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40346', '2', '40346 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38347', '2', '38347 1191182336 3 31160 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 46 4294967253 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40590', '2', '40590 1191182336 3 22641 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38350', '2', '38350 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38351', '2', '38351 1191182336 3 3323 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 14 14 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40345', '2', '40345 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40344', '2', '40344 1191182336 3 32715 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40343', '2', '40343 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40342', '2', '40342 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38356', '2', '38356 1191182336 3 36149 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 97 4294967284 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38357', '2', '38357 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38358', '2', '38358 1191182336 3 3213 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40341', '2', '40341 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40340', '2', '40340 1191182336 3 753 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38361', '2', '38361 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40339', '2', '40339 1191182336 3 36040 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 97 4294967258 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40338', '2', '40338 1191182336 3 3902 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40337', '2', '40337 1191182336 3 36525 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 42 4294967255 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40589', '2', '40589 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40336', '2', '40336 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38367', '2', '38367 1191182336 3 18743 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38369', '2', '38369 1191182336 3 39970 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40335', '2', '40335 1191182336 3 24669 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 40 4294967257 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40334', '2', '40334 1191182336 3 36061 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 108 4294967259 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40333', '2', '40333 1191182336 3 24776 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 39 4294967254 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38373', '2', '38373 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40332', '2', '40332 1191182336 3 2075 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 71 0 0 0 0 0 0 0 0 0 15 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40331', '2', '40331 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38376', '2', '38376 1191182336 3 19268 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40330', '2', '40330 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40329', '2', '40329 1191182336 3 36262 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 72 4294967280 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40328', '2', '40328 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38380', '2', '38380 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38381', '2', '38381 1191182336 3 14157 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38382', '2', '38382 1191182336 3 37157 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40327', '2', '40327 1191182336 3 31256 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2803 0 0 2804 0 0 0 0 0 0 0 0 5 4294967238 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38384', '2', '38384 1191182336 3 24776 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 0 0 0 0 0 0 0 0 0 0 0 0 39 4294967278 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38385', '2', '38385 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38386', '2', '38386 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38387', '2', '38387 1191182336 3 19258 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38388', '2', '38388 1191182336 3 754 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38389', '2', '38389 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40588', '2', '40588 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38392', '2', '38392 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40326', '2', '40326 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38394', '2', '38394 1191182336 3 4724 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38395', '2', '38395 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38396', '2', '38396 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38397', '2', '38397 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38398', '2', '38398 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40325', '2', '40325 1191182336 3 2624 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40324', '2', '40324 1191182336 3 36401 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2822 0 0 2824 0 0 0 0 0 0 0 0 81 4294967229 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38401', '2', '38401 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38402', '2', '38402 1191182336 3 17683 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38403', '2', '38403 1191182336 3 16652 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40323', '2', '40323 1191182336 3 4724 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40322', '2', '40322 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40321', '2', '40321 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38407', '2', '38407 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40320', '2', '40320 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40319', '2', '40319 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38410', '2', '38410 1191182336 3 36708 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 101 4294967279 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38412', '2', '38412 1191182336 3 37769 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38413', '2', '38413 1191182336 3 2168 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38414', '2', '38414 1191182336 3 2751 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40318', '2', '40318 1191182336 3 36526 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 43 4294967280 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40317', '2', '40317 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38417', '2', '38417 1191182336 3 6364 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40316', '2', '40316 1191182336 3 25268 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 12 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38419', '2', '38419 1191182336 3 31224 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 33 4294967263 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38420', '2', '38420 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38421', '2', '38421 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40315', '2', '40315 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40314', '2', '40314 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40313', '2', '40313 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40312', '2', '40312 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40587', '2', '40587 1191182336 3 3262 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40311', '2', '40311 1191182336 3 1458 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40310', '2', '40310 1191182336 3 24892 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 39 4294967284 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40309', '2', '40309 1191182336 3 3042 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40308', '2', '40308 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40307', '2', '40307 1191182336 3 897 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38432', '2', '38432 1191182336 3 24938 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2813 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 4294967269 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38433', '2', '38433 1191182336 3 9276 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38435', '2', '38435 1191182336 3 24886 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2820 0 0 0 0 0 0 0 0 0 0 0 39 4294967262 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40306', '2', '40306 1191182336 3 10329 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38437', '2', '38437 1191182336 3 2114 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38438', '2', '38438 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38439', '2', '38439 1191182336 3 16654 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38440', '2', '38440 1191182336 3 36485 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 45 4294967256 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40586', '2', '40586 1191182336 3 2975 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38442', '2', '38442 1191182336 3 13755 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38443', '2', '38443 1191182336 3 36062 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 81 4294967257 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38444', '2', '38444 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40305', '2', '40305 1191182336 3 5755 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38446', '2', '38446 1191182336 3 5020 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40585', '2', '40585 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40584', '2', '40584 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38449', '2', '38449 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40304', '2', '40304 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40303', '2', '40303 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38452', '2', '38452 1191182336 3 36283 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2813 0 0 0 0 0 0 0 0 0 0 0 0 0 0 81 4294967269 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40302', '2', '40302 1191182336 3 2623 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40301', '2', '40301 1191182336 3 789 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 0 0 68 0 0 0 0 0 0 670 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40300', '2', '40300 1191182336 3 2981 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38456', '2', '38456 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38457', '2', '38457 1191182336 3 6148 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40299', '2', '40299 1191182336 3 1394 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38459', '2', '38459 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38460', '2', '38460 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38461', '2', '38461 1191182336 3 13755 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40298', '2', '40298 1191182336 3 24774 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 39 4294967291 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38463', '2', '38463 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40297', '2', '40297 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38465', '2', '38465 1191182336 3 1213 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40583', '2', '40583 1191182336 3 30723 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38467', '2', '38467 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40296', '2', '40296 1191182336 3 24603 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 4294967277 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38469', '2', '38469 1191182336 3 5967 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38470', '2', '38470 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38471', '2', '38471 1191182336 3 4768 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40295', '2', '40295 1191182336 3 24669 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 40 4294967288 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38473', '2', '38473 1191182336 3 2075 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1583 0 0 0 0 0 0 0 0 0 1548 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40294', '2', '40294 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38475', '2', '38475 1191182336 3 2265 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38476', '2', '38476 1191182336 3 25187 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 17 4294967256 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40582', '2', '40582 1191182336 3 4632 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38478', '2', '38478 1191182336 3 24717 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 31 4294967289 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38479', '2', '38479 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40581', '2', '40581 1191182336 3 36262 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 72 4294967283 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38481', '2', '38481 1191182336 3 36049 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 75 4294967257 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40293', '2', '40293 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40292', '2', '40292 1191182336 3 36569 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 45 4294967256 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38484', '2', '38484 1191182336 3 1929 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38486', '2', '38486 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40291', '2', '40291 1191182336 3 3229 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38488', '2', '38488 1191182336 3 1405 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40290', '2', '40290 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40289', '2', '40289 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38491', '2', '38491 1191182336 3 4439 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38492', '2', '38492 1191182336 3 4447 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38493', '2', '38493 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40288', '2', '40288 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38495', '2', '38495 1191182336 3 36269 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 101 4294967256 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40287', '2', '40287 1191182336 3 36172 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 81 4294967256 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38497', '2', '38497 1191182336 3 24935 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 30 4294967291 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40286', '2', '40286 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40580', '2', '40580 1191182336 3 24605 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 31 4294967287 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38500', '2', '38500 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38501', '2', '38501 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38502', '2', '38502 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40579', '2', '40579 1191182336 3 36178 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 60 4294967256 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38504', '2', '38504 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40285', '2', '40285 1191182336 3 24663 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 52 4294967288 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38506', '2', '38506 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38507', '2', '38507 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38508', '2', '38508 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38509', '2', '38509 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38510', '2', '38510 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38511', '2', '38511 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38512', '2', '38512 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39814', '2', '39814 1191182336 3 2245 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38515', '2', '38515 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39813', '2', '39813 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38517', '2', '38517 1191182336 3 44669 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 56 4294967260 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38518', '2', '38518 1191182336 3 4700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40510', '2', '40510 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39812', '2', '39812 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39811', '2', '39811 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39810', '2', '39810 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38523', '2', '38523 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39809', '2', '39809 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38525', '2', '38525 1191182336 3 5624 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38526', '2', '38526 1191182336 3 31254 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 0 0 0 0 0 0 0 0 0 0 0 0 31 4294967278 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38527', '2', '38527 1191182336 3 36696 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 46 4294967287 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38528', '2', '38528 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38529', '2', '38529 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38530', '2', '38530 1191182336 3 4302 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39808', '2', '39808 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38532', '2', '38532 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39807', '2', '39807 1191182336 3 36041 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 72 4294967280 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38534', '2', '38534 1191182336 3 31227 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 4294967281 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39806', '2', '39806 1191182336 3 36397 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 108 4294967259 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39805', '2', '39805 1191182336 3 20659 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 367 0 0 363 0 0 366 0 0 0 2154 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39804', '2', '39804 1191182336 3 15968 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39803', '2', '39803 1191182336 3 25320 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 22 4294967288 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38539', '2', '38539 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39802', '2', '39802 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38541', '2', '38541 1191182336 3 36019 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 67 4294967287 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38542', '2', '38542 1191182336 3 1469 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39801', '2', '39801 1191182336 3 2013 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38545', '2', '38545 1191182336 3 2108 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38546', '2', '38546 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38547', '2', '38547 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38548', '2', '38548 1191182336 3 31244 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 51 4294967263 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38549', '2', '38549 1191182336 3 3329 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38550', '2', '38550 1191182336 3 3328 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38551', '2', '38551 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38552', '2', '38552 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39800', '2', '39800 1191182336 3 1521 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38554', '2', '38554 1191182336 3 36049 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 75 4294967260 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39799', '2', '39799 1191182336 3 36569 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 45 4294967252 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39798', '2', '39798 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38557', '2', '38557 1191182336 3 24935 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 30 4294967260 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38558', '2', '38558 1191182336 3 23909 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39797', '2', '39797 1191182336 3 24949 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 23 4294967255 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38560', '2', '38560 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38561', '2', '38561 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39796', '2', '39796 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38563', '2', '38563 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38564', '2', '38564 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38565', '2', '38565 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39795', '2', '39795 1191182336 3 5180 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38567', '2', '38567 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39794', '2', '39794 1191182336 3 36393 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 78 4294967253 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38569', '2', '38569 1191182336 3 3331 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38570', '2', '38570 1191182336 3 36513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 104 4294967288 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38571', '2', '38571 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38572', '2', '38572 1191182336 3 3057 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40509', '2', '40509 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39793', '2', '39793 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38575', '2', '38575 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38576', '2', '38576 1191182336 3 36057 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 78 4294967290 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38577', '2', '38577 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('25964', '6', '25964 1191182336 3 23500 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('26110', '6', '26110 1191182336 3 4604 1065353216 0 6 0 6 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('26229', '6', '26229 1191182336 3 2646 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('26232', '6', '26232 1191182336 3 15969 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 82 0 0 71 0 0 0 0 0 0 1009 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39627', '2', '39627 1191182336 3 23354 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39568', '2', '39568 1191182336 3 4771 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39569', '2', '39569 1191182336 3 24666 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2820 0 0 0 0 0 0 0 0 0 0 0 52 4294967262 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39570', '2', '39570 1191182336 3 3330 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39626', '2', '39626 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39625', '2', '39625 1191182336 3 36277 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 104 4294967281 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39573', '2', '39573 1191182336 3 24890 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 52 4294967252 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39574', '2', '39574 1191182336 3 2140 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1563 0 0 0 0 0 0 0 0 0 1547 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39575', '2', '39575 1191182336 3 4044 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39576', '2', '39576 1191182336 3 1462 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39577', '2', '39577 1191182336 3 36055 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 104 4294967290 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39624', '2', '39624 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39579', '2', '39579 1191182336 3 20673 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 367 0 0 363 0 0 366 0 0 0 2154 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39580', '2', '39580 1191182336 3 4660 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39581', '2', '39581 1191182336 3 31256 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2803 0 0 2804 0 0 0 0 0 0 0 0 5 4294967238 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39623', '2', '39623 1191182336 3 2020 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39583', '2', '39583 1191182336 3 4474 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39584', '2', '39584 1191182336 3 36598 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 108 4294967256 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39622', '2', '39622 1191182336 3 16656 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39586', '2', '39586 1191182336 3 36611 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 104 4294967260 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39621', '2', '39621 1191182336 3 812 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39620', '2', '39620 1191182336 3 22393 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39619', '2', '39619 1191182336 3 13905 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39590', '2', '39590 1191182336 3 1625 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 366 0 0 372 0 0 0 0 0 0 1211 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39591', '2', '39591 1191182336 3 25000 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 52 4294967251 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39618', '2', '39618 1191182336 3 30809 1065353216 0 2 0 2 0 0 0 0 0 124 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39617', '2', '39617 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39594', '2', '39594 1191182336 3 24609 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 41 4294967281 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39595', '2', '39595 1191182336 3 36381 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2818 0 0 0 0 0 0 0 0 0 0 0 101 4294967264 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39616', '2', '39616 1191182336 3 1315 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39597', '2', '39597 1191182336 3 36271 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 101 4294967281 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39615', '2', '39615 1191182336 3 36499 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 45 4294967282 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39599', '2', '39599 1191182336 3 25320 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 22 4294967280 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39614', '2', '39614 1191182336 3 37756 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40467', '2', '40467 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40468', '2', '40468 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40469', '2', '40469 1191182336 3 36169 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 78 4294967259 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40470', '2', '40470 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40471', '2', '40471 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40472', '2', '40472 1191182336 3 36597 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 104 4294967291 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40473', '2', '40473 1191182336 3 36066 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 4294967275 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40474', '2', '40474 1191182336 3 36065 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 81 4294967287 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40475', '2', '40475 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40476', '2', '40476 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40477', '2', '40477 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40478', '2', '40478 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40479', '2', '40479 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40480', '2', '40480 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40481', '2', '40481 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40482', '2', '40482 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40483', '2', '40483 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40484', '2', '40484 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40608', '2', '40608 1191182336 3 1482 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40609', '2', '40609 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40610', '2', '40610 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40611', '2', '40611 1191182336 3 1523 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40612', '2', '40612 1191182336 3 36640 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 34 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40613', '2', '40613 1191182336 3 2017 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40614', '2', '40614 1191182336 3 28498 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2804 0 0 2813 0 0 0 0 0 0 0 0 34 4294967244 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39550', '2', '39550 1191182336 3 14982 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1043 0 0 0 0 0 0 0 0 0 308 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39549', '2', '39549 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39637', '2', '39637 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39638', '2', '39638 1191182336 3 20709 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39546', '2', '39546 1191182336 3 25144 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 17 4294967255 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39545', '2', '39545 1191182336 3 5029 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39544', '2', '39544 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39543', '2', '39543 1191182336 3 5180 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39639', '2', '39639 1191182336 3 45998 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39640', '2', '39640 1191182336 3 21561 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39641', '2', '39641 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39642', '2', '39642 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39540', '2', '39540 1191182336 3 4044 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('25959', '6', '25959 1191182336 3 27668 1065353216 0 6 0 6 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('26233', '6', '26233 1191182336 3 6507 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39643', '2', '39643 1191182336 3 31151 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39536', '2', '39536 1191182336 3 24608 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 31 4294967258 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39644', '2', '39644 1191182336 3 1982 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39645', '2', '39645 1191182336 3 18678 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39646', '2', '39646 1191182336 3 36162 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 56 4294967281 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39647', '2', '39647 1191182336 3 16681 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39446', '2', '39446 1191182336 3 25116 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 17 4294967257 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39447', '2', '39447 1191182336 3 36609 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 97 4294967256 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40191', '2', '40191 1191182336 3 36056 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2821 0 0 0 0 0 0 0 0 0 0 0 104 4294967261 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40190', '2', '40190 1191182336 3 1214 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40562', '2', '40562 1191182336 3 5180 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40189', '2', '40189 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39453', '2', '39453 1191182336 3 5758 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40188', '2', '40188 1191182336 3 31268 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2803 0 0 2804 0 0 0 0 0 0 0 0 2 4294967238 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40187', '2', '40187 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39456', '2', '39456 1191182336 3 28497 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2823 0 0 2803 0 0 0 0 0 0 0 0 34 4294967242 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40186', '2', '40186 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40185', '2', '40185 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40184', '2', '40184 1191182336 3 1457 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39460', '2', '39460 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39461', '2', '39461 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40183', '2', '40183 1191182336 3 36512 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 101 4294967257 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39463', '2', '39463 1191182336 3 2620 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39464', '2', '39464 1191182336 3 25327 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 41 4294967289 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39465', '2', '39465 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40182', '2', '40182 1191182336 3 36498 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 43 4294967282 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40181', '2', '40181 1191182336 3 25187 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 17 4294967257 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40180', '2', '40180 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40179', '2', '40179 1191182336 3 36555 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 104 4294967252 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39470', '2', '39470 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39471', '2', '39471 1191182336 3 36556 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 108 4294967253 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40178', '2', '40178 1191182336 3 1930 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40561', '2', '40561 1191182336 3 14554 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39474', '2', '39474 1191182336 3 24609 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 41 4294967287 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40177', '2', '40177 1191182336 3 36043 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2818 0 0 0 0 0 0 0 0 0 0 0 75 4294967264 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39477', '2', '39477 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39478', '2', '39478 1191182336 3 789 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 0 0 69 0 0 0 0 0 0 672 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39479', '2', '39479 1191182336 3 886 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40176', '2', '40176 1191182336 3 5608 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40175', '2', '40175 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40560', '2', '40560 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40174', '2', '40174 1191182336 3 36043 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 75 4294967290 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39484', '2', '39484 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39485', '2', '39485 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39486', '2', '39486 1191182336 3 36288 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 108 4294967270 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39487', '2', '39487 1191182336 3 28497 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2823 0 0 2803 0 0 0 0 0 0 0 0 34 4294967242 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40173', '2', '40173 1191182336 3 10246 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1121 0 0 1071 0 0 0 0 0 0 890 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39489', '2', '39489 1191182336 3 31264 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2803 0 0 2804 0 0 0 0 0 0 0 0 5 4294967238 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39490', '2', '39490 1191182336 3 36598 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 108 4294967285 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39491', '2', '39491 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39492', '2', '39492 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39493', '2', '39493 1191182336 3 36458 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 60 4294967251 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40172', '2', '40172 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39495', '2', '39495 1191182336 3 24717 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2817 0 0 0 0 0 0 0 0 0 0 0 31 4294967265 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40171', '2', '40171 1191182336 3 36044 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 75 4294967260 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39497', '2', '39497 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40170', '2', '40170 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39499', '2', '39499 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40169', '2', '40169 1191182336 3 24832 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 41 4294967280 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39501', '2', '39501 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40559', '2', '40559 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39503', '2', '39503 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40168', '2', '40168 1191182336 3 25005 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 29 4294967255 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39505', '2', '39505 1191182336 3 8292 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39506', '2', '39506 1191182336 3 2274 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39507', '2', '39507 1191182336 3 3018 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39660', '2', '39660 1191182336 3 2203 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39659', '2', '39659 1191182336 3 3260 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40488', '2', '40488 1191182336 3 14553 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39658', '2', '39658 1191182336 3 1951 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39657', '2', '39657 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39513', '2', '39513 1191182336 3 36045 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 101 4294967260 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39514', '2', '39514 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39515', '2', '39515 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39516', '2', '39516 1191182336 3 14812 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39656', '2', '39656 1191182336 3 5183 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39655', '2', '39655 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39654', '2', '39654 1191182336 3 22891 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39653', '2', '39653 1191182336 3 30736 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39522', '2', '39522 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39652', '2', '39652 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39651', '2', '39651 1191182336 3 9480 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40487', '2', '40487 1191182336 3 17054 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39650', '2', '39650 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39649', '2', '39649 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39528', '2', '39528 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40486', '2', '40486 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39530', '2', '39530 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39531', '2', '39531 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39648', '2', '39648 1191182336 3 2824 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39312', '6', '39312 1191182336 3 4814 1065353216 0 6 0 6 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39601', '6', '39601 1191182336 3 22570 1065353216 0 6 0 6 0 0 0 0 0 3 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39602', '6', '39602 1191182336 3 15925 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39606', '6', '39606 1191182336 3 6296 1065353216 0 6 0 6 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39607', '6', '39607 1191182336 3 6293 1065353216 0 6 0 7855 1191182336 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39609', '6', '39609 1191182336 3 2967 1065353216 0 6 0 7855 1191182336 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39612', '6', '39612 1191182336 3 12223 1065353216 0 6 0 7855 1191182336 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39613', '6', '39613 1191182336 3 6506 1065353216 0 6 0 7855 1191182336 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40444', '2', '40444 1191182336 3 25124 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 22 4294967260 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40445', '2', '40445 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40446', '2', '40446 1191182336 3 24779 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 39 4294967270 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40447', '2', '40447 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40448', '2', '40448 1191182336 3 5749 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40449', '2', '40449 1191182336 3 2266 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40450', '2', '40450 1191182336 3 36155 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 75 4294967286 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40451', '2', '40451 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40452', '2', '40452 1191182336 3 4638 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40453', '2', '40453 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40454', '2', '40454 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40455', '2', '40455 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40456', '2', '40456 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40457', '2', '40457 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40458', '2', '40458 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40459', '2', '40459 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40460', '2', '40460 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40461', '2', '40461 1191182336 3 25229 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 41 4294967279 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40462', '2', '40462 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40463', '2', '40463 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40464', '2', '40464 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40465', '2', '40465 1191182336 3 3057 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40466', '2', '40466 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37506', '6', '37506 1191182336 3 858 1065353216 0 6 0 6 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37507', '6', '37507 1191182336 3 2318 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37508', '6', '37508 1191182336 3 4537 1065353216 0 6 0 6 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40507', '2', '40507 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38608', '2', '38608 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39784', '2', '39784 1191182336 3 5754 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38610', '2', '38610 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38611', '2', '38611 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38612', '2', '38612 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39783', '2', '39783 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40506', '2', '40506 1191182336 3 13911 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39782', '2', '39782 1191182336 3 36168 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 104 4294967288 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39781', '2', '39781 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39780', '2', '39780 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38618', '2', '38618 1191182336 3 13036 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39779', '2', '39779 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38620', '2', '38620 1191182336 3 31179 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 40 4294967284 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38621', '2', '38621 1191182336 3 44144 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40505', '2', '40505 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38623', '2', '38623 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38624', '2', '38624 1191182336 3 16680 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38625', '2', '38625 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39778', '2', '39778 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38627', '2', '38627 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39777', '2', '39777 1191182336 3 25270 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 12 4294967251 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38629', '2', '38629 1191182336 3 36281 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 78 4294967256 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38630', '2', '38630 1191182336 3 44147 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38632', '2', '38632 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39776', '2', '39776 1191182336 3 5742 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38635', '2', '38635 1191182336 3 3322 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38636', '2', '38636 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40504', '2', '40504 1191182336 3 36061 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 108 4294967260 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39775', '2', '39775 1191182336 3 38513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38639', '2', '38639 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39774', '2', '39774 1191182336 3 24938 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 4294967279 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38641', '2', '38641 1191182336 3 20677 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39773', '2', '39773 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39772', '2', '39772 1191182336 3 36162 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 56 4294967256 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39771', '2', '39771 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39770', '2', '39770 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38646', '2', '38646 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38647', '2', '38647 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39769', '2', '39769 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39768', '2', '39768 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38650', '2', '38650 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38651', '2', '38651 1191182336 3 5245 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39767', '2', '39767 1191182336 3 24621 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2820 0 0 0 0 0 0 0 0 0 0 0 33 4294967262 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39766', '2', '39766 1191182336 3 25061 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 23 4294967288 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38655', '2', '38655 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39765', '2', '39765 1191182336 3 36267 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 75 4294967256 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38657', '2', '38657 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39764', '2', '39764 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38659', '2', '38659 1191182336 3 24888 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 52 4294967256 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38660', '2', '38660 1191182336 3 1389 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39763', '2', '39763 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40503', '2', '40503 1191182336 3 24999 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 39 4294967282 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38663', '2', '38663 1191182336 3 16713 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39762', '2', '39762 1191182336 3 36050 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 56 4294967259 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38665', '2', '38665 1191182336 3 1959 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38666', '2', '38666 1191182336 3 6354 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39761', '2', '39761 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38668', '2', '38668 1191182336 3 753 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38669', '2', '38669 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39760', '2', '39760 1191182336 3 36276 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 78 4294967284 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39759', '2', '39759 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38672', '2', '38672 1191182336 3 6197 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38673', '2', '38673 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38674', '2', '38674 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38675', '2', '38675 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39758', '2', '39758 1191182336 3 14900 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 358 0 0 366 0 0 0 0 0 0 613 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38677', '2', '38677 1191182336 3 18300 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39757', '2', '39757 1191182336 3 36555 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 104 4294967252 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38679', '2', '38679 1191182336 3 18677 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40502', '2', '40502 1191182336 3 816 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39756', '2', '39756 1191182336 3 36456 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 56 4294967252 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38682', '2', '38682 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38683', '2', '38683 1191182336 3 24607 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 41 4294967277 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38684', '2', '38684 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39755', '2', '39755 1191182336 3 24836 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 31 4294967283 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38686', '2', '38686 1191182336 3 2971 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39754', '2', '39754 1191182336 3 35979 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 56 4294967280 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38688', '2', '38688 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39753', '2', '39753 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40501', '2', '40501 1191182336 3 13905 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39752', '2', '39752 1191182336 3 727 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 71 0 0 0 0 0 0 0 0 0 15 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39751', '2', '39751 1191182336 3 5079 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38693', '2', '38693 1191182336 3 18255 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38694', '2', '38694 1191182336 3 2057 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38695', '2', '38695 1191182336 3 4476 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39750', '2', '39750 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38697', '2', '38697 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38698', '2', '38698 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39749', '2', '39749 1191182336 3 826 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38700', '2', '38700 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38701', '2', '38701 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39748', '2', '39748 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39747', '2', '39747 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38704', '2', '38704 1191182336 3 24892 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 39 4294967256 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38705', '2', '38705 1191182336 3 9451 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39746', '2', '39746 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39745', '2', '39745 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38708', '2', '38708 1191182336 3 36457 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 58 4294967280 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39744', '2', '39744 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38712', '2', '38712 1191182336 3 36260 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 72 4294967290 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38713', '2', '38713 1191182336 3 36283 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 81 4294967280 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40013', '2', '40013 1191182336 3 31952 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40012', '2', '40012 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38716', '2', '38716 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38717', '2', '38717 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40011', '2', '40011 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38719', '2', '38719 1191182336 3 36653 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 33 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38720', '2', '38720 1191182336 3 24937 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 30 4294967290 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40010', '2', '40010 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38722', '2', '38722 1191182336 3 2079 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1584 0 0 0 0 0 0 0 0 0 1549 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38723', '2', '38723 1191182336 3 36049 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 75 4294967259 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38724', '2', '38724 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40009', '2', '40009 1191182336 3 756 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38726', '2', '38726 1191182336 3 24778 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 52 4294967283 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38727', '2', '38727 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38728', '2', '38728 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40008', '2', '40008 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40007', '2', '40007 1191182336 3 2084 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38731', '2', '38731 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38733', '2', '38733 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40006', '2', '40006 1191182336 3 36050 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 56 4294967281 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38735', '2', '38735 1191182336 3 4633 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38736', '2', '38736 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38737', '2', '38737 1191182336 3 20653 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 367 0 0 363 0 0 366 0 0 0 2154 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40005', '2', '40005 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38739', '2', '38739 1191182336 3 36027 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 69 4294967288 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38740', '2', '38740 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38741', '2', '38741 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40004', '2', '40004 1191182336 3 1300 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38743', '2', '38743 1191182336 3 6333 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40534', '2', '40534 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40533', '2', '40533 1191182336 3 9391 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38746', '2', '38746 1191182336 3 5750 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38747', '2', '38747 1191182336 3 2015 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40003', '2', '40003 1191182336 3 36570 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 46 4294967256 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38749', '2', '38749 1191182336 3 36612 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 108 4294967288 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38750', '2', '38750 1191182336 3 6198 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38751', '2', '38751 1191182336 3 36555 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 104 4294967256 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40002', '2', '40002 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40001', '2', '40001 1191182336 3 24667 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 39 4294967290 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38754', '2', '38754 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40000', '2', '40000 1191182336 3 25326 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 4294967279 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38756', '2', '38756 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39999', '2', '39999 1191182336 3 36385 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2825 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 4294967276 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38758', '2', '38758 1191182336 3 24685 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 42 4294967288 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39998', '2', '39998 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40532', '2', '40532 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38761', '2', '38761 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38762', '2', '38762 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38763', '2', '38763 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39997', '2', '39997 1191182336 3 5758 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38765', '2', '38765 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39996', '2', '39996 1191182336 3 2233 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38767', '2', '38767 1191182336 3 1220 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38768', '2', '38768 1191182336 3 36011 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 64 4294967288 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40531', '2', '40531 1191182336 3 36743 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39995', '2', '39995 1191182336 3 25271 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 13 4294967287 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39994', '2', '39994 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39993', '2', '39993 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38773', '2', '38773 1191182336 3 36153 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 72 4294967277 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39992', '2', '39992 1191182336 3 36148 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 72 4294967254 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38775', '2', '38775 1191182336 3 4478 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39991', '2', '39991 1191182336 3 1664 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38777', '2', '38777 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38778', '2', '38778 1191182336 3 28495 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2822 0 0 2804 0 0 0 0 0 0 0 0 34 4294967245 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39990', '2', '39990 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39989', '2', '39989 1191182336 3 24890 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 52 4294967283 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38782', '2', '38782 1191182336 3 36173 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 108 4294967287 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39988', '2', '39988 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38784', '2', '38784 1191182336 3 4636 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38785', '2', '38785 1191182336 3 36610 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 101 4294967283 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39987', '2', '39987 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40530', '2', '40530 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38788', '2', '38788 1191182336 3 1943 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39986', '2', '39986 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39985', '2', '39985 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38791', '2', '38791 1191182336 3 36471 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 58 4294967287 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39984', '2', '39984 1191182336 3 1287 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38793', '2', '38793 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38794', '2', '38794 1191182336 3 36266 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 54 4294967259 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38795', '2', '38795 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39983', '2', '39983 1191182336 3 10141 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1120 0 0 1070 0 0 0 0 0 0 887 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39982', '2', '39982 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40529', '2', '40529 1191182336 3 24837 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 23 4294967283 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38799', '2', '38799 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38800', '2', '38800 1191182336 3 36540 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 101 4294967252 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39981', '2', '39981 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39980', '2', '39980 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38803', '2', '38803 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39979', '2', '39979 1191182336 3 24601 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 40 4294967257 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39978', '2', '39978 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38806', '2', '38806 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38807', '2', '38807 1191182336 3 36527 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 45 4294967288 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39977', '2', '39977 1191182336 3 10401 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39976', '2', '39976 1191182336 3 24938 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 40 4294967260 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38810', '2', '38810 1191182336 3 36626 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 34 4294967285 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39975', '2', '39975 1191182336 3 18337 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38812', '2', '38812 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39974', '2', '39974 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38815', '2', '38815 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38816', '2', '38816 1191182336 3 2079 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2270 0 0 0 0 0 0 0 0 0 1990 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38817', '2', '38817 1191182336 3 832 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39973', '2', '39973 1191182336 3 9420 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38819', '2', '38819 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39972', '2', '39972 1191182336 3 10627 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39971', '2', '39971 1191182336 3 37771 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39970', '2', '39970 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39969', '2', '39969 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40528', '2', '40528 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38825', '2', '38825 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39968', '2', '39968 1191182336 3 2267 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38827', '2', '38827 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38828', '2', '38828 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39967', '2', '39967 1191182336 3 31234 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39966', '2', '39966 1191182336 3 36441 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 54 4294967252 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38831', '2', '38831 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39965', '2', '39965 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38833', '2', '38833 1191182336 3 3336 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38834', '2', '38834 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39964', '2', '39964 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38836', '2', '38836 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38837', '2', '38837 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38838', '2', '38838 1191182336 3 36388 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 78 4294967288 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39963', '2', '39963 1191182336 3 20261 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38840', '2', '38840 1191182336 3 36274 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 56 4294967285 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39962', '2', '39962 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39961', '2', '39961 1191182336 3 43696 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38843', '2', '38843 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39960', '2', '39960 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40527', '2', '40527 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39959', '2', '39959 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39958', '2', '39958 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38848', '2', '38848 1191182336 3 36637 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 30 4294967283 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38849', '2', '38849 1191182336 3 36176 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 108 4294967287 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39957', '2', '39957 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38851', '2', '38851 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39956', '2', '39956 1191182336 3 31191 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 30 4294967257 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38853', '2', '38853 1191182336 3 36457 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 58 4294967251 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38854', '2', '38854 1191182336 3 25200 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 17 4294967280 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40526', '2', '40526 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38856', '2', '38856 1191182336 3 36037 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 97 4294967258 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39955', '2', '39955 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38858', '2', '38858 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39954', '2', '39954 1191182336 3 34829 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38860', '2', '38860 1191182336 3 36157 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2817 0 0 0 0 0 0 0 0 0 0 0 101 4294967265 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39953', '2', '39953 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38862', '2', '38862 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39952', '2', '39952 1191182336 3 4723 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40525', '2', '40525 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38865', '2', '38865 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39951', '2', '39951 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38867', '2', '38867 1191182336 3 24719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 0 0 0 0 0 0 0 0 0 0 0 0 41 4294967278 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38868', '2', '38868 1191182336 3 25158 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 40 4294967285 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39950', '2', '39950 1191182336 3 18339 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39949', '2', '39949 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39948', '2', '39948 1191182336 3 34859 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39947', '2', '39947 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38873', '2', '38873 1191182336 3 36056 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 104 4294967280 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38874', '2', '38874 1191182336 3 1994 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 95 0 0 104 0 0 0 0 0 0 853 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40524', '2', '40524 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39946', '2', '39946 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38877', '2', '38877 1191182336 3 20408 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38878', '2', '38878 1191182336 3 36065 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 81 4294967258 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39945', '2', '39945 1191182336 3 1944 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38880', '2', '38880 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38881', '2', '38881 1191182336 3 25229 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 41 4294967255 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38882', '2', '38882 1191182336 3 36395 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 81 4294967253 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39944', '2', '39944 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38884', '2', '38884 1191182336 3 24669 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 40 4294967260 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38885', '2', '38885 1191182336 3 24724 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 23 4294967256 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38886', '2', '38886 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38888', '2', '38888 1191182336 3 6205 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38889', '2', '38889 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38890', '2', '38890 1191182336 3 36581 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 42 4294967251 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38891', '2', '38891 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39943', '2', '39943 1191182336 3 36611 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 104 4294967279 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38893', '2', '38893 1191182336 3 892 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38894', '2', '38894 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39942', '2', '39942 1191182336 3 6294 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39941', '2', '39941 1191182336 3 1318 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39940', '2', '39940 1191182336 3 31151 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40523', '2', '40523 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38899', '2', '38899 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39939', '2', '39939 1191182336 3 16685 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39938', '2', '39938 1191182336 3 36062 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 81 4294967287 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39937', '2', '39937 1191182336 3 12535 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39936', '2', '39936 1191182336 3 31189 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 30 4294967286 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38904', '2', '38904 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38905', '2', '38905 1191182336 3 36553 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 97 4294967290 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38906', '2', '38906 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40522', '2', '40522 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38908', '2', '38908 1191182336 3 25032 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 22 4294967252 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39935', '2', '39935 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39934', '2', '39934 1191182336 3 24934 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 30 4294967285 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38911', '2', '38911 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40284', '2', '40284 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40283', '2', '40283 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38914', '2', '38914 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38915', '2', '38915 1191182336 3 2226 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40282', '2', '40282 1191182336 3 4476 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38917', '2', '38917 1191182336 3 2265 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38918', '2', '38918 1191182336 3 32718 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38919', '2', '38919 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40578', '2', '40578 1191182336 3 24599 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 40 4294967290 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38921', '2', '38921 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38922', '2', '38922 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40281', '2', '40281 1191182336 3 24823 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 30 4294967256 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38924', '2', '38924 1191182336 3 36581 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 42 4294967279 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40577', '2', '40577 1191182336 3 36151 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 97 4294967283 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38926', '2', '38926 1191182336 3 36514 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 108 4294967291 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38927', '2', '38927 1191182336 3 2077 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 101 0 0 353 0 0 0 0 0 0 1029 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40280', '2', '40280 1191182336 3 36271 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 101 4294967252 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38930', '2', '38930 1191182336 3 36397 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 108 4294967283 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40279', '2', '40279 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40278', '2', '40278 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38933', '2', '38933 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38934', '2', '38934 1191182336 3 3341 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38935', '2', '38935 1191182336 3 1930 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40277', '2', '40277 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38937', '2', '38937 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38938', '2', '38938 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38939', '2', '38939 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40276', '2', '40276 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38941', '2', '38941 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40275', '2', '40275 1191182336 3 36165 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 104 4294967256 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38943', '2', '38943 1191182336 3 36154 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 54 4294967254 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38944', '2', '38944 1191182336 3 24716 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2821 0 0 0 0 0 0 0 0 0 0 0 22 4294967261 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40274', '2', '40274 1191182336 3 24827 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 4294967279 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40576', '2', '40576 1191182336 3 36283 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 81 4294967252 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40575', '2', '40575 1191182336 3 24599 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 40 4294967257 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40273', '2', '40273 1191182336 3 8303 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38949', '2', '38949 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40272', '2', '40272 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38951', '2', '38951 1191182336 3 24889 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 39 4294967257 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40271', '2', '40271 1191182336 3 25222 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 52 4294967251 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38954', '2', '38954 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38955', '2', '38955 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38956', '2', '38956 1191182336 3 36148 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 0 0 0 0 0 0 0 0 0 0 0 0 72 4294967278 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40270', '2', '40270 1191182336 3 6180 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40269', '2', '40269 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38959', '2', '38959 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40268', '2', '40268 1191182336 3 36682 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 46 4294967252 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40267', '2', '40267 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38962', '2', '38962 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40266', '2', '40266 1191182336 3 17963 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40265', '2', '40265 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38965', '2', '38965 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38966', '2', '38966 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38967', '2', '38967 1191182336 3 24599 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 40 4294967257 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40574', '2', '40574 1191182336 3 17969 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38969', '2', '38969 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40573', '2', '40573 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40572', '2', '40572 1191182336 3 1219 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38972', '2', '38972 1191182336 3 1927 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40264', '2', '40264 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38974', '2', '38974 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40263', '2', '40263 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40262', '2', '40262 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40261', '2', '40261 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40260', '2', '40260 1191182336 3 8251 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38979', '2', '38979 1191182336 3 8292 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38980', '2', '38980 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38981', '2', '38981 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38982', '2', '38982 1191182336 3 880 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38984', '2', '38984 1191182336 3 5743 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38985', '2', '38985 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40259', '2', '40259 1191182336 3 24837 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 23 4294967252 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40258', '2', '40258 1191182336 3 25033 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 23 4294967255 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40257', '2', '40257 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38989', '2', '38989 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40256', '2', '40256 1191182336 3 4723 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40255', '2', '40255 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38992', '2', '38992 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38993', '2', '38993 1191182336 3 24773 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 39 4294967256 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40571', '2', '40571 1191182336 3 24889 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 39 4294967256 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38995', '2', '38995 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40254', '2', '40254 1191182336 3 10141 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1121 0 0 1147 0 0 0 0 0 0 805 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38997', '2', '38997 1191182336 3 899 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40253', '2', '40253 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40252', '2', '40252 1191182336 3 24606 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 31 4294967259 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40251', '2', '40251 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40250', '2', '40250 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39003', '2', '39003 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39004', '2', '39004 1191182336 3 36066 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 4294967281 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39005', '2', '39005 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40249', '2', '40249 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39007', '2', '39007 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39008', '2', '39008 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40570', '2', '40570 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40248', '2', '40248 1191182336 3 24822 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 30 4294967283 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39011', '2', '39011 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39012', '2', '39012 1191182336 3 2168 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40247', '2', '40247 1191182336 3 1993 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40246', '2', '40246 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40245', '2', '40245 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39016', '2', '39016 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39017', '2', '39017 1191182336 3 36693 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 42 4294967252 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39018', '2', '39018 1191182336 3 31270 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2803 0 0 2804 0 0 0 0 0 0 0 0 2 4294967238 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40244', '2', '40244 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40243', '2', '40243 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40242', '2', '40242 1191182336 3 4476 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40569', '2', '40569 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39023', '2', '39023 1191182336 3 5743 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40568', '2', '40568 1191182336 3 36394 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 58 4294967290 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40567', '2', '40567 1191182336 3 36164 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 78 4294967256 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40241', '2', '40241 1191182336 3 2823 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39027', '2', '39027 1191182336 3 36166 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 78 4294967277 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40240', '2', '40240 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40239', '2', '40239 1191182336 3 8251 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39030', '2', '39030 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39031', '2', '39031 1191182336 3 5752 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40238', '2', '40238 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40237', '2', '40237 1191182336 3 1405 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40236', '2', '40236 1191182336 3 36054 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 78 4294967258 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40235', '2', '40235 1191182336 3 36486 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 46 4294967279 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40234', '2', '40234 1191182336 3 28495 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 34 4294967243 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40233', '2', '40233 1191182336 3 36668 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 34 4294967288 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40232', '2', '40232 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39040', '2', '39040 1191182336 3 25054 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 29 4294967291 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39041', '2', '39041 1191182336 3 886 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40231', '2', '40231 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40230', '2', '40230 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39044', '2', '39044 1191182336 3 3042 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39045', '2', '39045 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40229', '2', '40229 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40566', '2', '40566 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39048', '2', '39048 1191182336 3 28496 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2825 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 34 4294967239 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40228', '2', '40228 1191182336 3 2566 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40227', '2', '40227 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39051', '2', '39051 1191182336 3 36415 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 58 4294967258 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40226', '2', '40226 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39053', '2', '39053 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40225', '2', '40225 1191182336 3 24832 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 41 4294967257 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40224', '2', '40224 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40223', '2', '40223 1191182336 3 2167 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39057', '2', '39057 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39058', '2', '39058 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39059', '2', '39059 1191182336 3 3231 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39060', '2', '39060 1191182336 3 920 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39061', '2', '39061 1191182336 3 36514 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 108 4294967284 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40222', '2', '40222 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39063', '2', '39063 1191182336 3 36394 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 58 4294967253 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39064', '2', '39064 1191182336 3 15687 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 358 0 0 359 0 0 0 0 0 0 443 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39065', '2', '39065 1191182336 3 4723 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39066', '2', '39066 1191182336 3 28498 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2804 0 0 2813 0 0 0 0 0 0 0 0 34 4294967244 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40221', '2', '40221 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39068', '2', '39068 1191182336 3 2175 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39069', '2', '39069 1191182336 3 36568 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 43 4294967277 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39070', '2', '39070 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39071', '2', '39071 1191182336 3 2624 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40565', '2', '40565 1191182336 3 36598 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 108 4294967252 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39074', '2', '39074 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40220', '2', '40220 1191182336 3 36281 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 78 4294967256 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39076', '2', '39076 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40219', '2', '40219 1191182336 3 35987 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 58 4294967288 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40218', '2', '40218 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39079', '2', '39079 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40564', '2', '40564 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39081', '2', '39081 1191182336 3 3074 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40217', '2', '40217 1191182336 3 14901 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 351 0 0 353 0 0 0 0 0 0 1030 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39083', '2', '39083 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39084', '2', '39084 1191182336 3 36262 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 72 4294967286 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39085', '2', '39085 1191182336 3 24889 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2813 0 0 0 0 0 0 0 0 0 0 0 0 0 0 39 4294967269 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40216', '2', '40216 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39087', '2', '39087 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39088', '2', '39088 1191182336 3 36382 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 75 4294967259 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40215', '2', '40215 1191182336 3 36386 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 56 4294967282 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40214', '2', '40214 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39091', '2', '39091 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39092', '2', '39092 1191182336 3 25236 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 52 4294967260 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39093', '2', '39093 1191182336 3 36265 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2825 0 0 0 0 0 0 0 0 0 0 0 0 0 0 72 4294967276 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39094', '2', '39094 1191182336 3 36609 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 97 4294967256 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39095', '2', '39095 1191182336 3 36396 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 81 4294967287 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39096', '2', '39096 1191182336 3 24612 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 23 4294967277 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39097', '2', '39097 1191182336 3 914 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39098', '2', '39098 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39099', '2', '39099 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40213', '2', '40213 1191182336 3 36399 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 108 4294967253 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39101', '2', '39101 1191182336 3 36066 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 60 4294967257 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39102', '2', '39102 1191182336 3 25130 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 40 4294967288 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40212', '2', '40212 1191182336 3 24718 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 31 4294967290 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39104', '2', '39104 1191182336 3 31264 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2803 0 0 2804 0 0 0 0 0 0 0 0 5 4294967238 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39105', '2', '39105 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39106', '2', '39106 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40211', '2', '40211 1191182336 3 8246 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40563', '2', '40563 1191182336 3 24711 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 40 4294967283 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40210', '2', '40210 1191182336 3 1927 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40209', '2', '40209 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40208', '2', '40208 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39112', '2', '39112 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39743', '2', '39743 1191182336 3 4768 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40500', '2', '40500 1191182336 3 36997 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39742', '2', '39742 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40499', '2', '40499 1191182336 3 10407 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39741', '2', '39741 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39118', '2', '39118 1191182336 3 5029 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39119', '2', '39119 1191182336 3 25243 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 13 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39120', '2', '39120 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40498', '2', '40498 1191182336 3 9308 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39122', '2', '39122 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39123', '2', '39123 1191182336 3 25117 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 17 4294967252 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39740', '2', '39740 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39125', '2', '39125 1191182336 3 4477 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39739', '2', '39739 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39128', '2', '39128 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39129', '2', '39129 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39130', '2', '39130 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39738', '2', '39738 1191182336 3 31564 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 63 4294967254 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39737', '2', '39737 1191182336 3 5245 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39133', '2', '39133 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39736', '2', '39736 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39135', '2', '39135 1191182336 3 1944 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39136', '2', '39136 1191182336 3 25312 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 17 4294967288 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39735', '2', '39735 1191182336 3 31180 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39138', '2', '39138 1191182336 3 1218 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39139', '2', '39139 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39140', '2', '39140 1191182336 3 36284 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 81 4294967259 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39141', '2', '39141 1191182336 3 20408 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39734', '2', '39734 1191182336 3 31211 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 60 4294967257 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39733', '2', '39733 1191182336 3 8292 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39732', '2', '39732 1191182336 3 24603 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 30 4294967257 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39145', '2', '39145 1191182336 3 2073 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 68 0 0 0 0 0 0 0 0 0 6 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39731', '2', '39731 1191182336 3 3008 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40497', '2', '40497 1191182336 3 36159 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 101 4294967281 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39148', '2', '39148 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39149', '2', '39149 1191182336 3 4462 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39150', '2', '39150 1191182336 3 4660 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39730', '2', '39730 1191182336 3 4436 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39729', '2', '39729 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39153', '2', '39153 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39728', '2', '39728 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39155', '2', '39155 1191182336 3 3188 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39156', '2', '39156 1191182336 3 25054 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 29 4294967285 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39727', '2', '39727 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39158', '2', '39158 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39159', '2', '39159 1191182336 3 36444 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 60 4294967291 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39726', '2', '39726 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39161', '2', '39161 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39725', '2', '39725 1191182336 3 13035 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39163', '2', '39163 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39724', '2', '39724 1191182336 3 832 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40496', '2', '40496 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39166', '2', '39166 1191182336 3 25088 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 22 4294967288 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39167', '2', '39167 1191182336 3 25215 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 41 4294967286 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39168', '2', '39168 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39723', '2', '39723 1191182336 3 36595 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 97 4294967256 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39170', '2', '39170 1191182336 3 36665 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 30 4294967257 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40495', '2', '40495 1191182336 3 31952 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39172', '2', '39172 1191182336 3 32717 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39722', '2', '39722 1191182336 3 24601 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 40 4294967259 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39174', '2', '39174 1191182336 3 31268 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2825 0 0 2803 0 0 2802 0 0 0 0 0 0 0 0 2 4294967236 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39175', '2', '39175 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39176', '2', '39176 1191182336 3 25208 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 22 4294967291 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40494', '2', '40494 1191182336 3 12552 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39178', '2', '39178 1191182336 3 1355 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39721', '2', '39721 1191182336 3 12531 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39720', '2', '39720 1191182336 3 43695 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40493', '2', '40493 1191182336 3 31219 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 60 4294967289 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39182', '2', '39182 1191182336 3 36283 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 81 4294967259 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39183', '2', '39183 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39719', '2', '39719 1191182336 3 17055 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39185', '2', '39185 1191182336 3 2955 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39186', '2', '39186 1191182336 3 28498 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2804 0 0 2813 0 0 0 0 0 0 0 0 34 4294967244 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39718', '2', '39718 1191182336 3 9397 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39188', '2', '39188 1191182336 3 25138 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 52 4294967282 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39189', '2', '39189 1191182336 3 36486 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 46 4294967291 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39717', '2', '39717 1191182336 3 44505 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39716', '2', '39716 1191182336 3 10331 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39192', '2', '39192 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39715', '2', '39715 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39714', '2', '39714 1191182336 3 18600 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39713', '2', '39713 1191182336 3 6310 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39712', '2', '39712 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39197', '2', '39197 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39711', '2', '39711 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39710', '2', '39710 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39709', '2', '39709 1191182336 3 4477 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39201', '2', '39201 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39708', '2', '39708 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39203', '2', '39203 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40492', '2', '40492 1191182336 3 7755 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39707', '2', '39707 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39206', '2', '39206 1191182336 3 20694 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39706', '2', '39706 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39208', '2', '39208 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39705', '2', '39705 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39210', '2', '39210 1191182336 3 1679 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39211', '2', '39211 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39212', '2', '39212 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39213', '2', '39213 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39214', '2', '39214 1191182336 3 24714 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 40 4294967286 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39704', '2', '39704 1191182336 3 2055 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39703', '2', '39703 1191182336 3 20406 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39702', '2', '39702 1191182336 3 32716 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39218', '2', '39218 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39701', '2', '39701 1191182336 3 28452 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39700', '2', '39700 1191182336 3 24827 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 4294967281 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39699', '2', '39699 1191182336 3 35557 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39222', '2', '39222 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39223', '2', '39223 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39698', '2', '39698 1191182336 3 42780 1065353216 0 2 0 2 0 0 0 0 0 44 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39225', '2', '39225 1191182336 3 36279 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 104 4294967287 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39226', '2', '39226 1191182336 3 24892 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 39 4294967256 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40491', '2', '40491 1191182336 3 16672 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40490', '2', '40490 1191182336 3 2271 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39229', '2', '39229 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39697', '2', '39697 1191182336 3 43624 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39696', '2', '39696 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39232', '2', '39232 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39233', '2', '39233 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39234', '2', '39234 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39695', '2', '39695 1191182336 3 2742 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39236', '2', '39236 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39694', '2', '39694 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39693', '2', '39693 1191182336 3 3263 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40489', '2', '40489 1191182336 3 940 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39240', '2', '39240 1191182336 3 15687 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1119 0 0 0 0 0 0 0 0 0 384 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39241', '2', '39241 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39242', '2', '39242 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39243', '2', '39243 1191182336 3 25334 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 52 4294967255 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39244', '2', '39244 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39692', '2', '39692 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39691', '2', '39691 1191182336 3 20664 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 366 0 0 2317 0 0 2373 0 0 0 2153 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39690', '2', '39690 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39689', '2', '39689 1191182336 3 2730 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39249', '2', '39249 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39250', '2', '39250 1191182336 3 2073 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 74 0 0 0 0 0 0 0 0 0 14 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39251', '2', '39251 1191182336 3 14826 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39252', '2', '39252 1191182336 3 5742 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39688', '2', '39688 1191182336 3 1986 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39687', '2', '39687 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39686', '2', '39686 1191182336 3 5020 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39256', '2', '39256 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39685', '2', '39685 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39258', '2', '39258 1191182336 3 32716 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39259', '2', '39259 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39260', '2', '39260 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39261', '2', '39261 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39684', '2', '39684 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39683', '2', '39683 1191182336 3 20527 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39264', '2', '39264 1191182336 3 4638 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39682', '2', '39682 1191182336 3 25463 1065353216 0 2 0 2 0 0 0 0 0 140 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39681', '2', '39681 1191182336 3 16651 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39267', '2', '39267 1191182336 3 36389 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2822 0 0 2824 0 0 0 0 0 0 0 0 104 4294967229 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39268', '2', '39268 1191182336 3 4785 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39269', '2', '39269 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39680', '2', '39680 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39679', '2', '39679 1191182336 3 9428 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 96 0 0 104 0 0 0 0 0 0 854 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39678', '2', '39678 1191182336 3 9427 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39677', '2', '39677 1191182336 3 21592 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39274', '2', '39274 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39275', '2', '39275 1191182336 3 4632 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39276', '2', '39276 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39277', '2', '39277 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39676', '2', '39676 1191182336 3 17414 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39279', '2', '39279 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39280', '2', '39280 1191182336 3 24667 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 39 4294967287 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39281', '2', '39281 1191182336 3 25102 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 17 4294967285 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39282', '2', '39282 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39283', '2', '39283 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39284', '2', '39284 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39675', '2', '39675 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39674', '2', '39674 1191182336 3 31562 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 63 4294967257 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39673', '2', '39673 1191182336 3 1213 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39288', '2', '39288 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39672', '2', '39672 1191182336 3 1720 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39671', '2', '39671 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39291', '2', '39291 1191182336 3 14832 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39670', '2', '39670 1191182336 3 9759 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39669', '2', '39669 1191182336 3 14170 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39668', '2', '39668 1191182336 3 6643 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39295', '2', '39295 1191182336 3 4445 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39667', '2', '39667 1191182336 3 2034 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39297', '2', '39297 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39666', '2', '39666 1191182336 3 10578 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39665', '2', '39665 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39300', '2', '39300 1191182336 3 5753 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39301', '2', '39301 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39664', '2', '39664 1191182336 3 4694 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39303', '2', '39303 1191182336 3 816 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39304', '2', '39304 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39305', '2', '39305 1191182336 3 36708 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 101 4294967289 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39306', '2', '39306 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39307', '2', '39307 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39663', '2', '39663 1191182336 3 9486 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 95 95 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39662', '2', '39662 1191182336 3 1913 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39310', '2', '39310 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39661', '2', '39661 1191182336 3 35287 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39313', '2', '39313 1191182336 3 32715 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39933', '2', '39933 1191182336 3 36456 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 56 4294967255 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39315', '2', '39315 1191182336 3 3345 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39316', '2', '39316 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40521', '2', '40521 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39932', '2', '39932 1191182336 3 4465 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39931', '2', '39931 1191182336 3 2749 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39930', '2', '39930 1191182336 3 36667 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 33 4294967270 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39322', '2', '39322 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39929', '2', '39929 1191182336 3 10405 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39324', '2', '39324 1191182336 3 36382 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2813 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 4294967269 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39928', '2', '39928 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39326', '2', '39326 1191182336 3 1927 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39927', '2', '39927 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39926', '2', '39926 1191182336 3 6647 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39329', '2', '39329 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39330', '2', '39330 1191182336 3 28495 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2811 0 0 2803 0 0 2804 0 0 0 0 0 0 0 0 34 4294967241 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39331', '2', '39331 1191182336 3 36264 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 97 4294967252 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39925', '2', '39925 1191182336 3 44673 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 81 4294967254 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39924', '2', '39924 1191182336 3 10400 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39334', '2', '39334 1191182336 3 36011 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 64 4294967277 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39923', '2', '39923 1191182336 3 9375 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39922', '2', '39922 1191182336 3 36041 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2821 0 0 0 0 0 0 0 0 0 0 0 72 4294967261 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39338', '2', '39338 1191182336 3 2078 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 69 0 0 0 0 0 0 0 0 0 23 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39921', '2', '39921 1191182336 3 24999 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 39 4294967283 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39920', '2', '39920 1191182336 3 8292 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39919', '2', '39919 1191182336 3 31249 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 38 4294967290 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39918', '2', '39918 1191182336 3 1722 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39917', '2', '39917 1191182336 3 36056 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 104 4294967257 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39344', '2', '39344 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39916', '2', '39916 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39915', '2', '39915 1191182336 3 18296 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39914', '2', '39914 1191182336 3 3331 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39913', '2', '39913 1191182336 3 1973 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39912', '2', '39912 1191182336 3 24888 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2818 0 0 0 0 0 0 0 0 0 0 0 52 4294967264 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39350', '2', '39350 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39911', '2', '39911 1191182336 3 2754 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39910', '2', '39910 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39353', '2', '39353 1191182336 3 36270 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2813 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 4294967269 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39354', '2', '39354 1191182336 3 24607 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 41 4294967259 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39355', '2', '39355 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39356', '2', '39356 1191182336 3 24773 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2817 0 0 0 0 0 0 0 0 0 0 0 39 4294967265 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39357', '2', '39357 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39358', '2', '39358 1191182336 3 1664 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39909', '2', '39909 1191182336 3 13901 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39360', '2', '39360 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39361', '2', '39361 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39908', '2', '39908 1191182336 3 25874 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39363', '2', '39363 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39907', '2', '39907 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39906', '2', '39906 1191182336 3 16654 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39366', '2', '39366 1191182336 3 14826 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39367', '2', '39367 1191182336 3 4676 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40520', '2', '40520 1191182336 3 24669 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 40 4294967257 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39370', '2', '39370 1191182336 3 6360 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39371', '2', '39371 1191182336 3 1560 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39372', '2', '39372 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39905', '2', '39905 1191182336 3 44696 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 3727 0 0 2824 0 0 0 0 0 0 0 0 70 4294967206 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39374', '2', '39374 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39375', '2', '39375 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40519', '2', '40519 1191182336 3 897 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39904', '2', '39904 1191182336 3 3415 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39903', '2', '39903 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39902', '2', '39902 1191182336 3 18343 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39901', '2', '39901 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39381', '2', '39381 1191182336 3 5182 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39900', '2', '39900 1191182336 3 31125 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39383', '2', '39383 1191182336 3 36161 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 4294967279 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39899', '2', '39899 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39898', '2', '39898 1191182336 3 35836 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39386', '2', '39386 1191182336 3 24823 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2817 0 0 0 0 0 0 0 0 0 0 0 30 4294967265 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39387', '2', '39387 1191182336 3 24711 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 40 4294967284 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39897', '2', '39897 1191182336 3 6195 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39389', '2', '39389 1191182336 3 1280 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39896', '2', '39896 1191182336 3 37156 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39391', '2', '39391 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39895', '2', '39895 1191182336 3 44676 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 3727 0 0 2824 0 0 0 0 0 0 0 0 108 4294967206 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39393', '2', '39393 1191182336 3 1986 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39394', '2', '39394 1191182336 3 25040 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 29 4294967286 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40518', '2', '40518 1191182336 3 36066 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 60 4294967260 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39894', '2', '39894 1191182336 3 7754 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39397', '2', '39397 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39398', '2', '39398 1191182336 3 24608 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 31 4294967281 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39893', '2', '39893 1191182336 3 2018 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39400', '2', '39400 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39401', '2', '39401 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39892', '2', '39892 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39891', '2', '39891 1191182336 3 36485 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 45 4294967252 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39890', '2', '39890 1191182336 3 31231 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 40 4294967257 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39889', '2', '39889 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39888', '2', '39888 1191182336 3 13891 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39407', '2', '39407 1191182336 3 9327 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39887', '2', '39887 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39409', '2', '39409 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39410', '2', '39410 1191182336 3 36178 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 60 4294967286 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39411', '2', '39411 1191182336 3 36056 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 104 4294967287 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39412', '2', '39412 1191182336 3 35995 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 60 4294967287 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39413', '2', '39413 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40207', '2', '40207 1191182336 3 4716 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40206', '2', '40206 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39416', '2', '39416 1191182336 3 25299 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 17 4294967277 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11063', '9', '11063 1191182336 3 38147 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11065', '9', '11065 1191182336 3 41751 1065353216 0 9 0 9 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');

-- ----------------------------
-- Table structure for `item_loot`
-- ----------------------------
DROP TABLE IF EXISTS `item_loot`;
CREATE TABLE `item_loot` (
  `guid` int(11) unsigned NOT NULL default '0',
  `owner_guid` int(11) unsigned NOT NULL default '0',
  `itemid` int(11) unsigned NOT NULL default '0',
  `amount` int(11) unsigned NOT NULL default '0',
  `suffix` int(11) unsigned NOT NULL default '0',
  `property` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guid`,`itemid`),
  KEY `idx_owner_guid` (`owner_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Item System';

-- ----------------------------
-- Records of item_loot
-- ----------------------------

-- ----------------------------
-- Table structure for `item_soulbound_trade_data`
-- ----------------------------
DROP TABLE IF EXISTS `item_soulbound_trade_data`;
CREATE TABLE `item_soulbound_trade_data` (
  `itemGuid` int(16) unsigned NOT NULL default '0',
  `allowedPlayers` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`itemGuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='BOP item trade cache';

-- ----------------------------
-- Records of item_soulbound_trade_data
-- ----------------------------

-- ----------------------------
-- Table structure for `jail`
-- ----------------------------
DROP TABLE IF EXISTS `jail`;
CREATE TABLE `jail` (
  `guid` int(11) unsigned NOT NULL COMMENT 'GUID of the jail brother',
  `char` varchar(13) NOT NULL COMMENT 'Jailed charname',
  `release` int(11) unsigned NOT NULL COMMENT 'Release time for the char',
  `amnestietime` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL COMMENT 'Reason for the jail',
  `times` int(11) unsigned NOT NULL COMMENT 'How many times this char already was jailed',
  `gmacc` int(11) unsigned NOT NULL COMMENT 'Used GM acc to jail this char',
  `gmchar` varchar(13) NOT NULL COMMENT 'Used GM char to jail this char',
  `lasttime` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP COMMENT 'Last time jailed',
  `duration` int(11) unsigned NOT NULL default '0' COMMENT 'Duration of the jail',
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Jail table for MaNGOS by WarHead';

-- ----------------------------
-- Records of jail
-- ----------------------------

-- ----------------------------
-- Table structure for `jail_conf`
-- ----------------------------
DROP TABLE IF EXISTS `jail_conf`;
CREATE TABLE `jail_conf` (
  `id` int(11) NOT NULL auto_increment,
  `obt` varchar(50) default NULL,
  `jail_conf` int(11) default NULL,
  `jail_tele` float default NULL,
  `help_ger` varchar(255) character set latin1 default '',
  `help_enq` varchar(255) default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of jail_conf
-- ----------------------------
INSERT INTO `jail_conf` VALUES ('1', 'm_jailconf_max_jails', '3', null, 'Hier legst ihre fest nach wie fielen Jails der Char gelöscht werden \r\nStandart = 3\r\n ', '');
INSERT INTO `jail_conf` VALUES ('2', 'm_jailconf_max_duration', '672', null, 'Hier legst ihre fest wie hoch der maximale Jail Time in Stunden \r\nStandart = 672\r\n', '');
INSERT INTO `jail_conf` VALUES ('3', 'm_jailconf_min_reason', '25', null, 'Hier legst ihre die minimalen Zeichen fest die als Grund angeben müsst  \r\nStandart = 25\r\n\r\n', '');
INSERT INTO `jail_conf` VALUES ('4', 'm_jailconf_warn_player', '1', null, 'Hier legst ihre fest wann der Char gewarnt wirt  bevor er gelöscht wird \r\nStandart = 1\r\n', '');
INSERT INTO `jail_conf` VALUES ('5', 'm_jailconf_amnestie', '180', null, 'Hier legst ihre in Tagen fest wann der Jail Status  auf 0 zurückgesetzt wird   \r\nStandart = 180 Tage (das entspricht ca. ½ Jahr)  \r\n                     0  Tage (Aus )\r\n', '');
INSERT INTO `jail_conf` VALUES ('6', 'm_jailconf_ally_x', null, '31.7282', 'Teleport Alliance  X Achse \r\nStandart = 31,7282\r\n', '');
INSERT INTO `jail_conf` VALUES ('7', 'm_jailconf_ally_y', null, '135.794', 'Teleport Alliance  Y Achse \r\nStandart = 135,794\r\n', '');
INSERT INTO `jail_conf` VALUES ('8', 'm_jailconf_ally_z', null, '-40.0508', 'Teleport Alliance  Z Achse \r\nStandart = -40,0508', '');
INSERT INTO `jail_conf` VALUES ('9', 'm_jailconf_ally_o', null, '4.73516', 'Teleport Alliance  blickrichtung\r\nStandart = 4,73516', '');
INSERT INTO `jail_conf` VALUES ('10', 'm_jailconf_ally_m', '35', null, 'Teleport Alliance  Mape\r\nStandart = 35', '');
INSERT INTO `jail_conf` VALUES ('11', 'm_jailconf_horde_x', null, '2179.85', 'Teleport Horde  X Achse \r\nStandart = \r\n', '');
INSERT INTO `jail_conf` VALUES ('12', 'm_jailconf_horde_y', null, '-4763.96', 'Teleport Horde  Y Achse \r\nStandart = -4763,96', '');
INSERT INTO `jail_conf` VALUES ('13', 'm_jailconf_horde_z', null, '54.911', 'Teleport Horde  Z Achse \r\nStandart = 54,911', '');
INSERT INTO `jail_conf` VALUES ('14', 'm_jailconf_horde_o', null, '4.44216', 'Teleport  Horde  blickrichtung\r\nStandart = 4,44216', '');
INSERT INTO `jail_conf` VALUES ('15', 'm_jailconf_horde_m', '1', null, 'Teleport Horde  Mape\r\nStandart = 1', '');
INSERT INTO `jail_conf` VALUES ('16', 'm_jailconf_ban', '0', null, 'Nach wie vielen Jail soll der  Account Gebant werden\r\nStandart = 0  (aus)\r\n', '');
INSERT INTO `jail_conf` VALUES ('17', 'm_jailconf_radius', '10', null, 'Legt den Bewegung Radius in Metern waren des Jails fest\r\nStandart = 10\r\n', '');

-- ----------------------------
-- Table structure for `mail`
-- ----------------------------
DROP TABLE IF EXISTS `mail`;
CREATE TABLE `mail` (
  `id` int(11) unsigned NOT NULL default '0' COMMENT 'Identifier',
  `messageType` tinyint(3) unsigned NOT NULL default '0',
  `stationery` tinyint(3) NOT NULL default '41',
  `mailTemplateId` mediumint(8) unsigned NOT NULL default '0',
  `sender` int(11) unsigned NOT NULL default '0' COMMENT 'Character Global Unique Identifier',
  `receiver` int(11) unsigned NOT NULL default '0' COMMENT 'Character Global Unique Identifier',
  `subject` longtext,
  `body` longtext,
  `has_items` tinyint(3) unsigned NOT NULL default '0',
  `expire_time` bigint(40) NOT NULL default '0',
  `deliver_time` bigint(40) NOT NULL default '0',
  `money` int(11) unsigned NOT NULL default '0',
  `cod` int(11) unsigned NOT NULL default '0',
  `checked` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_receiver` (`receiver`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Mail System';

-- ----------------------------
-- Records of mail
-- ----------------------------
INSERT INTO `mail` VALUES ('2', '0', '61', '0', '2', '2', 'This item(s) have problems with equipping/storing in inventory.', 'There\'s were problems with equipping item(s).', '1', '1295796809', '1293204809', '0', '0', '2');
INSERT INTO `mail` VALUES ('3', '0', '61', '0', '7', '7', 'This item(s) have problems with equipping/storing in inventory.', 'There\'s were problems with equipping item(s).', '1', '1296188232', '1293596232', '0', '0', '4');
INSERT INTO `mail` VALUES ('4', '0', '61', '0', '7', '7', 'This item(s) have problems with equipping/storing in inventory.', 'There\'s were problems with equipping item(s).', '1', '1296188232', '1293596232', '0', '0', '4');

-- ----------------------------
-- Table structure for `mail_items`
-- ----------------------------
DROP TABLE IF EXISTS `mail_items`;
CREATE TABLE `mail_items` (
  `mail_id` int(11) NOT NULL default '0',
  `item_guid` int(11) NOT NULL default '0',
  `item_template` int(11) NOT NULL default '0',
  `receiver` int(11) unsigned NOT NULL default '0' COMMENT 'Character Global Unique Identifier',
  PRIMARY KEY  (`mail_id`,`item_guid`),
  KEY `idx_receiver` (`receiver`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of mail_items
-- ----------------------------
INSERT INTO `mail_items` VALUES ('2', '38', '1395', '2');
INSERT INTO `mail_items` VALUES ('2', '40', '6096', '2');
INSERT INTO `mail_items` VALUES ('2', '504', '47', '2');
INSERT INTO `mail_items` VALUES ('2', '506', '2092', '2');
INSERT INTO `mail_items` VALUES ('2', '508', '50055', '2');
INSERT INTO `mail_items` VALUES ('2', '512', '6948', '2');
INSERT INTO `mail_items` VALUES ('3', '9858', '34657', '7');
INSERT INTO `mail_items` VALUES ('3', '9854', '34656', '7');
INSERT INTO `mail_items` VALUES ('3', '9852', '34651', '7');
INSERT INTO `mail_items` VALUES ('3', '9848', '34653', '7');
INSERT INTO `mail_items` VALUES ('3', '9846', '34650', '7');
INSERT INTO `mail_items` VALUES ('3', '9842', '34655', '7');
INSERT INTO `mail_items` VALUES ('3', '380', '38147', '7');
INSERT INTO `mail_items` VALUES ('3', '370', '34658', '7');
INSERT INTO `mail_items` VALUES ('3', '366', '34648', '7');
INSERT INTO `mail_items` VALUES ('3', '360', '34649', '7');
INSERT INTO `mail_items` VALUES ('3', '354', '34659', '7');
INSERT INTO `mail_items` VALUES ('3', '350', '34652', '7');
INSERT INTO `mail_items` VALUES ('4', '374', '38145', '7');
INSERT INTO `mail_items` VALUES ('4', '9862', '38145', '7');
INSERT INTO `mail_items` VALUES ('4', '9866', '38145', '7');
INSERT INTO `mail_items` VALUES ('4', '9868', '38145', '7');

-- ----------------------------
-- Table structure for `pet_aura`
-- ----------------------------
DROP TABLE IF EXISTS `pet_aura`;
CREATE TABLE `pet_aura` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `caster_guid` bigint(20) unsigned NOT NULL default '0' COMMENT 'Full Global Unique Identifier',
  `item_guid` int(11) unsigned NOT NULL default '0',
  `spell` int(11) unsigned NOT NULL default '0',
  `stackcount` int(11) NOT NULL default '1',
  `remaincharges` int(11) NOT NULL default '0',
  `basepoints0` int(11) NOT NULL default '0',
  `basepoints1` int(11) NOT NULL default '0',
  `basepoints2` int(11) NOT NULL default '0',
  `maxduration0` int(11) NOT NULL default '0',
  `maxduration1` int(11) NOT NULL default '0',
  `maxduration2` int(11) NOT NULL default '0',
  `remaintime0` int(11) NOT NULL default '0',
  `remaintime1` int(11) NOT NULL default '0',
  `remaintime2` int(11) NOT NULL default '0',
  `effIndexMask` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guid`,`caster_guid`,`item_guid`,`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Pet System';

-- ----------------------------
-- Records of pet_aura
-- ----------------------------

-- ----------------------------
-- Table structure for `pet_spell`
-- ----------------------------
DROP TABLE IF EXISTS `pet_spell`;
CREATE TABLE `pet_spell` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `spell` int(11) unsigned NOT NULL default '0' COMMENT 'Spell Identifier',
  `active` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Pet System';

-- ----------------------------
-- Records of pet_spell
-- ----------------------------

-- ----------------------------
-- Table structure for `pet_spell_cooldown`
-- ----------------------------
DROP TABLE IF EXISTS `pet_spell_cooldown`;
CREATE TABLE `pet_spell_cooldown` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier, Low part',
  `spell` int(11) unsigned NOT NULL default '0' COMMENT 'Spell Identifier',
  `time` bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pet_spell_cooldown
-- ----------------------------

-- ----------------------------
-- Table structure for `petition`
-- ----------------------------
DROP TABLE IF EXISTS `petition`;
CREATE TABLE `petition` (
  `ownerguid` int(10) unsigned NOT NULL,
  `petitionguid` int(10) unsigned default '0',
  `name` varchar(255) NOT NULL default '',
  `type` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`ownerguid`,`type`),
  UNIQUE KEY `index_ownerguid_petitionguid` (`ownerguid`,`petitionguid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';

-- ----------------------------
-- Records of petition
-- ----------------------------

-- ----------------------------
-- Table structure for `petition_sign`
-- ----------------------------
DROP TABLE IF EXISTS `petition_sign`;
CREATE TABLE `petition_sign` (
  `ownerguid` int(10) unsigned NOT NULL,
  `petitionguid` int(11) unsigned NOT NULL default '0',
  `playerguid` int(11) unsigned NOT NULL default '0',
  `player_account` int(11) unsigned NOT NULL default '0',
  `type` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`petitionguid`,`playerguid`),
  KEY `Idx_playerguid` (`playerguid`),
  KEY `Idx_ownerguid` (`ownerguid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';

-- ----------------------------
-- Records of petition_sign
-- ----------------------------

-- ----------------------------
-- Table structure for `saved_variables`
-- ----------------------------
DROP TABLE IF EXISTS `saved_variables`;
CREATE TABLE `saved_variables` (
  `NextArenaPointDistributionTime` bigint(40) unsigned NOT NULL default '0',
  `NextDailyQuestResetTime` bigint(40) unsigned NOT NULL default '0',
  `NextWeeklyQuestResetTime` bigint(40) unsigned NOT NULL default '0',
  `NextRandomBGResetTime` bigint(40) unsigned NOT NULL default '0',
  `NextMonthlyQuestResetTime` bigint(40) unsigned NOT NULL default '0',
  `cleaning_flags` int(11) unsigned NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Variable Saves';

-- ----------------------------
-- Records of saved_variables
-- ----------------------------
INSERT INTO `saved_variables` VALUES ('0', '1294052400', '1294225200', '1294052400', '1296536400', '0');
INSERT INTO `saved_variables` VALUES ('0', '1294052400', '1294225200', '1294052400', '1296536400', '0');
INSERT INTO `saved_variables` VALUES ('0', '1294052400', '1294225200', '1294052400', '1296536400', '0');
