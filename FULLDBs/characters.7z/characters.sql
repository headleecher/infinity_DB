/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1_3306
Source Server Version : 50045
Source Host           : 127.0.0.1:3306
Source Database       : characters

Target Server Type    : MYSQL
Target Server Version : 50045
File Encoding         : 65001

Date: 2011-01-09 16:46:58
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `account_data`
-- ----------------------------
DROP TABLE IF EXISTS `account_data`;
CREATE TABLE `account_data` (
  `account` int(11) unsigned NOT NULL default '0',
  `type` int(11) unsigned NOT NULL default '0',
  `time` bigint(11) unsigned NOT NULL default '0',
  `data` longblob NOT NULL,
  PRIMARY KEY  (`account`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of account_data
-- ----------------------------
INSERT INTO `account_data` VALUES ('5', '0', '1291952975', 0x534554207363726970744572726F7273202231220A53455420666C61676765645475746F7269616C7320227601220A5345542063616D65726144697374616E63654D6178466163746F72202232220A5345542074616C656E744672616D6553686F776E202231220A);
INSERT INTO `account_data` VALUES ('5', '4', '1289771944', 0x4D4143524F2032202264616D22204162696C6974795F43726561747572655F446973656173655F30350D0A2E64616D616765203130303030300D0A454E440D0A4D4143524F2031202264696522204162696C6974795F43726561747572655F446973656173655F30320D0A2E6469650D0A454E440D0A4D4143524F20352022666C7922204162696C6974795F43726561747572655F4375727365645F30330D0A2E676D20666C79206F6E0D0A454E440D0A4D4143524F20342022696D6D6F7274616C22204162696C6974795F416D627573680D0A2E6D6F646966792068702039393939393939393939393939393939390D0A454E440D0A4D4143524F20332022737070656422204162696C6974795F43726561747572655F446973656173655F30330D0A2E6D6F6469667920737065656420390D0A454E440D0A);
INSERT INTO `account_data` VALUES ('6', '0', '1293995888', 0x534554207363726970744572726F7273202231220A53455420666C61676765645475746F7269616C732022760123234D23232523232623232423233A23232B23234523232823232A23235A23233823235B23233B23234B23232923235C23232D23233F23235E23235D23233723233123233C23234123234223232E23232F23234023233923234923234323232C23234F232344232346232330232333232336232335232334220A534554206C6F636B416374696F6E42617273202230220A5345542063616D65726156696577202235220A5345542063616D65726144697374616E63654D6178466163746F72202231220A);

-- ----------------------------
-- Table structure for `anticheat_config`
-- ----------------------------
DROP TABLE IF EXISTS `anticheat_config`;
CREATE TABLE `anticheat_config` (
  `checktype` mediumint(8) unsigned NOT NULL COMMENT 'Type of check',
  `description` varchar(255) default NULL,
  `check_period` int(11) unsigned NOT NULL default '0' COMMENT 'Time period of check, in ms, 0 - always',
  `alarmscount` int(11) unsigned NOT NULL default '1' COMMENT 'Count of alarms before action',
  `disableoperation` tinyint(3) unsigned NOT NULL default '0' COMMENT 'Anticheat disable operations in main core code after check fail',
  `messagenum` int(11) NOT NULL default '0' COMMENT 'Number of system message',
  `intparam1` mediumint(8) NOT NULL default '0' COMMENT 'Int parameter 1',
  `intparam2` mediumint(8) NOT NULL default '0' COMMENT 'Int parameter 2',
  `floatparam1` float NOT NULL default '0' COMMENT 'Float parameter 1',
  `floatparam2` float NOT NULL default '0' COMMENT 'Float parameter 2',
  `action1` mediumint(8) NOT NULL default '0' COMMENT 'Action 1',
  `actionparam1` mediumint(8) NOT NULL default '0' COMMENT 'Action parameter 1',
  `action2` mediumint(8) NOT NULL default '0' COMMENT 'Action 1',
  `actionparam2` mediumint(8) NOT NULL default '0' COMMENT 'Action parameter 1',
  PRIMARY KEY  (`checktype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 PACK_KEYS=0 COMMENT='Anticheat configuration';

-- ----------------------------
-- Records of anticheat_config
-- ----------------------------
INSERT INTO `anticheat_config` VALUES ('0', 'Null check', '0', '1', '0', '11000', '0', '0', '0', '0', '1', '0', '0', '0');
INSERT INTO `anticheat_config` VALUES ('1', 'Movement cheat', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('2', 'Spell cheat', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('3', 'Quest cheat', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('4', 'Transport cheat', '0', '3', '0', '11000', '0', '0', '60', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('5', 'Damage cheat', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('101', 'Speed hack', '500', '5', '0', '11000', '10000', '0', '0.0012', '0', '2', '1', '6', '20000');
INSERT INTO `anticheat_config` VALUES ('102', 'Fly hack', '500', '5', '0', '11000', '20000', '0', '10', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('103', 'Wall climb hack', '500', '2', '0', '11000', '10000', '0', '2.3', '2.37', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('104', 'Waterwalking hack', '1000', '3', '0', '11000', '20000', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('105', 'Teleport to plane hack', '500', '1', '0', '11000', '0', '0', '0.0001', '0.1', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('106', 'AirJump hack', '500', '3', '0', '11000', '30000', '0', '10', '25', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('107', 'Teleport hack', '0', '1', '0', '11000', '0', '0', '50', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('108', 'Fall hack', '0', '3', '0', '11000', '10000', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('201', 'Spell invalid', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('202', 'Spellcast in dead state', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('203', 'Spell not valid for player', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('204', 'Spell not in player book', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('501', 'Spell damage hack', '0', '1', '0', '11000', '0', '50000', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('502', 'Melee damage hack', '0', '1', '0', '11000', '0', '50000', '0', '0', '2', '1', '0', '0');

-- ----------------------------
-- Table structure for `anticheat_log`
-- ----------------------------
DROP TABLE IF EXISTS `anticheat_log`;
CREATE TABLE `anticheat_log` (
  `playername` varchar(32) NOT NULL,
  `checktype` mediumint(8) unsigned NOT NULL,
  `alarm_time` datetime NOT NULL,
  `reason` varchar(255) NOT NULL default 'Unknown',
  `guid` int(11) unsigned NOT NULL,
  `action1` mediumint(8) NOT NULL default '0',
  `action2` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`checktype`,`alarm_time`,`guid`),
  KEY `idx_Player` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Anticheat log table';

-- ----------------------------
-- Records of anticheat_log
-- ----------------------------
INSERT INTO `anticheat_log` VALUES ('Franklin', '106', '2010-11-26 22:19:43', 'AirJump hack Map Z = 64.112885, player Z = 108.896027, opcode MSG_MOVE_SET_FACING', '6', '2', '0');

-- ----------------------------
-- Table structure for `arena_team`
-- ----------------------------
DROP TABLE IF EXISTS `arena_team`;
CREATE TABLE `arena_team` (
  `arenateamid` int(10) unsigned NOT NULL default '0',
  `name` char(255) NOT NULL,
  `captainguid` int(10) unsigned NOT NULL default '0',
  `type` tinyint(3) unsigned NOT NULL default '0',
  `BackgroundColor` int(10) unsigned NOT NULL default '0',
  `EmblemStyle` int(10) unsigned NOT NULL default '0',
  `EmblemColor` int(10) unsigned NOT NULL default '0',
  `BorderStyle` int(10) unsigned NOT NULL default '0',
  `BorderColor` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`arenateamid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of arena_team
-- ----------------------------

-- ----------------------------
-- Table structure for `arena_team_member`
-- ----------------------------
DROP TABLE IF EXISTS `arena_team_member`;
CREATE TABLE `arena_team_member` (
  `arenateamid` int(10) unsigned NOT NULL default '0',
  `guid` int(10) unsigned NOT NULL default '0',
  `played_week` int(10) unsigned NOT NULL default '0',
  `wons_week` int(10) unsigned NOT NULL default '0',
  `played_season` int(10) unsigned NOT NULL default '0',
  `wons_season` int(10) unsigned NOT NULL default '0',
  `personal_rating` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`arenateamid`,`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of arena_team_member
-- ----------------------------

-- ----------------------------
-- Table structure for `arena_team_stats`
-- ----------------------------
DROP TABLE IF EXISTS `arena_team_stats`;
CREATE TABLE `arena_team_stats` (
  `arenateamid` int(10) unsigned NOT NULL default '0',
  `rating` int(10) unsigned NOT NULL default '0',
  `games_week` int(10) unsigned NOT NULL default '0',
  `wins_week` int(10) unsigned NOT NULL default '0',
  `games_season` int(10) unsigned NOT NULL default '0',
  `wins_season` int(10) unsigned NOT NULL default '0',
  `rank` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`arenateamid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of arena_team_stats
-- ----------------------------

-- ----------------------------
-- Table structure for `armory_character_stats`
-- ----------------------------
DROP TABLE IF EXISTS `armory_character_stats`;
CREATE TABLE `armory_character_stats` (
  `guid` int(11) NOT NULL,
  `data` longtext NOT NULL,
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='World of Warcraft Armory table';

-- ----------------------------
-- Records of armory_character_stats
-- ----------------------------

-- ----------------------------
-- Table structure for `armory_game_chart`
-- ----------------------------
DROP TABLE IF EXISTS `armory_game_chart`;
CREATE TABLE `armory_game_chart` (
  `gameid` int(11) NOT NULL,
  `teamid` int(11) NOT NULL,
  `guid` int(11) NOT NULL,
  `changeType` int(11) NOT NULL,
  `ratingChange` int(11) NOT NULL,
  `teamRating` int(11) NOT NULL,
  `damageDone` int(11) NOT NULL,
  `deaths` int(11) NOT NULL,
  `healingDone` int(11) NOT NULL,
  `damageTaken` int(11) NOT NULL,
  `healingTaken` int(11) NOT NULL,
  `killingBlows` int(11) NOT NULL,
  `mapId` int(11) NOT NULL,
  `start` int(11) NOT NULL,
  `end` int(11) NOT NULL,
  PRIMARY KEY  (`gameid`,`teamid`,`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='WoWArmory Game Chart';

-- ----------------------------
-- Records of armory_game_chart
-- ----------------------------

-- ----------------------------
-- Table structure for `auction`
-- ----------------------------
DROP TABLE IF EXISTS `auction`;
CREATE TABLE `auction` (
  `id` int(11) unsigned NOT NULL default '0',
  `houseid` int(11) unsigned NOT NULL default '0',
  `itemguid` int(11) unsigned NOT NULL default '0',
  `item_template` int(11) unsigned NOT NULL default '0' COMMENT 'Item Identifier',
  `itemowner` int(11) unsigned NOT NULL default '0',
  `buyoutprice` int(11) NOT NULL default '0',
  `time` bigint(40) NOT NULL default '0',
  `buyguid` int(11) unsigned NOT NULL default '0',
  `lastbid` int(11) NOT NULL default '0',
  `startbid` int(11) NOT NULL default '0',
  `deposit` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `item_guid` (`itemguid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of auction
-- ----------------------------
INSERT INTO `auction` VALUES ('4896', '2', '44511', '36178', '2', '1754825', '1294691559', '0', '0', '1702180', '0');
INSERT INTO `auction` VALUES ('5041', '2', '44656', '14897', '2', '186366', '1294644759', '0', '0', '184502', '0');
INSERT INTO `auction` VALUES ('4486', '2', '44101', '3164', '2', '415', '1294560657', '0', '0', '332', '0');
INSERT INTO `auction` VALUES ('4822', '6', '44437', '2291', '2', '8541528', '1294549918', '0', '0', '6833222', '0');
INSERT INTO `auction` VALUES ('4717', '2', '44332', '732', '2', '280', '1294571518', '0', '0', '254', '0');
INSERT INTO `auction` VALUES ('4754', '6', '44369', '867', '2', '1152968', '1294564318', '0', '0', '980022', '0');
INSERT INTO `auction` VALUES ('4821', '6', '44436', '940', '2', '2443458', '1294535518', '0', '0', '2296850', '0');
INSERT INTO `auction` VALUES ('4494', '6', '44109', '5524', '2', '780', '1294575057', '0', '0', '553', '0');
INSERT INTO `auction` VALUES ('4976', '2', '44591', '20532', '2', '121980', '1294648359', '0', '0', '93924', '0');
INSERT INTO `auction` VALUES ('4666', '2', '44281', '44165', '2', '115425', '1294560718', '0', '0', '95802', '0');
INSERT INTO `auction` VALUES ('4897', '2', '44512', '2018', '2', '220330', '1294637559', '0', '0', '213720', '0');
INSERT INTO `auction` VALUES ('4632', '2', '44247', '28492', '2', '2161375', '1294578718', '0', '0', '1945237', '0');
INSERT INTO `auction` VALUES ('4813', '6', '44428', '9719', '2', '372750', '1294564318', '0', '0', '354112', '0');
INSERT INTO `auction` VALUES ('4536', '7', '44151', '9719', '2', '388500', '1294571457', '0', '0', '306915', '0');
INSERT INTO `auction` VALUES ('4865', '6', '44480', '3340', '2', '1252', '1294535518', '0', '0', '1214', '0');
INSERT INTO `auction` VALUES ('5001', '2', '44616', '9719', '2', '351000', '1294666359', '0', '0', '287820', '0');
INSERT INTO `auction` VALUES ('4987', '2', '44602', '16676', '2', '1002383', '1294677159', '0', '0', '1002383', '0');
INSERT INTO `auction` VALUES ('4591', '2', '44206', '36384', '2', '4959040', '1294549918', '0', '0', '4363955', '0');
INSERT INTO `auction` VALUES ('4487', '6', '44102', '1613', '2', '794301', '1294575057', '0', '0', '651326', '0');
INSERT INTO `auction` VALUES ('4436', '6', '44050', '3019', '2', '21942', '1294501000', '0', '0', '21942', '0');
INSERT INTO `auction` VALUES ('5017', '2', '44632', '19943', '2', '219600', '1294666359', '0', '0', '210816', '0');
INSERT INTO `auction` VALUES ('5065', '2', '44680', '20692', '2', '574598', '1294677159', '0', '0', '528630', '0');
INSERT INTO `auction` VALUES ('4966', '2', '44581', '9375', '2', '273059', '1294648359', '0', '0', '212986', '0');
INSERT INTO `auction` VALUES ('4946', '2', '44561', '9719', '2', '416750', '1294687959', '0', '0', '366740', '0');
INSERT INTO `auction` VALUES ('4753', '6', '44368', '10625', '2', '2394560', '1294571518', '0', '0', '2250886', '0');
INSERT INTO `auction` VALUES ('4729', '2', '44344', '3164', '2', '3172', '1294557118', '0', '0', '2379', '0');
INSERT INTO `auction` VALUES ('4988', '2', '44603', '9719', '2', '412500', '1294651959', '0', '0', '342375', '0');
INSERT INTO `auction` VALUES ('4866', '6', '44481', '9719', '2', '421500', '1294557118', '0', '0', '400425', '0');
INSERT INTO `auction` VALUES ('4989', '2', '44604', '6549', '2', '800', '1294659159', '0', '0', '600', '0');
INSERT INTO `auction` VALUES ('4646', '2', '44261', '24822', '2', '1085884', '1294557118', '0', '0', '1053307', '0');
INSERT INTO `auction` VALUES ('4771', '6', '44386', '9719', '2', '316000', '1294539118', '0', '0', '278080', '0');
INSERT INTO `auction` VALUES ('4498', '6', '44113', '36273', '2', '2802132', '1294575057', '0', '0', '2493897', '0');
INSERT INTO `auction` VALUES ('5002', '2', '44617', '9719', '2', '377500', '1294691559', '0', '0', '324650', '0');
INSERT INTO `auction` VALUES ('4677', '2', '44292', '9719', '2', '343000', '1294549918', '0', '0', '274400', '0');
INSERT INTO `auction` VALUES ('4965', '2', '44580', '814', '2', '3458', '1294651959', '0', '0', '3319', '0');
INSERT INTO `auction` VALUES ('4378', '2', '43991', '1998', '2', '478550', '1294499190', '0', '0', '459408', '0');
INSERT INTO `auction` VALUES ('4791', '6', '44406', '4388', '2', '8600', '1294546318', '0', '0', '8342', '0');
INSERT INTO `auction` VALUES ('4636', '2', '44251', '18339', '2', '795942', '1294535518', '0', '0', '764104', '0');
INSERT INTO `auction` VALUES ('4710', '2', '44325', '37147', '2', '995', '1294578718', '0', '0', '696', '0');
INSERT INTO `auction` VALUES ('4581', '2', '44196', '4377', '2', '4800', '1294553518', '0', '0', '3456', '0');
INSERT INTO `auction` VALUES ('4973', '2', '44588', '31232', '2', '2763184', '1294677159', '0', '0', '2652656', '0');
INSERT INTO `auction` VALUES ('4790', '6', '44405', '31161', '2', '2533253', '1294535518', '0', '0', '1899939', '0');
INSERT INTO `auction` VALUES ('4608', '2', '44223', '2798', '2', '4280', '1294549918', '0', '0', '3680', '0');
INSERT INTO `auction` VALUES ('4777', '6', '44392', '9719', '2', '392250', '1294528318', '0', '0', '302032', '0');
INSERT INTO `auction` VALUES ('4975', '2', '44590', '25040', '2', '1266056', '1294644759', '0', '0', '1240734', '0');
INSERT INTO `auction` VALUES ('4841', '6', '44456', '9719', '2', '366000', '1294524718', '0', '0', '322080', '0');
INSERT INTO `auction` VALUES ('4964', '2', '44579', '3285', '2', '278', '1294641159', '0', '0', '227', '0');
INSERT INTO `auction` VALUES ('4788', '6', '44403', '9719', '2', '336000', '1294531918', '0', '0', '305760', '0');
INSERT INTO `auction` VALUES ('4868', '6', '44483', '9719', '2', '431750', '1294564318', '0', '0', '388575', '0');
INSERT INTO `auction` VALUES ('4512', '6', '44127', '1211', '2', '18468', '1294553457', '0', '0', '17359', '0');
INSERT INTO `auction` VALUES ('4867', '6', '44482', '7753', '2', '675229', '1294528318', '0', '0', '621210', '0');
INSERT INTO `auction` VALUES ('5005', '2', '44620', '35652', '2', '8349009', '1294691559', '0', '0', '7514108', '0');
INSERT INTO `auction` VALUES ('4559', '2', '44174', '1484', '2', '247251', '1294542718', '0', '0', '234888', '0');
INSERT INTO `auction` VALUES ('4799', '6', '44414', '9719', '2', '373000', '1294549918', '0', '0', '335700', '0');
INSERT INTO `auction` VALUES ('4640', '2', '44255', '868', '2', '2660402', '1294542718', '0', '0', '2287945', '0');
INSERT INTO `auction` VALUES ('4529', '7', '44144', '27516', '2', '16640', '1294531857', '0', '0', '15808', '0');
INSERT INTO `auction` VALUES ('4800', '6', '44415', '20531', '2', '67500', '1294539118', '0', '0', '64800', '0');
INSERT INTO `auction` VALUES ('4499', '6', '44114', '14549', '2', '2055186', '1294528257', '0', '0', '1705804', '0');
INSERT INTO `auction` VALUES ('4842', '6', '44457', '9719', '2', '364750', '1294564318', '0', '0', '342865', '0');
INSERT INTO `auction` VALUES ('4916', '2', '44531', '3022', '2', '72721', '1294677159', '0', '0', '72721', '0');
INSERT INTO `auction` VALUES ('4895', '2', '44510', '12528', '2', '2828031', '1294684359', '0', '0', '2234144', '0');
INSERT INTO `auction` VALUES ('4847', '6', '44462', '37770', '2', '4587520', '1294582318', '0', '0', '3945267', '0');
INSERT INTO `auction` VALUES ('4730', '2', '44345', '9719', '2', '373500', '1294564318', '0', '0', '298800', '0');
INSERT INTO `auction` VALUES ('4532', '7', '44147', '4474', '2', '285892', '1294528257', '0', '0', '265879', '0');
INSERT INTO `auction` VALUES ('4923', '2', '44538', '32470', '2', '86900', '1294651959', '0', '0', '79948', '0');
INSERT INTO `auction` VALUES ('4607', '2', '44222', '24589', '2', '513277', '1294528318', '0', '0', '410621', '0');
INSERT INTO `auction` VALUES ('4864', '6', '44479', '13882', '2', '585', '1294539118', '0', '0', '473', '0');
INSERT INTO `auction` VALUES ('4510', '6', '44125', '4636', '2', '4787', '1294578657', '0', '0', '4739', '0');
INSERT INTO `auction` VALUES ('4509', '6', '44124', '10561', '2', '57120', '1294531857', '0', '0', '52550', '0');
INSERT INTO `auction` VALUES ('4598', '2', '44213', '5967', '2', '10836', '1294546318', '0', '0', '8885', '0');
INSERT INTO `auction` VALUES ('4890', '2', '44505', '9719', '2', '384500', '1294680759', '0', '0', '322980', '0');
INSERT INTO `auction` VALUES ('4981', '2', '44596', '10567', '2', '545362', '1294644759', '0', '0', '512640', '0');
INSERT INTO `auction` VALUES ('4810', '6', '44425', '40199', '2', '7500', '1294535518', '0', '0', '6150', '0');
INSERT INTO `auction` VALUES ('5030', '2', '44645', '2046', '2', '133161', '1294669959', '0', '0', '133161', '0');
INSERT INTO `auction` VALUES ('5070', '2', '44685', '4394', '2', '33750', '1294669959', '0', '0', '24637', '0');
INSERT INTO `auction` VALUES ('4589', '2', '44204', '18295', '2', '853058', '1294575118', '0', '0', '639793', '0');
INSERT INTO `auction` VALUES ('4720', '2', '44335', '45998', '2', '475', '1294571518', '0', '0', '475', '0');
INSERT INTO `auction` VALUES ('4889', '2', '44504', '9719', '2', '389500', '1294677159', '0', '0', '331075', '0');
INSERT INTO `auction` VALUES ('4937', '2', '44552', '5742', '2', '498678', '1294677159', '0', '0', '458783', '0');
INSERT INTO `auction` VALUES ('4731', '2', '44346', '31247', '2', '2244235', '1294567918', '0', '0', '1885157', '0');
INSERT INTO `auction` VALUES ('4733', '2', '44348', '9755', '2', '578', '1294539118', '0', '0', '520', '0');
INSERT INTO `auction` VALUES ('4935', '2', '44550', '9719', '2', '359500', '1294677159', '0', '0', '316360', '0');
INSERT INTO `auction` VALUES ('4548', '2', '44163', '5257', '2', '250572', '1294531918', '0', '0', '207974', '0');
INSERT INTO `auction` VALUES ('5046', '2', '44661', '18709', '2', '367411', '1294684359', '0', '0', '297602', '0');
INSERT INTO `auction` VALUES ('4957', '2', '44572', '10561', '2', '24480', '1294669959', '0', '0', '22276', '0');
INSERT INTO `auction` VALUES ('4566', '2', '44181', '9719', '2', '328000', '1294535518', '0', '0', '311600', '0');
INSERT INTO `auction` VALUES ('4943', '2', '44558', '36382', '2', '2050030', '1294648359', '0', '0', '1722025', '0');
INSERT INTO `auction` VALUES ('4844', '6', '44459', '9719', '2', '350250', '1294564318', '0', '0', '304717', '0');
INSERT INTO `auction` VALUES ('4452', '7', '44067', '9719', '2', '357750', '1294501963', '0', '0', '325552', '0');
INSERT INTO `auction` VALUES ('4450', '6', '44065', '13917', '2', '1664', '1294498363', '0', '0', '1447', '0');
INSERT INTO `auction` VALUES ('4983', '2', '44598', '24724', '2', '736560', '1294655559', '0', '0', '692366', '0');
INSERT INTO `auction` VALUES ('4569', '2', '44184', '791', '2', '454928', '1294578718', '0', '0', '341196', '0');
INSERT INTO `auction` VALUES ('4990', '2', '44605', '36570', '2', '5123079', '1294666359', '0', '0', '4252155', '0');
INSERT INTO `auction` VALUES ('4625', '2', '44240', '11937', '2', '1767', '1294542718', '0', '0', '1590', '0');
INSERT INTO `auction` VALUES ('4501', '6', '44116', '37147', '2', '8700', '1294582257', '0', '0', '6786', '0');
INSERT INTO `auction` VALUES ('4535', '7', '44150', '27513', '2', '156', '1294571457', '0', '0', '120', '0');
INSERT INTO `auction` VALUES ('4539', '7', '44154', '9719', '2', '378000', '1294567857', '0', '0', '351540', '0');
INSERT INTO `auction` VALUES ('5013', '2', '44628', '4377', '2', '14580', '1294684359', '0', '0', '14580', '0');
INSERT INTO `auction` VALUES ('5007', '2', '44622', '4448', '2', '104978', '1294687959', '0', '0', '91330', '0');
INSERT INTO `auction` VALUES ('4734', '2', '44349', '40195', '2', '48300', '1294578718', '0', '0', '37191', '0');
INSERT INTO `auction` VALUES ('4689', '2', '44304', '18300', '2', '114560', '1294564318', '0', '0', '108832', '0');
INSERT INTO `auction` VALUES ('4673', '2', '44288', '12547', '2', '915713', '1294582318', '0', '0', '796670', '0');
INSERT INTO `auction` VALUES ('4491', '6', '44106', '2879', '2', '219406', '1294567857', '0', '0', '188689', '0');
INSERT INTO `auction` VALUES ('4768', '6', '44383', '13877', '2', '235', '1294542718', '0', '0', '169', '0');
INSERT INTO `auction` VALUES ('4708', '2', '44323', '40195', '2', '32700', '1294582318', '0', '0', '32373', '0');
INSERT INTO `auction` VALUES ('4568', '2', '44183', '5637', '2', '2376', '1294571518', '0', '0', '2043', '0');
INSERT INTO `auction` VALUES ('4461', '2', '44076', '14903', '2', '211331', '1294567857', '0', '0', '198651', '0');
INSERT INTO `auction` VALUES ('4719', '2', '44334', '6332', '2', '78408', '1294539118', '0', '0', '68214', '0');
INSERT INTO `auction` VALUES ('5044', '2', '44659', '12804', '2', '128880', '1294662759', '0', '0', '95371', '0');
INSERT INTO `auction` VALUES ('4855', '6', '44470', '18709', '2', '471933', '1294582318', '0', '0', '368107', '0');
INSERT INTO `auction` VALUES ('4881', '2', '44496', '27516', '2', '3700', '1294662759', '0', '0', '2664', '0');
INSERT INTO `auction` VALUES ('4637', '2', '44252', '4388', '2', '9840', '1294553518', '0', '0', '8659', '0');
INSERT INTO `auction` VALUES ('4863', '6', '44478', '2257', '2', '1426', '1294546318', '0', '0', '1155', '0');
INSERT INTO `auction` VALUES ('4711', '2', '44326', '25416', '2', '164160', '1294549918', '0', '0', '131328', '0');
INSERT INTO `auction` VALUES ('4571', '2', '44186', '9719', '2', '411500', '1294542718', '0', '0', '341545', '0');
INSERT INTO `auction` VALUES ('4958', '2', '44573', '34826', '2', '1020000', '1294673559', '0', '0', '877200', '0');
INSERT INTO `auction` VALUES ('4806', '6', '44421', '1475', '2', '3828', '1294535518', '0', '0', '2985', '0');
INSERT INTO `auction` VALUES ('4621', '2', '44236', '14554', '2', '6166752', '1294542718', '0', '0', '5056736', '0');
INSERT INTO `auction` VALUES ('4840', '6', '44455', '37761', '2', '2093776', '1294542718', '0', '0', '1675020', '0');
INSERT INTO `auction` VALUES ('4664', '2', '44279', '9719', '2', '327250', '1294557118', '0', '0', '258527', '0');
INSERT INTO `auction` VALUES ('4834', '6', '44449', '3280', '2', '283', '1294553518', '0', '0', '240', '0');
INSERT INTO `auction` VALUES ('4701', '2', '44316', '6364', '2', '2715', '1294524718', '0', '0', '2470', '0');
INSERT INTO `auction` VALUES ('4837', '6', '44452', '16653', '2', '532', '1294542718', '0', '0', '393', '0');
INSERT INTO `auction` VALUES ('4732', '2', '44347', '21882', '2', '190400', '1294571518', '0', '0', '150416', '0');
INSERT INTO `auction` VALUES ('4749', '6', '44364', '4402', '2', '6840', '1294575118', '0', '0', '5198', '0');
INSERT INTO `auction` VALUES ('5067', '2', '44682', '37159', '2', '3195', '1294677159', '0', '0', '3099', '0');
INSERT INTO `auction` VALUES ('4587', '2', '44202', '2108', '2', '81', '1294578718', '0', '0', '76', '0');
INSERT INTO `auction` VALUES ('4630', '2', '44245', '9719', '2', '348750', '1294528318', '0', '0', '275512', '0');
INSERT INTO `auction` VALUES ('4688', '2', '44303', '44676', '2', '5137759', '1294557118', '0', '0', '4521227', '0');
INSERT INTO `auction` VALUES ('4459', '2', '44074', '17414', '2', '1000640', '1294535457', '0', '0', '890569', '0');
INSERT INTO `auction` VALUES ('4484', '2', '44099', '29426', '2', '252992', '1294524657', '0', '0', '184684', '0');
INSERT INTO `auction` VALUES ('5023', '2', '44638', '40199', '2', '2416', '1294680759', '0', '0', '1739', '0');
INSERT INTO `auction` VALUES ('4979', '2', '44594', '5523', '2', '1323', '1294680759', '0', '0', '1018', '0');
INSERT INTO `auction` VALUES ('4899', '2', '44514', '2732', '2', '12000', '1294659159', '0', '0', '10080', '0');
INSERT INTO `auction` VALUES ('4917', '2', '44532', '9719', '2', '376250', '1294655559', '0', '0', '364962', '0');
INSERT INTO `auction` VALUES ('5022', '2', '44637', '36027', '2', '824353', '1294680759', '0', '0', '684212', '0');
INSERT INTO `auction` VALUES ('4626', '2', '44241', '27513', '2', '176', '1294549918', '0', '0', '168', '0');
INSERT INTO `auction` VALUES ('4853', '6', '44468', '9719', '2', '360250', '1294560718', '0', '0', '324225', '0');
INSERT INTO `auction` VALUES ('4761', '6', '44376', '31212', '2', '2718188', '1294535518', '0', '0', '2093004', '0');
INSERT INTO `auction` VALUES ('4926', '2', '44541', '18337', '2', '448917', '1294669959', '0', '0', '413003', '0');
INSERT INTO `auction` VALUES ('5066', '2', '44681', '6359', '2', '101', '1294662759', '0', '0', '99', '0');
INSERT INTO `auction` VALUES ('4709', '2', '44324', '9061', '2', '14560', '1294531918', '0', '0', '13832', '0');
INSERT INTO `auction` VALUES ('4555', '2', '44170', '9719', '2', '329500', '1294557118', '0', '0', '293255', '0');
INSERT INTO `auction` VALUES ('4848', '6', '44463', '9719', '2', '390500', '1294542718', '0', '0', '331925', '0');
INSERT INTO `auction` VALUES ('4824', '6', '44439', '1388', '2', '156', '1294542718', '0', '0', '151', '0');
INSERT INTO `auction` VALUES ('4766', '6', '44381', '4677', '2', '537', '1294524718', '0', '0', '418', '0');
INSERT INTO `auction` VALUES ('4944', '2', '44559', '19943', '2', '366320', '1294695159', '0', '0', '267413', '0');
INSERT INTO `auction` VALUES ('4764', '6', '44379', '31291', '2', '8043055', '1294542718', '0', '0', '6032291', '0');
INSERT INTO `auction` VALUES ('5036', '2', '44651', '9393', '2', '511731', '1294684359', '0', '0', '388915', '0');
INSERT INTO `auction` VALUES ('4845', '6', '44460', '39681', '2', '77952', '1294553518', '0', '0', '77172', '0');
INSERT INTO `auction` VALUES ('4828', '6', '44443', '7753', '2', '518135', '1294542718', '0', '0', '455958', '0');
INSERT INTO `auction` VALUES ('5020', '2', '44635', '4660', '2', '13243', '1294662759', '0', '0', '10726', '0');
INSERT INTO `auction` VALUES ('4597', '2', '44212', '811', '2', '6871016', '1294535518', '0', '0', '6458755', '0');
INSERT INTO `auction` VALUES ('4610', '2', '44225', '45909', '2', '71744', '1294528318', '0', '0', '69591', '0');
INSERT INTO `auction` VALUES ('4970', '2', '44585', '9719', '2', '328750', '1294637559', '0', '0', '253137', '0');
INSERT INTO `auction` VALUES ('4914', '2', '44529', '7786', '2', '372211', '1294695159', '0', '0', '312657', '0');
INSERT INTO `auction` VALUES ('4599', '2', '44214', '811', '2', '10781460', '1294578718', '0', '0', '9918943', '0');
INSERT INTO `auction` VALUES ('4518', '6', '44133', '36781', '2', '29440', '1294571457', '0', '0', '27968', '0');
INSERT INTO `auction` VALUES ('4858', '6', '44473', '10505', '2', '43380', '1294524718', '0', '0', '36873', '0');
INSERT INTO `auction` VALUES ('4369', '2', '43982', '36046', '2', '1034514', '1294499190', '0', '0', '920717', '0');
INSERT INTO `auction` VALUES ('4728', '2', '44343', '25744', '2', '102573', '1294549918', '0', '0', '100521', '0');
INSERT INTO `auction` VALUES ('4623', '2', '44238', '24401', '2', '771720', '1294524718', '0', '0', '563355', '0');
INSERT INTO `auction` VALUES ('4681', '2', '44296', '44475', '2', '172', '1294575118', '0', '0', '135', '0');
INSERT INTO `auction` VALUES ('4595', '2', '44210', '9719', '2', '421500', '1294571518', '0', '0', '408855', '0');
INSERT INTO `auction` VALUES ('4910', '2', '44525', '22277', '2', '15', '1294637559', '0', '0', '13', '0');
INSERT INTO `auction` VALUES ('4580', '2', '44195', '36003', '2', '997276', '1294535518', '0', '0', '887575', '0');
INSERT INTO `auction` VALUES ('4759', '6', '44374', '20698', '2', '10377812', '1294539118', '0', '0', '8509805', '0');
INSERT INTO `auction` VALUES ('4671', '2', '44286', '9719', '2', '402000', '1294535518', '0', '0', '301500', '0');
INSERT INTO `auction` VALUES ('4765', '6', '44380', '13874', '2', '7', '1294582318', '0', '0', '5', '0');
INSERT INTO `auction` VALUES ('4670', '2', '44285', '9719', '2', '400500', '1294571518', '0', '0', '308385', '0');
INSERT INTO `auction` VALUES ('5045', '2', '44660', '44649', '2', '3435192', '1294684359', '0', '0', '2988617', '0');
INSERT INTO `auction` VALUES ('4721', '2', '44336', '10562', '2', '79560', '1294575118', '0', '0', '69217', '0');
INSERT INTO `auction` VALUES ('4572', '2', '44187', '20544', '2', '198000', '1294535518', '0', '0', '192060', '0');
INSERT INTO `auction` VALUES ('4478', '2', '44093', '10560', '2', '55040', '1294557057', '0', '0', '47334', '0');
INSERT INTO `auction` VALUES ('4814', '6', '44429', '28531', '2', '1462699', '1294557118', '0', '0', '1243294', '0');
INSERT INTO `auction` VALUES ('4678', '2', '44293', '920', '2', '129643', '1294557118', '0', '0', '119271', '0');
INSERT INTO `auction` VALUES ('4635', '2', '44250', '10562', '2', '99900', '1294539118', '0', '0', '87912', '0');
INSERT INTO `auction` VALUES ('4577', '2', '44192', '1713', '2', '364228', '1294542718', '0', '0', '342374', '0');
INSERT INTO `auction` VALUES ('4802', '6', '44417', '9719', '2', '417250', '1294575118', '0', '0', '413077', '0');
INSERT INTO `auction` VALUES ('4656', '2', '44271', '31183', '2', '2552298', '1294578718', '0', '0', '2220499', '0');
INSERT INTO `auction` VALUES ('4563', '2', '44178', '1677', '2', '628806', '1294567918', '0', '0', '609941', '0');
INSERT INTO `auction` VALUES ('4955', '2', '44570', '9719', '2', '386250', '1294666359', '0', '0', '312862', '0');
INSERT INTO `auction` VALUES ('4999', '2', '44614', '18339', '2', '458803', '1294641159', '0', '0', '403746', '0');
INSERT INTO `auction` VALUES ('4903', '2', '44518', '1219', '2', '36453', '1294687959', '0', '0', '30255', '0');
INSERT INTO `auction` VALUES ('4658', '2', '44273', '4263', '2', '747', '1294578718', '0', '0', '702', '0');
INSERT INTO `auction` VALUES ('4972', '2', '44587', '37452', '2', '69360', '1294680759', '0', '0', '63117', '0');
INSERT INTO `auction` VALUES ('5000', '2', '44615', '6358', '2', '432', '1294648359', '0', '0', '388', '0');
INSERT INTO `auction` VALUES ('4818', '6', '44433', '31562', '2', '3375215', '1294582318', '0', '0', '2598915', '0');
INSERT INTO `auction` VALUES ('4537', '7', '44152', '790', '2', '139898', '1294546257', '0', '0', '111918', '0');
INSERT INTO `auction` VALUES ('4538', '7', '44153', '9719', '2', '334250', '1294571457', '0', '0', '254030', '0');
INSERT INTO `auction` VALUES ('5059', '2', '44674', '4611', '2', '5312', '1294669959', '0', '0', '3930', '0');
INSERT INTO `auction` VALUES ('4906', '2', '44521', '8151', '2', '14280', '1294662759', '0', '0', '13280', '0');
INSERT INTO `auction` VALUES ('4905', '2', '44520', '36484', '2', '6021847', '1294644759', '0', '0', '5720754', '0');
INSERT INTO `auction` VALUES ('4475', '2', '44090', '9719', '2', '314750', '1294528257', '0', '0', '289570', '0');
INSERT INTO `auction` VALUES ('4947', '2', '44562', '9262', '2', '82400', '1294662759', '0', '0', '57680', '0');
INSERT INTO `auction` VALUES ('4740', '2', '44355', '9719', '2', '415500', '1294578718', '0', '0', '386415', '0');
INSERT INTO `auction` VALUES ('4489', '6', '44104', '16649', '2', '412', '1294531857', '0', '0', '379', '0');
INSERT INTO `auction` VALUES ('4892', '2', '44507', '8152', '2', '65400', '1294644759', '0', '0', '60822', '0');
INSERT INTO `auction` VALUES ('5018', '2', '44633', '864', '2', '563539', '1294695159', '0', '0', '529726', '0');
INSERT INTO `auction` VALUES ('4644', '2', '44259', '8151', '2', '12150', '1294557118', '0', '0', '10449', '0');
INSERT INTO `auction` VALUES ('4873', '6', '44488', '31246', '2', '2307674', '1294531918', '0', '0', '1961522', '0');
INSERT INTO `auction` VALUES ('5037', '2', '44652', '24668', '2', '919524', '1294644759', '0', '0', '818376', '0');
INSERT INTO `auction` VALUES ('5069', '2', '44684', '4377', '2', '12960', '1294666359', '0', '0', '10368', '0');
INSERT INTO `auction` VALUES ('4794', '6', '44409', '9486', '2', '438413', '1294549918', '0', '0', '333193', '0');
INSERT INTO `auction` VALUES ('4705', '2', '44320', '10505', '2', '23430', '1294582318', '0', '0', '23430', '0');
INSERT INTO `auction` VALUES ('4596', '2', '44211', '30810', '2', '402480', '1294557118', '0', '0', '394430', '0');
INSERT INTO `auction` VALUES ('5060', '2', '44675', '2226', '2', '222166', '1294637559', '0', '0', '215501', '0');
INSERT INTO `auction` VALUES ('4574', '2', '44189', '6887', '2', '11160', '1294571518', '0', '0', '10936', '0');
INSERT INTO `auction` VALUES ('4939', '2', '44554', '36682', '2', '6264294', '1294662759', '0', '0', '5199364', '0');
INSERT INTO `auction` VALUES ('4830', '6', '44445', '35641', '2', '3769257', '1294578718', '0', '0', '3166175', '0');
INSERT INTO `auction` VALUES ('4888', '2', '44503', '9719', '2', '411000', '1294680759', '0', '0', '386340', '0');
INSERT INTO `auction` VALUES ('4982', '2', '44597', '814', '2', '1547', '1294662759', '0', '0', '1345', '0');
INSERT INTO `auction` VALUES ('4891', '2', '44506', '10402', '2', '16756', '1294651959', '0', '0', '15247', '0');
INSERT INTO `auction` VALUES ('4676', '2', '44291', '9719', '2', '394750', '1294582318', '0', '0', '296062', '0');
INSERT INTO `auction` VALUES ('4787', '6', '44402', '9719', '2', '403750', '1294524718', '0', '0', '399712', '0');
INSERT INTO `auction` VALUES ('4691', '2', '44306', '35666', '2', '2505680', '1294535518', '0', '0', '2204998', '0');
INSERT INTO `auction` VALUES ('5061', '2', '44676', '6359', '2', '49', '1294677159', '0', '0', '36', '0');
INSERT INTO `auction` VALUES ('5053', '2', '44668', '28495', '2', '833953', '1294655559', '0', '0', '808934', '0');
INSERT INTO `auction` VALUES ('5062', '2', '44677', '25254', '2', '2207145', '1294655559', '0', '0', '2140930', '0');
INSERT INTO `auction` VALUES ('4722', '2', '44337', '9719', '2', '383000', '1294578718', '0', '0', '287250', '0');
INSERT INTO `auction` VALUES ('4851', '6', '44466', '25268', '2', '2259442', '1294571518', '0', '0', '1897931', '0');
INSERT INTO `auction` VALUES ('4611', '2', '44226', '2066', '2', '754', '1294578718', '0', '0', '573', '0');
INSERT INTO `auction` VALUES ('4921', '2', '44536', '9719', '2', '428500', '1294648359', '0', '0', '419930', '0');
INSERT INTO `auction` VALUES ('5004', '2', '44619', '31220', '2', '1794903', '1294669959', '0', '0', '1364126', '0');
INSERT INTO `auction` VALUES ('4552', '2', '44167', '36639', '2', '5265821', '1294578718', '0', '0', '5055188', '0');
INSERT INTO `auction` VALUES ('4546', '2', '44161', '44700', '2', '5125', '1294531918', '0', '0', '4868', '0');
INSERT INTO `auction` VALUES ('4904', '2', '44519', '7072', '2', '5724', '1294691559', '0', '0', '4121', '0');
INSERT INTO `auction` VALUES ('4655', '2', '44270', '7072', '2', '6480', '1294575118', '0', '0', '6350', '0');
INSERT INTO `auction` VALUES ('4702', '2', '44317', '9719', '2', '347500', '1294524718', '0', '0', '305800', '0');
INSERT INTO `auction` VALUES ('4615', '2', '44230', '1169', '2', '4108298', '1294578718', '0', '0', '3820717', '0');
INSERT INTO `auction` VALUES ('4575', '2', '44190', '16710', '2', '700404', '1294539118', '0', '0', '679391', '0');
INSERT INTO `auction` VALUES ('4472', '2', '44087', '9719', '2', '360250', '1294531857', '0', '0', '270187', '0');
INSERT INTO `auction` VALUES ('4724', '2', '44339', '31254', '2', '1749033', '1294539118', '0', '0', '1696562', '0');
INSERT INTO `auction` VALUES ('4962', '2', '44577', '9719', '2', '399750', '1294659159', '0', '0', '335790', '0');
INSERT INTO `auction` VALUES ('4470', '2', '44085', '21114', '2', '724', '1294524657', '0', '0', '615', '0');
INSERT INTO `auction` VALUES ('4704', '2', '44319', '36781', '2', '19872', '1294535518', '0', '0', '14109', '0');
INSERT INTO `auction` VALUES ('5054', '2', '44669', '5635', '2', '316', '1294644759', '0', '0', '246', '0');
INSERT INTO `auction` VALUES ('4485', '2', '44100', '20545', '2', '14700', '1294582257', '0', '0', '10878', '0');
INSERT INTO `auction` VALUES ('4519', '6', '44134', '6359', '2', '551', '1294582257', '0', '0', '429', '0');
INSERT INTO `auction` VALUES ('4789', '6', '44404', '30733', '2', '17343964', '1294564318', '0', '0', '15089248', '0');
INSERT INTO `auction` VALUES ('5050', '2', '44665', '44700', '2', '4825', '1294651959', '0', '0', '3860', '0');
INSERT INTO `auction` VALUES ('4645', '2', '44260', '14170', '2', '3707', '1294567918', '0', '0', '2928', '0');
INSERT INTO `auction` VALUES ('4590', '2', '44205', '3475', '2', '4314136', '1294567918', '0', '0', '3753298', '0');
INSERT INTO `auction` VALUES ('4932', '2', '44547', '4660', '2', '14152', '1294680759', '0', '0', '11746', '0');
INSERT INTO `auction` VALUES ('4758', '6', '44373', '1288', '2', '3048', '1294557118', '0', '0', '2438', '0');
INSERT INTO `auction` VALUES ('4642', '2', '44257', '9719', '2', '396750', '1294546318', '0', '0', '301530', '0');
INSERT INTO `auction` VALUES ('4483', '2', '44098', '2167', '2', '20809', '1294549857', '0', '0', '18728', '0');
INSERT INTO `auction` VALUES ('4516', '6', '44131', '4449', '2', '172451', '1294582257', '0', '0', '156930', '0');
INSERT INTO `auction` VALUES ('4931', '2', '44546', '20540', '2', '134400', '1294669959', '0', '0', '127680', '0');
INSERT INTO `auction` VALUES ('4930', '2', '44545', '16724', '2', '1024902', '1294659159', '0', '0', '983905', '0');
INSERT INTO `auction` VALUES ('5052', '2', '44667', '10561', '2', '50160', '1294662759', '0', '0', '39626', '0');
INSERT INTO `auction` VALUES ('4882', '2', '44497', '9719', '2', '380750', '1294666359', '0', '0', '327445', '0');
INSERT INTO `auction` VALUES ('4641', '2', '44256', '9719', '2', '358250', '1294531918', '0', '0', '340337', '0');
INSERT INTO `auction` VALUES ('4804', '6', '44419', '9719', '2', '344250', '1294553518', '0', '0', '313267', '0');
INSERT INTO `auction` VALUES ('4811', '6', '44426', '36155', '2', '1494941', '1294557118', '0', '0', '1479991', '0');
INSERT INTO `auction` VALUES ('4780', '6', '44395', '766', '2', '479', '1294582318', '0', '0', '455', '0');
INSERT INTO `auction` VALUES ('4736', '2', '44351', '31188', '2', '1691233', '1294542718', '0', '0', '1336074', '0');
INSERT INTO `auction` VALUES ('4945', '2', '44560', '1265', '2', '774795', '1294659159', '0', '0', '767047', '0');
INSERT INTO `auction` VALUES ('5006', '2', '44621', '766', '2', '700', '1294659159', '0', '0', '700', '0');
INSERT INTO `auction` VALUES ('4823', '6', '44438', '2291', '2', '6448497', '1294560718', '0', '0', '5739162', '0');
INSERT INTO `auction` VALUES ('4924', '2', '44539', '9719', '2', '353750', '1294687959', '0', '0', '293612', '0');
INSERT INTO `auction` VALUES ('4993', '2', '44608', '6647', '2', '310', '1294662759', '0', '0', '232', '0');
INSERT INTO `auction` VALUES ('4876', '6', '44491', '3197', '2', '520088', '1294557118', '0', '0', '514887', '0');
INSERT INTO `auction` VALUES ('4675', '2', '44290', '36373', '2', '4696720', '1294560718', '0', '0', '3945244', '0');
INSERT INTO `auction` VALUES ('4674', '2', '44289', '24662', '2', '1370159', '1294575118', '0', '0', '1205739', '0');
INSERT INTO `auction` VALUES ('4469', '2', '44084', '13911', '2', '758', '1294578657', '0', '0', '720', '0');
INSERT INTO `auction` VALUES ('4525', '7', '44140', '44505', '2', '8977645', '1294567857', '0', '0', '7092339', '0');
INSERT INTO `auction` VALUES ('4994', '2', '44609', '7973', '2', '7400', '1294651959', '0', '0', '5920', '0');
INSERT INTO `auction` VALUES ('4627', '2', '44242', '20526', '2', '53240', '1294524718', '0', '0', '53240', '0');
INSERT INTO `auction` VALUES ('4706', '2', '44321', '10560', '2', '46760', '1294549918', '0', '0', '35070', '0');
INSERT INTO `auction` VALUES ('4561', '2', '44176', '5206', '2', '1998', '1294535518', '0', '0', '1398', '0');
INSERT INTO `auction` VALUES ('4900', '2', '44515', '44475', '2', '200', '1294691559', '0', '0', '164', '0');
INSERT INTO `auction` VALUES ('4437', '6', '44051', '36500', '2', '5569388', '1294497400', '0', '0', '5513694', '0');
INSERT INTO `auction` VALUES ('4862', '6', '44477', '6660', '2', '3113186', '1294571518', '0', '0', '2521680', '0');
INSERT INTO `auction` VALUES ('4430', '7', '44044', '6294', '2', '62', '1294500939', '0', '0', '55', '0');
INSERT INTO `auction` VALUES ('4579', '2', '44194', '44156', '2', '49600', '1294557118', '0', '0', '49104', '0');
INSERT INTO `auction` VALUES ('4927', '2', '44542', '1406', '2', '117716', '1294666359', '0', '0', '98881', '0');
INSERT INTO `auction` VALUES ('4570', '2', '44185', '24345', '2', '5960000', '1294528318', '0', '0', '4470000', '0');
INSERT INTO `auction` VALUES ('4978', '2', '44593', '6203', '2', '1376', '1294641159', '0', '0', '1018', '0');
INSERT INTO `auction` VALUES ('4584', '2', '44199', '6359', '2', '392', '1294578718', '0', '0', '301', '0');
INSERT INTO `auction` VALUES ('4911', '2', '44526', '13911', '2', '752', '1294673559', '0', '0', '676', '0');
INSERT INTO `auction` VALUES ('4786', '6', '44401', '9719', '2', '318500', '1294578718', '0', '0', '286650', '0');
INSERT INTO `auction` VALUES ('4557', '2', '44172', '5742', '2', '481984', '1294549918', '0', '0', '409686', '0');
INSERT INTO `auction` VALUES ('4505', '6', '44120', '2168', '2', '28164', '1294578657', '0', '0', '28164', '0');
INSERT INTO `auction` VALUES ('4687', '2', '44302', '24666', '2', '1809963', '1294542718', '0', '0', '1683265', '0');
INSERT INTO `auction` VALUES ('4869', '6', '44484', '9719', '2', '384500', '1294564318', '0', '0', '303755', '0');
INSERT INTO `auction` VALUES ('4741', '2', '44356', '13903', '2', '187', '1294531918', '0', '0', '147', '0');
INSERT INTO `auction` VALUES ('5033', '2', '44648', '21882', '2', '190000', '1294662759', '0', '0', '146300', '0');
INSERT INTO `auction` VALUES ('4969', '2', '44584', '9719', '2', '315750', '1294669959', '0', '0', '303120', '0');
INSERT INTO `auction` VALUES ('4527', '7', '44142', '9719', '2', '359500', '1294571457', '0', '0', '273220', '0');
INSERT INTO `auction` VALUES ('4880', '2', '44495', '1280', '2', '154879', '1294680759', '0', '0', '123903', '0');
INSERT INTO `auction` VALUES ('4588', '2', '44203', '2259', '2', '661', '1294542718', '0', '0', '561', '0');
INSERT INTO `auction` VALUES ('4495', '6', '44110', '2268', '2', '1361', '1294524657', '0', '0', '993', '0');
INSERT INTO `auction` VALUES ('5064', '2', '44679', '1288', '2', '3448', '1294666359', '0', '0', '2758', '0');
INSERT INTO `auction` VALUES ('4742', '2', '44357', '31197', '2', '1689611', '1294531918', '0', '0', '1385481', '0');
INSERT INTO `auction` VALUES ('4667', '2', '44282', '9719', '2', '367750', '1294553518', '0', '0', '316265', '0');
INSERT INTO `auction` VALUES ('4694', '2', '44309', '9719', '2', '312750', '1294575118', '0', '0', '312750', '0');
INSERT INTO `auction` VALUES ('4769', '6', '44384', '30809', '2', '472392', '1294528318', '0', '0', '406257', '0');
INSERT INTO `auction` VALUES ('4872', '6', '44487', '24714', '2', '1200638', '1294539118', '0', '0', '1116593', '0');
INSERT INTO `auction` VALUES ('5038', '2', '44653', '17414', '2', '843110', '1294687959', '0', '0', '741936', '0');
INSERT INTO `auction` VALUES ('4479', '2', '44094', '9061', '2', '13950', '1294549857', '0', '0', '11439', '0');
INSERT INTO `auction` VALUES ('4462', '2', '44077', '4768', '2', '7175', '1294539057', '0', '0', '6457', '0');
INSERT INTO `auction` VALUES ('4562', '2', '44177', '1263', '2', '15615298', '1294535518', '0', '0', '12804544', '0');
INSERT INTO `auction` VALUES ('4612', '2', '44227', '9392', '2', '1034521', '1294546318', '0', '0', '848307', '0');
INSERT INTO `auction` VALUES ('4466', '2', '44081', '24401', '2', '314760', '1294531857', '0', '0', '220332', '0');
INSERT INTO `auction` VALUES ('4940', '2', '44555', '31214', '2', '3175580', '1294637559', '0', '0', '2730998', '0');
INSERT INTO `auction` VALUES ('4949', '2', '44564', '44669', '2', '2941751', '1294669959', '0', '0', '2294565', '0');
INSERT INTO `auction` VALUES ('4547', '2', '44162', '2734', '2', '30900', '1294539118', '0', '0', '26265', '0');
INSERT INTO `auction` VALUES ('5010', '2', '44625', '36155', '2', '1389000', '1294648359', '0', '0', '1236210', '0');
INSERT INTO `auction` VALUES ('4585', '2', '44200', '31940', '2', '1321796', '1294575118', '0', '0', '1070654', '0');
INSERT INTO `auction` VALUES ('4631', '2', '44246', '9755', '2', '699', '1294578718', '0', '0', '552', '0');
INSERT INTO `auction` VALUES ('4918', '2', '44533', '16648', '2', '585', '1294680759', '0', '0', '520', '0');
INSERT INTO `auction` VALUES ('4977', '2', '44592', '9719', '2', '331000', '1294677159', '0', '0', '304520', '0');
INSERT INTO `auction` VALUES ('4775', '6', '44390', '20695', '2', '2189681', '1294528318', '0', '0', '1970712', '0');
INSERT INTO `auction` VALUES ('4798', '6', '44413', '37069', '2', '3721493', '1294549918', '0', '0', '3386558', '0');
INSERT INTO `auction` VALUES ('4602', '2', '44217', '31223', '2', '1759110', '1294575118', '0', '0', '1706336', '0');
INSERT INTO `auction` VALUES ('4770', '6', '44385', '2164', '2', '5941633', '1294549918', '0', '0', '4990971', '0');
INSERT INTO `auction` VALUES ('5031', '2', '44646', '9719', '2', '357750', '1294695159', '0', '0', '282622', '0');
INSERT INTO `auction` VALUES ('4522', '7', '44137', '44687', '2', '3172751', '1294524657', '0', '0', '2696838', '0');
INSERT INTO `auction` VALUES ('5016', '2', '44631', '1936', '2', '57426', '1294637559', '0', '0', '56851', '0');
INSERT INTO `auction` VALUES ('4995', '2', '44610', '9719', '2', '324250', '1294648359', '0', '0', '317765', '0');
INSERT INTO `auction` VALUES ('4629', '2', '44244', '9719', '2', '432000', '1294567918', '0', '0', '336960', '0');
INSERT INTO `auction` VALUES ('4751', '6', '44366', '30730', '2', '8856442', '1294549918', '0', '0', '7882233', '0');
INSERT INTO `auction` VALUES ('4523', '7', '44138', '6354', '2', '7', '1294571457', '0', '0', '6', '0');
INSERT INTO `auction` VALUES ('4793', '6', '44408', '24677', '2', '912278', '1294546318', '0', '0', '793681', '0');
INSERT INTO `auction` VALUES ('4760', '6', '44375', '1483', '2', '173205', '1294557118', '0', '0', '157616', '0');
INSERT INTO `auction` VALUES ('4698', '2', '44313', '10559', '2', '11580', '1294542718', '0', '0', '9148', '0');
INSERT INTO `auction` VALUES ('5040', '2', '44655', '11603', '2', '2395828', '1294651959', '0', '0', '2132286', '0');
INSERT INTO `auction` VALUES ('4879', '2', '44494', '23320', '2', '6476000', '1294669959', '0', '0', '5310320', '0');
INSERT INTO `auction` VALUES ('5003', '2', '44618', '7734', '2', '878256', '1294680759', '0', '0', '834343', '0');
INSERT INTO `auction` VALUES ('4959', '2', '44574', '2258', '2', '658', '1294673559', '0', '0', '513', '0');
INSERT INTO `auction` VALUES ('4757', '6', '44372', '9719', '2', '384250', '1294546318', '0', '0', '292030', '0');
INSERT INTO `auction` VALUES ('5015', '2', '44630', '9719', '2', '429500', '1294691559', '0', '0', '377960', '0');
INSERT INTO `auction` VALUES ('5035', '2', '44650', '27516', '2', '4260', '1294695159', '0', '0', '3834', '0');
INSERT INTO `auction` VALUES ('4622', '2', '44237', '9719', '2', '346750', '1294531918', '0', '0', '343282', '0');
INSERT INTO `auction` VALUES ('4643', '2', '44258', '36637', '2', '3335832', '1294528318', '0', '0', '3169040', '0');
INSERT INTO `auction` VALUES ('4638', '2', '44253', '9719', '2', '400250', '1294553518', '0', '0', '332207', '0');
INSERT INTO `auction` VALUES ('4530', '7', '44145', '31215', '2', '2150224', '1294564257', '0', '0', '1849192', '0');
INSERT INTO `auction` VALUES ('4613', '2', '44228', '9402', '2', '2196786', '1294531918', '0', '0', '2021043', '0');
INSERT INTO `auction` VALUES ('4531', '7', '44146', '36159', '2', '2097038', '1294542657', '0', '0', '1908304', '0');
INSERT INTO `auction` VALUES ('4594', '2', '44209', '10571', '2', '846842', '1294524718', '0', '0', '745220', '0');
INSERT INTO `auction` VALUES ('4835', '6', '44450', '9719', '2', '437250', '1294553518', '0', '0', '327937', '0');
INSERT INTO `auction` VALUES ('4465', '2', '44080', '16646', '2', '612', '1294539057', '0', '0', '587', '0');
INSERT INTO `auction` VALUES ('4407', '6', '44020', '10505', '2', '20280', '1294499190', '0', '0', '18049', '0');
INSERT INTO `auction` VALUES ('4952', '2', '44567', '13755', '2', '4748', '1294695159', '0', '0', '3988', '0');
INSERT INTO `auction` VALUES ('4748', '6', '44363', '44147', '2', '57750', '1294575118', '0', '0', '56017', '0');
INSERT INTO `auction` VALUES ('4471', '2', '44086', '753', '2', '237076', '1294546257', '0', '0', '218109', '0');
INSERT INTO `auction` VALUES ('4744', '6', '44359', '9719', '2', '380500', '1294557118', '0', '0', '315815', '0');
INSERT INTO `auction` VALUES ('4506', '6', '44121', '9719', '2', '347500', '1294578657', '0', '0', '291900', '0');
INSERT INTO `auction` VALUES ('4633', '2', '44248', '37159', '2', '9945', '1294549918', '0', '0', '8652', '0');
INSERT INTO `auction` VALUES ('4781', '6', '44396', '9719', '2', '364750', '1294575118', '0', '0', '364750', '0');
INSERT INTO `auction` VALUES ('5049', '2', '44664', '31198', '2', '1548520', '1294648359', '0', '0', '1285271', '0');
INSERT INTO `auction` VALUES ('4836', '6', '44451', '46004', '2', '98400', '1294542718', '0', '0', '71832', '0');
INSERT INTO `auction` VALUES ('4468', '2', '44083', '9061', '2', '20410', '1294542657', '0', '0', '17144', '0');
INSERT INTO `auction` VALUES ('4913', '2', '44528', '3295', '2', '130', '1294651959', '0', '0', '115', '0');
INSERT INTO `auction` VALUES ('4803', '6', '44418', '8152', '2', '72420', '1294528318', '0', '0', '63729', '0');
INSERT INTO `auction` VALUES ('4556', '2', '44171', '37758', '2', '2893324', '1294542718', '0', '0', '2864390', '0');
INSERT INTO `auction` VALUES ('4756', '6', '44371', '36781', '2', '18480', '1294549918', '0', '0', '16632', '0');
INSERT INTO `auction` VALUES ('4961', '2', '44576', '9719', '2', '346750', '1294680759', '0', '0', '315542', '0');
INSERT INTO `auction` VALUES ('4886', '2', '44501', '16712', '2', '745023', '1294691559', '0', '0', '677970', '0');
INSERT INTO `auction` VALUES ('4685', '2', '44300', '1608', '2', '758579', '1294553518', '0', '0', '728235', '0');
INSERT INTO `auction` VALUES ('4807', '6', '44422', '9060', '2', '66800', '1294564318', '0', '0', '49432', '0');
INSERT INTO `auction` VALUES ('4714', '2', '44329', '4394', '2', '17100', '1294549918', '0', '0', '13338', '0');
INSERT INTO `auction` VALUES ('5011', '2', '44626', '9719', '2', '423750', '1294684359', '0', '0', '394087', '0');
INSERT INTO `auction` VALUES ('5029', '2', '44644', '37822', '2', '2720237', '1294673559', '0', '0', '2121784', '0');
INSERT INTO `auction` VALUES ('4919', '2', '44534', '9719', '2', '331500', '1294669959', '0', '0', '281775', '0');
INSERT INTO `auction` VALUES ('5068', '2', '44683', '1219', '2', '41601', '1294666359', '0', '0', '39936', '0');
INSERT INTO `auction` VALUES ('4795', '6', '44410', '25068', '2', '1451158', '1294560718', '0', '0', '1160926', '0');
INSERT INTO `auction` VALUES ('4474', '2', '44089', '21589', '2', '1818', '1294535457', '0', '0', '1745', '0');
INSERT INTO `auction` VALUES ('4464', '2', '44079', '14087', '2', '135', '1294578657', '0', '0', '126', '0');
INSERT INTO `auction` VALUES ('4782', '6', '44397', '9719', '2', '331500', '1294578718', '0', '0', '321555', '0');
INSERT INTO `auction` VALUES ('4693', '2', '44308', '890', '2', '302354', '1294539118', '0', '0', '287236', '0');
INSERT INTO `auction` VALUES ('4726', '2', '44341', '24603', '2', '817691', '1294557118', '0', '0', '654152', '0');
INSERT INTO `auction` VALUES ('4481', '2', '44096', '21882', '2', '300300', '1294560657', '0', '0', '240240', '0');
INSERT INTO `auction` VALUES ('4929', '2', '44544', '9719', '2', '376500', '1294659159', '0', '0', '308730', '0');
INSERT INTO `auction` VALUES ('4887', '2', '44502', '9719', '2', '396250', '1294641159', '0', '0', '364550', '0');
INSERT INTO `auction` VALUES ('4885', '2', '44500', '9719', '2', '341500', '1294691559', '0', '0', '297105', '0');
INSERT INTO `auction` VALUES ('4654', '2', '44269', '6203', '2', '1437', '1294578718', '0', '0', '1077', '0');
INSERT INTO `auction` VALUES ('4737', '2', '44352', '5182', '2', '71322', '1294567918', '0', '0', '59197', '0');
INSERT INTO `auction` VALUES ('4884', '2', '44499', '16681', '2', '1007193', '1294684359', '0', '0', '755394', '0');
INSERT INTO `auction` VALUES ('4716', '2', '44331', '9719', '2', '322250', '1294542718', '0', '0', '241687', '0');
INSERT INTO `auction` VALUES ('4541', '7', '44156', '10246', '2', '818045', '1294582257', '0', '0', '678977', '0');
INSERT INTO `auction` VALUES ('5072', '2', '44687', '2284', '2', '10391', '1294695159', '0', '0', '8416', '0');
INSERT INTO `auction` VALUES ('4508', '6', '44123', '9719', '2', '328750', '1294542657', '0', '0', '309025', '0');
INSERT INTO `auction` VALUES ('4600', '2', '44215', '3329', '2', '1926', '1294528318', '0', '0', '1598', '0');
INSERT INTO `auction` VALUES ('5032', '2', '44647', '9719', '2', '325750', '1294677159', '0', '0', '309462', '0');
INSERT INTO `auction` VALUES ('4682', '2', '44297', '37822', '2', '3006384', '1294524718', '0', '0', '2675681', '0');
INSERT INTO `auction` VALUES ('4564', '2', '44179', '9719', '2', '431500', '1294531918', '0', '0', '427185', '0');
INSERT INTO `auction` VALUES ('4968', '2', '44583', '2066', '2', '665', '1294680759', '0', '0', '478', '0');
INSERT INTO `auction` VALUES ('5055', '2', '44670', '2265', '2', '31426', '1294684359', '0', '0', '29226', '0');
INSERT INTO `auction` VALUES ('4659', '2', '44274', '9719', '2', '364000', '1294564318', '0', '0', '316680', '0');
INSERT INTO `auction` VALUES ('4605', '2', '44220', '40195', '2', '22650', '1294571518', '0', '0', '20611', '0');
INSERT INTO `auction` VALUES ('4948', '2', '44563', '39681', '2', '483056', '1294662759', '0', '0', '352630', '0');
INSERT INTO `auction` VALUES ('4500', '6', '44115', '1482', '2', '221737', '1294567857', '0', '0', '170737', '0');
INSERT INTO `auction` VALUES ('5048', '2', '44663', '5758', '2', '10120', '1294680759', '0', '0', '9816', '0');
INSERT INTO `auction` VALUES ('5012', '2', '44627', '1491', '2', '148873', '1294662759', '0', '0', '111654', '0');
INSERT INTO `auction` VALUES ('4859', '6', '44474', '4768', '2', '8494', '1294557118', '0', '0', '7050', '0');
INSERT INTO `auction` VALUES ('4490', '6', '44105', '934', '2', '801714', '1294553457', '0', '0', '769645', '0');
INSERT INTO `auction` VALUES ('4796', '6', '44411', '18255', '2', '2152', '1294578718', '0', '0', '1872', '0');
INSERT INTO `auction` VALUES ('4521', '7', '44136', '2099', '2', '9068924', '1294578657', '0', '0', '8706167', '0');
INSERT INTO `auction` VALUES ('4875', '6', '44490', '6353', '2', '6', '1294528318', '0', '0', '5', '0');
INSERT INTO `auction` VALUES ('4805', '6', '44420', '9719', '2', '379500', '1294531918', '0', '0', '368115', '0');
INSERT INTO `auction` VALUES ('4511', '6', '44126', '4444', '2', '82769', '1294539057', '0', '0', '81941', '0');
INSERT INTO `auction` VALUES ('4648', '2', '44263', '30727', '2', '7555548', '1294524718', '0', '0', '7479992', '0');
INSERT INTO `auction` VALUES ('4815', '6', '44430', '37147', '2', '1135', '1294531918', '0', '0', '919', '0');
INSERT INTO `auction` VALUES ('4861', '6', '44476', '25264', '2', '3131012', '1294535518', '0', '0', '2567429', '0');
INSERT INTO `auction` VALUES ('4606', '2', '44221', '2955', '2', '164191', '1294582318', '0', '0', '154339', '0');
INSERT INTO `auction` VALUES ('4713', '2', '44328', '9719', '2', '321750', '1294578718', '0', '0', '302445', '0');
INSERT INTO `auction` VALUES ('4925', '2', '44540', '30610', '2', '165648', '1294680759', '0', '0', '162335', '0');
INSERT INTO `auction` VALUES ('4507', '6', '44122', '7973', '2', '2318', '1294539057', '0', '0', '1622', '0');
INSERT INTO `auction` VALUES ('4826', '6', '44441', '812', '2', '11318192', '1294557118', '0', '0', '10073190', '0');
INSERT INTO `auction` VALUES ('4534', '7', '44149', '10505', '2', '41230', '1294535457', '0', '0', '32984', '0');
INSERT INTO `auction` VALUES ('4451', '7', '44066', '20693', '2', '833570', '1294501963', '0', '0', '791891', '0');
INSERT INTO `auction` VALUES ('4870', '6', '44485', '20261', '2', '1039174', '1294542718', '0', '0', '820947', '0');
INSERT INTO `auction` VALUES ('5039', '2', '44654', '36500', '2', '6183249', '1294680759', '0', '0', '5379426', '0');
INSERT INTO `auction` VALUES ('4663', '2', '44278', '4694', '2', '4767', '1294524718', '0', '0', '3956', '0');
INSERT INTO `auction` VALUES ('4660', '2', '44275', '24603', '2', '833812', '1294557118', '0', '0', '758768', '0');
INSERT INTO `auction` VALUES ('4809', '6', '44424', '2244', '2', '10439015', '1294524718', '0', '0', '8873162', '0');
INSERT INTO `auction` VALUES ('4746', '6', '44361', '31172', '2', '2549465', '1294535518', '0', '0', '2167045', '0');
INSERT INTO `auction` VALUES ('4963', '2', '44578', '9719', '2', '362750', '1294684359', '0', '0', '322847', '0');
INSERT INTO `auction` VALUES ('4503', '6', '44118', '9262', '2', '77600', '1294582257', '0', '0', '58976', '0');
INSERT INTO `auction` VALUES ('4950', '2', '44565', '9719', '2', '340500', '1294641159', '0', '0', '289425', '0');
INSERT INTO `auction` VALUES ('4941', '2', '44556', '39682', '2', '355200', '1294659159', '0', '0', '355200', '0');
INSERT INTO `auction` VALUES ('4542', '7', '44157', '20670', '2', '625708', '1294535457', '0', '0', '556880', '0');
INSERT INTO `auction` VALUES ('5026', '2', '44641', '36263', '2', '2024915', '1294695159', '0', '0', '1842672', '0');
INSERT INTO `auction` VALUES ('4513', '6', '44128', '1296', '2', '79128', '1294575057', '0', '0', '63302', '0');
INSERT INTO `auction` VALUES ('4620', '2', '44235', '5181', '2', '100646', '1294535518', '0', '0', '98633', '0');
INSERT INTO `auction` VALUES ('4825', '6', '44440', '7072', '2', '2172', '1294539118', '0', '0', '1954', '0');
INSERT INTO `auction` VALUES ('4857', '6', '44472', '43624', '2', '49770', '1294546318', '0', '0', '44295', '0');
INSERT INTO `auction` VALUES ('4894', '2', '44509', '1722', '2', '1643823', '1294684359', '0', '0', '1364373', '0');
INSERT INTO `auction` VALUES ('4690', '2', '44305', '4044', '2', '243421', '1294567918', '0', '0', '209342', '0');
INSERT INTO `auction` VALUES ('4488', '6', '44103', '35615', '2', '2573895', '1294575057', '0', '0', '2393722', '0');
INSERT INTO `auction` VALUES ('4567', '2', '44182', '35557', '2', '46', '1294578718', '0', '0', '43', '0');
INSERT INTO `auction` VALUES ('4922', '2', '44537', '18610', '2', '323', '1294648359', '0', '0', '310', '0');
INSERT INTO `auction` VALUES ('4401', '6', '44014', '2623', '2', '195680', '1294499190', '0', '0', '156544', '0');
INSERT INTO `auction` VALUES ('4874', '6', '44489', '3164', '2', '2146', '1294578718', '0', '0', '1974', '0');
INSERT INTO `auction` VALUES ('4850', '6', '44465', '9719', '2', '413500', '1294564318', '0', '0', '392825', '0');
INSERT INTO `auction` VALUES ('4996', '2', '44611', '36541', '2', '6565912', '1294655559', '0', '0', '5778002', '0');
INSERT INTO `auction` VALUES ('4592', '2', '44207', '1980', '2', '819144', '1294528318', '0', '0', '663506', '0');
INSERT INTO `auction` VALUES ('4934', '2', '44549', '20709', '2', '1740', '1294673559', '0', '0', '1287', '0');
INSERT INTO `auction` VALUES ('4476', '2', '44091', '36386', '2', '2009570', '1294539057', '0', '0', '1667943', '0');
INSERT INTO `auction` VALUES ('4936', '2', '44551', '20679', '2', '59280', '1294641159', '0', '0', '45052', '0');
INSERT INTO `auction` VALUES ('4609', '2', '44224', '30740', '2', '13136920', '1294528318', '0', '0', '11297751', '0');
INSERT INTO `auction` VALUES ('4672', '2', '44287', '36272', '2', '3900141', '1294582318', '0', '0', '3510126', '0');
INSERT INTO `auction` VALUES ('4773', '6', '44388', '9719', '2', '374000', '1294560718', '0', '0', '355300', '0');
INSERT INTO `auction` VALUES ('4649', '2', '44264', '34837', '2', '1883484', '1294578718', '0', '0', '1638631', '0');
INSERT INTO `auction` VALUES ('4684', '2', '44299', '2292', '2', '90699', '1294539118', '0', '0', '73466', '0');
INSERT INTO `auction` VALUES ('4776', '6', '44391', '25242', '2', '2335038', '1294567918', '0', '0', '2218286', '0');
INSERT INTO `auction` VALUES ('4783', '6', '44398', '30738', '2', '6035240', '1294539118', '0', '0', '5974887', '0');
INSERT INTO `auction` VALUES ('4784', '6', '44399', '1728', '2', '13340140', '1294575118', '0', '0', '11472520', '0');
INSERT INTO `auction` VALUES ('4554', '2', '44169', '1076', '2', '35204', '1294539118', '0', '0', '28515', '0');
INSERT INTO `auction` VALUES ('4524', '7', '44139', '4637', '2', '7806', '1294582257', '0', '0', '7806', '0');
INSERT INTO `auction` VALUES ('4692', '2', '44307', '4387', '2', '23520', '1294542718', '0', '0', '16934', '0');
INSERT INTO `auction` VALUES ('4762', '6', '44377', '8226', '2', '472740', '1294578718', '0', '0', '463285', '0');
INSERT INTO `auction` VALUES ('4528', '7', '44143', '13917', '2', '1432', '1294571457', '0', '0', '1389', '0');
INSERT INTO `auction` VALUES ('4997', '2', '44612', '6315', '2', '123510', '1294677159', '0', '0', '111159', '0');
INSERT INTO `auction` VALUES ('4985', '2', '44600', '2751', '2', '29160', '1294655559', '0', '0', '29160', '0');
INSERT INTO `auction` VALUES ('4871', '6', '44486', '41119', '2', '28800', '1294542718', '0', '0', '28800', '0');
INSERT INTO `auction` VALUES ('4998', '2', '44613', '23386', '2', '847', '1294648359', '0', '0', '830', '0');
INSERT INTO `auction` VALUES ('4920', '2', '44535', '4791', '2', '10255', '1294651959', '0', '0', '8409', '0');
INSERT INTO `auction` VALUES ('4544', '2', '44159', '37147', '2', '12250', '1294546318', '0', '0', '10902', '0');
INSERT INTO `auction` VALUES ('4680', '2', '44295', '20540', '2', '108550', '1294575118', '0', '0', '105293', '0');
INSERT INTO `auction` VALUES ('4738', '2', '44353', '720', '2', '93642', '1294553518', '0', '0', '73040', '0');
INSERT INTO `auction` VALUES ('4651', '2', '44266', '9719', '2', '422500', '1294567918', '0', '0', '422500', '0');
INSERT INTO `auction` VALUES ('5025', '2', '44640', '3164', '2', '2754', '1294637559', '0', '0', '2203', '0');
INSERT INTO `auction` VALUES ('4683', '2', '44298', '9719', '2', '395000', '1294553518', '0', '0', '371300', '0');
INSERT INTO `auction` VALUES ('4686', '2', '44301', '24291', '2', '3620', '1294578718', '0', '0', '2606', '0');
INSERT INTO `auction` VALUES ('4699', '2', '44314', '4394', '2', '28680', '1294549918', '0', '0', '21796', '0');
INSERT INTO `auction` VALUES ('4493', '6', '44108', '24603', '2', '835604', '1294535457', '0', '0', '743687', '0');
INSERT INTO `auction` VALUES ('4515', '6', '44130', '24827', '2', '1563494', '1294564257', '0', '0', '1500954', '0');
INSERT INTO `auction` VALUES ('4877', '2', '44492', '9719', '2', '318500', '1294641159', '0', '0', '251615', '0');
INSERT INTO `auction` VALUES ('4792', '6', '44407', '14170', '2', '3492', '1294571518', '0', '0', '2479', '0');
INSERT INTO `auction` VALUES ('5024', '2', '44639', '10514', '2', '9480', '1294677159', '0', '0', '7489', '0');
INSERT INTO `auction` VALUES ('4558', '2', '44173', '4394', '2', '36450', '1294539118', '0', '0', '28066', '0');
INSERT INTO `auction` VALUES ('4984', '2', '44599', '9719', '2', '355000', '1294648359', '0', '0', '287550', '0');
INSERT INTO `auction` VALUES ('4715', '2', '44330', '9719', '2', '315250', '1294560718', '0', '0', '249047', '0');
INSERT INTO `auction` VALUES ('4933', '2', '44548', '9719', '2', '332250', '1294680759', '0', '0', '325605', '0');
INSERT INTO `auction` VALUES ('4482', '2', '44097', '10505', '2', '41480', '1294542657', '0', '0', '36087', '0');
INSERT INTO `auction` VALUES ('4650', '2', '44265', '44475', '2', '192', '1294553518', '0', '0', '170', '0');
INSERT INTO `auction` VALUES ('4820', '6', '44435', '6359', '2', '350', '1294546318', '0', '0', '252', '0');
INSERT INTO `auction` VALUES ('4639', '2', '44254', '1980', '2', '782936', '1294582318', '0', '0', '735959', '0');
INSERT INTO `auction` VALUES ('4893', '2', '44508', '16646', '2', '480', '1294655559', '0', '0', '403', '0');
INSERT INTO `auction` VALUES ('4801', '6', '44416', '44708', '2', '14441965', '1294567918', '0', '0', '11409152', '0');
INSERT INTO `auction` VALUES ('4517', '6', '44132', '40199', '2', '10000', '1294560657', '0', '0', '8800', '0');
INSERT INTO `auction` VALUES ('4668', '2', '44283', '6356', '2', '7', '1294539118', '0', '0', '5', '0');
INSERT INTO `auction` VALUES ('4832', '6', '44447', '31125', '2', '2884990', '1294582318', '0', '0', '2798440', '0');
INSERT INTO `auction` VALUES ('4735', '2', '44350', '6651', '2', '2076', '1294546318', '0', '0', '1557', '0');
INSERT INTO `auction` VALUES ('4852', '6', '44467', '15313', '2', '6121', '1294549918', '0', '0', '4529', '0');
INSERT INTO `auction` VALUES ('5051', '2', '44666', '36261', '2', '3011829', '1294669959', '0', '0', '2801000', '0');
INSERT INTO `auction` VALUES ('4616', '2', '44231', '6201', '2', '432', '1294535518', '0', '0', '410', '0');
INSERT INTO `auction` VALUES ('4827', '6', '44442', '3295', '2', '83', '1294524718', '0', '0', '77', '0');
INSERT INTO `auction` VALUES ('4545', '2', '44160', '44475', '2', '140', '1294524718', '0', '0', '113', '0');
INSERT INTO `auction` VALUES ('4992', '2', '44607', '4589', '2', '28874', '1294677159', '0', '0', '21078', '0');
INSERT INTO `auction` VALUES ('5063', '2', '44678', '24476', '2', '10472', '1294666359', '0', '0', '9529', '0');
INSERT INTO `auction` VALUES ('4601', '2', '44216', '36484', '2', '4832682', '1294557118', '0', '0', '4736028', '0');
INSERT INTO `auction` VALUES ('4679', '2', '44294', '9719', '2', '385750', '1294542718', '0', '0', '354890', '0');
INSERT INTO `auction` VALUES ('4502', '6', '44117', '766', '2', '645', '1294582257', '0', '0', '645', '0');
INSERT INTO `auction` VALUES ('5021', '2', '44636', '5524', '2', '2308', '1294680759', '0', '0', '1938', '0');
INSERT INTO `auction` VALUES ('4526', '7', '44141', '10559', '2', '6630', '1294560657', '0', '0', '4641', '0');
INSERT INTO `auction` VALUES ('4520', '6', '44135', '10505', '2', '4180', '1294557057', '0', '0', '3553', '0');
INSERT INTO `auction` VALUES ('4953', '2', '44568', '4434', '2', '36147', '1294651959', '0', '0', '30724', '0');
INSERT INTO `auction` VALUES ('4942', '2', '44557', '36781', '2', '19712', '1294641159', '0', '0', '13798', '0');
INSERT INTO `auction` VALUES ('4543', '7', '44158', '24836', '2', '1551005', '1294528257', '0', '0', '1349374', '0');
INSERT INTO `auction` VALUES ('4533', '7', '44148', '2620', '2', '203856', '1294582257', '0', '0', '177354', '0');
INSERT INTO `auction` VALUES ('4831', '6', '44446', '31191', '2', '1104048', '1294567918', '0', '0', '839076', '0');
INSERT INTO `auction` VALUES ('4767', '6', '44382', '36038', '2', '1358193', '1294539118', '0', '0', '1344611', '0');
INSERT INTO `auction` VALUES ('4812', '6', '44427', '24775', '2', '1730307', '1294557118', '0', '0', '1505367', '0');
INSERT INTO `auction` VALUES ('5047', '2', '44662', '1475', '2', '1989', '1294644759', '0', '0', '1392', '0');
INSERT INTO `auction` VALUES ('4856', '6', '44471', '24449', '2', '75482', '1294575118', '0', '0', '73217', '0');
INSERT INTO `auction` VALUES ('4843', '6', '44458', '9719', '2', '416000', '1294531918', '0', '0', '370240', '0');
INSERT INTO `auction` VALUES ('4971', '2', '44586', '36781', '2', '10224', '1294687959', '0', '0', '7668', '0');
INSERT INTO `auction` VALUES ('4727', '2', '44342', '3295', '2', '133', '1294524718', '0', '0', '123', '0');
INSERT INTO `auction` VALUES ('4669', '2', '44284', '36610', '2', '8650418', '1294571518', '0', '0', '7352855', '0');
INSERT INTO `auction` VALUES ('4514', '6', '44129', '4611', '2', '632', '1294549857', '0', '0', '505', '0');
INSERT INTO `auction` VALUES ('4898', '2', '44513', '25228', '2', '3873398', '1294659159', '0', '0', '3757196', '0');
INSERT INTO `auction` VALUES ('4707', '2', '44322', '45984', '2', '168000', '1294524718', '0', '0', '146160', '0');
INSERT INTO `auction` VALUES ('4901', '2', '44516', '24822', '2', '1052688', '1294666359', '0', '0', '936892', '0');
INSERT INTO `auction` VALUES ('4603', '2', '44218', '49227', '2', '11158603', '1294524718', '0', '0', '9373226', '0');
INSERT INTO `auction` VALUES ('4778', '6', '44393', '9719', '2', '424000', '1294582318', '0', '0', '334960', '0');
INSERT INTO `auction` VALUES ('4617', '2', '44232', '24889', '2', '1117702', '1294535518', '0', '0', '1050639', '0');
INSERT INTO `auction` VALUES ('4817', '6', '44432', '942', '2', '598140', '1294546318', '0', '0', '568233', '0');
INSERT INTO `auction` VALUES ('4540', '7', '44155', '2072', '2', '261529', '1294524657', '0', '0', '211838', '0');
INSERT INTO `auction` VALUES ('4755', '6', '44370', '36393', '2', '2553060', '1294575118', '0', '0', '2527529', '0');
INSERT INTO `auction` VALUES ('4551', '2', '44166', '34829', '2', '787600', '1294546318', '0', '0', '669460', '0');
INSERT INTO `auction` VALUES ('4816', '6', '44431', '20709', '2', '3312', '1294553518', '0', '0', '2947', '0');
INSERT INTO `auction` VALUES ('4652', '2', '44267', '10561', '2', '24360', '1294578718', '0', '0', '22411', '0');
INSERT INTO `auction` VALUES ('4604', '2', '44219', '37145', '2', '7600', '1294531918', '0', '0', '6840', '0');
INSERT INTO `auction` VALUES ('4838', '6', '44453', '9719', '2', '424750', '1294553518', '0', '0', '327057', '0');
INSERT INTO `auction` VALUES ('4492', '6', '44107', '812', '2', '7666150', '1294539057', '0', '0', '6209581', '0');
INSERT INTO `auction` VALUES ('4593', '2', '44208', '34622', '2', '2385600', '1294524718', '0', '0', '1932336', '0');
INSERT INTO `auction` VALUES ('4703', '2', '44318', '9719', '2', '335750', '1294539118', '0', '0', '302175', '0');
INSERT INTO `auction` VALUES ('4550', '2', '44165', '9719', '2', '349750', '1294564318', '0', '0', '297287', '0');
INSERT INTO `auction` VALUES ('4785', '6', '44400', '2911', '2', '37535', '1294535518', '0', '0', '31529', '0');
INSERT INTO `auction` VALUES ('4661', '2', '44276', '36569', '2', '6662679', '1294571518', '0', '0', '6662679', '0');
INSERT INTO `auction` VALUES ('4467', '2', '44082', '36682', '2', '5114832', '1294560657', '0', '0', '5012535', '0');
INSERT INTO `auction` VALUES ('4647', '2', '44262', '9719', '2', '396000', '1294546318', '0', '0', '332640', '0');
INSERT INTO `auction` VALUES ('4974', '2', '44589', '9719', '2', '343500', '1294684359', '0', '0', '278235', '0');
INSERT INTO `auction` VALUES ('5027', '2', '44642', '31199', '2', '1155275', '1294659159', '0', '0', '1132169', '0');
INSERT INTO `auction` VALUES ('4697', '2', '44312', '44475', '2', '120', '1294546318', '0', '0', '112', '0');
INSERT INTO `auction` VALUES ('4619', '2', '44234', '9719', '2', '338750', '1294578718', '0', '0', '301487', '0');
INSERT INTO `auction` VALUES ('4938', '2', '44553', '4387', '2', '21888', '1294637559', '0', '0', '20793', '0');
INSERT INTO `auction` VALUES ('5019', '2', '44634', '10559', '2', '54720', '1294637559', '0', '0', '44323', '0');
INSERT INTO `auction` VALUES ('4774', '6', '44389', '22641', '2', '10857', '1294535518', '0', '0', '9228', '0');
INSERT INTO `auction` VALUES ('5034', '2', '44649', '9719', '2', '429750', '1294651959', '0', '0', '391072', '0');
INSERT INTO `auction` VALUES ('4477', '2', '44092', '36382', '2', '2122123', '1294539057', '0', '0', '1803804', '0');
INSERT INTO `auction` VALUES ('4473', '2', '44088', '18512', '2', '72960', '1294578657', '0', '0', '51801', '0');
INSERT INTO `auction` VALUES ('4576', '2', '44191', '9719', '2', '371750', '1294567918', '0', '0', '315987', '0');
INSERT INTO `auction` VALUES ('4712', '2', '44327', '44475', '2', '199', '1294578718', '0', '0', '161', '0');
INSERT INTO `auction` VALUES ('4860', '6', '44475', '2271', '2', '236356', '1294528318', '0', '0', '215083', '0');
INSERT INTO `auction` VALUES ('4504', '6', '44119', '3164', '2', '2284', '1294524657', '0', '0', '2055', '0');
INSERT INTO `auction` VALUES ('4695', '2', '44310', '18678', '2', '1441499', '1294578718', '0', '0', '1326179', '0');
INSERT INTO `auction` VALUES ('4954', '2', '44569', '9719', '2', '355500', '1294666359', '0', '0', '273735', '0');
INSERT INTO `auction` VALUES ('4878', '2', '44493', '39681', '2', '45696', '1294659159', '0', '0', '37470', '0');
INSERT INTO `auction` VALUES ('4928', '2', '44543', '36484', '2', '7493372', '1294648359', '0', '0', '6744034', '0');
INSERT INTO `auction` VALUES ('4653', '2', '44268', '9444', '2', '12604', '1294578718', '0', '0', '10587', '0');
INSERT INTO `auction` VALUES ('4725', '2', '44340', '10562', '2', '73260', '1294539118', '0', '0', '54945', '0');
INSERT INTO `auction` VALUES ('4618', '2', '44233', '14554', '2', '7910909', '1294560718', '0', '0', '7910909', '0');
INSERT INTO `auction` VALUES ('4583', '2', '44198', '5752', '2', '192017', '1294560718', '0', '0', '178575', '0');
INSERT INTO `auction` VALUES ('4747', '6', '44362', '36527', '2', '5112887', '1294528318', '0', '0', '4397082', '0');
INSERT INTO `auction` VALUES ('4662', '2', '44277', '39682', '2', '98880', '1294546318', '0', '0', '83059', '0');
INSERT INTO `auction` VALUES ('5028', '2', '44643', '8106', '2', '442083', '1294662759', '0', '0', '393453', '0');
INSERT INTO `auction` VALUES ('4846', '6', '44461', '16676', '2', '978126', '1294571518', '0', '0', '733594', '0');
INSERT INTO `auction` VALUES ('4752', '6', '44367', '2824', '2', '5302897', '1294535518', '0', '0', '5302897', '0');
INSERT INTO `auction` VALUES ('4657', '2', '44272', '6292', '2', '53', '1294542718', '0', '0', '39', '0');
INSERT INTO `auction` VALUES ('4745', '6', '44360', '24665', '2', '1385867', '1294567918', '0', '0', '1233421', '0');
INSERT INTO `auction` VALUES ('4833', '6', '44448', '1355', '2', '14101', '1294528318', '0', '0', '11421', '0');
INSERT INTO `auction` VALUES ('4496', '6', '44111', '44700', '2', '4050', '1294531857', '0', '0', '3037', '0');
INSERT INTO `auction` VALUES ('4772', '6', '44387', '39681', '2', '139440', '1294542718', '0', '0', '122707', '0');
INSERT INTO `auction` VALUES ('4915', '2', '44530', '10625', '2', '1956697', '1294644759', '0', '0', '1545790', '0');
INSERT INTO `auction` VALUES ('4586', '2', '44201', '36441', '2', '1373208', '1294567918', '0', '0', '1139762', '0');
INSERT INTO `auction` VALUES ('4463', '2', '44078', '45909', '2', '30464', '1294524657', '0', '0', '29854', '0');
INSERT INTO `auction` VALUES ('4883', '2', '44498', '9719', '2', '396250', '1294644759', '0', '0', '344737', '0');
INSERT INTO `auction` VALUES ('4980', '2', '44595', '13891', '2', '824', '1294669959', '0', '0', '576', '0');
INSERT INTO `auction` VALUES ('4967', '2', '44582', '13910', '2', '520', '1294659159', '0', '0', '384', '0');
INSERT INTO `auction` VALUES ('4497', '6', '44112', '37145', '2', '760', '1294582257', '0', '0', '638', '0');
INSERT INTO `auction` VALUES ('4549', '2', '44164', '45909', '2', '34176', '1294549918', '0', '0', '30074', '0');
INSERT INTO `auction` VALUES ('4582', '2', '44197', '39681', '2', '379680', '1294528318', '0', '0', '326524', '0');
INSERT INTO `auction` VALUES ('4634', '2', '44249', '867', '2', '844084', '1294528318', '0', '0', '818761', '0');
INSERT INTO `auction` VALUES ('4839', '6', '44454', '9719', '2', '399750', '1294564318', '0', '0', '383760', '0');
INSERT INTO `auction` VALUES ('4739', '2', '44354', '9719', '2', '336000', '1294535518', '0', '0', '282240', '0');
INSERT INTO `auction` VALUES ('4854', '6', '44469', '16645', '2', '607', '1294578718', '0', '0', '509', '0');
INSERT INTO `auction` VALUES ('4573', '2', '44188', '7973', '2', '1709', '1294567918', '0', '0', '1674', '0');
INSERT INTO `auction` VALUES ('4696', '2', '44311', '9719', '2', '434750', '1294571518', '0', '0', '378232', '0');
INSERT INTO `auction` VALUES ('5056', '2', '44671', '24685', '2', '928135', '1294666359', '0', '0', '909572', '0');
INSERT INTO `auction` VALUES ('4700', '2', '44315', '20678', '2', '73080', '1294582318', '0', '0', '55540', '0');
INSERT INTO `auction` VALUES ('4578', '2', '44193', '2100', '2', '5235609', '1294528318', '0', '0', '4397911', '0');
INSERT INTO `auction` VALUES ('4951', '2', '44566', '37145', '2', '10500', '1294669959', '0', '0', '9870', '0');
INSERT INTO `auction` VALUES ('4723', '2', '44338', '24401', '2', '546750', '1294575118', '0', '0', '497542', '0');
INSERT INTO `auction` VALUES ('4912', '2', '44527', '24599', '2', '1114969', '1294655559', '0', '0', '970023', '0');
INSERT INTO `auction` VALUES ('5014', '2', '44629', '9719', '2', '395750', '1294655559', '0', '0', '340345', '0');
INSERT INTO `auction` VALUES ('4986', '2', '44601', '9719', '2', '350500', '1294684359', '0', '0', '339985', '0');
INSERT INTO `auction` VALUES ('4909', '2', '44524', '24663', '2', '1356422', '1294644759', '0', '0', '1166522', '0');
INSERT INTO `auction` VALUES ('4560', '2', '44175', '1720', '2', '2088905', '1294560718', '0', '0', '1880014', '0');
INSERT INTO `auction` VALUES ('5071', '2', '44686', '27511', '2', '164', '1294691559', '0', '0', '139', '0');
INSERT INTO `auction` VALUES ('4553', '2', '44168', '2110', '2', '50', '1294549918', '0', '0', '47', '0');
INSERT INTO `auction` VALUES ('4902', '2', '44517', '18512', '2', '74240', '1294673559', '0', '0', '72012', '0');
INSERT INTO `auction` VALUES ('4908', '2', '44523', '31158', '2', '2491365', '1294680759', '0', '0', '2192401', '0');
INSERT INTO `auction` VALUES ('4480', '2', '44095', '37145', '2', '14430', '1294549857', '0', '0', '11688', '0');
INSERT INTO `auction` VALUES ('4565', '2', '44180', '9719', '2', '322750', '1294557118', '0', '0', '287247', '0');
INSERT INTO `auction` VALUES ('4808', '6', '44423', '3295', '2', '85', '1294531918', '0', '0', '72', '0');
INSERT INTO `auction` VALUES ('4829', '6', '44444', '9719', '2', '434500', '1294553518', '0', '0', '412775', '0');
INSERT INTO `auction` VALUES ('4718', '2', '44333', '6202', '2', '328', '1294549918', '0', '0', '308', '0');
INSERT INTO `auction` VALUES ('5009', '2', '44624', '9719', '2', '387250', '1294637559', '0', '0', '290437', '0');
INSERT INTO `auction` VALUES ('4819', '6', '44434', '37147', '2', '7155', '1294528318', '0', '0', '5223', '0');
INSERT INTO `auction` VALUES ('4665', '2', '44280', '7729', '2', '410561', '1294571518', '0', '0', '365399', '0');
INSERT INTO `auction` VALUES ('4907', '2', '44522', '49227', '2', '8614362', '1294691559', '0', '0', '8442074', '0');
INSERT INTO `auction` VALUES ('5057', '2', '44672', '10514', '2', '27000', '1294666359', '0', '0', '23490', '0');
INSERT INTO `auction` VALUES ('4960', '2', '44575', '36065', '2', '1883947', '1294691559', '0', '0', '1582515', '0');
INSERT INTO `auction` VALUES ('5043', '2', '44658', '37147', '2', '10170', '1294651959', '0', '0', '7424', '0');
INSERT INTO `auction` VALUES ('5058', '2', '44673', '10559', '2', '104580', '1294655559', '0', '0', '90984', '0');
INSERT INTO `auction` VALUES ('4849', '6', '44464', '4263', '2', '944', '1294560718', '0', '0', '679', '0');
INSERT INTO `auction` VALUES ('4750', '6', '44365', '24828', '2', '1483115', '1294524718', '0', '0', '1423790', '0');
INSERT INTO `auction` VALUES ('4797', '6', '44412', '6458', '2', '180', '1294557118', '0', '0', '158', '0');
INSERT INTO `auction` VALUES ('4628', '2', '44243', '9719', '2', '428500', '1294567918', '0', '0', '428500', '0');
INSERT INTO `auction` VALUES ('4779', '6', '44394', '9719', '2', '325000', '1294571518', '0', '0', '269750', '0');
INSERT INTO `auction` VALUES ('4763', '6', '44378', '9427', '2', '1232072', '1294535518', '0', '0', '1232072', '0');
INSERT INTO `auction` VALUES ('5042', '2', '44657', '37757', '2', '2575132', '1294684359', '0', '0', '2085856', '0');
INSERT INTO `auction` VALUES ('5008', '2', '44623', '5635', '2', '1117', '1294684359', '0', '0', '1049', '0');
INSERT INTO `auction` VALUES ('4460', '2', '44075', '24715', '2', '997301', '1294553457', '0', '0', '837732', '0');
INSERT INTO `auction` VALUES ('4743', '2', '44358', '31221', '2', '1747197', '1294542718', '0', '0', '1415229', '0');
INSERT INTO `auction` VALUES ('4614', '2', '44229', '4359', '2', '812', '1294564318', '0', '0', '690', '0');
INSERT INTO `auction` VALUES ('4991', '2', '44606', '13878', '2', '206', '1294651959', '0', '0', '197', '0');
INSERT INTO `auction` VALUES ('4956', '2', '44571', '9719', '2', '429000', '1294691559', '0', '0', '368940', '0');
INSERT INTO `auction` VALUES ('4624', '2', '44239', '16702', '2', '668965', '1294560718', '0', '0', '541861', '0');

-- ----------------------------
-- Table structure for `auctionhousebot`
-- ----------------------------
DROP TABLE IF EXISTS `auctionhousebot`;
CREATE TABLE `auctionhousebot` (
  `auctionhouse` int(11) NOT NULL default '0' COMMENT 'mapID of the auctionhouse.',
  `name` char(25) default NULL COMMENT 'Text name of the auctionhouse.',
  `minitems` int(11) default '0' COMMENT 'This is the minimum number of items you want to keep in the auction house. a 0 here will make it the same as the maximum.',
  `maxitems` int(11) default '0' COMMENT 'This is the number of items you want to keep in the auction house.',
  `mintime` int(11) default '8' COMMENT 'Sets the minimum number of hours for an auction.',
  `maxtime` int(11) default '24' COMMENT 'Sets the maximum number of hours for an auction.',
  `percentgreytradegoods` int(11) default '0' COMMENT 'Sets the percentage of the Grey Trade Goods auction items',
  `percentwhitetradegoods` int(11) default '27' COMMENT 'Sets the percentage of the White Trade Goods auction items',
  `percentgreentradegoods` int(11) default '12' COMMENT 'Sets the percentage of the Green Trade Goods auction items',
  `percentbluetradegoods` int(11) default '10' COMMENT 'Sets the percentage of the Blue Trade Goods auction items',
  `percentpurpletradegoods` int(11) default '1' COMMENT 'Sets the percentage of the Purple Trade Goods auction items',
  `percentorangetradegoods` int(11) default '0' COMMENT 'Sets the percentage of the Orange Trade Goods auction items',
  `percentyellowtradegoods` int(11) default '0' COMMENT 'Sets the percentage of the Yellow Trade Goods auction items',
  `percentgreyitems` int(11) default '0' COMMENT 'Sets the percentage of the non trade Grey auction items',
  `percentwhiteitems` int(11) default '10' COMMENT 'Sets the percentage of the non trade White auction items',
  `percentgreenitems` int(11) default '30' COMMENT 'Sets the percentage of the non trade Green auction items',
  `percentblueitems` int(11) default '8' COMMENT 'Sets the percentage of the non trade Blue auction items',
  `percentpurpleitems` int(11) default '2' COMMENT 'Sets the percentage of the non trade Purple auction items',
  `percentorangeitems` int(11) default '0' COMMENT 'Sets the percentage of the non trade Orange auction items',
  `percentyellowitems` int(11) default '0' COMMENT 'Sets the percentage of the non trade Yellow auction items',
  `minpricegrey` int(11) default '100' COMMENT 'Minimum price of Grey items (percentage).',
  `maxpricegrey` int(11) default '150' COMMENT 'Maximum price of Grey items (percentage).',
  `minpricewhite` int(11) default '150' COMMENT 'Minimum price of White items (percentage).',
  `maxpricewhite` int(11) default '250' COMMENT 'Maximum price of White items (percentage).',
  `minpricegreen` int(11) default '800' COMMENT 'Minimum price of Green items (percentage).',
  `maxpricegreen` int(11) default '1400' COMMENT 'Maximum price of Green items (percentage).',
  `minpriceblue` int(11) default '1250' COMMENT 'Minimum price of Blue items (percentage).',
  `maxpriceblue` int(11) default '1750' COMMENT 'Maximum price of Blue items (percentage).',
  `minpricepurple` int(11) default '2250' COMMENT 'Minimum price of Purple items (percentage).',
  `maxpricepurple` int(11) default '4550' COMMENT 'Maximum price of Purple items (percentage).',
  `minpriceorange` int(11) default '3250' COMMENT 'Minimum price of Orange items (percentage).',
  `maxpriceorange` int(11) default '5550' COMMENT 'Maximum price of Orange items (percentage).',
  `minpriceyellow` int(11) default '5250' COMMENT 'Minimum price of Yellow items (percentage).',
  `maxpriceyellow` int(11) default '6550' COMMENT 'Maximum price of Yellow items (percentage).',
  `minbidpricegrey` int(11) default '70' COMMENT 'Starting bid price of Grey items as a percentage of the randomly chosen buyout price. Default: 70',
  `maxbidpricegrey` int(11) default '100' COMMENT 'Starting bid price of Grey items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpricewhite` int(11) default '70' COMMENT 'Starting bid price of White items as a percentage of the randomly chosen buyout price. Default: 70',
  `maxbidpricewhite` int(11) default '100' COMMENT 'Starting bid price of White items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpricegreen` int(11) default '80' COMMENT 'Starting bid price of Green items as a percentage of the randomly chosen buyout price. Default: 80',
  `maxbidpricegreen` int(11) default '100' COMMENT 'Starting bid price of Green items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpriceblue` int(11) default '75' COMMENT 'Starting bid price of Blue items as a percentage of the randomly chosen buyout price. Default: 75',
  `maxbidpriceblue` int(11) default '100' COMMENT 'Starting bid price of Blue items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpricepurple` int(11) default '80' COMMENT 'Starting bid price of Purple items as a percentage of the randomly chosen buyout price. Default: 80',
  `maxbidpricepurple` int(11) default '100' COMMENT 'Starting bid price of Purple items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpriceorange` int(11) default '80' COMMENT 'Starting bid price of Orange items as a percentage of the randomly chosen buyout price. Default: 80',
  `maxbidpriceorange` int(11) default '100' COMMENT 'Starting bid price of Orange items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpriceyellow` int(11) default '80' COMMENT 'Starting bid price of Yellow items as a percentage of the randomly chosen buyout price. Default: 80',
  `maxbidpriceyellow` int(11) default '100' COMMENT 'Starting bid price of Yellow items as a percentage of the randomly chosen buyout price. Default: 100',
  `maxstackgrey` int(11) default '0' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackwhite` int(11) default '0' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackgreen` int(11) default '3' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackblue` int(11) default '2' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackpurple` int(11) default '1' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackorange` int(11) default '1' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackyellow` int(11) default '1' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `buyerpricegrey` int(11) default '1' COMMENT 'Multiplier to vendorprice when buying grey items from auctionhouse',
  `buyerpricewhite` int(11) default '1' COMMENT 'Multiplier to vendorprice when buying white items from auctionhouse',
  `buyerpricegreen` int(11) default '5' COMMENT 'Multiplier to vendorprice when buying green items from auctionhouse',
  `buyerpriceblue` int(11) default '12' COMMENT 'Multiplier to vendorprice when buying blue items from auctionhouse',
  `buyerpricepurple` int(11) default '15' COMMENT 'Multiplier to vendorprice when buying purple items from auctionhouse',
  `buyerpriceorange` int(11) default '20' COMMENT 'Multiplier to vendorprice when buying orange items from auctionhouse',
  `buyerpriceyellow` int(11) default '22' COMMENT 'Multiplier to vendorprice when buying yellow items from auctionhouse',
  `buyerbiddinginterval` int(11) default '1' COMMENT 'Interval how frequently AHB bids on each AH. Time in minutes',
  `buyerbidsperinterval` int(11) default '1' COMMENT 'number of bids to put in per bidding interval',
  PRIMARY KEY  (`auctionhouse`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of auctionhousebot
-- ----------------------------
INSERT INTO `auctionhousebot` VALUES ('2', 'Alliance', '800', '800', '8', '24', '0', '27', '12', '10', '1', '0', '0', '0', '10', '30', '8', '2', '0', '0', '100', '150', '150', '250', '800', '1400', '1250', '1750', '2250', '4550', '3250', '5550', '5250', '6550', '70', '100', '70', '100', '80', '100', '75', '100', '80', '100', '80', '100', '80', '100', '0', '0', '3', '2', '1', '1', '1', '1', '1', '5', '12', '15', '20', '22', '1', '1');
INSERT INTO `auctionhousebot` VALUES ('6', 'Horde', '800', '800', '8', '24', '0', '27', '12', '10', '1', '0', '0', '0', '10', '30', '8', '2', '0', '0', '100', '150', '150', '250', '800', '1400', '1250', '1750', '2250', '4550', '3250', '5550', '5250', '6550', '70', '100', '70', '100', '80', '100', '75', '100', '80', '100', '80', '100', '80', '100', '0', '0', '3', '2', '1', '1', '1', '1', '1', '5', '12', '15', '20', '22', '1', '1');
INSERT INTO `auctionhousebot` VALUES ('7', 'Neutral', '800', '800', '8', '24', '0', '27', '12', '10', '1', '0', '0', '0', '10', '30', '8', '2', '0', '0', '100', '150', '150', '250', '800', '1400', '1250', '1750', '2250', '4550', '3250', '5550', '5250', '6550', '70', '100', '70', '100', '80', '100', '75', '100', '80', '100', '80', '100', '80', '100', '0', '0', '3', '2', '1', '1', '1', '1', '1', '5', '12', '15', '20', '22', '1', '1');

-- ----------------------------
-- Table structure for `autobroadcast`
-- ----------------------------
DROP TABLE IF EXISTS `autobroadcast`;
CREATE TABLE `autobroadcast` (
  `id` int(11) NOT NULL auto_increment,
  `text` longtext NOT NULL,
  `next` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of autobroadcast
-- ----------------------------
INSERT INTO `autobroadcast` VALUES ('1', 'Hello', '0');

-- ----------------------------
-- Table structure for `bugreport`
-- ----------------------------
DROP TABLE IF EXISTS `bugreport`;
CREATE TABLE `bugreport` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Identifier',
  `type` longtext NOT NULL,
  `content` longtext NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Debug System';

-- ----------------------------
-- Records of bugreport
-- ----------------------------

-- ----------------------------
-- Table structure for `character_account_data`
-- ----------------------------
DROP TABLE IF EXISTS `character_account_data`;
CREATE TABLE `character_account_data` (
  `guid` int(11) unsigned NOT NULL default '0',
  `type` int(11) unsigned NOT NULL default '0',
  `time` bigint(11) unsigned NOT NULL default '0',
  `data` longblob NOT NULL,
  PRIMARY KEY  (`guid`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_account_data
-- ----------------------------
INSERT INTO `character_account_data` VALUES ('6', '3', '1290957658', 0x42494E44494E474D4F444520300D0A62696E6420494E534552542053435245454E53484F540D0A62696E642050414745555020464C495043414D4552415941570D0A62696E64205052494E5453435245454E2053435245454E53484F540D0A62696E642053484946542D4C205147545F544F47474C455F545241434B45525F4B420D0A);
INSERT INTO `character_account_data` VALUES ('6', '7', '1293995906', 0x56455253494F4E20350A0A414444454456455253494F4E2031330A0A4F5054494F4E5F4755494C445F524543525549544D454E545F4348414E4E454C204155544F0A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C532035323432383830330A0A434F4C4F52530A53595354454D20323535203235352030204E0A534159203235352032353520323535204E0A5041525459203137302031373020323535204E0A5241494420323535203132372030204E0A4755494C4420363420323535203634204E0A4F46464943455220363420313932203634204E0A59454C4C20323535203634203634204E0A57484953504552203235352031323820323535204E0A574849535045525F464F524549474E203235352031323820323535204E0A574849535045525F494E464F524D203235352031323820323535204E0A454D4F54452032353520313238203634204E0A544558545F454D4F54452032353520313238203634204E0A4D4F4E535445525F534159203235352032353520313539204E0A4D4F4E535445525F5041525459203137302031373020323535204E0A4D4F4E535445525F59454C4C20323535203634203634204E0A4D4F4E535445525F57484953504552203235352031383120323335204E0A4D4F4E535445525F454D4F54452032353520313238203634204E0A4348414E4E454C203235352031393220313932204E0A4348414E4E454C5F4A4F494E203139322031323820313238204E0A4348414E4E454C5F4C45415645203139322031323820313238204E0A4348414E4E454C5F4C495354203139322031323820313238204E0A4348414E4E454C5F4E4F54494345203139322031393220313932204E0A4348414E4E454C5F4E4F544943455F55534552203139322031393220313932204E0A41464B203235352031323820323535204E0A444E44203235352031323820323535204E0A49474E4F5245442032353520302030204E0A534B494C4C20383520383520323535204E0A4C4F4F542030203137302030204E0A4D4F4E455920323535203235352030204E0A4F50454E494E47203132382031323820323535204E0A5452414445534B494C4C53203235352032353520323535204E0A5045545F494E464F203132382031323820323535204E0A434F4D4241545F4D4953435F494E464F203132382031323820323535204E0A434F4D4241545F58505F4741494E203131312031313120323535204E0A434F4D4241545F484F4E4F525F4741494E2032323420323032203130204E0A434F4D4241545F46414354494F4E5F4348414E4745203132382031323820323535204E0A42475F53595354454D5F4E45555452414C2032353520313230203130204E0A42475F53595354454D5F414C4C49414E434520302031373420323339204E0A42475F53595354454D5F484F5244452032353520302030204E0A524149445F4C4541444552203235352037322039204E0A524149445F5741524E494E47203235352037322030204E0A524149445F424F53535F454D4F544520323535203232312030204E0A524149445F424F53535F5748495350455220323535203232312030204E0A46494C54455245442032353520302030204E0A424154544C4547524F554E4420323535203132372030204E0A424154544C4547524F554E445F4C4541444552203235352032313920313833204E0A524553545249435445442032353520302030204E0A424154544C454E4554203235352032353520323535204E0A414348494556454D454E5420323535203235352030204E0A4755494C445F414348494556454D454E5420363420323535203634204E0A4152454E415F504F494E5453203235352032353520323535204E0A50415254595F4C4541444552203131382032303020323535204E0A54415247455449434F4E5320323535203235352030204E0A424E5F5748495350455220302032353520323436204E0A424E5F574849535045525F494E464F524D20302032353520323436204E0A424E5F434F4E564552534154494F4E20302031373720323430204E0A424E5F434F4E564552534154494F4E5F4E4F5449434520302031373720323430204E0A424E5F434F4E564552534154494F4E5F4C49535420302031373720323430204E0A424E5F494E4C494E455F544F4153545F414C455254203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F414443415354203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F4144434153545F494E464F524D203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F434F4E564552534154494F4E203133302031393720323535204E0A4348414E4E454C31203235352031393220313932204E0A4348414E4E454C32203235352031393220313932204E0A4348414E4E454C33203235352031393220313932204E0A4348414E4E454C34203235352031393220313932204E0A4348414E4E454C35203235352031393220313932204E0A4348414E4E454C36203235352031393220313932204E0A4348414E4E454C37203235352031393220313932204E0A4348414E4E454C38203235352031393220313932204E0A4348414E4E454C39203235352031393220313932204E0A4348414E4E454C3130203235352031393220313932204E0A454E440A0A57494E444F5720310A4E414D452047656E6572616C0A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420310A53484F574E20310A4D455353414745530A53595354454D0A53595354454D5F4E4F4D454E550A5341590A454D4F54450A59454C4C0A574849535045520A50415254590A50415254595F4C45414445520A524149440A524149445F4C45414445520A524149445F5741524E494E470A424154544C4547524F554E440A424154544C4547524F554E445F4C45414445520A4755494C440A4F4646494345520A4D4F4E535445525F5341590A4D4F4E535445525F59454C4C0A4D4F4E535445525F454D4F54450A4D4F4E535445525F574849535045520A4D4F4E535445525F424F53535F454D4F54450A4D4F4E535445525F424F53535F574849535045520A4552524F52530A41464B0A444E440A49474E4F5245440A42475F484F5244450A42475F414C4C49414E43450A42475F4E45555452414C0A434F4D4241545F46414354494F4E5F4348414E47450A534B494C4C0A4C4F4F540A4D4F4E45590A4348414E4E454C0A414348494556454D454E540A4755494C445F414348494556454D454E540A54415247455449434F4E530A424E5F574849535045520A424E5F574849535045525F494E464F524D0A424E5F434F4E564552534154494F4E0A424E5F494E4C494E455F544F4153545F414C4552540A454E440A0A4348414E4E454C530A5472697669610A454E440A0A5A4F4E454348414E4E454C532035323432383830330A0A454E440A0A57494E444F5720320A4E414D4520436F6D626174204C6F670A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420320A53484F574E20300A4D455353414745530A4F50454E494E470A5452414445534B494C4C530A5045545F494E464F0A434F4D4241545F58505F4741494E0A434F4D4241545F484F4E4F525F4741494E0A434F4D4241545F4D4953435F494E464F0A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720330A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720340A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720350A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720360A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720370A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720380A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720390A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F572031300A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A);
INSERT INTO `character_account_data` VALUES ('7', '7', '1293596234', 0x56455253494F4E20350A0A414444454456455253494F4E2031330A0A4F5054494F4E5F4755494C445F524543525549544D454E545F4348414E4E454C204155544F0A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C532035323432383830330A0A434F4C4F52530A53595354454D20323535203235352030204E0A534159203235352032353520323535204E0A5041525459203137302031373020323535204E0A5241494420323535203132372030204E0A4755494C4420363420323535203634204E0A4F46464943455220363420313932203634204E0A59454C4C20323535203634203634204E0A57484953504552203235352031323820323535204E0A574849535045525F464F524549474E203235352031323820323535204E0A574849535045525F494E464F524D203235352031323820323535204E0A454D4F54452032353520313238203634204E0A544558545F454D4F54452032353520313238203634204E0A4D4F4E535445525F534159203235352032353520313539204E0A4D4F4E535445525F5041525459203137302031373020323535204E0A4D4F4E535445525F59454C4C20323535203634203634204E0A4D4F4E535445525F57484953504552203235352031383120323335204E0A4D4F4E535445525F454D4F54452032353520313238203634204E0A4348414E4E454C203235352031393220313932204E0A4348414E4E454C5F4A4F494E203139322031323820313238204E0A4348414E4E454C5F4C45415645203139322031323820313238204E0A4348414E4E454C5F4C495354203139322031323820313238204E0A4348414E4E454C5F4E4F54494345203139322031393220313932204E0A4348414E4E454C5F4E4F544943455F55534552203139322031393220313932204E0A41464B203235352031323820323535204E0A444E44203235352031323820323535204E0A49474E4F5245442032353520302030204E0A534B494C4C20383520383520323535204E0A4C4F4F542030203137302030204E0A4D4F4E455920323535203235352030204E0A4F50454E494E47203132382031323820323535204E0A5452414445534B494C4C53203235352032353520323535204E0A5045545F494E464F203132382031323820323535204E0A434F4D4241545F4D4953435F494E464F203132382031323820323535204E0A434F4D4241545F58505F4741494E203131312031313120323535204E0A434F4D4241545F484F4E4F525F4741494E2032323420323032203130204E0A434F4D4241545F46414354494F4E5F4348414E4745203132382031323820323535204E0A42475F53595354454D5F4E45555452414C2032353520313230203130204E0A42475F53595354454D5F414C4C49414E434520302031373420323339204E0A42475F53595354454D5F484F5244452032353520302030204E0A524149445F4C4541444552203235352037322039204E0A524149445F5741524E494E47203235352037322030204E0A524149445F424F53535F454D4F544520323535203232312030204E0A524149445F424F53535F5748495350455220323535203232312030204E0A46494C54455245442032353520302030204E0A424154544C4547524F554E4420323535203132372030204E0A424154544C4547524F554E445F4C4541444552203235352032313920313833204E0A524553545249435445442032353520302030204E0A424154544C454E4554203235352032353520323535204E0A414348494556454D454E5420323535203235352030204E0A4755494C445F414348494556454D454E5420363420323535203634204E0A4152454E415F504F494E5453203235352032353520323535204E0A50415254595F4C4541444552203131382032303020323535204E0A54415247455449434F4E5320323535203235352030204E0A424E5F5748495350455220302032353520323436204E0A424E5F574849535045525F494E464F524D20302032353520323436204E0A424E5F434F4E564552534154494F4E20302031373720323430204E0A424E5F434F4E564552534154494F4E5F4E4F5449434520302031373720323430204E0A424E5F434F4E564552534154494F4E5F4C49535420302031373720323430204E0A424E5F494E4C494E455F544F4153545F414C455254203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F414443415354203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F4144434153545F494E464F524D203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F434F4E564552534154494F4E203133302031393720323535204E0A4348414E4E454C31203235352031393220313932204E0A4348414E4E454C32203235352031393220313932204E0A4348414E4E454C33203235352031393220313932204E0A4348414E4E454C34203235352031393220313932204E0A4348414E4E454C35203235352031393220313932204E0A4348414E4E454C36203235352031393220313932204E0A4348414E4E454C37203235352031393220313932204E0A4348414E4E454C38203235352031393220313932204E0A4348414E4E454C39203235352031393220313932204E0A4348414E4E454C3130203235352031393220313932204E0A454E440A0A57494E444F5720310A4E414D452047656E6572616C0A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420310A53484F574E20310A4D455353414745530A53595354454D0A53595354454D5F4E4F4D454E550A5341590A454D4F54450A59454C4C0A574849535045520A50415254590A50415254595F4C45414445520A524149440A524149445F4C45414445520A524149445F5741524E494E470A424154544C4547524F554E440A424154544C4547524F554E445F4C45414445520A4755494C440A4F4646494345520A4D4F4E535445525F5341590A4D4F4E535445525F59454C4C0A4D4F4E535445525F454D4F54450A4D4F4E535445525F574849535045520A4D4F4E535445525F424F53535F454D4F54450A4D4F4E535445525F424F53535F574849535045520A4552524F52530A41464B0A444E440A49474E4F5245440A42475F484F5244450A42475F414C4C49414E43450A42475F4E45555452414C0A434F4D4241545F46414354494F4E5F4348414E47450A534B494C4C0A4C4F4F540A4D4F4E45590A4348414E4E454C0A414348494556454D454E540A4755494C445F414348494556454D454E540A54415247455449434F4E530A424E5F574849535045520A424E5F574849535045525F494E464F524D0A424E5F434F4E564552534154494F4E0A424E5F494E4C494E455F544F4153545F414C4552540A454E440A0A4348414E4E454C530A5472697669610A454E440A0A5A4F4E454348414E4E454C532031383837343337310A0A454E440A0A57494E444F5720320A4E414D4520436F6D626174204C6F670A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420320A53484F574E20300A4D455353414745530A4F50454E494E470A5452414445534B494C4C530A5045545F494E464F0A434F4D4241545F58505F4741494E0A434F4D4241545F484F4E4F525F4741494E0A434F4D4241545F4D4953435F494E464F0A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720330A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720340A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720350A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720360A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720370A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720380A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720390A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F572031300A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A);
INSERT INTO `character_account_data` VALUES ('2', '7', '1290821039', 0x56455253494F4E20350A0A414444454456455253494F4E2031330A0A4F5054494F4E5F4755494C445F524543525549544D454E545F4348414E4E454C204155544F0A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C532035323432383830330A0A434F4C4F52530A53595354454D20323535203235352030204E0A534159203235352032353520323535204E0A5041525459203137302031373020323535204E0A5241494420323535203132372030204E0A4755494C4420363420323535203634204E0A4F46464943455220363420313932203634204E0A59454C4C20323535203634203634204E0A57484953504552203235352031323820323535204E0A574849535045525F464F524549474E203235352031323820323535204E0A574849535045525F494E464F524D203235352031323820323535204E0A454D4F54452032353520313238203634204E0A544558545F454D4F54452032353520313238203634204E0A4D4F4E535445525F534159203235352032353520313539204E0A4D4F4E535445525F5041525459203137302031373020323535204E0A4D4F4E535445525F59454C4C20323535203634203634204E0A4D4F4E535445525F57484953504552203235352031383120323335204E0A4D4F4E535445525F454D4F54452032353520313238203634204E0A4348414E4E454C203235352031393220313932204E0A4348414E4E454C5F4A4F494E203139322031323820313238204E0A4348414E4E454C5F4C45415645203139322031323820313238204E0A4348414E4E454C5F4C495354203139322031323820313238204E0A4348414E4E454C5F4E4F54494345203139322031393220313932204E0A4348414E4E454C5F4E4F544943455F55534552203139322031393220313932204E0A41464B203235352031323820323535204E0A444E44203235352031323820323535204E0A49474E4F5245442032353520302030204E0A534B494C4C20383520383520323535204E0A4C4F4F542030203137302030204E0A4D4F4E455920323535203235352030204E0A4F50454E494E47203132382031323820323535204E0A5452414445534B494C4C53203235352032353520323535204E0A5045545F494E464F203132382031323820323535204E0A434F4D4241545F4D4953435F494E464F203132382031323820323535204E0A434F4D4241545F58505F4741494E203131312031313120323535204E0A434F4D4241545F484F4E4F525F4741494E2032323420323032203130204E0A434F4D4241545F46414354494F4E5F4348414E4745203132382031323820323535204E0A42475F53595354454D5F4E45555452414C2032353520313230203130204E0A42475F53595354454D5F414C4C49414E434520302031373420323339204E0A42475F53595354454D5F484F5244452032353520302030204E0A524149445F4C4541444552203235352037322039204E0A524149445F5741524E494E47203235352037322030204E0A524149445F424F53535F454D4F544520323535203232312030204E0A524149445F424F53535F5748495350455220323535203232312030204E0A46494C54455245442032353520302030204E0A424154544C4547524F554E4420323535203132372030204E0A424154544C4547524F554E445F4C4541444552203235352032313920313833204E0A524553545249435445442032353520302030204E0A424154544C454E4554203235352032353520323535204E0A414348494556454D454E5420323535203235352030204E0A4755494C445F414348494556454D454E5420363420323535203634204E0A4152454E415F504F494E5453203235352032353520323535204E0A50415254595F4C4541444552203131382032303020323535204E0A54415247455449434F4E5320323535203235352030204E0A424E5F5748495350455220302032353520323436204E0A424E5F574849535045525F494E464F524D20302032353520323436204E0A424E5F434F4E564552534154494F4E20302031373720323430204E0A424E5F434F4E564552534154494F4E5F4E4F5449434520302031373720323430204E0A424E5F434F4E564552534154494F4E5F4C49535420302031373720323430204E0A424E5F494E4C494E455F544F4153545F414C455254203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F414443415354203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F4144434153545F494E464F524D203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F434F4E564552534154494F4E203133302031393720323535204E0A4348414E4E454C31203235352031393220313932204E0A4348414E4E454C32203235352031393220313932204E0A4348414E4E454C33203235352031393220313932204E0A4348414E4E454C34203235352031393220313932204E0A4348414E4E454C35203235352031393220313932204E0A4348414E4E454C36203235352031393220313932204E0A4348414E4E454C37203235352031393220313932204E0A4348414E4E454C38203235352031393220313932204E0A4348414E4E454C39203235352031393220313932204E0A4348414E4E454C3130203235352031393220313932204E0A454E440A0A57494E444F5720310A4E414D452047656E6572616C0A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420310A53484F574E20310A4D455353414745530A53595354454D0A53595354454D5F4E4F4D454E550A5341590A454D4F54450A59454C4C0A574849535045520A50415254590A50415254595F4C45414445520A524149440A524149445F4C45414445520A524149445F5741524E494E470A424154544C4547524F554E440A424154544C4547524F554E445F4C45414445520A4755494C440A4F4646494345520A4D4F4E535445525F5341590A4D4F4E535445525F59454C4C0A4D4F4E535445525F454D4F54450A4D4F4E535445525F574849535045520A4D4F4E535445525F424F53535F454D4F54450A4D4F4E535445525F424F53535F574849535045520A4552524F52530A41464B0A444E440A49474E4F5245440A42475F484F5244450A42475F414C4C49414E43450A42475F4E45555452414C0A434F4D4241545F46414354494F4E5F4348414E47450A534B494C4C0A4C4F4F540A4D4F4E45590A4348414E4E454C0A414348494556454D454E540A4755494C445F414348494556454D454E540A54415247455449434F4E530A424E5F574849535045520A424E5F574849535045525F494E464F524D0A424E5F434F4E564552534154494F4E0A424E5F494E4C494E455F544F4153545F414C4552540A454E440A0A4348414E4E454C530A4C6F6F6B696E67466F7247726F75700A5472697669610A454E440A0A5A4F4E454348414E4E454C532031383837343337310A0A454E440A0A57494E444F5720320A4E414D4520436F6D626174204C6F670A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420320A53484F574E20300A4D455353414745530A4F50454E494E470A5452414445534B494C4C530A5045545F494E464F0A434F4D4241545F58505F4741494E0A434F4D4241545F484F4E4F525F4741494E0A434F4D4241545F4D4953435F494E464F0A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720330A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720340A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720350A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720360A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720370A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720380A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720390A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F572031300A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A);
INSERT INTO `character_account_data` VALUES ('6', '1', '1294391699', 0x534554206D696E696D61705A6F6F6D202230220A534554206D696E696D6170496E736964655A6F6F6D202230220A5345542071756573744C6F67436F6C6C6170736546696C74657220222D31220A53455420747261636B656451756573747320227601220A53455420747261636B6564416368696576656D656E747320227601220A5345542063616D657261536176656444697374616E6365202231352E303030303030220A5345542063616D65726153617665645069746368202231312E353439393934220A53455420706C61796572537461744C65667444726F70646F776E2022504C41594552535441545F424153455F5354415453220A53455420706C6179657253746174526967687444726F70646F776E2022504C41594552535441545F4D454C45455F434F4D424154220A);
INSERT INTO `character_account_data` VALUES ('9', '1', '1294423083', 0x534554206D696E696D61705A6F6F6D202230220A534554206D696E696D6170496E736964655A6F6F6D202230220A5345542071756573744C6F67436F6C6C6170736546696C74657220222D31220A53455420747261636B656451756573747320227601244D79220A53455420747261636B6564416368696576656D656E747320227601220A5345542063616D657261536176656444697374616E6365202232312E303033363232220A5345542063616D657261536176656456656869636C6544697374616E6365202233322E393038393839220A5345542063616D65726153617665645069746368202233302E303030303031220A53455420706C61796572537461744C65667444726F70646F776E2022504C41594552535441545F424153455F5354415453220A53455420706C6179657253746174526967687444726F70646F776E2022504C41594552535441545F52414E4745445F434F4D424154220A);
INSERT INTO `character_account_data` VALUES ('9', '3', '1290847749', 0x42494E44494E474D4F444520300D0A62696E6420494E534552542053435245454E53484F540D0A62696E642050414745555020464C495043414D4552415941570D0A62696E64205052494E5453435245454E2053435245454E53484F540D0A62696E642053484946542D4C205147545F544F47474C455F545241434B45525F4B420D0A);
INSERT INTO `character_account_data` VALUES ('9', '7', '1294415066', 0x56455253494F4E20350A0A414444454456455253494F4E2031330A0A4F5054494F4E5F4755494C445F524543525549544D454E545F4348414E4E454C204155544F0A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C532035323432383830330A0A434F4C4F52530A53595354454D20323535203235352030204E0A534159203235352032353520323535204E0A5041525459203137302031373020323535204E0A5241494420323535203132372030204E0A4755494C4420363420323535203634204E0A4F46464943455220363420313932203634204E0A59454C4C20323535203634203634204E0A57484953504552203235352031323820323535204E0A574849535045525F464F524549474E203235352031323820323535204E0A574849535045525F494E464F524D203235352031323820323535204E0A454D4F54452032353520313238203634204E0A544558545F454D4F54452032353520313238203634204E0A4D4F4E535445525F534159203235352032353520313539204E0A4D4F4E535445525F5041525459203137302031373020323535204E0A4D4F4E535445525F59454C4C20323535203634203634204E0A4D4F4E535445525F57484953504552203235352031383120323335204E0A4D4F4E535445525F454D4F54452032353520313238203634204E0A4348414E4E454C203235352031393220313932204E0A4348414E4E454C5F4A4F494E203139322031323820313238204E0A4348414E4E454C5F4C45415645203139322031323820313238204E0A4348414E4E454C5F4C495354203139322031323820313238204E0A4348414E4E454C5F4E4F54494345203139322031393220313932204E0A4348414E4E454C5F4E4F544943455F55534552203139322031393220313932204E0A41464B203235352031323820323535204E0A444E44203235352031323820323535204E0A49474E4F5245442032353520302030204E0A534B494C4C20383520383520323535204E0A4C4F4F542030203137302030204E0A4D4F4E455920323535203235352030204E0A4F50454E494E47203132382031323820323535204E0A5452414445534B494C4C53203235352032353520323535204E0A5045545F494E464F203132382031323820323535204E0A434F4D4241545F4D4953435F494E464F203132382031323820323535204E0A434F4D4241545F58505F4741494E203131312031313120323535204E0A434F4D4241545F484F4E4F525F4741494E2032323420323032203130204E0A434F4D4241545F46414354494F4E5F4348414E4745203132382031323820323535204E0A42475F53595354454D5F4E45555452414C2032353520313230203130204E0A42475F53595354454D5F414C4C49414E434520302031373420323339204E0A42475F53595354454D5F484F5244452032353520302030204E0A524149445F4C4541444552203235352037322039204E0A524149445F5741524E494E47203235352037322030204E0A524149445F424F53535F454D4F544520323535203232312030204E0A524149445F424F53535F5748495350455220323535203232312030204E0A46494C54455245442032353520302030204E0A424154544C4547524F554E4420323535203132372030204E0A424154544C4547524F554E445F4C4541444552203235352032313920313833204E0A524553545249435445442032353520302030204E0A424154544C454E4554203235352032353520323535204E0A414348494556454D454E5420323535203235352030204E0A4755494C445F414348494556454D454E5420363420323535203634204E0A4152454E415F504F494E5453203235352032353520323535204E0A50415254595F4C4541444552203131382032303020323535204E0A54415247455449434F4E5320323535203235352030204E0A424E5F5748495350455220302032353520323436204E0A424E5F574849535045525F494E464F524D20302032353520323436204E0A424E5F434F4E564552534154494F4E20302031373720323430204E0A424E5F434F4E564552534154494F4E5F4E4F5449434520302031373720323430204E0A424E5F434F4E564552534154494F4E5F4C49535420302031373720323430204E0A424E5F494E4C494E455F544F4153545F414C455254203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F414443415354203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F4144434153545F494E464F524D203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F434F4E564552534154494F4E203133302031393720323535204E0A4348414E4E454C31203235352031393220313932204E0A4348414E4E454C32203235352031393220313932204E0A4348414E4E454C33203235352031393220313932204E0A4348414E4E454C34203235352031393220313932204E0A4348414E4E454C35203235352031393220313932204E0A4348414E4E454C36203235352031393220313932204E0A4348414E4E454C37203235352031393220313932204E0A4348414E4E454C38203235352031393220313932204E0A4348414E4E454C39203235352031393220313932204E0A4348414E4E454C3130203235352031393220313932204E0A454E440A0A57494E444F5720310A4E414D452047656E6572616C0A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420310A53484F574E20310A4D455353414745530A53595354454D0A53595354454D5F4E4F4D454E550A5341590A454D4F54450A59454C4C0A574849535045520A50415254590A50415254595F4C45414445520A524149440A524149445F4C45414445520A524149445F5741524E494E470A424154544C4547524F554E440A424154544C4547524F554E445F4C45414445520A4755494C440A4F4646494345520A4D4F4E535445525F5341590A4D4F4E535445525F59454C4C0A4D4F4E535445525F454D4F54450A4D4F4E535445525F574849535045520A4D4F4E535445525F424F53535F454D4F54450A4D4F4E535445525F424F53535F574849535045520A4552524F52530A41464B0A444E440A49474E4F5245440A42475F484F5244450A42475F414C4C49414E43450A42475F4E45555452414C0A434F4D4241545F46414354494F4E5F4348414E47450A534B494C4C0A4C4F4F540A4D4F4E45590A4348414E4E454C0A414348494556454D454E540A4755494C445F414348494556454D454E540A54415247455449434F4E530A424E5F574849535045520A424E5F574849535045525F494E464F524D0A424E5F434F4E564552534154494F4E0A424E5F494E4C494E455F544F4153545F414C4552540A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C532031383837343337310A0A454E440A0A57494E444F5720320A4E414D4520436F6D626174204C6F670A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420320A53484F574E20300A4D455353414745530A4F50454E494E470A5452414445534B494C4C530A5045545F494E464F0A434F4D4241545F58505F4741494E0A434F4D4241545F484F4E4F525F4741494E0A434F4D4241545F4D4953435F494E464F0A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720330A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720340A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720350A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720360A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720370A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720380A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720390A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F572031300A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A);
INSERT INTO `character_account_data` VALUES ('7', '1', '1293596540', 0x534554206D696E696D61705A6F6F6D202230220A534554206D696E696D6170496E736964655A6F6F6D202230220A5345542071756573744C6F67436F6C6C6170736546696C74657220222D31220A53455420747261636B656451756573747320227601220A53455420747261636B6564416368696576656D656E747320227601220A5345542063616D657261536176656444697374616E63652022362E353439363030220A5345542063616D657261536176656450697463682022312E303439393934220A53455420706C61796572537461744C65667444726F70646F776E2022504C41594552535441545F424153455F5354415453220A53455420706C6179657253746174526967687444726F70646F776E2022504C41594552535441545F4D454C45455F434F4D424154220A);
INSERT INTO `character_account_data` VALUES ('7', '3', '1293596233', 0x42494E44494E474D4F444520300D0A62696E642053484946542D4C205147545F544F47474C455F545241434B45525F4B420D0A);
INSERT INTO `character_account_data` VALUES ('2', '1', '1290821038', 0x534554206D696E696D61705A6F6F6D202230220A5345542071756573744C6F67436F6C6C6170736546696C74657220222D31220A53455420747261636B656451756573747320227601220A53455420747261636B6564416368696576656D656E747320227601220A5345542063616D657261536176656444697374616E6365202232302E343639303238220A5345542063616D65726153617665645069746368202231332E343137353436220A53455420706C61796572537461744C65667444726F70646F776E2022504C41594552535441545F424153455F5354415453220A53455420706C6179657253746174526967687444726F70646F776E2022504C41594552535441545F4D454C45455F434F4D424154220A);
INSERT INTO `character_account_data` VALUES ('2', '3', '1290503503', 0x42494E44494E474D4F444520300D0A62696E642053484946542D4C205147545F544F47474C455F545241434B45525F4B420D0A);

-- ----------------------------
-- Table structure for `character_achievement`
-- ----------------------------
DROP TABLE IF EXISTS `character_achievement`;
CREATE TABLE `character_achievement` (
  `guid` int(11) unsigned NOT NULL,
  `achievement` int(11) unsigned NOT NULL,
  `date` bigint(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`achievement`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_achievement
-- ----------------------------
INSERT INTO `character_achievement` VALUES ('7', '7', '1293596540');
INSERT INTO `character_achievement` VALUES ('7', '6', '1293596540');
INSERT INTO `character_achievement` VALUES ('7', '133', '1293596540');
INSERT INTO `character_achievement` VALUES ('7', '132', '1293596540');
INSERT INTO `character_achievement` VALUES ('7', '891', '1293596540');
INSERT INTO `character_achievement` VALUES ('7', '131', '1293596540');
INSERT INTO `character_achievement` VALUES ('7', '10', '1293596540');
INSERT INTO `character_achievement` VALUES ('7', '889', '1293596540');
INSERT INTO `character_achievement` VALUES ('6', '6', '1292600097');
INSERT INTO `character_achievement` VALUES ('7', '9', '1293596540');
INSERT INTO `character_achievement` VALUES ('7', '8', '1293596540');
INSERT INTO `character_achievement` VALUES ('6', '503', '1292744030');

-- ----------------------------
-- Table structure for `character_achievement_progress`
-- ----------------------------
DROP TABLE IF EXISTS `character_achievement_progress`;
CREATE TABLE `character_achievement_progress` (
  `guid` int(11) unsigned NOT NULL,
  `criteria` int(11) unsigned NOT NULL,
  `counter` int(11) unsigned NOT NULL,
  `date` bigint(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`criteria`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_achievement_progress
-- ----------------------------
INSERT INTO `character_achievement_progress` VALUES ('7', '5592', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5576', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '840', '150', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '40', '55', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('6', '5215', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '9686', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '3510', '1007', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '5316', '5345', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '1526', '1', '1292744170');
INSERT INTO `character_achievement_progress` VALUES ('6', '1531', '1', '1292599841');
INSERT INTO `character_achievement_progress` VALUES ('6', '996', '13085', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '2239', '54', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '36', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '3506', '1007', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '10505', '1', '1292577449');
INSERT INTO `character_achievement_progress` VALUES ('6', '3355', '6810', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '5577', '60', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '233', '54', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '1513', '1', '1292577187');
INSERT INTO `character_achievement_progress` VALUES ('6', '73', '54', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '5371', '184', '1290610616');
INSERT INTO `character_achievement_progress` VALUES ('6', '41', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '992', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '3361', '3413', '1290752521');
INSERT INTO `character_achievement_progress` VALUES ('6', '9687', '5345', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '841', '75', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '5376', '87', '1290753226');
INSERT INTO `character_achievement_progress` VALUES ('6', '3511', '1007', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '6752', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '4224', '8915', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '1518', '1', '1292577167');
INSERT INTO `character_achievement_progress` VALUES ('6', '5701', '1', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '4960', '2', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '613', '75', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '5317', '13085', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '7891', '15', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '1504', '1', '1293996035');
INSERT INTO `character_achievement_progress` VALUES ('6', '842', '75', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '1527', '1', '1292744435');
INSERT INTO `character_achievement_progress` VALUES ('6', '6753', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '5230', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5249', '1', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('7', '756', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '36', '30', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5579', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '4763', '3500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '843', '300', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5314', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '994', '3100', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '754', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '34', '10', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5577', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '841', '225', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '41', '55', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '1872', '75', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '992', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '656', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '9687', '3100', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '4743', '3200', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '167', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '39', '55', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '9598', '40', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5230', '55', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '1870', '150', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '9685', '4000', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '8821', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5589', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5317', '4000', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5301', '7', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '37', '40', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5212', '55', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '1884', '3500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '844', '300', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '9683', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '8819', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5315', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5219', '55', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '995', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '755', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '35', '20', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '6394', '26', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5578', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5562', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '842', '300', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5313', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5249', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '2417', '3200', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '1873', '150', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '993', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '753', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '641', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('6', '37', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5592', '1', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '6751', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '111', '4', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '5372', '8885', '1290610616');
INSERT INTO `character_achievement_progress` VALUES ('6', '5212', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '7222', '2', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '9683', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '1514', '1', '1292577063');
INSERT INTO `character_achievement_progress` VALUES ('6', '3507', '1007', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '4092', '6810', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '5313', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '4091', '3413', '1290752521');
INSERT INTO `character_achievement_progress` VALUES ('6', '993', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '614', '75', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '1528', '1', '1292204627');
INSERT INTO `character_achievement_progress` VALUES ('6', '4961', '2', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '3512', '1007', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '2072', '2326', '1292228115');
INSERT INTO `character_achievement_progress` VALUES ('6', '232', '54', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '40', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '755', '60', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5967', '36', '1290959143');
INSERT INTO `character_achievement_progress` VALUES ('6', '5375', '2770', '1290753226');
INSERT INTO `character_achievement_progress` VALUES ('6', '1546', '1', '1293995978');
INSERT INTO `character_achievement_progress` VALUES ('7', '1871', '150', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '9686', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '8822', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '7222', '26', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5590', '270', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '38', '50', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '9684', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '8820', '500', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '5316', '3100', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '2020', '200', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('7', '996', '4000', '1293596540');
INSERT INTO `character_achievement_progress` VALUES ('6', '4959', '2', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '234', '54', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '4943', '2770', '1290753226');
INSERT INTO `character_achievement_progress` VALUES ('6', '4093', '1007', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '230', '50', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '3631', '54', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '612', '75', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '9684', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5314', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5373', '42', '1290610616');
INSERT INTO `character_achievement_progress` VALUES ('6', '5563', '1', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '843', '75', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '6754', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '1510', '1', '1290959910');
INSERT INTO `character_achievement_progress` VALUES ('6', '1524', '1', '1292604600');
INSERT INTO `character_achievement_progress` VALUES ('6', '38', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '6393', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '615', '75', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '1517', '1', '1292204133');
INSERT INTO `character_achievement_progress` VALUES ('6', '994', '5345', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5300', '1', '1292204532');
INSERT INTO `character_achievement_progress` VALUES ('6', '756', '60', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5323', '250', '1293996053');
INSERT INTO `character_achievement_progress` VALUES ('6', '5593', '4', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '1529', '1', '1292599639');
INSERT INTO `character_achievement_progress` VALUES ('6', '1515', '1', '1292200294');
INSERT INTO `character_achievement_progress` VALUES ('6', '34', '10', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '162', '27825', '1290610616');
INSERT INTO `character_achievement_progress` VALUES ('6', '7221', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '1511', '1', '1292204791');
INSERT INTO `character_achievement_progress` VALUES ('6', '1520', '1', '1292604806');
INSERT INTO `character_achievement_progress` VALUES ('6', '3513', '6810', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '844', '75', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '5968', '2', '1293885466');
INSERT INTO `character_achievement_progress` VALUES ('6', '5374', '87', '1290753226');
INSERT INTO `character_achievement_progress` VALUES ('6', '231', '54', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '8822', '500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '167', '60', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '9685', '13085', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '39', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '8821', '500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '6755', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '5301', '8', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '9598', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5315', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '149', '2', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '8820', '500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '995', '2745', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '1521', '1', '1292229317');
INSERT INTO `character_achievement_progress` VALUES ('6', '2020', '200', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '1884', '3500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '1508', '1', '1290502447');
INSERT INTO `character_achievement_progress` VALUES ('6', '6394', '2', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '5562', '1', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '1509', '1', '1290828299');
INSERT INTO `character_achievement_progress` VALUES ('6', '5242', '1', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '8819', '500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5589', '60', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '4763', '3500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '3354', '1007', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '236', '54', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '35', '12', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '1512', '1', '1290959319');
INSERT INTO `character_achievement_progress` VALUES ('6', '840', '75', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '753', '60', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '168', '75', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '5576', '60', '1290502430');

-- ----------------------------
-- Table structure for `character_action`
-- ----------------------------
DROP TABLE IF EXISTS `character_action`;
CREATE TABLE `character_action` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `spec` tinyint(3) unsigned NOT NULL default '0',
  `button` tinyint(3) unsigned NOT NULL default '0',
  `action` int(11) unsigned NOT NULL default '0',
  `type` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spec`,`button`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_action
-- ----------------------------
INSERT INTO `character_action` VALUES ('9', '0', '6', '1', '64');
INSERT INTO `character_action` VALUES ('9', '0', '4', '45902', '0');
INSERT INTO `character_action` VALUES ('9', '0', '5', '47541', '0');
INSERT INTO `character_action` VALUES ('9', '0', '10', '20577', '0');
INSERT INTO `character_action` VALUES ('6', '0', '5', '20271', '0');
INSERT INTO `character_action` VALUES ('6', '0', '4', '21084', '0');
INSERT INTO `character_action` VALUES ('6', '0', '3', '28730', '0');
INSERT INTO `character_action` VALUES ('6', '0', '1', '19740', '0');
INSERT INTO `character_action` VALUES ('9', '0', '3', '45462', '0');
INSERT INTO `character_action` VALUES ('6', '0', '2', '635', '0');
INSERT INTO `character_action` VALUES ('6', '0', '0', '6603', '0');
INSERT INTO `character_action` VALUES ('9', '0', '7', '2', '64');
INSERT INTO `character_action` VALUES ('9', '0', '8', '5', '64');
INSERT INTO `character_action` VALUES ('9', '0', '9', '4', '64');
INSERT INTO `character_action` VALUES ('9', '0', '11', '3', '64');
INSERT INTO `character_action` VALUES ('7', '0', '0', '6603', '0');
INSERT INTO `character_action` VALUES ('7', '0', '1', '49576', '0');
INSERT INTO `character_action` VALUES ('7', '0', '2', '45477', '0');
INSERT INTO `character_action` VALUES ('7', '0', '3', '45462', '0');
INSERT INTO `character_action` VALUES ('7', '0', '4', '45902', '0');
INSERT INTO `character_action` VALUES ('7', '0', '5', '47541', '0');
INSERT INTO `character_action` VALUES ('7', '0', '6', '2', '64');
INSERT INTO `character_action` VALUES ('7', '0', '7', '1', '64');
INSERT INTO `character_action` VALUES ('7', '0', '8', '5', '64');
INSERT INTO `character_action` VALUES ('7', '0', '9', '3', '64');
INSERT INTO `character_action` VALUES ('7', '0', '10', '4', '64');
INSERT INTO `character_action` VALUES ('9', '0', '2', '45477', '0');
INSERT INTO `character_action` VALUES ('9', '0', '1', '49576', '0');
INSERT INTO `character_action` VALUES ('9', '0', '0', '6603', '0');

-- ----------------------------
-- Table structure for `character_aura`
-- ----------------------------
DROP TABLE IF EXISTS `character_aura`;
CREATE TABLE `character_aura` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `caster_guid` bigint(20) unsigned NOT NULL default '0' COMMENT 'Full Global Unique Identifier',
  `item_guid` int(11) unsigned NOT NULL default '0',
  `spell` int(11) unsigned NOT NULL default '0',
  `stackcount` int(11) NOT NULL default '1',
  `remaincharges` int(11) NOT NULL default '0',
  `basepoints0` int(11) NOT NULL default '0',
  `basepoints1` int(11) NOT NULL default '0',
  `basepoints2` int(11) NOT NULL default '0',
  `maxduration0` int(11) NOT NULL default '0',
  `maxduration1` int(11) NOT NULL default '0',
  `maxduration2` int(11) NOT NULL default '0',
  `remaintime0` int(11) NOT NULL default '0',
  `remaintime1` int(11) NOT NULL default '0',
  `remaintime2` int(11) NOT NULL default '0',
  `effIndexMask` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guid`,`caster_guid`,`item_guid`,`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_aura
-- ----------------------------
INSERT INTO `character_aura` VALUES ('7', '7', '0', '48266', '1', '0', '15', '0', '-20', '-1', '-1', '-1', '-1', '-1', '-1', '7');
INSERT INTO `character_aura` VALUES ('7', '7', '0', '51915', '1', '0', '0', '0', '0', '-1', '0', '0', '-1', '0', '0', '1');
INSERT INTO `character_aura` VALUES ('7', '7', '0', '63611', '1', '0', '0', '4', '0', '0', '-1', '0', '0', '-1', '0', '2');
INSERT INTO `character_aura` VALUES ('9', '9', '0', '48266', '0', '0', '15', '0', '-28', '-1', '-1', '-1', '-1', '-1', '-1', '7');
INSERT INTO `character_aura` VALUES ('9', '9', '0', '63611', '0', '0', '0', '4', '0', '0', '-1', '0', '0', '-1', '0', '2');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '63531', '0', '0', '0', '0', '0', '0', '-1', '-1', '0', '-1', '-1', '6');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '63510', '0', '0', '0', '0', '0', '0', '-1', '-1', '0', '-1', '-1', '6');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '63514', '0', '0', '0', '0', '0', '0', '-1', '0', '0', '-1', '0', '2');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '465', '0', '0', '55', '0', '0', '-1', '0', '0', '-1', '0', '0', '1');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '19740', '0', '0', '20', '20', '0', '600000', '600000', '0', '114931', '114931', '0', '3');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '21084', '0', '0', '0', '0', '20187', '1800000', '1800000', '1800000', '472739', '472739', '472739', '7');

-- ----------------------------
-- Table structure for `character_battleground_data`
-- ----------------------------
DROP TABLE IF EXISTS `character_battleground_data`;
CREATE TABLE `character_battleground_data` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `instance_id` int(11) unsigned NOT NULL default '0',
  `team` int(11) unsigned NOT NULL default '0',
  `join_x` float NOT NULL default '0',
  `join_y` float NOT NULL default '0',
  `join_z` float NOT NULL default '0',
  `join_o` float NOT NULL default '0',
  `join_map` int(11) NOT NULL default '0',
  `taxi_start` int(11) NOT NULL default '0',
  `taxi_end` int(11) NOT NULL default '0',
  `mount_spell` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_battleground_data
-- ----------------------------

-- ----------------------------
-- Table structure for `character_battleground_random`
-- ----------------------------
DROP TABLE IF EXISTS `character_battleground_random`;
CREATE TABLE `character_battleground_random` (
  `guid` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_battleground_random
-- ----------------------------

-- ----------------------------
-- Table structure for `character_db_version`
-- ----------------------------
DROP TABLE IF EXISTS `character_db_version`;
CREATE TABLE `character_db_version` (
  `required_10973_01_characters_game_event_status` bit(1) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Last applied sql update to DB';

-- ----------------------------
-- Records of character_db_version
-- ----------------------------
INSERT INTO `character_db_version` VALUES (null);

-- ----------------------------
-- Table structure for `character_declinedname`
-- ----------------------------
DROP TABLE IF EXISTS `character_declinedname`;
CREATE TABLE `character_declinedname` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `genitive` varchar(15) NOT NULL default '',
  `dative` varchar(15) NOT NULL default '',
  `accusative` varchar(15) NOT NULL default '',
  `instrumental` varchar(15) NOT NULL default '',
  `prepositional` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of character_declinedname
-- ----------------------------

-- ----------------------------
-- Table structure for `character_equipmentsets`
-- ----------------------------
DROP TABLE IF EXISTS `character_equipmentsets`;
CREATE TABLE `character_equipmentsets` (
  `guid` int(11) NOT NULL default '0',
  `setguid` bigint(20) NOT NULL auto_increment,
  `setindex` tinyint(4) NOT NULL default '0',
  `name` varchar(100) NOT NULL,
  `iconname` varchar(100) NOT NULL,
  `item0` int(11) NOT NULL default '0',
  `item1` int(11) NOT NULL default '0',
  `item2` int(11) NOT NULL default '0',
  `item3` int(11) NOT NULL default '0',
  `item4` int(11) NOT NULL default '0',
  `item5` int(11) NOT NULL default '0',
  `item6` int(11) NOT NULL default '0',
  `item7` int(11) NOT NULL default '0',
  `item8` int(11) NOT NULL default '0',
  `item9` int(11) NOT NULL default '0',
  `item10` int(11) NOT NULL default '0',
  `item11` int(11) NOT NULL default '0',
  `item12` int(11) NOT NULL default '0',
  `item13` int(11) NOT NULL default '0',
  `item14` int(11) NOT NULL default '0',
  `item15` int(11) NOT NULL default '0',
  `item16` int(11) NOT NULL default '0',
  `item17` int(11) NOT NULL default '0',
  `item18` int(11) NOT NULL default '0',
  PRIMARY KEY  (`setguid`),
  UNIQUE KEY `idx_set` (`guid`,`setguid`,`setindex`),
  KEY `Idx_setindex` (`setindex`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_equipmentsets
-- ----------------------------

-- ----------------------------
-- Table structure for `character_feed_log`
-- ----------------------------
DROP TABLE IF EXISTS `character_feed_log`;
CREATE TABLE `character_feed_log` (
  `guid` int(11) NOT NULL,
  `type` smallint(1) NOT NULL,
  `data` int(11) NOT NULL,
  `date` int(11) default NULL,
  `counter` int(11) NOT NULL,
  `difficulty` smallint(6) default '-1',
  `item_guid` int(11) NOT NULL,
  PRIMARY KEY  (`guid`,`type`,`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_feed_log
-- ----------------------------

-- ----------------------------
-- Table structure for `character_gifts`
-- ----------------------------
DROP TABLE IF EXISTS `character_gifts`;
CREATE TABLE `character_gifts` (
  `guid` int(20) unsigned NOT NULL default '0',
  `item_guid` int(11) unsigned NOT NULL default '0',
  `entry` int(20) unsigned NOT NULL default '0',
  `flags` int(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`item_guid`),
  KEY `idx_guid` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_gifts
-- ----------------------------

-- ----------------------------
-- Table structure for `character_glyphs`
-- ----------------------------
DROP TABLE IF EXISTS `character_glyphs`;
CREATE TABLE `character_glyphs` (
  `guid` int(11) unsigned NOT NULL,
  `spec` tinyint(3) unsigned NOT NULL default '0',
  `slot` tinyint(3) unsigned NOT NULL default '0',
  `glyph` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spec`,`slot`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_glyphs
-- ----------------------------

-- ----------------------------
-- Table structure for `character_homebind`
-- ----------------------------
DROP TABLE IF EXISTS `character_homebind`;
CREATE TABLE `character_homebind` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `map` int(11) unsigned NOT NULL default '0' COMMENT 'Map Identifier',
  `zone` int(11) unsigned NOT NULL default '0' COMMENT 'Zone Identifier',
  `position_x` float NOT NULL default '0',
  `position_y` float NOT NULL default '0',
  `position_z` float NOT NULL default '0',
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_homebind
-- ----------------------------
INSERT INTO `character_homebind` VALUES ('9', '609', '4298', '2356.21', '-5662.21', '426.026');
INSERT INTO `character_homebind` VALUES ('6', '530', '3665', '9478.2', '-6858.35', '17.372');
INSERT INTO `character_homebind` VALUES ('7', '609', '4298', '2355.84', '-5664.77', '426.028');
INSERT INTO `character_homebind` VALUES ('2', '0', '1', '-6240', '331', '383');

-- ----------------------------
-- Table structure for `character_instance`
-- ----------------------------
DROP TABLE IF EXISTS `character_instance`;
CREATE TABLE `character_instance` (
  `guid` int(11) unsigned NOT NULL default '0',
  `instance` int(11) unsigned NOT NULL default '0',
  `permanent` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_instance
-- ----------------------------
INSERT INTO `character_instance` VALUES ('9', '4', '0');
INSERT INTO `character_instance` VALUES ('9', '2', '0');
INSERT INTO `character_instance` VALUES ('9', '1', '0');
INSERT INTO `character_instance` VALUES ('9', '3', '0');

-- ----------------------------
-- Table structure for `character_inventory`
-- ----------------------------
DROP TABLE IF EXISTS `character_inventory`;
CREATE TABLE `character_inventory` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `bag` int(11) unsigned NOT NULL default '0',
  `slot` tinyint(3) unsigned NOT NULL default '0',
  `item` int(11) unsigned NOT NULL default '0' COMMENT 'Item Global Unique Identifier',
  `item_template` int(11) unsigned NOT NULL default '0' COMMENT 'Item Identifier',
  PRIMARY KEY  (`item`),
  KEY `idx_guid` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_inventory
-- ----------------------------
INSERT INTO `character_inventory` VALUES ('2', '0', '4', '36', '56');
INSERT INTO `character_inventory` VALUES ('2', '0', '7', '42', '55');
INSERT INTO `character_inventory` VALUES ('2', '0', '15', '44', '35');
INSERT INTO `character_inventory` VALUES ('2', '0', '23', '46', '6948');
INSERT INTO `character_inventory` VALUES ('6', '7855', '0', '39607', '6293');
INSERT INTO `character_inventory` VALUES ('6', '0', '21', '13504', '4496');
INSERT INTO `character_inventory` VALUES ('9', '0', '1', '11051', '34657');
INSERT INTO `character_inventory` VALUES ('7', '0', '24', '9874', '40582');
INSERT INTO `character_inventory` VALUES ('6', '13504', '3', '28442', '1179');
INSERT INTO `character_inventory` VALUES ('9', '0', '9', '11043', '34649');
INSERT INTO `character_inventory` VALUES ('7', '0', '23', '9872', '41751');
INSERT INTO `character_inventory` VALUES ('7', '0', '11', '9870', '38147');
INSERT INTO `character_inventory` VALUES ('7', '0', '8', '358', '34653');
INSERT INTO `character_inventory` VALUES ('6', '0', '23', '630', '6948');
INSERT INTO `character_inventory` VALUES ('7', '0', '23', '382', '41751');
INSERT INTO `character_inventory` VALUES ('6', '0', '3', '622', '24143');
INSERT INTO `character_inventory` VALUES ('9', '0', '23', '11065', '41751');
INSERT INTO `character_inventory` VALUES ('9', '0', '11', '11063', '38147');
INSERT INTO `character_inventory` VALUES ('9', '0', '22', '11061', '38145');
INSERT INTO `character_inventory` VALUES ('9', '0', '21', '11059', '38145');
INSERT INTO `character_inventory` VALUES ('9', '0', '20', '11057', '38145');
INSERT INTO `character_inventory` VALUES ('9', '0', '19', '11055', '38145');
INSERT INTO `character_inventory` VALUES ('6', '0', '5', '28432', '2635');
INSERT INTO `character_inventory` VALUES ('6', '0', '26', '37504', '118');
INSERT INTO `character_inventory` VALUES ('6', '0', '27', '37506', '858');
INSERT INTO `character_inventory` VALUES ('6', '0', '30', '37507', '2318');
INSERT INTO `character_inventory` VALUES ('6', '0', '16', '10296', '20841');
INSERT INTO `character_inventory` VALUES ('7', '0', '21', '376', '38145');
INSERT INTO `character_inventory` VALUES ('7', '0', '22', '378', '38145');
INSERT INTO `character_inventory` VALUES ('6', '0', '35', '39601', '22570');
INSERT INTO `character_inventory` VALUES ('6', '0', '36', '39602', '15925');
INSERT INTO `character_inventory` VALUES ('6', '0', '29', '25959', '27668');
INSERT INTO `character_inventory` VALUES ('7', '0', '5', '362', '34651');
INSERT INTO `character_inventory` VALUES ('7', '0', '6', '364', '34656');
INSERT INTO `character_inventory` VALUES ('7', '0', '4', '356', '34650');
INSERT INTO `character_inventory` VALUES ('6', '0', '24', '10500', '159');
INSERT INTO `character_inventory` VALUES ('6', '7855', '2', '39612', '12223');
INSERT INTO `character_inventory` VALUES ('6', '0', '14', '23656', '1421');
INSERT INTO `character_inventory` VALUES ('7', '0', '1', '368', '34657');
INSERT INTO `character_inventory` VALUES ('7', '0', '2', '352', '34655');
INSERT INTO `character_inventory` VALUES ('6', '0', '20', '10279', '4496');
INSERT INTO `character_inventory` VALUES ('7', '0', '19', '372', '38145');
INSERT INTO `character_inventory` VALUES ('9', '0', '7', '11049', '34648');
INSERT INTO `character_inventory` VALUES ('6', '0', '31', '37508', '4537');
INSERT INTO `character_inventory` VALUES ('6', '0', '32', '26233', '6507');
INSERT INTO `character_inventory` VALUES ('9', '0', '14', '11037', '34659');
INSERT INTO `character_inventory` VALUES ('6', '0', '25', '25964', '23500');
INSERT INTO `character_inventory` VALUES ('9', '0', '10', '11053', '34658');
INSERT INTO `character_inventory` VALUES ('6', '0', '34', '39312', '4814');
INSERT INTO `character_inventory` VALUES ('6', '0', '33', '23868', '22976');
INSERT INTO `character_inventory` VALUES ('9', '0', '5', '11045', '34651');
INSERT INTO `character_inventory` VALUES ('9', '0', '0', '11033', '34652');
INSERT INTO `character_inventory` VALUES ('9', '0', '2', '11035', '34655');
INSERT INTO `character_inventory` VALUES ('6', '7855', '1', '39609', '2967');
INSERT INTO `character_inventory` VALUES ('6', '0', '9', '23867', '23376');
INSERT INTO `character_inventory` VALUES ('6', '0', '4', '22916', '22953');
INSERT INTO `character_inventory` VALUES ('6', '0', '15', '13503', '2488');
INSERT INTO `character_inventory` VALUES ('9', '0', '6', '11047', '34656');
INSERT INTO `character_inventory` VALUES ('2', '0', '3', '500', '49');
INSERT INTO `character_inventory` VALUES ('2', '0', '6', '502', '48');
INSERT INTO `character_inventory` VALUES ('7', '0', '20', '9864', '38145');
INSERT INTO `character_inventory` VALUES ('2', '0', '17', '510', '28979');
INSERT INTO `character_inventory` VALUES ('7', '0', '10', '9860', '34658');
INSERT INTO `character_inventory` VALUES ('7', '0', '7', '9856', '34648');
INSERT INTO `character_inventory` VALUES ('7', '0', '9', '9850', '34649');
INSERT INTO `character_inventory` VALUES ('7', '0', '14', '9844', '34659');
INSERT INTO `character_inventory` VALUES ('7', '0', '0', '9840', '34652');
INSERT INTO `character_inventory` VALUES ('6', '0', '8', '38710', '28148');
INSERT INTO `character_inventory` VALUES ('6', '0', '22', '38711', '22571');
INSERT INTO `character_inventory` VALUES ('6', '0', '38', '26232', '15969');
INSERT INTO `character_inventory` VALUES ('6', '0', '28', '26110', '4604');
INSERT INTO `character_inventory` VALUES ('6', '7855', '3', '39613', '6506');
INSERT INTO `character_inventory` VALUES ('6', '0', '37', '39606', '6296');
INSERT INTO `character_inventory` VALUES ('6', '0', '7', '28141', '2642');
INSERT INTO `character_inventory` VALUES ('6', '0', '19', '7855', '20474');
INSERT INTO `character_inventory` VALUES ('9', '0', '8', '11041', '34653');
INSERT INTO `character_inventory` VALUES ('6', '0', '6', '26229', '2646');
INSERT INTO `character_inventory` VALUES ('9', '0', '4', '11039', '34650');

-- ----------------------------
-- Table structure for `character_pet`
-- ----------------------------
DROP TABLE IF EXISTS `character_pet`;
CREATE TABLE `character_pet` (
  `id` int(11) unsigned NOT NULL default '0',
  `entry` int(11) unsigned NOT NULL default '0',
  `owner` int(11) unsigned NOT NULL default '0',
  `modelid` int(11) unsigned default '0',
  `CreatedBySpell` int(11) unsigned NOT NULL default '0',
  `PetType` tinyint(3) unsigned NOT NULL default '0',
  `level` int(11) unsigned NOT NULL default '1',
  `exp` int(11) unsigned NOT NULL default '0',
  `Reactstate` tinyint(1) unsigned NOT NULL default '0',
  `name` varchar(100) default 'Pet',
  `renamed` tinyint(1) unsigned NOT NULL default '0',
  `slot` int(11) unsigned NOT NULL default '0',
  `curhealth` int(11) unsigned NOT NULL default '1',
  `curmana` int(11) unsigned NOT NULL default '0',
  `curhappiness` int(11) unsigned NOT NULL default '0',
  `savetime` bigint(20) unsigned NOT NULL default '0',
  `resettalents_cost` int(11) unsigned NOT NULL default '0',
  `resettalents_time` bigint(20) unsigned NOT NULL default '0',
  `abdata` longtext,
  PRIMARY KEY  (`id`),
  KEY `owner` (`owner`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Pet System';

-- ----------------------------
-- Records of character_pet
-- ----------------------------

-- ----------------------------
-- Table structure for `character_pet_declinedname`
-- ----------------------------
DROP TABLE IF EXISTS `character_pet_declinedname`;
CREATE TABLE `character_pet_declinedname` (
  `id` int(11) unsigned NOT NULL default '0',
  `owner` int(11) unsigned NOT NULL default '0',
  `genitive` varchar(12) NOT NULL default '',
  `dative` varchar(12) NOT NULL default '',
  `accusative` varchar(12) NOT NULL default '',
  `instrumental` varchar(12) NOT NULL default '',
  `prepositional` varchar(12) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `owner_key` (`owner`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of character_pet_declinedname
-- ----------------------------

-- ----------------------------
-- Table structure for `character_queststatus`
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus`;
CREATE TABLE `character_queststatus` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `quest` int(11) unsigned NOT NULL default '0' COMMENT 'Quest Identifier',
  `status` int(11) unsigned NOT NULL default '0',
  `rewarded` tinyint(1) unsigned NOT NULL default '0',
  `explored` tinyint(1) unsigned NOT NULL default '0',
  `timer` bigint(20) unsigned NOT NULL default '0',
  `mobcount1` int(11) unsigned NOT NULL default '0',
  `mobcount2` int(11) unsigned NOT NULL default '0',
  `mobcount3` int(11) unsigned NOT NULL default '0',
  `mobcount4` int(11) unsigned NOT NULL default '0',
  `itemcount1` int(11) unsigned NOT NULL default '0',
  `itemcount2` int(11) unsigned NOT NULL default '0',
  `itemcount3` int(11) unsigned NOT NULL default '0',
  `itemcount4` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`quest`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus
-- ----------------------------
INSERT INTO `character_queststatus` VALUES ('6', '9705', '1', '1', '0', '1290828900', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9704', '1', '1', '0', '1290828900', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8350', '1', '1', '0', '1290832144', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8347', '1', '1', '0', '1290828900', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8338', '1', '1', '0', '1290828900', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8335', '1', '1', '0', '1290828900', '8', '2', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9147', '3', '0', '0', '1293996958', '0', '0', '0', '0', '3', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '10166', '1', '1', '1', '1292744602', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8490', '1', '1', '0', '1293885505', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8474', '1', '1', '0', '1292744602', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9253', '1', '1', '0', '1292744602', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8473', '1', '1', '0', '1292605919', '10', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9255', '1', '1', '0', '1292604448', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8488', '1', '1', '1', '1292603548', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9144', '1', '1', '0', '1293885505', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8887', '1', '1', '0', '1292600870', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8487', '1', '1', '0', '1292600870', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('9', '12641', '3', '0', '0', '1292575453', '1', '1', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9359', '1', '1', '0', '1292577505', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9252', '1', '1', '0', '1292604448', '4', '4', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8475', '1', '1', '0', '1292228887', '8', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9076', '1', '1', '0', '1292600870', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9067', '1', '1', '0', '1292577505', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8886', '1', '1', '0', '1292600870', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8480', '1', '1', '0', '1292227716', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9395', '1', '1', '0', '1292205026', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9358', '1', '1', '0', '1292577505', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9258', '1', '1', '0', '1292605105', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9254', '1', '1', '0', '1292577505', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8892', '1', '1', '0', '1292228887', '5', '5', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8491', '1', '1', '0', '1292204688', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9066', '1', '1', '0', '1292229337', '1', '1', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9064', '1', '1', '0', '1292200383', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8334', '1', '1', '0', '1290827822', '7', '7', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8346', '1', '1', '0', '1290753393', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8345', '1', '1', '0', '1290753393', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9062', '1', '1', '0', '1292200383', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8330', '1', '1', '0', '1290753393', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '10069', '1', '1', '0', '1290747446', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9676', '1', '1', '0', '1290612331', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8336', '1', '1', '0', '1290753616', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8327', '1', '1', '0', '1290753616', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8326', '1', '1', '0', '1290753393', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8325', '1', '1', '0', '1290612331', '8', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8463', '1', '1', '0', '1290959548', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9035', '1', '1', '0', '1292200383', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9256', '1', '1', '0', '1292204688', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8483', '1', '1', '0', '1292149404', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8482', '1', '1', '0', '1292149404', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('9', '12593', '1', '0', '0', '1291572981', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8486', '1', '1', '0', '1292149404', '5', '5', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9352', '1', '1', '0', '1292149404', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8895', '1', '1', '0', '1290959548', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9119', '1', '1', '0', '1290960448', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8472', '1', '1', '0', '1290959548', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8468', '1', '1', '0', '1290959548', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9148', '1', '1', '0', '1293996958', '0', '0', '0', '0', '0', '0', '0', '0');

-- ----------------------------
-- Table structure for `character_queststatus_daily`
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus_daily`;
CREATE TABLE `character_queststatus_daily` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `quest` int(11) unsigned NOT NULL default '0' COMMENT 'Quest Identifier',
  PRIMARY KEY  (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus_daily
-- ----------------------------

-- ----------------------------
-- Table structure for `character_queststatus_monthly`
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus_monthly`;
CREATE TABLE `character_queststatus_monthly` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `quest` int(11) unsigned NOT NULL default '0' COMMENT 'Quest Identifier',
  PRIMARY KEY  (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus_monthly
-- ----------------------------

-- ----------------------------
-- Table structure for `character_queststatus_weekly`
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus_weekly`;
CREATE TABLE `character_queststatus_weekly` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `quest` int(11) unsigned NOT NULL default '0' COMMENT 'Quest Identifier',
  PRIMARY KEY  (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus_weekly
-- ----------------------------

-- ----------------------------
-- Table structure for `character_reputation`
-- ----------------------------
DROP TABLE IF EXISTS `character_reputation`;
CREATE TABLE `character_reputation` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `faction` int(11) unsigned NOT NULL default '0',
  `standing` int(11) NOT NULL default '0',
  `flags` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guid`,`faction`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_reputation
-- ----------------------------
INSERT INTO `character_reputation` VALUES ('9', '1156', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1155', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '1154', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '1137', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '1136', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '1126', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '1124', '379', '17');
INSERT INTO `character_reputation` VALUES ('9', '1119', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '1118', '0', '12');
INSERT INTO `character_reputation` VALUES ('9', '1117', '0', '12');
INSERT INTO `character_reputation` VALUES ('9', '1106', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '1105', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1104', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1098', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '1094', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '1097', '0', '12');
INSERT INTO `character_reputation` VALUES ('9', '1037', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '952', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '948', '0', '8');
INSERT INTO `character_reputation` VALUES ('9', '949', '0', '24');
INSERT INTO `character_reputation` VALUES ('9', '1090', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1091', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1082', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '1085', '379', '17');
INSERT INTO `character_reputation` VALUES ('9', '1077', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1073', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1068', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '1067', '379', '17');
INSERT INTO `character_reputation` VALUES ('9', '1064', '379', '17');
INSERT INTO `character_reputation` VALUES ('9', '1052', '860', '152');
INSERT INTO `character_reputation` VALUES ('9', '1050', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '1038', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1031', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1015', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '1012', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1011', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1005', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '989', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '978', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '970', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '942', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '967', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '934', '0', '80');
INSERT INTO `character_reputation` VALUES ('9', '941', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '933', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '936', '0', '28');
INSERT INTO `character_reputation` VALUES ('9', '932', '0', '80');
INSERT INTO `character_reputation` VALUES ('9', '990', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '922', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '911', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '910', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '509', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '510', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '270', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '909', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '930', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '892', '0', '24');
INSERT INTO `character_reputation` VALUES ('9', '891', '0', '14');
INSERT INTO `character_reputation` VALUES ('9', '889', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '890', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '809', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '980', '0', '24');
INSERT INTO `character_reputation` VALUES ('9', '749', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '729', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '730', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '935', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '946', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '947', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '609', '0', '1');
INSERT INTO `character_reputation` VALUES ('9', '576', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '574', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '569', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '571', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '570', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '289', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '46', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '577', '0', '64');
INSERT INTO `character_reputation` VALUES ('9', '589', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '550', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '551', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '549', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '83', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '86', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '69', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '47', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '72', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '54', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '68', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '81', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '530', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '76', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '529', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '67', '0', '25');
INSERT INTO `character_reputation` VALUES ('9', '469', '0', '14');
INSERT INTO `character_reputation` VALUES ('9', '169', '0', '12');
INSERT INTO `character_reputation` VALUES ('9', '470', '0', '64');
INSERT INTO `character_reputation` VALUES ('9', '471', '0', '22');
INSERT INTO `character_reputation` VALUES ('9', '369', '0', '64');
INSERT INTO `character_reputation` VALUES ('9', '70', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '349', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '59', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '93', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '92', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '21', '0', '64');
INSERT INTO `character_reputation` VALUES ('9', '87', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '729', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '730', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '935', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '947', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '609', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '574', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '576', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '571', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '589', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '577', '0', '64');
INSERT INTO `character_reputation` VALUES ('6', '46', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '289', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '570', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '550', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '551', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '47', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '946', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '549', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '83', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '86', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '69', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '72', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '369', '0', '64');
INSERT INTO `character_reputation` VALUES ('6', '471', '0', '22');
INSERT INTO `character_reputation` VALUES ('6', '470', '0', '64');
INSERT INTO `character_reputation` VALUES ('6', '93', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '54', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '68', '2245', '17');
INSERT INTO `character_reputation` VALUES ('6', '81', '2245', '17');
INSERT INTO `character_reputation` VALUES ('6', '67', '0', '25');
INSERT INTO `character_reputation` VALUES ('6', '569', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '530', '2245', '17');
INSERT INTO `character_reputation` VALUES ('6', '76', '2245', '17');
INSERT INTO `character_reputation` VALUES ('6', '529', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '21', '0', '64');
INSERT INTO `character_reputation` VALUES ('6', '469', '0', '14');
INSERT INTO `character_reputation` VALUES ('6', '169', '0', '12');
INSERT INTO `character_reputation` VALUES ('6', '70', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '349', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '59', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '92', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '87', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '87', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '21', '0', '64');
INSERT INTO `character_reputation` VALUES ('7', '92', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '93', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '59', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '349', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '70', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '369', '0', '64');
INSERT INTO `character_reputation` VALUES ('7', '471', '0', '20');
INSERT INTO `character_reputation` VALUES ('7', '470', '0', '64');
INSERT INTO `character_reputation` VALUES ('7', '169', '0', '12');
INSERT INTO `character_reputation` VALUES ('7', '469', '0', '25');
INSERT INTO `character_reputation` VALUES ('7', '67', '0', '14');
INSERT INTO `character_reputation` VALUES ('7', '529', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '76', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '530', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '81', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '68', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '54', '0', '273');
INSERT INTO `character_reputation` VALUES ('7', '72', '0', '17');
INSERT INTO `character_reputation` VALUES ('7', '47', '0', '273');
INSERT INTO `character_reputation` VALUES ('7', '69', '0', '273');
INSERT INTO `character_reputation` VALUES ('7', '86', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '83', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '549', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '551', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '550', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '589', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '577', '0', '64');
INSERT INTO `character_reputation` VALUES ('7', '46', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '289', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '570', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '571', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '569', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '574', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '576', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '609', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '947', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '946', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '935', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '730', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '729', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '749', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '980', '0', '24');
INSERT INTO `character_reputation` VALUES ('7', '809', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '890', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '889', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '891', '0', '24');
INSERT INTO `character_reputation` VALUES ('7', '892', '0', '14');
INSERT INTO `character_reputation` VALUES ('7', '930', '0', '273');
INSERT INTO `character_reputation` VALUES ('7', '909', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '270', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '510', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '509', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '910', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '911', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '922', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '990', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '932', '0', '80');
INSERT INTO `character_reputation` VALUES ('7', '936', '0', '28');
INSERT INTO `character_reputation` VALUES ('7', '933', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '941', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '934', '0', '80');
INSERT INTO `character_reputation` VALUES ('7', '967', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '942', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '970', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '978', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '989', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1005', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '1011', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1012', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1015', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '1031', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1038', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1050', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1052', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '1064', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '1067', '0', '3');
INSERT INTO `character_reputation` VALUES ('7', '1068', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1073', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1077', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1085', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '1082', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '1091', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1090', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '949', '0', '24');
INSERT INTO `character_reputation` VALUES ('7', '948', '0', '8');
INSERT INTO `character_reputation` VALUES ('7', '952', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '1037', '0', '136');
INSERT INTO `character_reputation` VALUES ('7', '1097', '0', '12');
INSERT INTO `character_reputation` VALUES ('7', '1094', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1098', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1104', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1105', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1106', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1117', '0', '12');
INSERT INTO `character_reputation` VALUES ('7', '1118', '0', '12');
INSERT INTO `character_reputation` VALUES ('7', '1119', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '1124', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '1126', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1136', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '1137', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '1154', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '1155', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '1156', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '87', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '21', '0', '64');
INSERT INTO `character_reputation` VALUES ('2', '92', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '93', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '59', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '349', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '70', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '369', '0', '64');
INSERT INTO `character_reputation` VALUES ('2', '471', '0', '20');
INSERT INTO `character_reputation` VALUES ('2', '470', '0', '64');
INSERT INTO `character_reputation` VALUES ('2', '169', '0', '12');
INSERT INTO `character_reputation` VALUES ('2', '469', '0', '25');
INSERT INTO `character_reputation` VALUES ('2', '67', '0', '14');
INSERT INTO `character_reputation` VALUES ('2', '529', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '76', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '530', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '81', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '68', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '54', '0', '17');
INSERT INTO `character_reputation` VALUES ('2', '72', '0', '273');
INSERT INTO `character_reputation` VALUES ('2', '47', '0', '273');
INSERT INTO `character_reputation` VALUES ('2', '69', '0', '273');
INSERT INTO `character_reputation` VALUES ('2', '86', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '83', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '549', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '551', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '550', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '589', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '577', '0', '64');
INSERT INTO `character_reputation` VALUES ('2', '46', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '289', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '570', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '571', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '569', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '574', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '576', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '609', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '947', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '946', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '935', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '730', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '729', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '749', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '980', '0', '24');
INSERT INTO `character_reputation` VALUES ('2', '809', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '890', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '889', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '891', '0', '24');
INSERT INTO `character_reputation` VALUES ('2', '892', '0', '14');
INSERT INTO `character_reputation` VALUES ('2', '930', '0', '273');
INSERT INTO `character_reputation` VALUES ('2', '909', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '270', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '510', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '509', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '910', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '911', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '922', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '990', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '932', '0', '80');
INSERT INTO `character_reputation` VALUES ('2', '936', '0', '28');
INSERT INTO `character_reputation` VALUES ('2', '933', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '941', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '934', '0', '80');
INSERT INTO `character_reputation` VALUES ('2', '967', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '942', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '970', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '978', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '989', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1005', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1011', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1012', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1015', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '1031', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1038', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1050', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1052', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '1064', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '1067', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '1068', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1073', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1077', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1085', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '1082', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1091', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1090', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '949', '0', '24');
INSERT INTO `character_reputation` VALUES ('2', '948', '0', '8');
INSERT INTO `character_reputation` VALUES ('2', '952', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '1037', '0', '136');
INSERT INTO `character_reputation` VALUES ('2', '1097', '0', '12');
INSERT INTO `character_reputation` VALUES ('2', '1094', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1098', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1104', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1105', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1106', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1117', '0', '12');
INSERT INTO `character_reputation` VALUES ('2', '1118', '0', '12');
INSERT INTO `character_reputation` VALUES ('2', '1119', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '1124', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '1126', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1136', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1137', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1154', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1155', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1156', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '749', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '980', '0', '24');
INSERT INTO `character_reputation` VALUES ('6', '809', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '890', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '889', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '891', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '892', '0', '24');
INSERT INTO `character_reputation` VALUES ('6', '930', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '909', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '270', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '510', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '509', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '910', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '911', '9085', '17');
INSERT INTO `character_reputation` VALUES ('6', '922', '250', '17');
INSERT INTO `character_reputation` VALUES ('6', '990', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '932', '0', '80');
INSERT INTO `character_reputation` VALUES ('6', '936', '0', '28');
INSERT INTO `character_reputation` VALUES ('6', '933', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '941', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '934', '0', '80');
INSERT INTO `character_reputation` VALUES ('6', '967', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '942', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '970', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '978', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '989', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1005', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '1011', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1012', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1015', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '1031', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1038', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1050', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '1052', '0', '152');
INSERT INTO `character_reputation` VALUES ('6', '1064', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1067', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1068', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '1073', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1077', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1085', '0', '17');
INSERT INTO `character_reputation` VALUES ('6', '1082', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '1091', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1090', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '949', '0', '24');
INSERT INTO `character_reputation` VALUES ('6', '948', '0', '8');
INSERT INTO `character_reputation` VALUES ('6', '952', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '1037', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '1097', '0', '12');
INSERT INTO `character_reputation` VALUES ('6', '1094', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '1098', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1104', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1105', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1106', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1117', '0', '12');
INSERT INTO `character_reputation` VALUES ('6', '1118', '0', '12');
INSERT INTO `character_reputation` VALUES ('6', '1119', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '1124', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1126', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '1136', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '1137', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '1154', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '1155', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '1156', '0', '16');

-- ----------------------------
-- Table structure for `character_skills`
-- ----------------------------
DROP TABLE IF EXISTS `character_skills`;
CREATE TABLE `character_skills` (
  `guid` int(11) unsigned NOT NULL COMMENT 'Global Unique Identifier',
  `skill` mediumint(9) unsigned NOT NULL,
  `value` mediumint(9) unsigned NOT NULL,
  `max` mediumint(9) unsigned NOT NULL,
  PRIMARY KEY  (`guid`,`skill`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_skills
-- ----------------------------
INSERT INTO `character_skills` VALUES ('2', '8', '1', '1');
INSERT INTO `character_skills` VALUES ('2', '136', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '313', '300', '300');
INSERT INTO `character_skills` VALUES ('2', '98', '300', '300');
INSERT INTO `character_skills` VALUES ('2', '162', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '228', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '6', '1', '1');
INSERT INTO `character_skills` VALUES ('2', '95', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '415', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '172', '300', '300');
INSERT INTO `character_skills` VALUES ('9', '44', '300', '300');
INSERT INTO `character_skills` VALUES ('9', '771', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '43', '300', '300');
INSERT INTO `character_skills` VALUES ('9', '770', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '762', '150', '150');
INSERT INTO `character_skills` VALUES ('9', '162', '300', '300');
INSERT INTO `character_skills` VALUES ('9', '673', '300', '300');
INSERT INTO `character_skills` VALUES ('9', '129', '270', '300');
INSERT INTO `character_skills` VALUES ('6', '594', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '162', '60', '60');
INSERT INTO `character_skills` VALUES ('6', '433', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '137', '300', '300');
INSERT INTO `character_skills` VALUES ('9', '772', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '109', '300', '300');
INSERT INTO `character_skills` VALUES ('9', '229', '300', '300');
INSERT INTO `character_skills` VALUES ('9', '293', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '413', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '118', '300', '300');
INSERT INTO `character_skills` VALUES ('9', '414', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '55', '300', '300');
INSERT INTO `character_skills` VALUES ('9', '95', '300', '300');
INSERT INTO `character_skills` VALUES ('9', '415', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '129', '270', '300');
INSERT INTO `character_skills` VALUES ('7', '98', '300', '300');
INSERT INTO `character_skills` VALUES ('7', '162', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '762', '150', '150');
INSERT INTO `character_skills` VALUES ('7', '770', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '43', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '771', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '44', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '172', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '772', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '229', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '293', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '413', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '118', '1', '275');
INSERT INTO `character_skills` VALUES ('7', '414', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '55', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '95', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '415', '1', '1');
INSERT INTO `character_skills` VALUES ('2', '176', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '173', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '253', '1', '1');
INSERT INTO `character_skills` VALUES ('2', '38', '1', '1');
INSERT INTO `character_skills` VALUES ('2', '118', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '414', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '109', '300', '300');
INSERT INTO `character_skills` VALUES ('7', '756', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '137', '300', '300');
INSERT INTO `character_skills` VALUES ('6', '185', '1', '75');
INSERT INTO `character_skills` VALUES ('6', '129', '1', '75');
INSERT INTO `character_skills` VALUES ('6', '43', '60', '60');
INSERT INTO `character_skills` VALUES ('6', '756', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '109', '300', '300');
INSERT INTO `character_skills` VALUES ('6', '413', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '414', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '55', '60', '60');
INSERT INTO `character_skills` VALUES ('6', '95', '60', '60');
INSERT INTO `character_skills` VALUES ('6', '415', '1', '1');

-- ----------------------------
-- Table structure for `character_social`
-- ----------------------------
DROP TABLE IF EXISTS `character_social`;
CREATE TABLE `character_social` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Character Global Unique Identifier',
  `friend` int(11) unsigned NOT NULL default '0' COMMENT 'Friend Global Unique Identifier',
  `flags` tinyint(1) unsigned NOT NULL default '0' COMMENT 'Friend Flags',
  `note` varchar(48) NOT NULL default '' COMMENT 'Friend Note',
  PRIMARY KEY  (`guid`,`friend`,`flags`),
  KEY `guid` (`guid`),
  KEY `friend` (`friend`),
  KEY `guid_flags` (`guid`,`flags`),
  KEY `friend_flags` (`friend`,`flags`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_social
-- ----------------------------

-- ----------------------------
-- Table structure for `character_spell`
-- ----------------------------
DROP TABLE IF EXISTS `character_spell`;
CREATE TABLE `character_spell` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `spell` int(11) unsigned NOT NULL default '0' COMMENT 'Spell Identifier',
  `active` tinyint(3) unsigned NOT NULL default '1',
  `disabled` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spell`),
  KEY `Idx_spell` (`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_spell
-- ----------------------------
INSERT INTO `character_spell` VALUES ('6', '37836', '1', '0');
INSERT INTO `character_spell` VALUES ('6', '3273', '1', '0');
INSERT INTO `character_spell` VALUES ('6', '2550', '1', '0');
INSERT INTO `character_spell` VALUES ('6', '20271', '1', '0');
INSERT INTO `character_spell` VALUES ('6', '19740', '1', '0');
INSERT INTO `character_spell` VALUES ('6', '465', '1', '0');

-- ----------------------------
-- Table structure for `character_spell_cooldown`
-- ----------------------------
DROP TABLE IF EXISTS `character_spell_cooldown`;
CREATE TABLE `character_spell_cooldown` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier, Low part',
  `spell` int(11) unsigned NOT NULL default '0' COMMENT 'Spell Identifier',
  `item` int(11) unsigned NOT NULL default '0' COMMENT 'Item Identifier',
  `time` bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_spell_cooldown
-- ----------------------------

-- ----------------------------
-- Table structure for `character_stats`
-- ----------------------------
DROP TABLE IF EXISTS `character_stats`;
CREATE TABLE `character_stats` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier, Low part',
  `maxhealth` int(10) unsigned NOT NULL default '0',
  `maxpower1` int(10) unsigned NOT NULL default '0',
  `maxpower2` int(10) unsigned NOT NULL default '0',
  `maxpower3` int(10) unsigned NOT NULL default '0',
  `maxpower4` int(10) unsigned NOT NULL default '0',
  `maxpower5` int(10) unsigned NOT NULL default '0',
  `maxpower6` int(10) unsigned NOT NULL default '0',
  `maxpower7` int(10) unsigned NOT NULL default '0',
  `strength` int(10) unsigned NOT NULL default '0',
  `agility` int(10) unsigned NOT NULL default '0',
  `stamina` int(10) unsigned NOT NULL default '0',
  `intellect` int(10) unsigned NOT NULL default '0',
  `spirit` int(10) unsigned NOT NULL default '0',
  `armor` int(10) unsigned NOT NULL default '0',
  `resHoly` int(10) unsigned NOT NULL default '0',
  `resFire` int(10) unsigned NOT NULL default '0',
  `resNature` int(10) unsigned NOT NULL default '0',
  `resFrost` int(10) unsigned NOT NULL default '0',
  `resShadow` int(10) unsigned NOT NULL default '0',
  `resArcane` int(10) unsigned NOT NULL default '0',
  `blockPct` float unsigned NOT NULL default '0',
  `dodgePct` float unsigned NOT NULL default '0',
  `parryPct` float unsigned NOT NULL default '0',
  `critPct` float unsigned NOT NULL default '0',
  `rangedCritPct` float unsigned NOT NULL default '0',
  `spellCritPct` float unsigned NOT NULL default '0',
  `attackPower` int(10) unsigned NOT NULL default '0',
  `rangedAttackPower` int(10) unsigned NOT NULL default '0',
  `spellPower` int(10) unsigned NOT NULL default '0',
  `apmelee` int(11) NOT NULL,
  `ranged` int(11) NOT NULL,
  `blockrating` int(11) NOT NULL,
  `defrating` int(11) NOT NULL,
  `dodgerating` int(11) NOT NULL,
  `parryrating` int(11) NOT NULL,
  `resilience` int(11) NOT NULL,
  `manaregen` float NOT NULL,
  `melee_hitrating` int(11) NOT NULL,
  `melee_critrating` int(11) NOT NULL,
  `melee_hasterating` int(11) NOT NULL,
  `melee_mainmindmg` float NOT NULL,
  `melee_mainmaxdmg` float NOT NULL,
  `melee_offmindmg` float NOT NULL,
  `melee_offmaxdmg` float NOT NULL,
  `melee_maintime` float NOT NULL,
  `melee_offtime` float NOT NULL,
  `ranged_critrating` int(11) NOT NULL,
  `ranged_hasterating` int(11) NOT NULL,
  `ranged_hitrating` int(11) NOT NULL,
  `ranged_mindmg` float NOT NULL,
  `ranged_maxdmg` float NOT NULL,
  `ranged_attacktime` float NOT NULL,
  `spell_hitrating` int(11) NOT NULL,
  `spell_critrating` int(11) NOT NULL,
  `spell_hasterating` int(11) NOT NULL,
  `spell_bonusdmg` int(11) NOT NULL,
  `spell_bonusheal` int(11) NOT NULL,
  `spell_critproc` float NOT NULL,
  `account` int(11) unsigned NOT NULL default '0',
  `name` varchar(12) NOT NULL default '',
  `race` tinyint(3) unsigned NOT NULL default '0',
  `class` tinyint(3) unsigned NOT NULL default '0',
  `gender` tinyint(3) unsigned NOT NULL default '0',
  `level` tinyint(3) unsigned NOT NULL default '0',
  `map` int(11) unsigned NOT NULL default '0',
  `money` int(10) unsigned NOT NULL default '0',
  `totaltime` int(11) unsigned NOT NULL default '0',
  `online` int(10) unsigned NOT NULL default '0',
  `arenaPoints` int(10) unsigned NOT NULL default '0',
  `totalHonorPoints` int(10) unsigned NOT NULL default '0',
  `totalKills` int(10) unsigned NOT NULL default '0',
  `equipmentCache` longtext NOT NULL,
  `specCount` tinyint(3) unsigned NOT NULL default '1',
  `activeSpec` tinyint(3) unsigned NOT NULL default '0',
  `data` longtext NOT NULL,
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_stats
-- ----------------------------
INSERT INTO `character_stats` VALUES ('6', '266', '404', '1000', '0', '100', '0', '0', '0', '33', '29', '33', '31', '28', '533', '0', '0', '0', '0', '0', '0', '5', '7.86195', '0', '8.2913', '5.8913', '0', '82', '19', '0', '102', '39', '0', '0', '0', '0', '0', '3.10298', '0', '0', '0', '20.3', '26.3', '20.3', '26.3', '2100', '2100', '0', '0', '0', '6.57143', '7.57143', '2000', '0', '0', '0', '0', '0', '5.2451', '6', 'Franklin', '10', '2', '0', '12', '530', '8915', '41933', '1', '0', '0', '0', '6 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 522 266 404 0 0 100 0 0 0 266 404 1000 0 100 0 0 0 1078368065 0 0 0 0 0 0 0 0 0 0 0 0 0 12 1610 0 0 0 262152 2048 4194320 1157840896 1157234688 1157234688 1053038739 1069547520 15476 15476 0 1101162086 1104307814 0 0 1 0 0 0 0 0 1065353216 0 0 0 33 29 33 31 28 1065353216 0 0 0 0 0 0 0 0 0 533 0 0 0 0 0 0 1113325568 0 0 0 0 0 0 0 0 0 0 0 0 0 219 116 0 82 20 0 19 20 0 1087523109 1089620261 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 0 0 0 100795142 16777216 0 0 0 9147 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 24143 0 22953 0 2635 0 2646 0 2642 0 28148 0 23376 0 0 0 0 0 0 0 0 0 1421 0 2488 0 20841 0 0 0 0 0 0 0 0 0 0 0 0 0 0 622 1191182336 22916 1191182336 28432 1191182336 26229 1191182336 28141 1191182336 38710 1191182336 23867 1191182336 0 0 0 0 0 0 0 0 23656 1191182336 13503 1191182336 10296 1191182336 0 0 0 0 7855 1191182336 10279 1191182336 13504 1191182336 38711 1191182336 630 1191182336 10500 1191182336 25964 1191182336 37504 1191182336 37506 1191182336 26110 1191182336 25959 1191182336 37507 1191182336 37508 1191182336 26233 1191182336 23868 1191182336 39312 1191182336 39601 1191182336 39602 1191182336 39606 1191182336 26232 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 513 9800 43 3932220 0 55 3932220 0 95 3932220 0 109 19661100 0 65665 4915201 0 137 19661100 0 162 3932220 0 65721 4915201 0 413 65537 0 414 65537 0 415 65537 0 433 65537 0 594 65537 0 756 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 2 0 0 1084227584 1090229533 0 0 0 1090824491 1086096777 1086096777 0 1084741596 1084741596 1084741596 1084741596 1084741596 1084741596 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 3221225472 29889405 0 56 0 0 0 832 0 0 0 0 0 128 3221225472 3 122880 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6108 8915 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 1065353216 1065353216 1065353216 1065353216 1065353216 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 0 0 ', '1', '0', '6 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 522 266 404 0 0 100 0 0 0 266 404 1000 0 100 0 0 0 1078368065 0 0 0 0 0 0 0 0 0 0 0 0 0 12 1610 0 0 0 262152 2048 4194320 1157840896 1157234688 1157234688 1053038739 1069547520 15476 15476 0 1101162086 1104307814 0 0 1 0 0 0 0 0 1065353216 0 0 0 33 29 33 31 28 1065353216 0 0 0 0 0 0 0 0 0 533 0 0 0 0 0 0 1113325568 0 0 0 0 0 0 0 0 0 0 0 0 0 219 116 0 82 20 0 19 20 0 1087523109 1089620261 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 0 0 0 100795142 16777216 0 0 0 9147 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 24143 0 22953 0 2635 0 2646 0 2642 0 28148 0 23376 0 0 0 0 0 0 0 0 0 1421 0 2488 0 20841 0 0 0 0 0 0 0 0 0 0 0 0 0 0 622 1191182336 22916 1191182336 28432 1191182336 26229 1191182336 28141 1191182336 38710 1191182336 23867 1191182336 0 0 0 0 0 0 0 0 23656 1191182336 13503 1191182336 10296 1191182336 0 0 0 0 7855 1191182336 10279 1191182336 13504 1191182336 38711 1191182336 630 1191182336 10500 1191182336 25964 1191182336 37504 1191182336 37506 1191182336 26110 1191182336 25959 1191182336 37507 1191182336 37508 1191182336 26233 1191182336 23868 1191182336 39312 1191182336 39601 1191182336 39602 1191182336 39606 1191182336 26232 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 513 9800 43 3932220 0 55 3932220 0 95 3932220 0 109 19661100 0 65665 4915201 0 137 19661100 0 162 3932220 0 65721 4915201 0 413 65537 0 414 65537 0 415 65537 0 433 65537 0 594 65537 0 756 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 2 0 0 1084227584 1090229533 0 0 0 1090824491 1086096777 1086096777 0 1084741596 1084741596 1084741596 1084741596 1084741596 1084741596 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 3221225472 29889405 0 56 0 0 0 832 0 0 0 0 0 128 3221225472 3 122880 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6108 8915 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 1065353216 1065353216 1065353216 1065353216 1065353216 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 0 0 ');
INSERT INTO `character_stats` VALUES ('7', '3149', '0', '1000', '0', '100', '0', '8', '1000', '249', '113', '197', '33', '41', '3541', '0', '0', '0', '0', '0', '0', '0', '8.09132', '9.77071', '12.591', '1.79098', '0', '643', '103', '0', '643', '103', '0', '0', '0', '62', '0', '0', '13', '43', '0', '106.786', '107.936', '106.786', '107.936', '2000', '2000', '43', '0', '13', '18.0714', '19.2214', '2000', '13', '43', '0', '0', '0', '3.39818', '6', 'Emma', '10', '6', '1', '55', '609', '0', '2756', '1', '0', '0', '0', '7 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 1979807634 4046454883 0 0 0 100730378 3149 0 0 0 100 0 0 0 3149 0 1000 0 100 0 8 1000 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 1610 0 0 0 262152 2048 4194304 1157234688 1157234688 1157234688 1053038739 1069547520 15475 15475 0 1121292872 1121443605 1112753532 1112753532 1 0 0 0 0 0 1065353216 0 0 0 249 113 197 33 41 1125122048 1108869120 1120403456 0 0 0 0 0 0 0 3541 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1359 256 643 0 0 103 0 0 1099993673 1100596604 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 2 0 0 34343432 16777217 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 0 0 0 9840 1191182336 368 1191182336 352 1191182336 0 0 356 1191182336 362 1191182336 364 1191182336 9856 1191182336 358 1191182336 9850 1191182336 9860 1191182336 9870 1191182336 0 0 0 0 9844 1191182336 0 0 0 0 0 0 0 0 372 1191182336 9864 1191182336 376 1191182336 378 1191182336 382 1191182336 9874 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 560 148200 43 17694990 0 44 17694990 0 55 17694990 0 95 17694990 0 98 19661100 0 118 18022401 0 262273 19661070 0 162 17694990 0 172 17694990 0 229 17694990 0 293 65537 0 413 65537 0 414 65537 0 415 65537 0 131834 9830550 0 770 65537 0 771 65537 0 772 65537 0 109 19661100 0 137 19661100 0 756 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 0 0 0 1090614800 1092375760 0 0 1095333028 1071988410 1071988410 0 1079606200 1079606200 1079606200 1079606200 1079606200 1079606200 114 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 111150 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 62 0 13 13 13 43 43 43 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1036831949 1036831949 1036831949 1036831949 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 15 0 ', '1', '0', '7 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 1979807634 4046454883 0 0 0 100730378 3149 0 0 0 100 0 0 0 3149 0 1000 0 100 0 8 1000 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 1610 0 0 0 262152 2048 4194304 1157234688 1157234688 1157234688 1053038739 1069547520 15475 15475 0 1121292872 1121443605 1112753532 1112753532 1 0 0 0 0 0 1065353216 0 0 0 249 113 197 33 41 1125122048 1108869120 1120403456 0 0 0 0 0 0 0 3541 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1359 256 643 0 0 103 0 0 1099993673 1100596604 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 2 0 0 34343432 16777217 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 0 0 0 9840 1191182336 368 1191182336 352 1191182336 0 0 356 1191182336 362 1191182336 364 1191182336 9856 1191182336 358 1191182336 9850 1191182336 9860 1191182336 9870 1191182336 0 0 0 0 9844 1191182336 0 0 0 0 0 0 0 0 372 1191182336 9864 1191182336 376 1191182336 378 1191182336 382 1191182336 9874 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 560 148200 43 17694990 0 44 17694990 0 55 17694990 0 95 17694990 0 98 19661100 0 118 18022401 0 262273 19661070 0 162 17694990 0 172 17694990 0 229 17694990 0 293 65537 0 413 65537 0 414 65537 0 415 65537 0 131834 9830550 0 770 65537 0 771 65537 0 772 65537 0 109 19661100 0 137 19661100 0 756 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 0 0 0 1090614800 1092375760 0 0 1095333028 1071988410 1071988410 0 1079606200 1079606200 1079606200 1079606200 1079606200 1079606200 114 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 111150 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 62 0 13 13 13 43 43 43 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1036831949 1036831949 1036831949 1036831949 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 15 0 ');
INSERT INTO `character_stats` VALUES ('9', '3619', '0', '1000', '0', '100', '0', '8', '1000', '266', '116', '211', '28', '50', '3547', '0', '0', '0', '0', '0', '0', '0', '8.01733', '9.78261', '12.0953', '0.0953296', '0', '692', '106', '0', '692', '106', '0', '0', '0', '66', '0', '0', '13', '43', '0', '114.836', '115.986', '114.836', '115.986', '2000', '2000', '43', '0', '13', '18.5643', '19.7143', '2000', '13', '43', '0', '0', '0', '3.07143', '5', 'Sora', '5', '6', '1', '60', '578', '20711', '20131', '1', '0', '0', '0', '9 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100730373 3619 0 0 0 100 0 0 0 3619 0 1000 0 100 0 8 1000 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 35 0 0 0 8 2048 4194304 1157234688 1157234688 1157234688 1053038739 1069547520 58 58 0 1122348002 1122498735 0 0 0 0 0 0 0 0 1065353216 0 0 0 266 116 211 28 50 1125122048 1108869120 1120403456 0 0 0 0 0 0 0 3547 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1689 0 692 0 0 106 0 0 1100252072 1100855003 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 8 0 0 135680 33554432 1 0 0 12593 1 0 0 0 12641 0 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 0 0 0 11033 1191182336 11051 1191182336 11035 1191182336 0 0 11039 1191182336 11045 1191182336 11047 1191182336 11049 1191182336 11041 1191182336 11043 1191182336 11053 1191182336 11063 1191182336 0 0 0 0 11037 1191182336 0 0 0 0 0 0 0 0 11055 1191182336 11057 1191182336 11059 1191182336 11061 1191182336 11065 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 248188 290000 43 19661100 0 44 19661100 0 55 19661100 0 95 19661100 0 109 19661100 0 118 19661100 0 262273 19661070 0 162 19661100 0 172 19661100 0 229 19661100 0 293 65537 0 413 65537 0 414 65537 0 415 65537 0 673 19661100 0 131834 9830550 0 770 65537 0 771 65537 0 772 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 2 0 0 0 1090537211 1092388240 0 0 1094813304 1036205092 1036205092 0 1078235722 1078235722 1078235722 1078235722 1078235722 1078235722 123 0 8388609 0 0 8388608 0 4194304 0 0 0 128 0 12582912 32768 0 1 0 872415236 4096 0 512 64 8 0 0 269746240 0 1572864 536870912 0 17039360 256 0 0 2147483648 0 134217728 0 0 1073741824 0 131072 0 134217794 0 0 0 524288 0 0 0 0 0 0 0 262144 2147483648 4194304 0 0 512 32768 0 0 0 268435457 0 0 0 0 0 0 0 0 0 0 130 0 0 0 0 0 0 0 0 0 0 0 33554432 131072 0 0 0 0 67108864 0 0 0 0 0 4096 0 0 268435456 0 2097152 1032 0 0 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20711 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 66 0 13 13 13 43 43 43 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1036831949 1036831949 1036831949 1036831949 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 15 0 ', '1', '0', '9 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100730373 3619 0 0 0 100 0 0 0 3619 0 1000 0 100 0 8 1000 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 35 0 0 0 8 2048 4194304 1157234688 1157234688 1157234688 1053038739 1069547520 58 58 0 1122348002 1122498735 0 0 0 0 0 0 0 0 1065353216 0 0 0 266 116 211 28 50 1125122048 1108869120 1120403456 0 0 0 0 0 0 0 3547 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1689 0 692 0 0 106 0 0 1100252072 1100855003 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 8 0 0 135680 33554432 1 0 0 12593 1 0 0 0 12641 0 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 0 0 0 11033 1191182336 11051 1191182336 11035 1191182336 0 0 11039 1191182336 11045 1191182336 11047 1191182336 11049 1191182336 11041 1191182336 11043 1191182336 11053 1191182336 11063 1191182336 0 0 0 0 11037 1191182336 0 0 0 0 0 0 0 0 11055 1191182336 11057 1191182336 11059 1191182336 11061 1191182336 11065 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 248188 290000 43 19661100 0 44 19661100 0 55 19661100 0 95 19661100 0 109 19661100 0 118 19661100 0 262273 19661070 0 162 19661100 0 172 19661100 0 229 19661100 0 293 65537 0 413 65537 0 414 65537 0 415 65537 0 673 19661100 0 131834 9830550 0 770 65537 0 771 65537 0 772 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 2 0 0 0 1090537211 1092388240 0 0 1094813304 1036205092 1036205092 0 1078235722 1078235722 1078235722 1078235722 1078235722 1078235722 123 0 8388609 0 0 8388608 0 4194304 0 0 0 128 0 12582912 32768 0 1 0 872415236 4096 0 512 64 8 0 0 269746240 0 1572864 536870912 0 17039360 256 0 0 2147483648 0 134217728 0 0 1073741824 0 131072 0 134217794 0 0 0 524288 0 0 0 0 0 0 0 262144 2147483648 4194304 0 0 512 32768 0 0 0 268435457 0 0 0 0 0 0 0 0 0 0 130 0 0 0 0 0 0 0 0 0 0 0 33554432 131072 0 0 0 0 67108864 0 0 0 0 0 4096 0 0 268435456 0 2097152 1032 0 0 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20711 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 66 0 13 13 13 43 43 43 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1036831949 1036831949 1036831949 1036831949 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 15 0 ');

-- ----------------------------
-- Table structure for `character_talent`
-- ----------------------------
DROP TABLE IF EXISTS `character_talent`;
CREATE TABLE `character_talent` (
  `guid` int(11) unsigned NOT NULL,
  `talent_id` int(11) unsigned NOT NULL,
  `current_rank` tinyint(3) unsigned NOT NULL default '0',
  `spec` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`talent_id`,`spec`),
  KEY `guid_key` (`guid`),
  KEY `talent_key` (`talent_id`),
  KEY `spec_key` (`spec`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_talent
-- ----------------------------
INSERT INTO `character_talent` VALUES ('9', '1945', '0', '0');
INSERT INTO `character_talent` VALUES ('9', '2017', '0', '0');
INSERT INTO `character_talent` VALUES ('6', '1403', '0', '0');
INSERT INTO `character_talent` VALUES ('6', '1442', '0', '0');
INSERT INTO `character_talent` VALUES ('9', '1939', '0', '0');

-- ----------------------------
-- Table structure for `character_ticket`
-- ----------------------------
DROP TABLE IF EXISTS `character_ticket`;
CREATE TABLE `character_ticket` (
  `ticket_id` int(11) unsigned NOT NULL auto_increment,
  `guid` int(11) unsigned NOT NULL default '0',
  `ticket_text` text,
  `response_text` text,
  `ticket_lastchange` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`ticket_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_ticket
-- ----------------------------

-- ----------------------------
-- Table structure for `character_tutorial`
-- ----------------------------
DROP TABLE IF EXISTS `character_tutorial`;
CREATE TABLE `character_tutorial` (
  `account` bigint(20) unsigned NOT NULL auto_increment COMMENT 'Account Identifier',
  `tut0` int(11) unsigned NOT NULL default '0',
  `tut1` int(11) unsigned NOT NULL default '0',
  `tut2` int(11) unsigned NOT NULL default '0',
  `tut3` int(11) unsigned NOT NULL default '0',
  `tut4` int(11) unsigned NOT NULL default '0',
  `tut5` int(11) unsigned NOT NULL default '0',
  `tut6` int(11) unsigned NOT NULL default '0',
  `tut7` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`account`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_tutorial
-- ----------------------------
INSERT INTO `character_tutorial` VALUES ('5', '4294950903', '133564151', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_tutorial` VALUES ('6', '4193828855', '130026151', '0', '0', '0', '0', '0', '0');

-- ----------------------------
-- Table structure for `characters`
-- ----------------------------
DROP TABLE IF EXISTS `characters`;
CREATE TABLE `characters` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `account` int(11) unsigned NOT NULL default '0' COMMENT 'Account Identifier',
  `data` longtext NOT NULL,
  `name` varchar(12) NOT NULL default '',
  `race` tinyint(3) unsigned NOT NULL default '0',
  `class` tinyint(3) unsigned NOT NULL default '0',
  `gender` tinyint(3) unsigned NOT NULL default '0',
  `level` tinyint(3) unsigned NOT NULL default '0',
  `xp` int(10) unsigned NOT NULL default '0',
  `money` int(10) unsigned NOT NULL default '0',
  `playerBytes` int(10) unsigned NOT NULL default '0',
  `playerBytes2` int(10) unsigned NOT NULL default '0',
  `playerFlags` int(10) unsigned NOT NULL default '0',
  `position_x` float NOT NULL default '0',
  `position_y` float NOT NULL default '0',
  `position_z` float NOT NULL default '0',
  `map` int(11) unsigned NOT NULL default '0' COMMENT 'Map Identifier',
  `dungeon_difficulty` tinyint(1) unsigned NOT NULL default '0',
  `orientation` float NOT NULL default '0',
  `taximask` longtext,
  `online` tinyint(3) unsigned NOT NULL default '0',
  `cinematic` tinyint(3) unsigned NOT NULL default '0',
  `totaltime` int(11) unsigned NOT NULL default '0',
  `leveltime` int(11) unsigned NOT NULL default '0',
  `logout_time` bigint(20) unsigned NOT NULL default '0',
  `is_logout_resting` tinyint(3) unsigned NOT NULL default '0',
  `rest_bonus` float NOT NULL default '0',
  `resettalents_cost` int(11) unsigned NOT NULL default '0',
  `resettalents_time` bigint(20) unsigned NOT NULL default '0',
  `trans_x` float NOT NULL default '0',
  `trans_y` float NOT NULL default '0',
  `trans_z` float NOT NULL default '0',
  `trans_o` float NOT NULL default '0',
  `transguid` bigint(20) unsigned NOT NULL default '0',
  `extra_flags` int(11) unsigned NOT NULL default '0',
  `stable_slots` tinyint(1) unsigned NOT NULL default '0',
  `at_login` int(11) unsigned NOT NULL default '0',
  `zone` int(11) unsigned NOT NULL default '0',
  `death_expire_time` bigint(20) unsigned NOT NULL default '0',
  `taxi_path` text,
  `arenaPoints` int(10) unsigned NOT NULL default '0',
  `totalHonorPoints` int(10) unsigned NOT NULL default '0',
  `todayHonorPoints` int(10) unsigned NOT NULL default '0',
  `yesterdayHonorPoints` int(10) unsigned NOT NULL default '0',
  `totalKills` int(10) unsigned NOT NULL default '0',
  `todayKills` smallint(5) unsigned NOT NULL default '0',
  `yesterdayKills` smallint(5) unsigned NOT NULL default '0',
  `chosenTitle` int(10) unsigned NOT NULL default '0',
  `knownCurrencies` bigint(20) unsigned NOT NULL default '0',
  `watchedFaction` int(10) unsigned NOT NULL default '0',
  `drunk` smallint(5) unsigned NOT NULL default '0',
  `health` int(10) unsigned NOT NULL default '0',
  `power1` int(10) unsigned NOT NULL default '0',
  `power2` int(10) unsigned NOT NULL default '0',
  `power3` int(10) unsigned NOT NULL default '0',
  `power4` int(10) unsigned NOT NULL default '0',
  `power5` int(10) unsigned NOT NULL default '0',
  `power6` int(10) unsigned NOT NULL default '0',
  `power7` int(10) unsigned NOT NULL default '0',
  `specCount` tinyint(3) unsigned NOT NULL default '1',
  `activeSpec` tinyint(3) unsigned NOT NULL default '0',
  `exploredZones` longtext,
  `equipmentCache` longtext,
  `ammoId` int(10) unsigned NOT NULL default '0',
  `knownTitles` longtext,
  `actionBars` tinyint(3) unsigned NOT NULL default '0',
  `grantableLevels` tinyint(3) unsigned NOT NULL default '0',
  `deleteInfos_Account` int(11) unsigned default NULL,
  `deleteInfos_Name` varchar(12) default NULL,
  `deleteDate` bigint(20) default NULL,
  PRIMARY KEY  (`guid`),
  KEY `idx_account` (`account`),
  KEY `idx_online` (`online`),
  KEY `idx_name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of characters
-- ----------------------------
INSERT INTO `characters` VALUES ('9', '5', '9 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100730373 3619 0 0 0 100 0 0 0 3619 0 1000 0 100 0 8 1000 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 35 0 0 0 8 2048 4194304 1157234688 1157234688 1157234688 1053038739 1069547520 58 58 0 1122348002 1122498735 0 0 0 0 0 0 0 0 1065353216 0 0 0 266 116 211 28 50 1125122048 1108869120 1120403456 0 0 0 0 0 0 0 3547 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1689 0 692 0 0 106 0 0 1100252072 1100855003 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 8 0 0 135680 33554432 1 0 0 12593 1 0 0 0 12641 0 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 0 0 0 11033 1191182336 11051 1191182336 11035 1191182336 0 0 11039 1191182336 11045 1191182336 11047 1191182336 11049 1191182336 11041 1191182336 11043 1191182336 11053 1191182336 11063 1191182336 0 0 0 0 11037 1191182336 0 0 0 0 0 0 0 0 11055 1191182336 11057 1191182336 11059 1191182336 11061 1191182336 11065 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 248188 290000 43 19661100 0 44 19661100 0 55 19661100 0 95 19661100 0 109 19661100 0 118 19661100 0 262273 19661070 0 162 19661100 0 172 19661100 0 229 19661100 0 293 65537 0 413 65537 0 414 65537 0 415 65537 0 673 19661100 0 131834 9830550 0 770 65537 0 771 65537 0 772 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 2 0 0 0 1090537211 1092388240 0 0 1094813304 1036205092 1036205092 0 1078235722 1078235722 1078235722 1078235722 1078235722 1078235722 123 0 8388609 0 0 8388608 0 4194304 0 0 0 128 0 12582912 32768 0 1 0 872415236 4096 0 512 64 8 0 0 269746240 0 1572864 536870912 0 17039360 256 0 0 2147483648 0 134217728 0 0 1073741824 0 131072 0 134217794 0 0 0 524288 0 0 0 0 0 0 0 262144 2147483648 4194304 0 0 512 32768 0 0 0 268435457 0 0 0 0 0 0 0 0 0 0 130 0 0 0 0 0 0 0 0 0 0 0 33554432 131072 0 0 0 0 67108864 0 0 0 0 0 4096 0 0 268435456 0 2097152 1032 0 0 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20711 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 66 0 13 13 13 43 43 43 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1036831949 1036831949 1036831949 1036831949 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 15 0 ', 'Sora', '5', '6', '1', '60', '248188', '20711', '135680', '33554432', '8', '953.051', '1046.91', '359.967', '578', '0', '3.24037', '4294967295 4093640703 830406655 4 33570816 1310944 3250593812 73752 896 67111952 2281701376 4190109713 1049856 12582912 ', '0', '1', '20131', '2525', '1294423108', '0', '0.43158', '0', '0', '0', '0', '0', '0', '0', '3', '0', '0', '0', '1294417529', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '4294967295', '0', '3619', '0', '0', '0', '100', '0', '0', '0', '1', '0', '8388609 0 0 8388608 0 4194304 0 0 0 128 0 12582912 32768 0 1 0 872415236 4096 0 512 64 8 0 0 269746240 0 1572864 536870912 0 17039360 256 0 0 2147483648 0 134217728 0 0 1073741824 0 131072 0 134217794 0 0 0 524288 0 0 0 0 0 0 0 262144 2147483648 4194304 0 0 512 32768 0 0 0 268435457 0 0 0 0 0 0 0 0 0 0 130 0 0 0 0 0 0 0 0 0 0 0 33554432 131072 0 0 0 0 67108864 0 0 0 0 0 4096 0 0 268435456 0 2097152 1032 0 0 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 ', '0', '0 0 0 0 0 0 ', '0', '0', null, null, null);
INSERT INTO `characters` VALUES ('6', '6', '6 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 522 266 404 0 0 100 0 0 0 266 404 1000 0 100 0 0 0 1078368065 0 0 0 0 0 0 0 0 0 0 0 0 0 12 1610 0 0 0 262152 2048 4194320 1157840896 1157234688 1157234688 1053038739 1069547520 15476 15476 0 1101162086 1104307814 0 0 1 0 0 0 0 0 1065353216 0 0 0 33 29 33 31 28 1065353216 0 0 0 0 0 0 0 0 0 533 0 0 0 0 0 0 1113325568 0 0 0 0 0 0 0 0 0 0 0 0 0 219 116 0 82 20 0 19 20 0 1087523109 1089620261 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 0 0 0 100795142 16777216 0 0 0 9147 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 24143 0 22953 0 2635 0 2646 0 2642 0 28148 0 23376 0 0 0 0 0 0 0 0 0 1421 0 2488 0 20841 0 0 0 0 0 0 0 0 0 0 0 0 0 0 622 1191182336 22916 1191182336 28432 1191182336 26229 1191182336 28141 1191182336 38710 1191182336 23867 1191182336 0 0 0 0 0 0 0 0 23656 1191182336 13503 1191182336 10296 1191182336 0 0 0 0 7855 1191182336 10279 1191182336 13504 1191182336 38711 1191182336 630 1191182336 10500 1191182336 25964 1191182336 37504 1191182336 37506 1191182336 26110 1191182336 25959 1191182336 37507 1191182336 37508 1191182336 26233 1191182336 23868 1191182336 39312 1191182336 39601 1191182336 39602 1191182336 39606 1191182336 26232 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 513 9800 43 3932220 0 55 3932220 0 95 3932220 0 109 19661100 0 65665 4915201 0 137 19661100 0 162 3932220 0 65721 4915201 0 413 65537 0 414 65537 0 415 65537 0 433 65537 0 594 65537 0 756 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 2 0 0 1084227584 1090229533 0 0 0 1090824491 1086096777 1086096777 0 1084741596 1084741596 1084741596 1084741596 1084741596 1084741596 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 3221225472 29889405 0 56 0 0 0 832 0 0 0 0 0 128 3221225472 3 122880 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6108 8915 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 1065353216 1065353216 1065353216 1065353216 1065353216 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 0 0 ', 'Franklin', '10', '2', '0', '12', '513', '8915', '100795142', '16777216', '0', '8034.42', '-6903.82', '57.6354', '530', '0', '3.18495', '0 0 131072 4 0 0 0 0 0 0 0 0 0 0 ', '0', '1', '41933', '659', '1294391723', '0', '6108.94', '0', '0', '0', '0', '0', '0', '0', '4', '0', '0', '3430', '1293883513', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '4294967295', '0', '266', '404', '0', '0', '100', '0', '0', '0', '1', '0', '0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 3221225472 29889405 0 56 0 0 0 832 0 0 0 0 0 128 3221225472 3 122880 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '0 0 0 0 0 0 24143 0 22953 0 2635 0 2646 0 2642 0 28148 0 23376 0 0 0 0 0 0 0 0 0 1421 0 2488 0 20841 0 0 0 0 0 ', '0', '0 0 0 0 0 0 ', '0', '0', null, null, null);
INSERT INTO `characters` VALUES ('2', '5', '', 'Isellyoubuy', '7', '4', '1', '5', '85', '0', '100795140', '16777216', '0', '-6437.93', '-287.903', '3.9304', '1', '0', '1.95643', '32 0 0 8 0 0 0 0 0 0 0 0 0 0 ', '0', '1', '252', '252', '1290821047', '0', '480.587', '0', '0', '0', '0', '0', '0', '0', '2', '0', '0', '1377', '1290503813', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '4294967295', '0', '113', '0', '0', '0', '100', '0', '0', '0', '1', '0', '0 0 0 0 0 0 1048576 0 0 0 0 4194304 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 131072 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '0 0 0 0 0 0 49 0 56 0 0 0 48 0 55 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 0 0 0 28979 0 0 0 ', '0', '0 0 0 0 0 0 ', '0', '0', null, null, null);
INSERT INTO `characters` VALUES ('7', '6', '7 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 1979807634 4046454883 0 0 0 100730378 3149 0 0 0 100 0 0 0 3149 0 1000 0 100 0 8 1000 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 1610 0 0 0 262152 2048 4194304 1157234688 1157234688 1157234688 1053038739 1069547520 15475 15475 0 1121292872 1121443605 1112753532 1112753532 1 0 0 0 0 0 1065353216 0 0 0 249 113 197 33 41 1125122048 1108869120 1120403456 0 0 0 0 0 0 0 3541 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1359 256 643 0 0 103 0 0 1099993673 1100596604 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 2 0 0 34343432 16777217 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 0 0 0 9840 1191182336 368 1191182336 352 1191182336 0 0 356 1191182336 362 1191182336 364 1191182336 9856 1191182336 358 1191182336 9850 1191182336 9860 1191182336 9870 1191182336 0 0 0 0 9844 1191182336 0 0 0 0 0 0 0 0 372 1191182336 9864 1191182336 376 1191182336 378 1191182336 382 1191182336 9874 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 560 148200 43 17694990 0 44 17694990 0 55 17694990 0 95 17694990 0 98 19661100 0 118 18022401 0 262273 19661070 0 162 17694990 0 172 17694990 0 229 17694990 0 293 65537 0 413 65537 0 414 65537 0 415 65537 0 131834 9830550 0 770 65537 0 771 65537 0 772 65537 0 109 19661100 0 137 19661100 0 756 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 0 0 0 1090614800 1092375760 0 0 1095333028 1071988410 1071988410 0 1079606200 1079606200 1079606200 1079606200 1079606200 1079606200 114 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 111150 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 62 0 13 13 13 43 43 43 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1036831949 1036831949 1036831949 1036831949 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 15 0 ', 'Emma', '10', '6', '1', '55', '560', '0', '34343432', '16777217', '2', '2366.5', '-5656.04', '426.096', '609', '0', '0.578849', '4294967295 4093640703 830406655 4 33570816 1310944 3250593812 73752 896 67111952 2281701376 4190109713 1049856 12582912 ', '0', '1', '2756', '2756', '1293599229', '0', '111150', '0', '0', '0', '0', '0', '0', '0', '4', '0', '0', '4298', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '4294967295', '0', '3149', '0', '0', '0', '100', '0', '0', '0', '1', '0', '0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 ', '0', '0 0 0 0 0 0 ', '0', '0', null, null, null);

-- ----------------------------
-- Table structure for `corpse`
-- ----------------------------
DROP TABLE IF EXISTS `corpse`;
CREATE TABLE `corpse` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `player` int(11) unsigned NOT NULL default '0' COMMENT 'Character Global Unique Identifier',
  `position_x` float NOT NULL default '0',
  `position_y` float NOT NULL default '0',
  `position_z` float NOT NULL default '0',
  `orientation` float NOT NULL default '0',
  `map` int(11) unsigned NOT NULL default '0' COMMENT 'Map Identifier',
  `phaseMask` smallint(5) unsigned NOT NULL default '1',
  `time` bigint(20) unsigned NOT NULL default '0',
  `corpse_type` tinyint(3) unsigned NOT NULL default '0',
  `instance` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`),
  KEY `idx_type` (`corpse_type`),
  KEY `instance` (`instance`),
  KEY `Idx_player` (`player`),
  KEY `Idx_time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Death System';

-- ----------------------------
-- Records of corpse
-- ----------------------------

-- ----------------------------
-- Table structure for `creature_respawn`
-- ----------------------------
DROP TABLE IF EXISTS `creature_respawn`;
CREATE TABLE `creature_respawn` (
  `guid` int(10) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `respawntime` bigint(20) NOT NULL default '0',
  `instance` mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Grid Loading System';

-- ----------------------------
-- Records of creature_respawn
-- ----------------------------

-- ----------------------------
-- Table structure for `game_event_status`
-- ----------------------------
DROP TABLE IF EXISTS `game_event_status`;
CREATE TABLE `game_event_status` (
  `event` smallint(6) unsigned NOT NULL default '0',
  PRIMARY KEY  (`event`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Game event system';

-- ----------------------------
-- Records of game_event_status
-- ----------------------------
INSERT INTO `game_event_status` VALUES ('16');
INSERT INTO `game_event_status` VALUES ('21');
INSERT INTO `game_event_status` VALUES ('39');
INSERT INTO `game_event_status` VALUES ('44');
INSERT INTO `game_event_status` VALUES ('46');
INSERT INTO `game_event_status` VALUES ('47');
INSERT INTO `game_event_status` VALUES ('50');
INSERT INTO `game_event_status` VALUES ('64');
INSERT INTO `game_event_status` VALUES ('68');

-- ----------------------------
-- Table structure for `gameobject_respawn`
-- ----------------------------
DROP TABLE IF EXISTS `gameobject_respawn`;
CREATE TABLE `gameobject_respawn` (
  `guid` int(10) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `respawntime` bigint(20) NOT NULL default '0',
  `instance` mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Grid Loading System';

-- ----------------------------
-- Records of gameobject_respawn
-- ----------------------------
INSERT INTO `gameobject_respawn` VALUES ('1885', '1294918440', '2');
INSERT INTO `gameobject_respawn` VALUES ('1892', '1294918402', '2');

-- ----------------------------
-- Table structure for `group_instance`
-- ----------------------------
DROP TABLE IF EXISTS `group_instance`;
CREATE TABLE `group_instance` (
  `leaderGuid` int(11) unsigned NOT NULL default '0',
  `instance` int(11) unsigned NOT NULL default '0',
  `permanent` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`leaderGuid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of group_instance
-- ----------------------------

-- ----------------------------
-- Table structure for `group_member`
-- ----------------------------
DROP TABLE IF EXISTS `group_member`;
CREATE TABLE `group_member` (
  `groupId` int(11) unsigned NOT NULL,
  `memberGuid` int(11) unsigned NOT NULL,
  `assistant` tinyint(1) unsigned NOT NULL,
  `subgroup` smallint(6) unsigned NOT NULL,
  PRIMARY KEY  (`groupId`,`memberGuid`),
  KEY `Idx_memberGuid` (`memberGuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Groups';

-- ----------------------------
-- Records of group_member
-- ----------------------------

-- ----------------------------
-- Table structure for `groups`
-- ----------------------------
DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `groupId` int(11) unsigned NOT NULL,
  `leaderGuid` int(11) unsigned NOT NULL,
  `mainTank` int(11) unsigned NOT NULL,
  `mainAssistant` int(11) unsigned NOT NULL,
  `lootMethod` tinyint(4) unsigned NOT NULL,
  `looterGuid` int(11) unsigned NOT NULL,
  `lootThreshold` tinyint(4) unsigned NOT NULL,
  `icon1` int(11) unsigned NOT NULL,
  `icon2` int(11) unsigned NOT NULL,
  `icon3` int(11) unsigned NOT NULL,
  `icon4` int(11) unsigned NOT NULL,
  `icon5` int(11) unsigned NOT NULL,
  `icon6` int(11) unsigned NOT NULL,
  `icon7` int(11) unsigned NOT NULL,
  `icon8` int(11) unsigned NOT NULL,
  `groupType` tinyint(1) unsigned NOT NULL,
  `difficulty` tinyint(3) unsigned NOT NULL default '0',
  `raiddifficulty` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`groupId`),
  UNIQUE KEY `leaderGuid` (`leaderGuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Groups';

-- ----------------------------
-- Records of groups
-- ----------------------------

-- ----------------------------
-- Table structure for `guild`
-- ----------------------------
DROP TABLE IF EXISTS `guild`;
CREATE TABLE `guild` (
  `guildid` int(6) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `leaderguid` int(6) unsigned NOT NULL default '0',
  `EmblemStyle` int(5) NOT NULL default '0',
  `EmblemColor` int(5) NOT NULL default '0',
  `BorderStyle` int(5) NOT NULL default '0',
  `BorderColor` int(5) NOT NULL default '0',
  `BackgroundColor` int(5) NOT NULL default '0',
  `info` text NOT NULL,
  `motd` varchar(255) NOT NULL default '',
  `createdate` bigint(20) NOT NULL default '0',
  `BankMoney` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`guildid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';

-- ----------------------------
-- Records of guild
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_bank_eventlog`
-- ----------------------------
DROP TABLE IF EXISTS `guild_bank_eventlog`;
CREATE TABLE `guild_bank_eventlog` (
  `guildid` int(11) unsigned NOT NULL default '0' COMMENT 'Guild Identificator',
  `LogGuid` int(11) unsigned NOT NULL default '0' COMMENT 'Log record identificator - auxiliary column',
  `TabId` tinyint(3) unsigned NOT NULL default '0' COMMENT 'Guild bank TabId',
  `EventType` tinyint(3) unsigned NOT NULL default '0' COMMENT 'Event type',
  `PlayerGuid` int(11) unsigned NOT NULL default '0',
  `ItemOrMoney` int(11) unsigned NOT NULL default '0',
  `ItemStackCount` tinyint(3) unsigned NOT NULL default '0',
  `DestTabId` tinyint(1) unsigned NOT NULL default '0' COMMENT 'Destination Tab Id',
  `TimeStamp` bigint(20) unsigned NOT NULL default '0' COMMENT 'Event UNIX time',
  PRIMARY KEY  (`guildid`,`LogGuid`,`TabId`),
  KEY `guildid_key` (`guildid`),
  KEY `Idx_PlayerGuid` (`PlayerGuid`),
  KEY `Idx_LogGuid` (`LogGuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_bank_eventlog
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_bank_item`
-- ----------------------------
DROP TABLE IF EXISTS `guild_bank_item`;
CREATE TABLE `guild_bank_item` (
  `guildid` int(11) unsigned NOT NULL default '0',
  `TabId` tinyint(1) unsigned NOT NULL default '0',
  `SlotId` tinyint(3) unsigned NOT NULL default '0',
  `item_guid` int(11) unsigned NOT NULL default '0',
  `item_entry` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guildid`,`TabId`,`SlotId`),
  KEY `guildid_key` (`guildid`),
  KEY `Idx_item_guid` (`item_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_bank_item
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_bank_right`
-- ----------------------------
DROP TABLE IF EXISTS `guild_bank_right`;
CREATE TABLE `guild_bank_right` (
  `guildid` int(11) unsigned NOT NULL default '0',
  `TabId` tinyint(1) unsigned NOT NULL default '0',
  `rid` int(11) unsigned NOT NULL default '0',
  `gbright` tinyint(3) unsigned NOT NULL default '0',
  `SlotPerDay` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guildid`,`TabId`,`rid`),
  KEY `guildid_key` (`guildid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_bank_right
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_bank_tab`
-- ----------------------------
DROP TABLE IF EXISTS `guild_bank_tab`;
CREATE TABLE `guild_bank_tab` (
  `guildid` int(11) unsigned NOT NULL default '0',
  `TabId` tinyint(1) unsigned NOT NULL default '0',
  `TabName` varchar(100) NOT NULL default '',
  `TabIcon` varchar(100) NOT NULL default '',
  `TabText` text,
  PRIMARY KEY  (`guildid`,`TabId`),
  KEY `guildid_key` (`guildid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_bank_tab
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_eventlog`
-- ----------------------------
DROP TABLE IF EXISTS `guild_eventlog`;
CREATE TABLE `guild_eventlog` (
  `guildid` int(11) NOT NULL COMMENT 'Guild Identificator',
  `LogGuid` int(11) NOT NULL COMMENT 'Log record identificator - auxiliary column',
  `EventType` tinyint(1) NOT NULL COMMENT 'Event type',
  `PlayerGuid1` int(11) NOT NULL COMMENT 'Player 1',
  `PlayerGuid2` int(11) NOT NULL COMMENT 'Player 2',
  `NewRank` tinyint(2) NOT NULL COMMENT 'New rank(in case promotion/demotion)',
  `TimeStamp` bigint(20) NOT NULL COMMENT 'Event UNIX time',
  PRIMARY KEY  (`guildid`,`LogGuid`),
  KEY `Idx_PlayerGuid1` (`PlayerGuid1`),
  KEY `Idx_PlayerGuid2` (`PlayerGuid2`),
  KEY `Idx_LogGuid` (`LogGuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Guild Eventlog';

-- ----------------------------
-- Records of guild_eventlog
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_member`
-- ----------------------------
DROP TABLE IF EXISTS `guild_member`;
CREATE TABLE `guild_member` (
  `guildid` int(6) unsigned NOT NULL default '0',
  `guid` int(11) unsigned NOT NULL default '0',
  `rank` tinyint(2) unsigned NOT NULL default '0',
  `pnote` varchar(255) NOT NULL default '',
  `offnote` varchar(255) NOT NULL default '',
  `BankResetTimeMoney` int(11) unsigned NOT NULL default '0',
  `BankRemMoney` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab0` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab0` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab1` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab1` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab2` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab2` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab3` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab3` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab4` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab4` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab5` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab5` int(11) unsigned NOT NULL default '0',
  UNIQUE KEY `guid_key` (`guid`),
  KEY `guildid_key` (`guildid`),
  KEY `guildid_rank_key` (`guildid`,`rank`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Guild System';

-- ----------------------------
-- Records of guild_member
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_rank`
-- ----------------------------
DROP TABLE IF EXISTS `guild_rank`;
CREATE TABLE `guild_rank` (
  `guildid` int(6) unsigned NOT NULL default '0',
  `rid` int(11) unsigned NOT NULL,
  `rname` varchar(255) NOT NULL default '',
  `rights` int(3) unsigned NOT NULL default '0',
  `BankMoneyPerDay` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guildid`,`rid`),
  KEY `Idx_rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';

-- ----------------------------
-- Records of guild_rank
-- ----------------------------

-- ----------------------------
-- Table structure for `instance`
-- ----------------------------
DROP TABLE IF EXISTS `instance`;
CREATE TABLE `instance` (
  `id` int(11) unsigned NOT NULL default '0',
  `map` int(11) unsigned NOT NULL default '0',
  `resettime` bigint(40) NOT NULL default '0',
  `difficulty` tinyint(1) unsigned NOT NULL default '0',
  `data` longtext,
  PRIMARY KEY  (`id`),
  KEY `map` (`map`),
  KEY `resettime` (`resettime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of instance
-- ----------------------------
INSERT INTO `instance` VALUES ('1', '724', '0', '0', '');
INSERT INTO `instance` VALUES ('2', '631', '0', '0', '');
INSERT INTO `instance` VALUES ('4', '616', '0', '0', '0');
INSERT INTO `instance` VALUES ('3', '603', '0', '0', '0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 3');

-- ----------------------------
-- Table structure for `instance_reset`
-- ----------------------------
DROP TABLE IF EXISTS `instance_reset`;
CREATE TABLE `instance_reset` (
  `mapid` int(11) unsigned NOT NULL default '0',
  `difficulty` tinyint(1) unsigned NOT NULL default '0',
  `resettime` bigint(40) NOT NULL default '0',
  PRIMARY KEY  (`mapid`,`difficulty`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of instance_reset
-- ----------------------------
INSERT INTO `instance_reset` VALUES ('249', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('309', '0', '1294689600');
INSERT INTO `instance_reset` VALUES ('409', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('469', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('509', '0', '1294689600');
INSERT INTO `instance_reset` VALUES ('531', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('532', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('533', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('534', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('544', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('548', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('550', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('564', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('565', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('568', '0', '1294621200');
INSERT INTO `instance_reset` VALUES ('580', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('603', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('615', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('616', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('624', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('631', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('649', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('724', '0', '1294794000');
INSERT INTO `instance_reset` VALUES ('249', '1', '1294794000');
INSERT INTO `instance_reset` VALUES ('269', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('533', '1', '1294794000');
INSERT INTO `instance_reset` VALUES ('540', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('542', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('543', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('545', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('546', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('547', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('552', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('553', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('554', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('555', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('556', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('557', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('558', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('560', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('574', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('575', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('576', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('578', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('585', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('595', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('598', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('599', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('600', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('601', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('602', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('603', '1', '1294794000');
INSERT INTO `instance_reset` VALUES ('604', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('608', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('615', '1', '1294794000');
INSERT INTO `instance_reset` VALUES ('616', '1', '1294794000');
INSERT INTO `instance_reset` VALUES ('619', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('624', '1', '1294794000');
INSERT INTO `instance_reset` VALUES ('631', '1', '1294794000');
INSERT INTO `instance_reset` VALUES ('632', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('649', '1', '1294794000');
INSERT INTO `instance_reset` VALUES ('650', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('658', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('668', '1', '1294621200');
INSERT INTO `instance_reset` VALUES ('724', '1', '1294794000');
INSERT INTO `instance_reset` VALUES ('631', '2', '1294794000');
INSERT INTO `instance_reset` VALUES ('649', '2', '1294794000');
INSERT INTO `instance_reset` VALUES ('724', '2', '1294794000');
INSERT INTO `instance_reset` VALUES ('631', '3', '1294794000');
INSERT INTO `instance_reset` VALUES ('649', '3', '1294794000');
INSERT INTO `instance_reset` VALUES ('724', '3', '1294794000');

-- ----------------------------
-- Table structure for `item_instance`
-- ----------------------------
DROP TABLE IF EXISTS `item_instance`;
CREATE TABLE `item_instance` (
  `guid` int(11) unsigned NOT NULL default '0',
  `owner_guid` int(11) unsigned NOT NULL default '0',
  `data` longtext,
  `text` longtext,
  PRIMARY KEY  (`guid`),
  KEY `idx_owner_guid` (`owner_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Item System';

-- ----------------------------
-- Records of item_instance
-- ----------------------------
INSERT INTO `item_instance` VALUES ('11061', '9', '11061 1191182336 7 38145 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11059', '9', '11059 1191182336 7 38145 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11057', '9', '11057 1191182336 7 38145 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11055', '9', '11055 1191182336 7 38145 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11053', '9', '11053 1191182336 3 34658 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11051', '9', '11051 1191182336 3 34657 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11047', '9', '11047 1191182336 3 34656 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11049', '9', '11049 1191182336 3 34648 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11043', '9', '11043 1191182336 3 34649 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11045', '9', '11045 1191182336 3 34651 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11041', '9', '11041 1191182336 3 34653 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11037', '9', '11037 1191182336 3 34659 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11039', '9', '11039 1191182336 3 34650 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 59 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11035', '9', '11035 1191182336 3 34655 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11033', '9', '11033 1191182336 3 34652 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('36', '2', '36 1191182336 3 56 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 24 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38', '2', '38 1191182336 3 1395 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40', '2', '40 1191182336 3 6096 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('42', '2', '42 1191182336 3 55 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44', '2', '44 1191182336 3 35 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 17 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('46', '2', '46 1191182336 3 6948 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('13504', '6', '13504 1191182336 7 4496 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 28438 1191182336 28439 1191182336 28440 1191182336 28442 1191182336 28443 1191182336 28444 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('22916', '6', '22916 1191182336 3 22953 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('10279', '6', '10279 1191182336 7 4496 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 22761 1191182336 28431 1191182336 13501 1191182336 28435 1191182336 28436 1191182336 28437 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('362', '7', '362 1191182336 3 34651 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('366', '7', '366 1191182336 3 34648 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 54 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('368', '7', '368 1191182336 3 34657 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('352', '7', '352 1191182336 3 34655 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 68 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('630', '6', '630 1191182336 3 6948 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('622', '6', '622 1191182336 3 24143 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('370', '7', '370 1191182336 3 34658 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('350', '7', '350 1191182336 3 34652 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 69 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('380', '7', '380 1191182336 3 38147 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('382', '7', '382 1191182336 3 41751 1065353216 0 7 0 7 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('354', '7', '354 1191182336 3 34659 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('356', '7', '356 1191182336 3 34650 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('358', '7', '358 1191182336 3 34653 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 39 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('360', '7', '360 1191182336 3 34649 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 39 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('364', '7', '364 1191182336 3 34656 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('372', '7', '372 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('374', '7', '374 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('376', '7', '376 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('378', '7', '378 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('500', '2', '500 1191182336 3 49 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('502', '2', '502 1191182336 3 48 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 17 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('504', '2', '504 1191182336 3 47 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('506', '2', '506 1191182336 3 2092 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 0 0 ', '');
INSERT INTO `item_instance` VALUES ('508', '2', '508 1191182336 3 50055 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 0 0 ', '');
INSERT INTO `item_instance` VALUES ('510', '2', '510 1191182336 3 28979 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('512', '2', '512 1191182336 3 6948 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9874', '7', '9874 1191182336 3 40582 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9872', '7', '9872 1191182336 3 41751 1065353216 0 7 0 7 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9870', '7', '9870 1191182336 3 38147 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9868', '7', '9868 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9866', '7', '9866 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9864', '7', '9864 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9862', '7', '9862 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9860', '7', '9860 1191182336 3 34658 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9840', '7', '9840 1191182336 3 34652 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9842', '7', '9842 1191182336 3 34655 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9844', '7', '9844 1191182336 3 34659 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9846', '7', '9846 1191182336 3 34650 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9848', '7', '9848 1191182336 3 34653 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9850', '7', '9850 1191182336 3 34649 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9852', '7', '9852 1191182336 3 34651 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9854', '7', '9854 1191182336 3 34656 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9856', '7', '9856 1191182336 3 34648 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9858', '7', '9858 1191182336 3 34657 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('10296', '6', '10296 1191182336 3 20841 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('10500', '6', '10500 1191182336 3 159 1065353216 0 6 0 6 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('7855', '6', '7855 1191182336 7 20474 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 39607 1191182336 39609 1191182336 39612 1191182336 39613 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('23867', '6', '23867 1191182336 3 23376 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('13503', '6', '13503 1191182336 3 2488 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44153', '2', '44153 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44380', '2', '44380 1191182336 3 13874 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44381', '2', '44381 1191182336 3 4677 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44382', '2', '44382 1191182336 3 36038 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 72 4294967257 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44383', '2', '44383 1191182336 3 13877 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44384', '2', '44384 1191182336 3 30809 1065353216 0 2 0 2 0 0 0 0 0 243 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44385', '2', '44385 1191182336 3 2164 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44386', '2', '44386 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44387', '2', '44387 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('28442', '6', '28442 1191182336 3 1179 1065353216 0 6 0 13504 1191182336 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38710', '6', '38710 1191182336 3 28148 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38711', '6', '38711 1191182336 7 22571 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37504', '6', '37504 1191182336 3 118 1065353216 0 6 0 6 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('28432', '6', '28432 1191182336 3 2635 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('28141', '6', '28141 1191182336 3 2642 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44080', '2', '44080 1191182336 3 16646 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44333', '2', '44333 1191182336 3 6202 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 0 0 ', '');
INSERT INTO `item_instance` VALUES ('23868', '6', '23868 1191182336 7 22976 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44623', '2', '44623 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44624', '2', '44624 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44625', '2', '44625 1191182336 3 36155 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 4294967277 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44626', '2', '44626 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44627', '2', '44627 1191182336 3 1491 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44628', '2', '44628 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44629', '2', '44629 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44020', '2', '44020 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44630', '2', '44630 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44631', '2', '44631 1191182336 3 1936 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44632', '2', '44632 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44102', '2', '44102 1191182336 3 1613 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 364 0 0 366 0 0 0 0 0 0 869 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44514', '2', '44514 1191182336 3 2732 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44513', '2', '44513 1191182336 3 25228 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 40 4294967252 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44103', '2', '44103 1191182336 3 35615 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44633', '2', '44633 1191182336 3 864 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 103 0 0 106 0 0 0 0 0 0 1189 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('23656', '6', '23656 1191182336 3 1421 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44111', '2', '44111 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44543', '2', '44543 1191182336 3 36484 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 43 4294967255 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44544', '2', '44544 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44545', '2', '44545 1191182336 3 16724 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44546', '2', '44546 1191182336 3 20540 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44547', '2', '44547 1191182336 3 4660 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44548', '2', '44548 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44549', '2', '44549 1191182336 3 20709 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44550', '2', '44550 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44551', '2', '44551 1191182336 3 20679 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44552', '2', '44552 1191182336 3 5742 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44553', '2', '44553 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44554', '2', '44554 1191182336 3 36682 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 46 4294967252 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44555', '2', '44555 1191182336 3 31214 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 46 4294967256 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44124', '2', '44124 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44558', '2', '44558 1191182336 3 36382 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 75 4294967287 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44556', '2', '44556 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44557', '2', '44557 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44082', '2', '44082 1191182336 3 36682 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 46 4294967252 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44123', '2', '44123 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44559', '2', '44559 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44560', '2', '44560 1191182336 3 1265 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44083', '2', '44083 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44084', '2', '44084 1191182336 3 13911 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44568', '2', '44568 1191182336 3 4434 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44561', '2', '44561 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44562', '2', '44562 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44563', '2', '44563 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44564', '2', '44564 1191182336 3 44669 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 3727 0 0 2824 0 0 0 0 0 0 0 0 56 4294967206 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44565', '2', '44565 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44566', '2', '44566 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44567', '2', '44567 1191182336 3 13755 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44574', '2', '44574 1191182336 3 2258 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44569', '2', '44569 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44570', '2', '44570 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44571', '2', '44571 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44572', '2', '44572 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44573', '2', '44573 1191182336 3 34826 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44575', '2', '44575 1191182336 3 36065 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 81 4294967277 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44576', '2', '44576 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44577', '2', '44577 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44578', '2', '44578 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44579', '2', '44579 1191182336 3 3285 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44085', '2', '44085 1191182336 3 21114 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44580', '2', '44580 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44581', '2', '44581 1191182336 3 9375 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44582', '2', '44582 1191182336 3 13910 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44583', '2', '44583 1191182336 3 2066 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44466', '2', '44466 1191182336 3 25268 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 4294967277 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44467', '2', '44467 1191182336 3 15313 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44468', '2', '44468 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44086', '2', '44086 1191182336 3 753 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44081', '2', '44081 1191182336 3 24401 1065353216 0 2 0 2 0 0 0 0 0 61 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44636', '2', '44636 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44637', '2', '44637 1191182336 3 36027 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 69 4294967290 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44638', '2', '44638 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44299', '2', '44299 1191182336 3 2292 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44300', '2', '44300 1191182336 3 1608 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1592 0 0 0 0 0 0 0 0 0 1557 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44136', '2', '44136 1191182336 3 2099 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44291', '2', '44291 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44292', '2', '44292 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44293', '2', '44293 1191182336 3 920 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44294', '2', '44294 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44295', '2', '44295 1191182336 3 20540 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44296', '2', '44296 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44297', '2', '44297 1191182336 3 37822 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44298', '2', '44298 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44137', '2', '44137 1191182336 3 44687 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 3727 0 0 2824 0 0 0 0 0 0 0 0 65 4294967206 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44044', '2', '44044 1191182336 3 6294 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44159', '2', '44159 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44360', '2', '44360 1191182336 3 24665 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 52 4294967274 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44361', '2', '44361 1191182336 3 31172 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 47 4294967256 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44203', '2', '44203 1191182336 3 2259 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44204', '2', '44204 1191182336 3 18295 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1398 0 0 0 0 0 0 0 0 0 1508 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44205', '2', '44205 1191182336 3 3475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44206', '2', '44206 1191182336 3 36384 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2813 0 0 0 0 0 0 0 0 0 0 0 0 0 0 101 4294967269 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44207', '2', '44207 1191182336 3 1980 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44138', '2', '44138 1191182336 3 6354 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44139', '2', '44139 1191182336 3 4637 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44335', '2', '44335 1191182336 3 45998 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44336', '2', '44336 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44337', '2', '44337 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44338', '2', '44338 1191182336 3 24401 1065353216 0 2 0 2 0 0 0 0 0 81 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44339', '2', '44339 1191182336 3 31254 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 31 4294967283 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44340', '2', '44340 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44341', '2', '44341 1191182336 3 24603 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 30 4294967259 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44342', '2', '44342 1191182336 3 3295 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44343', '2', '44343 1191182336 3 25744 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44344', '2', '44344 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44345', '2', '44345 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44346', '2', '44346 1191182336 3 31247 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 38 4294967289 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44347', '2', '44347 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44348', '2', '44348 1191182336 3 9755 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44349', '2', '44349 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44350', '2', '44350 1191182336 3 6651 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44351', '2', '44351 1191182336 3 31188 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 30 4294967260 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44352', '2', '44352 1191182336 3 5182 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44353', '2', '44353 1191182336 3 720 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44354', '2', '44354 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44355', '2', '44355 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44356', '2', '44356 1191182336 3 13903 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44357', '2', '44357 1191182336 3 31197 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 44 4294967283 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44358', '2', '44358 1191182336 3 31221 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 33 4294967285 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44359', '2', '44359 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44140', '2', '44140 1191182336 3 44505 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44141', '2', '44141 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44093', '2', '44093 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44665', '2', '44665 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44666', '2', '44666 1191182336 3 36261 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2822 0 0 2824 0 0 0 0 0 0 0 0 97 4294967229 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44667', '2', '44667 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44668', '2', '44668 1191182336 3 28495 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 34 4294967243 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44669', '2', '44669 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44670', '2', '44670 1191182336 3 2265 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44671', '2', '44671 1191182336 3 24685 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 42 4294967260 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44672', '2', '44672 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44673', '2', '44673 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44674', '2', '44674 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44675', '2', '44675 1191182336 3 2226 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44676', '2', '44676 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44677', '2', '44677 1191182336 3 25254 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 12 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44678', '2', '44678 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44679', '2', '44679 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44680', '2', '44680 1191182336 3 20692 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1436 0 0 0 0 0 0 0 0 0 1454 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44681', '2', '44681 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44682', '2', '44682 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44683', '2', '44683 1191182336 3 1219 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44684', '2', '44684 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44685', '2', '44685 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44686', '2', '44686 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44687', '2', '44687 1191182336 3 2284 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44688', '2', '44688 1191182336 3 6197 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44127', '2', '44127 1191182336 3 1211 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44128', '2', '44128 1191182336 3 1296 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44129', '2', '44129 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44130', '2', '44130 1191182336 3 24827 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 40 4294967286 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44131', '2', '44131 1191182336 3 4449 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44132', '2', '44132 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44133', '2', '44133 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44303', '2', '44303 1191182336 3 44676 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 3727 0 0 2824 0 0 0 0 0 0 0 0 108 4294967206 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44094', '2', '44094 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44095', '2', '44095 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44439', '2', '44439 1191182336 3 1388 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44440', '2', '44440 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44441', '2', '44441 1191182336 3 812 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44442', '2', '44442 1191182336 3 3295 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44443', '2', '44443 1191182336 3 7753 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44423', '2', '44423 1191182336 3 3295 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44424', '2', '44424 1191182336 3 2244 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44425', '2', '44425 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44426', '2', '44426 1191182336 3 36155 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 75 4294967289 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44427', '2', '44427 1191182336 3 24775 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 52 4294967287 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44428', '2', '44428 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44429', '2', '44429 1191182336 3 28531 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 12 4294967256 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44430', '2', '44430 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44431', '2', '44431 1191182336 3 20709 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44432', '2', '44432 1191182336 3 942 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44433', '2', '44433 1191182336 3 31562 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 63 4294967255 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44434', '2', '44434 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44435', '2', '44435 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44436', '2', '44436 1191182336 3 940 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44437', '2', '44437 1191182336 3 2291 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44438', '2', '44438 1191182336 3 2291 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44420', '2', '44420 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44421', '2', '44421 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44422', '2', '44422 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44405', '2', '44405 1191182336 3 31161 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 46 4294967256 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44406', '2', '44406 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44407', '2', '44407 1191182336 3 14170 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44408', '2', '44408 1191182336 3 24677 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 41 4294967259 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44409', '2', '44409 1191182336 3 9486 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 95 95 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44410', '2', '44410 1191182336 3 25068 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2815 0 0 2802 0 0 0 0 0 0 0 0 0 0 0 29 4294967267 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44411', '2', '44411 1191182336 3 18255 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44412', '2', '44412 1191182336 3 6458 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44413', '2', '44413 1191182336 3 37069 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44414', '2', '44414 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44415', '2', '44415 1191182336 3 20531 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44416', '2', '44416 1191182336 3 44708 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44417', '2', '44417 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44418', '2', '44418 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44419', '2', '44419 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44096', '2', '44096 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44097', '2', '44097 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44098', '2', '44098 1191182336 3 2167 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44142', '2', '44142 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44143', '2', '44143 1191182336 3 13917 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44144', '2', '44144 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44512', '2', '44512 1191182336 3 2018 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44490', '2', '44490 1191182336 3 6353 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44491', '2', '44491 1191182336 3 3197 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 351 0 0 352 0 0 0 0 0 0 1115 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44492', '2', '44492 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44493', '2', '44493 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44494', '2', '44494 1191182336 3 23320 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44495', '2', '44495 1191182336 3 1280 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44496', '2', '44496 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44497', '2', '44497 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44498', '2', '44498 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44499', '2', '44499 1191182336 3 16681 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44500', '2', '44500 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44501', '2', '44501 1191182336 3 16712 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44502', '2', '44502 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44503', '2', '44503 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44504', '2', '44504 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44505', '2', '44505 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44506', '2', '44506 1191182336 3 10402 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44507', '2', '44507 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44508', '2', '44508 1191182336 3 16646 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44509', '2', '44509 1191182336 3 1722 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44510', '2', '44510 1191182336 3 12528 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44511', '2', '44511 1191182336 3 36178 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 60 4294967256 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44125', '2', '44125 1191182336 3 4636 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44091', '2', '44091 1191182336 3 36386 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 56 4294967284 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44460', '2', '44460 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44458', '2', '44458 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44459', '2', '44459 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44454', '2', '44454 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44455', '2', '44455 1191182336 3 37761 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44456', '2', '44456 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44457', '2', '44457 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44092', '2', '44092 1191182336 3 36382 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 4294967279 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44066', '2', '44066 1191182336 3 20693 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44453', '2', '44453 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44104', '2', '44104 1191182336 3 16649 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44105', '2', '44105 1191182336 3 934 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44445', '2', '44445 1191182336 3 35641 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44446', '2', '44446 1191182336 3 31191 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 30 4294967285 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44447', '2', '44447 1191182336 3 31125 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44448', '2', '44448 1191182336 3 1355 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44449', '2', '44449 1191182336 3 3280 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44450', '2', '44450 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44451', '2', '44451 1191182336 3 46004 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44452', '2', '44452 1191182336 3 16653 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44444', '2', '44444 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44163', '2', '44163 1191182336 3 5257 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44164', '2', '44164 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44165', '2', '44165 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44611', '2', '44611 1191182336 3 36541 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 104 4294967256 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44100', '2', '44100 1191182336 3 20545 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44065', '2', '44065 1191182336 3 13917 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44126', '2', '44126 1191182336 3 4444 1065353216 0 2 0 2 0 0 0 0 0 1 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44612', '2', '44612 1191182336 3 6315 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44613', '2', '44613 1191182336 3 23386 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44614', '2', '44614 1191182336 3 18339 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44615', '2', '44615 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44616', '2', '44616 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44617', '2', '44617 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('43991', '2', '43991 1191182336 3 1998 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44101', '2', '44101 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44618', '2', '44618 1191182336 3 7734 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44619', '2', '44619 1191182336 3 31220 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 60 4294967258 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44620', '2', '44620 1191182336 3 35652 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44621', '2', '44621 1191182336 3 766 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44622', '2', '44622 1191182336 3 4448 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 95 95 0 0 ', '');
INSERT INTO `item_instance` VALUES ('25964', '6', '25964 1191182336 3 23500 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44645', '2', '44645 1191182336 3 2046 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44646', '2', '44646 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44647', '2', '44647 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44648', '2', '44648 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44649', '2', '44649 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44650', '2', '44650 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44651', '2', '44651 1191182336 3 9393 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44652', '2', '44652 1191182336 3 24668 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 29 4294967287 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44653', '2', '44653 1191182336 3 17414 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44654', '2', '44654 1191182336 3 36500 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 46 4294967255 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44655', '2', '44655 1191182336 3 11603 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44656', '2', '44656 1191182336 3 14897 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 353 0 0 352 0 0 0 0 0 0 1200 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44657', '2', '44657 1191182336 3 37757 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44658', '2', '44658 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44659', '2', '44659 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44660', '2', '44660 1191182336 3 44649 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 75 4294967255 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44661', '2', '44661 1191182336 3 18709 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44662', '2', '44662 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44663', '2', '44663 1191182336 3 5758 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44664', '2', '44664 1191182336 3 31198 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 44 4294967257 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44078', '2', '44078 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44079', '2', '44079 1191182336 3 14087 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 14 14 0 0 ', '');
INSERT INTO `item_instance` VALUES ('26110', '6', '26110 1191182336 3 4604 1065353216 0 6 0 6 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('26229', '6', '26229 1191182336 3 2646 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('26232', '6', '26232 1191182336 3 15969 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 82 0 0 71 0 0 0 0 0 0 1009 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44152', '2', '44152 1191182336 3 790 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 83 0 0 69 0 0 0 0 0 0 1097 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44584', '2', '44584 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44585', '2', '44585 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44586', '2', '44586 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44587', '2', '44587 1191182336 3 37452 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44596', '2', '44596 1191182336 3 10567 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44301', '2', '44301 1191182336 3 24291 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44302', '2', '44302 1191182336 3 24666 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 52 4294967257 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44588', '2', '44588 1191182336 3 31232 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2818 0 0 0 0 0 0 0 0 0 0 0 40 4294967264 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44589', '2', '44589 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44590', '2', '44590 1191182336 3 25040 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 29 4294967256 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44591', '2', '44591 1191182336 3 20532 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44592', '2', '44592 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44593', '2', '44593 1191182336 3 6203 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44594', '2', '44594 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44595', '2', '44595 1191182336 3 13891 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('25959', '6', '25959 1191182336 3 27668 1065353216 0 6 0 6 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('26233', '6', '26233 1191182336 3 6507 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44375', '2', '44375 1191182336 3 1483 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44376', '2', '44376 1191182336 3 31212 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 60 4294967263 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44377', '2', '44377 1191182336 3 8226 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44378', '2', '44378 1191182336 3 9427 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44379', '2', '44379 1191182336 3 31291 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44154', '2', '44154 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44605', '2', '44605 1191182336 3 36570 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 46 4294967283 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44109', '2', '44109 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44606', '2', '44606 1191182336 3 13878 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44607', '2', '44607 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44608', '2', '44608 1191182336 3 6647 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44609', '2', '44609 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44388', '2', '44388 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44389', '2', '44389 1191182336 3 22641 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44390', '2', '44390 1191182336 3 20695 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44391', '2', '44391 1191182336 3 25242 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 12 4294967255 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44392', '2', '44392 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44393', '2', '44393 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44394', '2', '44394 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44395', '2', '44395 1191182336 3 766 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44396', '2', '44396 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44397', '2', '44397 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44398', '2', '44398 1191182336 3 30738 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44399', '2', '44399 1191182336 3 1728 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44400', '2', '44400 1191182336 3 2911 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44401', '2', '44401 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44402', '2', '44402 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44403', '2', '44403 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44404', '2', '44404 1191182336 3 30733 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44238', '2', '44238 1191182336 3 24401 1065353216 0 2 0 2 0 0 0 0 0 118 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44239', '2', '44239 1191182336 3 16702 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44240', '2', '44240 1191182336 3 11937 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44241', '2', '44241 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44242', '2', '44242 1191182336 3 20526 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44243', '2', '44243 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44244', '2', '44244 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44245', '2', '44245 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44246', '2', '44246 1191182336 3 9755 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44247', '2', '44247 1191182336 3 28492 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 41 4294967247 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44248', '2', '44248 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44249', '2', '44249 1191182336 3 867 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44250', '2', '44250 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44251', '2', '44251 1191182336 3 18339 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44252', '2', '44252 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44253', '2', '44253 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44254', '2', '44254 1191182336 3 1980 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44255', '2', '44255 1191182336 3 868 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44256', '2', '44256 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44257', '2', '44257 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44258', '2', '44258 1191182336 3 36637 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 30 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44259', '2', '44259 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44260', '2', '44260 1191182336 3 14170 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44261', '2', '44261 1191182336 3 24822 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2821 0 0 0 0 0 0 0 0 0 0 0 30 4294967261 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44262', '2', '44262 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44263', '2', '44263 1191182336 3 30727 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44264', '2', '44264 1191182336 3 34837 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44265', '2', '44265 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44266', '2', '44266 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44267', '2', '44267 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44268', '2', '44268 1191182336 3 9444 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44269', '2', '44269 1191182336 3 6203 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44270', '2', '44270 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44271', '2', '44271 1191182336 3 31183 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 49 4294967253 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44272', '2', '44272 1191182336 3 6292 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44273', '2', '44273 1191182336 3 4263 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44274', '2', '44274 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44275', '2', '44275 1191182336 3 24603 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2818 0 0 0 0 0 0 0 0 0 0 0 30 4294967264 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44276', '2', '44276 1191182336 3 36569 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 45 4294967282 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44277', '2', '44277 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44278', '2', '44278 1191182336 3 4694 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44279', '2', '44279 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44280', '2', '44280 1191182336 3 7729 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44281', '2', '44281 1191182336 3 44165 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44282', '2', '44282 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44283', '2', '44283 1191182336 3 6356 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44284', '2', '44284 1191182336 3 36610 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 101 4294967291 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44285', '2', '44285 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44286', '2', '44286 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44287', '2', '44287 1191182336 3 36272 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2821 0 0 0 0 0 0 0 0 0 0 0 101 4294967261 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44288', '2', '44288 1191182336 3 12547 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44289', '2', '44289 1191182336 3 24662 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 39 4294967271 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44290', '2', '44290 1191182336 3 36373 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 97 4294967281 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44110', '2', '44110 1191182336 3 2268 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39312', '6', '39312 1191182336 3 4814 1065353216 0 6 0 6 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39601', '6', '39601 1191182336 3 22570 1065353216 0 6 0 6 0 0 0 0 0 3 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39602', '6', '39602 1191182336 3 15925 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39606', '6', '39606 1191182336 3 6296 1065353216 0 6 0 6 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39607', '6', '39607 1191182336 3 6293 1065353216 0 6 0 7855 1191182336 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39609', '6', '39609 1191182336 3 2967 1065353216 0 6 0 7855 1191182336 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39612', '6', '39612 1191182336 3 12223 1065353216 0 6 0 7855 1191182336 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('39613', '6', '39613 1191182336 3 6506 1065353216 0 6 0 7855 1191182336 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44134', '2', '44134 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44635', '2', '44635 1191182336 3 4660 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44634', '2', '44634 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44135', '2', '44135 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37506', '6', '37506 1191182336 3 858 1065353216 0 6 0 6 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37507', '6', '37507 1191182336 3 2318 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('37508', '6', '37508 1191182336 3 4537 1065353216 0 6 0 6 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44644', '2', '44644 1191182336 3 37822 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44643', '2', '44643 1191182336 3 8106 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44642', '2', '44642 1191182336 3 31199 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 44 4294967258 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44641', '2', '44641 1191182336 3 36263 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 97 4294967283 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44640', '2', '44640 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44639', '2', '44639 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44610', '2', '44610 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44542', '2', '44542 1191182336 3 1406 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44541', '2', '44541 1191182336 3 18337 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44487', '2', '44487 1191182336 3 24714 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 40 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44334', '2', '44334 1191182336 3 6332 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44074', '2', '44074 1191182336 3 17414 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44075', '2', '44075 1191182336 3 24715 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 30 4294967287 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44076', '2', '44076 1191182336 3 14903 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 104 0 0 108 0 0 0 0 0 0 1194 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44077', '2', '44077 1191182336 3 4768 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44304', '2', '44304 1191182336 3 18300 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44305', '2', '44305 1191182336 3 4044 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44306', '2', '44306 1191182336 3 35666 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44307', '2', '44307 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44308', '2', '44308 1191182336 3 890 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44309', '2', '44309 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44310', '2', '44310 1191182336 3 18678 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44311', '2', '44311 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44312', '2', '44312 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44313', '2', '44313 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44314', '2', '44314 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44315', '2', '44315 1191182336 3 20678 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44316', '2', '44316 1191182336 3 6364 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44317', '2', '44317 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44318', '2', '44318 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44319', '2', '44319 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44320', '2', '44320 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44321', '2', '44321 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44322', '2', '44322 1191182336 3 45984 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44323', '2', '44323 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44324', '2', '44324 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44325', '2', '44325 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44326', '2', '44326 1191182336 3 25416 1065353216 0 2 0 2 0 0 0 0 0 95 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44327', '2', '44327 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44328', '2', '44328 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44329', '2', '44329 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44330', '2', '44330 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44331', '2', '44331 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44332', '2', '44332 1191182336 3 732 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44122', '2', '44122 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44121', '2', '44121 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44233', '2', '44233 1191182336 3 14554 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44234', '2', '44234 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44235', '2', '44235 1191182336 3 5181 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44067', '2', '44067 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44120', '2', '44120 1191182336 3 2168 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44155', '2', '44155 1191182336 3 2072 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 0 0 107 0 0 0 0 0 0 1107 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44156', '2', '44156 1191182336 3 10246 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1122 0 0 1148 0 0 0 0 0 0 808 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44471', '2', '44471 1191182336 3 24449 1065353216 0 2 0 2 0 0 0 0 0 69 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44472', '2', '44472 1191182336 3 43624 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44473', '2', '44473 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44474', '2', '44474 1191182336 3 4768 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44475', '2', '44475 1191182336 3 2271 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44476', '2', '44476 1191182336 3 25264 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 16 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44477', '2', '44477 1191182336 3 6660 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44478', '2', '44478 1191182336 3 2257 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44479', '2', '44479 1191182336 3 13882 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44480', '2', '44480 1191182336 3 3340 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44481', '2', '44481 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44482', '2', '44482 1191182336 3 7753 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44483', '2', '44483 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44157', '2', '44157 1191182336 3 20670 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 366 0 0 2317 0 0 2373 0 0 0 2153 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44158', '2', '44158 1191182336 3 24836 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 31 4294967253 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44208', '2', '44208 1191182336 3 34622 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44209', '2', '44209 1191182336 3 10571 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44210', '2', '44210 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44211', '2', '44211 1191182336 3 30810 1065353216 0 2 0 2 0 0 0 0 0 215 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44212', '2', '44212 1191182336 3 811 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44213', '2', '44213 1191182336 3 5967 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44214', '2', '44214 1191182336 3 811 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44215', '2', '44215 1191182336 3 3329 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44216', '2', '44216 1191182336 3 36484 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 43 4294967291 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44217', '2', '44217 1191182336 3 31223 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 0 0 0 0 0 0 0 0 0 0 0 0 33 4294967278 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44218', '2', '44218 1191182336 3 49227 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 56 4294967260 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44219', '2', '44219 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44220', '2', '44220 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44221', '2', '44221 1191182336 3 2955 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44222', '2', '44222 1191182336 3 24589 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 29 4294967290 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44223', '2', '44223 1191182336 3 2798 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44224', '2', '44224 1191182336 3 30740 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44225', '2', '44225 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44226', '2', '44226 1191182336 3 2066 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44227', '2', '44227 1191182336 3 9392 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44228', '2', '44228 1191182336 3 9402 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44229', '2', '44229 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44230', '2', '44230 1191182336 3 1169 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44231', '2', '44231 1191182336 3 6201 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44232', '2', '44232 1191182336 3 24889 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 39 4294967252 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44115', '2', '44115 1191182336 3 1482 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44116', '2', '44116 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44117', '2', '44117 1191182336 3 766 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44118', '2', '44118 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44119', '2', '44119 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44515', '2', '44515 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44470', '2', '44470 1191182336 3 18709 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44112', '2', '44112 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44113', '2', '44113 1191182336 3 36273 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 75 4294967287 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44469', '2', '44469 1191182336 3 16645 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44114', '2', '44114 1191182336 3 14549 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44516', '2', '44516 1191182336 3 24822 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 30 4294967256 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44517', '2', '44517 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44518', '2', '44518 1191182336 3 1219 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44519', '2', '44519 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44520', '2', '44520 1191182336 3 36484 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 43 4294967256 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44521', '2', '44521 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44522', '2', '44522 1191182336 3 49227 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 56 4294967254 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44523', '2', '44523 1191182336 3 31158 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 60 4294967260 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44524', '2', '44524 1191182336 3 24663 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2818 0 0 0 0 0 0 0 0 0 0 0 52 4294967264 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44525', '2', '44525 1191182336 3 22277 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44526', '2', '44526 1191182336 3 13911 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44527', '2', '44527 1191182336 3 24599 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2821 0 0 0 0 0 0 0 0 0 0 0 40 4294967261 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44528', '2', '44528 1191182336 3 3295 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44529', '2', '44529 1191182336 3 7786 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44530', '2', '44530 1191182336 3 10625 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44531', '2', '44531 1191182336 3 3022 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44532', '2', '44532 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44533', '2', '44533 1191182336 3 16648 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44534', '2', '44534 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44535', '2', '44535 1191182336 3 4791 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44536', '2', '44536 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44537', '2', '44537 1191182336 3 18610 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44538', '2', '44538 1191182336 3 32470 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44539', '2', '44539 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44540', '2', '44540 1191182336 3 30610 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44162', '2', '44162 1191182336 3 2734 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44236', '2', '44236 1191182336 3 14554 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44160', '2', '44160 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44161', '2', '44161 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44087', '2', '44087 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44088', '2', '44088 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44488', '2', '44488 1191182336 3 31246 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 51 4294967260 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44489', '2', '44489 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44237', '2', '44237 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44089', '2', '44089 1191182336 3 21589 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44090', '2', '44090 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44370', '2', '44370 1191182336 3 36393 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 78 4294967263 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44371', '2', '44371 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44372', '2', '44372 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44373', '2', '44373 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44374', '2', '44374 1191182336 3 20698 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('43982', '2', '43982 1191182336 3 36046 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 75 4294967260 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44362', '2', '44362 1191182336 3 36527 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 4294967280 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44363', '2', '44363 1191182336 3 44147 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44364', '2', '44364 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44365', '2', '44365 1191182336 3 24828 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 30 4294967291 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44366', '2', '44366 1191182336 3 30730 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44367', '2', '44367 1191182336 3 2824 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44368', '2', '44368 1191182336 3 10625 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44369', '2', '44369 1191182336 3 867 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44099', '2', '44099 1191182336 3 29426 1065353216 0 2 0 2 0 0 0 0 0 134 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44145', '2', '44145 1191182336 3 31215 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 46 4294967256 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44146', '2', '44146 1191182336 3 36159 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 101 4294967254 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44147', '2', '44147 1191182336 3 4474 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44148', '2', '44148 1191182336 3 2620 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44149', '2', '44149 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44150', '2', '44150 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44151', '2', '44151 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44014', '2', '44014 1191182336 3 2623 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44106', '2', '44106 1191182336 3 2879 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44484', '2', '44484 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44485', '2', '44485 1191182336 3 20261 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44486', '2', '44486 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44107', '2', '44107 1191182336 3 812 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44597', '2', '44597 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44598', '2', '44598 1191182336 3 24724 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 23 4294967254 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44599', '2', '44599 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44600', '2', '44600 1191182336 3 2751 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44601', '2', '44601 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44602', '2', '44602 1191182336 3 16676 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44603', '2', '44603 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44604', '2', '44604 1191182336 3 6549 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44166', '2', '44166 1191182336 3 34829 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44167', '2', '44167 1191182336 3 36639 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 33 4294967287 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44168', '2', '44168 1191182336 3 2110 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44169', '2', '44169 1191182336 3 1076 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44170', '2', '44170 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44171', '2', '44171 1191182336 3 37758 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44172', '2', '44172 1191182336 3 5742 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44173', '2', '44173 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44174', '2', '44174 1191182336 3 1484 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44175', '2', '44175 1191182336 3 1720 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44176', '2', '44176 1191182336 3 5206 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44177', '2', '44177 1191182336 3 1263 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44178', '2', '44178 1191182336 3 1677 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44179', '2', '44179 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44180', '2', '44180 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44181', '2', '44181 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44182', '2', '44182 1191182336 3 35557 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44183', '2', '44183 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44184', '2', '44184 1191182336 3 791 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44185', '2', '44185 1191182336 3 24345 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44186', '2', '44186 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44187', '2', '44187 1191182336 3 20544 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44188', '2', '44188 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44189', '2', '44189 1191182336 3 6887 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44190', '2', '44190 1191182336 3 16710 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44191', '2', '44191 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44192', '2', '44192 1191182336 3 1713 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44193', '2', '44193 1191182336 3 2100 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44194', '2', '44194 1191182336 3 44156 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44195', '2', '44195 1191182336 3 36003 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 62 4294967259 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44196', '2', '44196 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44197', '2', '44197 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44198', '2', '44198 1191182336 3 5752 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44199', '2', '44199 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44200', '2', '44200 1191182336 3 31940 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 35 4294967260 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44201', '2', '44201 1191182336 3 36441 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 54 4294967255 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44202', '2', '44202 1191182336 3 2108 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44050', '2', '44050 1191182336 3 3019 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44461', '2', '44461 1191182336 3 16676 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44462', '2', '44462 1191182336 3 37770 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44463', '2', '44463 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44464', '2', '44464 1191182336 3 4263 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44465', '2', '44465 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44051', '2', '44051 1191182336 3 36500 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 46 4294967252 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44108', '2', '44108 1191182336 3 24603 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2821 0 0 0 0 0 0 0 0 0 0 0 30 4294967261 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11063', '9', '11063 1191182336 3 38147 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11065', '9', '11065 1191182336 3 41751 1065353216 0 9 0 9 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');

-- ----------------------------
-- Table structure for `item_loot`
-- ----------------------------
DROP TABLE IF EXISTS `item_loot`;
CREATE TABLE `item_loot` (
  `guid` int(11) unsigned NOT NULL default '0',
  `owner_guid` int(11) unsigned NOT NULL default '0',
  `itemid` int(11) unsigned NOT NULL default '0',
  `amount` int(11) unsigned NOT NULL default '0',
  `suffix` int(11) unsigned NOT NULL default '0',
  `property` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guid`,`itemid`),
  KEY `idx_owner_guid` (`owner_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Item System';

-- ----------------------------
-- Records of item_loot
-- ----------------------------

-- ----------------------------
-- Table structure for `item_soulbound_trade_data`
-- ----------------------------
DROP TABLE IF EXISTS `item_soulbound_trade_data`;
CREATE TABLE `item_soulbound_trade_data` (
  `itemGuid` int(16) unsigned NOT NULL default '0',
  `allowedPlayers` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`itemGuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='BOP item trade cache';

-- ----------------------------
-- Records of item_soulbound_trade_data
-- ----------------------------

-- ----------------------------
-- Table structure for `jail`
-- ----------------------------
DROP TABLE IF EXISTS `jail`;
CREATE TABLE `jail` (
  `guid` int(11) unsigned NOT NULL COMMENT 'GUID of the jail brother',
  `char` varchar(13) NOT NULL COMMENT 'Jailed charname',
  `release` int(11) unsigned NOT NULL COMMENT 'Release time for the char',
  `amnestietime` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL COMMENT 'Reason for the jail',
  `times` int(11) unsigned NOT NULL COMMENT 'How many times this char already was jailed',
  `gmacc` int(11) unsigned NOT NULL COMMENT 'Used GM acc to jail this char',
  `gmchar` varchar(13) NOT NULL COMMENT 'Used GM char to jail this char',
  `lasttime` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP COMMENT 'Last time jailed',
  `duration` int(11) unsigned NOT NULL default '0' COMMENT 'Duration of the jail',
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Jail table for MaNGOS by WarHead';

-- ----------------------------
-- Records of jail
-- ----------------------------

-- ----------------------------
-- Table structure for `jail_conf`
-- ----------------------------
DROP TABLE IF EXISTS `jail_conf`;
CREATE TABLE `jail_conf` (
  `id` int(11) NOT NULL auto_increment,
  `obt` varchar(50) default NULL,
  `jail_conf` int(11) default NULL,
  `jail_tele` float default NULL,
  `help_ger` varchar(255) character set latin1 default '',
  `help_enq` varchar(255) default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of jail_conf
-- ----------------------------
INSERT INTO `jail_conf` VALUES ('1', 'm_jailconf_max_jails', '3', null, 'Hier legst ihre fest nach wie fielen Jails der Char gelöscht werden \r\nStandart = 3\r\n ', '');
INSERT INTO `jail_conf` VALUES ('2', 'm_jailconf_max_duration', '672', null, 'Hier legst ihre fest wie hoch der maximale Jail Time in Stunden \r\nStandart = 672\r\n', '');
INSERT INTO `jail_conf` VALUES ('3', 'm_jailconf_min_reason', '25', null, 'Hier legst ihre die minimalen Zeichen fest die als Grund angeben müsst  \r\nStandart = 25\r\n\r\n', '');
INSERT INTO `jail_conf` VALUES ('4', 'm_jailconf_warn_player', '1', null, 'Hier legst ihre fest wann der Char gewarnt wirt  bevor er gelöscht wird \r\nStandart = 1\r\n', '');
INSERT INTO `jail_conf` VALUES ('5', 'm_jailconf_amnestie', '180', null, 'Hier legst ihre in Tagen fest wann der Jail Status  auf 0 zurückgesetzt wird   \r\nStandart = 180 Tage (das entspricht ca. ½ Jahr)  \r\n                     0  Tage (Aus )\r\n', '');
INSERT INTO `jail_conf` VALUES ('6', 'm_jailconf_ally_x', null, '31.7282', 'Teleport Alliance  X Achse \r\nStandart = 31,7282\r\n', '');
INSERT INTO `jail_conf` VALUES ('7', 'm_jailconf_ally_y', null, '135.794', 'Teleport Alliance  Y Achse \r\nStandart = 135,794\r\n', '');
INSERT INTO `jail_conf` VALUES ('8', 'm_jailconf_ally_z', null, '-40.0508', 'Teleport Alliance  Z Achse \r\nStandart = -40,0508', '');
INSERT INTO `jail_conf` VALUES ('9', 'm_jailconf_ally_o', null, '4.73516', 'Teleport Alliance  blickrichtung\r\nStandart = 4,73516', '');
INSERT INTO `jail_conf` VALUES ('10', 'm_jailconf_ally_m', '35', null, 'Teleport Alliance  Mape\r\nStandart = 35', '');
INSERT INTO `jail_conf` VALUES ('11', 'm_jailconf_horde_x', null, '2179.85', 'Teleport Horde  X Achse \r\nStandart = \r\n', '');
INSERT INTO `jail_conf` VALUES ('12', 'm_jailconf_horde_y', null, '-4763.96', 'Teleport Horde  Y Achse \r\nStandart = -4763,96', '');
INSERT INTO `jail_conf` VALUES ('13', 'm_jailconf_horde_z', null, '54.911', 'Teleport Horde  Z Achse \r\nStandart = 54,911', '');
INSERT INTO `jail_conf` VALUES ('14', 'm_jailconf_horde_o', null, '4.44216', 'Teleport  Horde  blickrichtung\r\nStandart = 4,44216', '');
INSERT INTO `jail_conf` VALUES ('15', 'm_jailconf_horde_m', '1', null, 'Teleport Horde  Mape\r\nStandart = 1', '');
INSERT INTO `jail_conf` VALUES ('16', 'm_jailconf_ban', '0', null, 'Nach wie vielen Jail soll der  Account Gebant werden\r\nStandart = 0  (aus)\r\n', '');
INSERT INTO `jail_conf` VALUES ('17', 'm_jailconf_radius', '10', null, 'Legt den Bewegung Radius in Metern waren des Jails fest\r\nStandart = 10\r\n', '');

-- ----------------------------
-- Table structure for `mail`
-- ----------------------------
DROP TABLE IF EXISTS `mail`;
CREATE TABLE `mail` (
  `id` int(11) unsigned NOT NULL default '0' COMMENT 'Identifier',
  `messageType` tinyint(3) unsigned NOT NULL default '0',
  `stationery` tinyint(3) NOT NULL default '41',
  `mailTemplateId` mediumint(8) unsigned NOT NULL default '0',
  `sender` int(11) unsigned NOT NULL default '0' COMMENT 'Character Global Unique Identifier',
  `receiver` int(11) unsigned NOT NULL default '0' COMMENT 'Character Global Unique Identifier',
  `subject` longtext,
  `body` longtext,
  `has_items` tinyint(3) unsigned NOT NULL default '0',
  `expire_time` bigint(40) NOT NULL default '0',
  `deliver_time` bigint(40) NOT NULL default '0',
  `money` int(11) unsigned NOT NULL default '0',
  `cod` int(11) unsigned NOT NULL default '0',
  `checked` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_receiver` (`receiver`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Mail System';

-- ----------------------------
-- Records of mail
-- ----------------------------
INSERT INTO `mail` VALUES ('2', '0', '61', '0', '2', '2', 'This item(s) have problems with equipping/storing in inventory.', 'There\'s were problems with equipping item(s).', '1', '1295796809', '1293204809', '0', '0', '2');
INSERT INTO `mail` VALUES ('3', '0', '61', '0', '7', '7', 'This item(s) have problems with equipping/storing in inventory.', 'There\'s were problems with equipping item(s).', '1', '1296188232', '1293596232', '0', '0', '4');
INSERT INTO `mail` VALUES ('4', '0', '61', '0', '7', '7', 'This item(s) have problems with equipping/storing in inventory.', 'There\'s were problems with equipping item(s).', '1', '1296188232', '1293596232', '0', '0', '4');
INSERT INTO `mail` VALUES ('5', '3', '41', '282', '35093', '9', '', '', '0', '1297005144', '1294413144', '0', '0', '0');

-- ----------------------------
-- Table structure for `mail_items`
-- ----------------------------
DROP TABLE IF EXISTS `mail_items`;
CREATE TABLE `mail_items` (
  `mail_id` int(11) NOT NULL default '0',
  `item_guid` int(11) NOT NULL default '0',
  `item_template` int(11) NOT NULL default '0',
  `receiver` int(11) unsigned NOT NULL default '0' COMMENT 'Character Global Unique Identifier',
  PRIMARY KEY  (`mail_id`,`item_guid`),
  KEY `idx_receiver` (`receiver`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of mail_items
-- ----------------------------
INSERT INTO `mail_items` VALUES ('2', '38', '1395', '2');
INSERT INTO `mail_items` VALUES ('2', '40', '6096', '2');
INSERT INTO `mail_items` VALUES ('2', '504', '47', '2');
INSERT INTO `mail_items` VALUES ('2', '506', '2092', '2');
INSERT INTO `mail_items` VALUES ('2', '508', '50055', '2');
INSERT INTO `mail_items` VALUES ('2', '512', '6948', '2');
INSERT INTO `mail_items` VALUES ('3', '9858', '34657', '7');
INSERT INTO `mail_items` VALUES ('3', '9854', '34656', '7');
INSERT INTO `mail_items` VALUES ('3', '9852', '34651', '7');
INSERT INTO `mail_items` VALUES ('3', '9848', '34653', '7');
INSERT INTO `mail_items` VALUES ('3', '9846', '34650', '7');
INSERT INTO `mail_items` VALUES ('3', '9842', '34655', '7');
INSERT INTO `mail_items` VALUES ('3', '380', '38147', '7');
INSERT INTO `mail_items` VALUES ('3', '370', '34658', '7');
INSERT INTO `mail_items` VALUES ('3', '366', '34648', '7');
INSERT INTO `mail_items` VALUES ('3', '360', '34649', '7');
INSERT INTO `mail_items` VALUES ('3', '354', '34659', '7');
INSERT INTO `mail_items` VALUES ('3', '350', '34652', '7');
INSERT INTO `mail_items` VALUES ('4', '374', '38145', '7');
INSERT INTO `mail_items` VALUES ('4', '9862', '38145', '7');
INSERT INTO `mail_items` VALUES ('4', '9866', '38145', '7');
INSERT INTO `mail_items` VALUES ('4', '9868', '38145', '7');

-- ----------------------------
-- Table structure for `pet_aura`
-- ----------------------------
DROP TABLE IF EXISTS `pet_aura`;
CREATE TABLE `pet_aura` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `caster_guid` bigint(20) unsigned NOT NULL default '0' COMMENT 'Full Global Unique Identifier',
  `item_guid` int(11) unsigned NOT NULL default '0',
  `spell` int(11) unsigned NOT NULL default '0',
  `stackcount` int(11) NOT NULL default '1',
  `remaincharges` int(11) NOT NULL default '0',
  `basepoints0` int(11) NOT NULL default '0',
  `basepoints1` int(11) NOT NULL default '0',
  `basepoints2` int(11) NOT NULL default '0',
  `maxduration0` int(11) NOT NULL default '0',
  `maxduration1` int(11) NOT NULL default '0',
  `maxduration2` int(11) NOT NULL default '0',
  `remaintime0` int(11) NOT NULL default '0',
  `remaintime1` int(11) NOT NULL default '0',
  `remaintime2` int(11) NOT NULL default '0',
  `effIndexMask` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guid`,`caster_guid`,`item_guid`,`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Pet System';

-- ----------------------------
-- Records of pet_aura
-- ----------------------------

-- ----------------------------
-- Table structure for `pet_spell`
-- ----------------------------
DROP TABLE IF EXISTS `pet_spell`;
CREATE TABLE `pet_spell` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `spell` int(11) unsigned NOT NULL default '0' COMMENT 'Spell Identifier',
  `active` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Pet System';

-- ----------------------------
-- Records of pet_spell
-- ----------------------------

-- ----------------------------
-- Table structure for `pet_spell_cooldown`
-- ----------------------------
DROP TABLE IF EXISTS `pet_spell_cooldown`;
CREATE TABLE `pet_spell_cooldown` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier, Low part',
  `spell` int(11) unsigned NOT NULL default '0' COMMENT 'Spell Identifier',
  `time` bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pet_spell_cooldown
-- ----------------------------

-- ----------------------------
-- Table structure for `petition`
-- ----------------------------
DROP TABLE IF EXISTS `petition`;
CREATE TABLE `petition` (
  `ownerguid` int(10) unsigned NOT NULL,
  `petitionguid` int(10) unsigned default '0',
  `name` varchar(255) NOT NULL default '',
  `type` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`ownerguid`,`type`),
  UNIQUE KEY `index_ownerguid_petitionguid` (`ownerguid`,`petitionguid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';

-- ----------------------------
-- Records of petition
-- ----------------------------

-- ----------------------------
-- Table structure for `petition_sign`
-- ----------------------------
DROP TABLE IF EXISTS `petition_sign`;
CREATE TABLE `petition_sign` (
  `ownerguid` int(10) unsigned NOT NULL,
  `petitionguid` int(11) unsigned NOT NULL default '0',
  `playerguid` int(11) unsigned NOT NULL default '0',
  `player_account` int(11) unsigned NOT NULL default '0',
  `type` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`petitionguid`,`playerguid`),
  KEY `Idx_playerguid` (`playerguid`),
  KEY `Idx_ownerguid` (`ownerguid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';

-- ----------------------------
-- Records of petition_sign
-- ----------------------------

-- ----------------------------
-- Table structure for `saved_variables`
-- ----------------------------
DROP TABLE IF EXISTS `saved_variables`;
CREATE TABLE `saved_variables` (
  `NextArenaPointDistributionTime` bigint(40) unsigned NOT NULL default '0',
  `NextDailyQuestResetTime` bigint(40) unsigned NOT NULL default '0',
  `NextWeeklyQuestResetTime` bigint(40) unsigned NOT NULL default '0',
  `NextRandomBGResetTime` bigint(40) unsigned NOT NULL default '0',
  `NextMonthlyQuestResetTime` bigint(40) unsigned NOT NULL default '0',
  `cleaning_flags` int(11) unsigned NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Variable Saves';

-- ----------------------------
-- Records of saved_variables
-- ----------------------------
INSERT INTO `saved_variables` VALUES ('0', '1294657200', '1294830000', '1294657200', '1296536400', '0');
INSERT INTO `saved_variables` VALUES ('0', '1294657200', '1294830000', '1294657200', '1296536400', '0');
INSERT INTO `saved_variables` VALUES ('0', '1294657200', '1294830000', '1294657200', '1296536400', '0');
