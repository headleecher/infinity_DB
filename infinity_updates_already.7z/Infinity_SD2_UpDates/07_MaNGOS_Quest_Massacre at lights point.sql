-- Script update for Mine Cart   // Faction is still buggy with player
UPDATE `creature_template` SET `ScriptName` = 'npc_scarlet_minercar' WHERE `entry` = 28817;

-- moved the cannons around to get correct aim 
DELETE FROM `creature` WHERE `id`=28833;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`phaseMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(4456475, 28833, 609, 1, 1, 0, 0, 2265.26, -6190.15, 12.9752, 1.94359, 25, 0, 0, 26140, 2117, 0, 0),
(4456468, 28833, 609, 1, 1, 0, 0, 2110.31, -6182.88, 12.9535, 1.23178, 25, 0, 0, 26140, 2117, 0, 0),
(4456467, 28833, 609, 1, 1, 0, 0, 2115.53, -6185.41, 13.0516, 1.21455, 25, 0, 0, 26140, 2117, 0, 0),
(4456473, 28833, 609, 1, 1, 0, 0, 2259.49, -6192.26, 12.8938, 1.82874, 25, 0, 0, 26140, 2117, 0, 0),
(4456474, 28833, 609, 1, 1, 0, 0, 2253.41, -6194.36, 12.8233, 1.83659, 25, 0, 0, 26140, 2117, 0, 0),
(4456469, 28833, 609, 1, 1, 0, 0, 2104.37, -6180.76, 12.8765, 1.22786, 25, 0, 0, 26140, 2117, 0, 0);

-------------------------------------------------------------------------------------------
/* Scourge Gryphon */ -- to correct rsa typo & Correct gryphon
UPDATE creature_template SET
    spell1 = 57403,
    spell2 = 0,
    spell3 = 0,
    spell4 = 0,
    spell5 = 0,
    spell6 = 0,
    VehicleId = 25
WHERE entry IN (28864);

DELETE FROM `creature_template_addon` WHERE (`entry`=28864);
INSERT INTO `creature_template_addon` (`entry`, `mount`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (28864, 0, 0, 0, 0, 0, '61453 0 61453 2');
-------------------------------------------------------------------------------------------