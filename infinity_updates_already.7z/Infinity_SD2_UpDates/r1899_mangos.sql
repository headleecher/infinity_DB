UPDATE creature_template SET ScriptName='npc_greer_orehammer' WHERE entry=23859;
