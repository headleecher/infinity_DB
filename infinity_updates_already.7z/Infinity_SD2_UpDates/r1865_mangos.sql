UPDATE creature_template SET ScriptName='npc_injured_rainspeaker' WHERE entry=28217;
