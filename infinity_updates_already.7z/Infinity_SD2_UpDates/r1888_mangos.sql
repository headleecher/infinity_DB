UPDATE creature_template SET ScriptName='npc_zeppit' WHERE entry=22484;
