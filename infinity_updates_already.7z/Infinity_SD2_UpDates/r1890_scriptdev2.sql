DELETE FROM script_texts WHERE entry=-1000628;
INSERT INTO script_texts (entry,content_default,sound,type,language,emote,comment) VALUES
(-1000628,'%s feeds on the freshly-killed warp chaser.',0,2,0,0,'hungry ray EMOTE_FEED');
