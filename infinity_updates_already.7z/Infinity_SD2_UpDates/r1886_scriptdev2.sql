DELETE FROM sd2_db_version;
INSERT INTO sd2_db_version (version) VALUES ('ScriptDev2 (for MaNGOS 10761+) ');
