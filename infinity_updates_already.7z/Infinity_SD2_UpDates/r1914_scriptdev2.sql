UPDATE sd2_db_version SET version='ScriptDev2 (for MaNGOS 10928+) ';
