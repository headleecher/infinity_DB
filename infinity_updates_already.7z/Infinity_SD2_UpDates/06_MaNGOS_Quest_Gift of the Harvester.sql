UPDATE `creature_template` SET `ScriptName` = 'mob_scarlet_miner' WHERE `entry` = 28822;
UPDATE `creature_template` SET `ScriptName` = 'mob_scarlet_miner' WHERE `entry` = 28819;
UPDATE `creature_template` SET `ScriptName` = 'mob_scarlet_miner' WHERE `entry` = 28891;

UPDATE `item_template` SET `ScriptName` = 'mob_scarlet_miner' WHERE `entry` = 39253;

-- Quest gift of the harvester