UPDATE creature_template SET ScriptName='npc_hungry_nether_ray' WHERE entry=23439;
