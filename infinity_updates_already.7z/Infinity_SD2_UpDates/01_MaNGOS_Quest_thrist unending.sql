-- Thirst Unending

UPDATE `creature_template` SET `ScriptName`='npc_mana_wyrm' WHERE `entry`='15274';
UPDATE `quest_template` SET `ReqCreatureOrGOCount1`='1' WHERE `entry`='8346';


