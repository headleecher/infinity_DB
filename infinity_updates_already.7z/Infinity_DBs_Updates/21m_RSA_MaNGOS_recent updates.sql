DELETE FROM  `creature_template_addon` WHERE `entry` IN (37972,37973,37970,38401,38784,38785,38399,38769,38770,38400,38771,38772);
INSERT INTO `creature_template_addon` (`entry`, `mount`, `bytes1`, `emote`, `moveflags`, `auras`) VALUES
(37970, 0, 0, 0, 0, '71598 0 71598 1'),
(37972, 0, 0, 0, 0, '71598 0 71598 1'),
(37973, 0, 0, 0, 0, '71598 0 71598 1'),
(38401, 0, 0, 0, 0, '71598 0 71598 1'),
(38784, 0, 0, 0, 0, '71598 0 71598 1'),
(38785, 0, 0, 0, 0, '71598 0 71598 1'),
(38399, 0, 0, 0, 0, '71598 0 71598 1'),
(38769, 0, 0, 0, 0, '71598 0 71598 1'),
(38770, 0, 0, 0, 0, '71598 0 71598 1'),
(38400, 0, 0, 0, 0, '71598 0 71598 1'),
(38771, 0, 0, 0, 0, '71598 0 71598 1'),
(38772, 0, 0, 0, 0, '71598 0 71598 1');

-- Loot and deathstate for blood council (correct YTDB bugs, flags - from already killed princes)
UPDATE `creature_template` SET `unit_flags` = '0' WHERE `entry` IN (37972,37973,37970,38401,38784,38785,38399,38769,38770,38400,38771,38772);
 
-- FallenAngelX
ALTER TABLE db_version_Infinity_Update CHANGE COLUMN r20 r21 bit;
REPLACE INTO `db_version_Infinity_Update` (`version`) VALUES ('r21');

UPDATE db_version SET `cache_id`= 'r21';
UPDATE db_version SET `version`= 'YTDB578_Infinity_Update_r21';