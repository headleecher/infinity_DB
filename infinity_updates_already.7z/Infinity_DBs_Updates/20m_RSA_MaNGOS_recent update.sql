-- Pet 26125 - DK ghoul
DELETE FROM `pet_scaling_data` WHERE `creature_entry` = 26125;
INSERT INTO `pet_scaling_data` (`creature_entry`, `aura`, `healthbase`, `health`, `powerbase`, `power`, `str`, `agi`, `sta`, `inte`, `spi`, `armor`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `apbase`, `apbasescale`, `attackpower`, `damage`, `spelldamage`, `spellhit`, `hit`, `expertize`, `attackspeed`, `crit`, `regen`) VALUES
(26125,     0, 0, 1000, 0, 0, 70, 0, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 200, 0, 0, 0, 0, 100, 100, 100, 0, 0),
(26125, 48965, 0,    0, 0, 0, 14, 0,  6, 0, 0, 0, 0, 0, 0, 0, 0, 0,  0,   0, 0, 0, 0, 0,   0,   0,   0, 0, 0),
(26125, 49571, 0,    0, 0, 0, 28, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0,  0,   0, 0, 0, 0, 0,   0,   0,   0, 0, 0),
(26125, 49572, 0,    0, 0, 0, 42, 0, 18, 0, 0, 0, 0, 0, 0, 0, 0, 0,  0,   0, 0, 0, 0, 0,   0,   0,   0, 0, 0),
(26125, 58686, 0,    0, 0, 0, 40, 0, 40, 0, 0, 0, 0, 0, 0, 0, 0, 0,  0,   0, 0, 0, 0, 0,   0,   0,   0, 0, 0);


-- FallenAngelX
ALTER TABLE db_version_Infinity_Update CHANGE COLUMN r19 r20 bit;
REPLACE INTO `db_version_Infinity_Update` (`version`) VALUES ('r20');

UPDATE db_version SET `cache_id`= 'r20';
UPDATE db_version SET `version`= 'YTDB578_Infinity_Update_r20';