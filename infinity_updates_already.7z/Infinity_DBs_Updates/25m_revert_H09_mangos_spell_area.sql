-- Invisibilidad entre facciones en Acherus (Map=609)
DELETE FROM `spell_area` WHERE (`spell`='51913' AND `area`='4298' AND `quest_start`='0' AND `quest_start_active`='0' AND `aura_spell`='0' AND `racemask`='2' AND `gender`='1');

-- FallenAngelX
ALTER TABLE db_version_Infinity_Update CHANGE COLUMN r24 r25 bit;
REPLACE INTO `db_version_Infinity_Update` (`version`) VALUES ('r25');

UPDATE db_version SET `cache_id`= 'r25';
UPDATE db_version SET `version`= 'YTDB578_Infinity_Update_r25';