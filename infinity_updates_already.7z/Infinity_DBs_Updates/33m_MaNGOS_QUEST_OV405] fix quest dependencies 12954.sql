-- fix quest dependencies 12954 
UPDATE `quest_template` SET `NextQuestId` = '12933', `NextQuestInChain` = '12934' WHERE `entry` =12954; 
UPDATE `quest_template` SET `NextQuestId` = '12933', `NextQuestInChain` = '12934' WHERE `entry` =12932; 
UPDATE `quest_template` SET `PrevQuestId` = '0', `NextQuestInChain` = '12934' WHERE `entry` =12933; 

-- FallenAngelX
ALTER TABLE db_version_Infinity_Update CHANGE COLUMN r32 r33 bit;
REPLACE INTO `db_version_Infinity_Update` (`version`) VALUES ('r33');

UPDATE db_version SET `cache_id`= 'r33';
UPDATE db_version SET `version`= 'YTDB579_Infinity_Update_r33';