-- Quest 12996
UPDATE `creature_template` SET `spell1` = 54459,`spell2` = 54458,`spell3` = 54460,`VehicleId` = 208 WHERE  `creature_template`.`entry` = 29918;

-- Explosive decoy
UPDATE `creature_template` SET `ScriptName` = 'npc_explosive_decoy' WHERE `entry` = '29134';


-- FallenAngelX
ALTER TABLE db_version_Infinity_Update CHANGE COLUMN r18 r19 bit;
REPLACE INTO `db_version_Infinity_Update` (`version`) VALUES ('r19');

UPDATE db_version SET `cache_id`= 'r19';
UPDATE db_version SET `version`= 'YTDB578_Infinity_Update_r19';