UPDATE `creature_template`
SET `PowerType` = 3, `spell1` = 62225, `spell2` = 47480, `spell3` = 47481, `spell4` = 47482, `spell5` = 47484, `spell6` = 67866,
`ScriptName` = 'npc_risen_ally'
WHERE `entry` = 30230;

UPDATE `creature_template` SET `VehicleId` = 146 WHERE `entry` = 28875;

UPDATE `creature_template` SET
spell1 = 47938,
spell2 = 47921,
spell3 = 47966,
spell4 = 47939,
spell5 = 0,
spell6 = 0,
VehicleId = 55
WHERE `entry` IN (27061);

--- FallenAngelX
ALTER TABLE db_version_Infinity_Update CHANGE COLUMN r12 r13 bit;
REPLACE INTO `db_version_Infinity_Update` (`version`) VALUES ('r13');

UPDATE db_version SET `cache_id`= 'r13';
UPDATE db_version SET `version`= 'YTDB576_Infinity_Update_r13';